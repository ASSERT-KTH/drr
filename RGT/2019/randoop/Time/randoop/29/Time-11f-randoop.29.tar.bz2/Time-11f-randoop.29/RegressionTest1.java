import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', chronology3);
        org.joda.time.Period period6 = period4.minusMonths((int) '#');
        int int7 = period6.getHours();
        org.joda.time.Period period9 = period6.minusSeconds((int) '#');
        boolean boolean10 = period1.equals((java.lang.Object) period6);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period6.toDurationTo(readableInstant11);
        long long13 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration12);
        java.lang.Class<?> wildcardClass14 = duration12.getClass();
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration12);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-92015999903L) + "'", long13 == (-92015999903L));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-92015999903L) + "'", long15 == (-92015999903L));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.Period period1 = org.joda.time.Period.months((-25199800));
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        illegalFieldValueException4.prependMessage("200");
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("");
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalInstantException10);
        boolean boolean12 = period1.equals((java.lang.Object) illegalFieldValueException4);
        java.lang.Number number13 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(number13);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
//        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-28800000));
//        int int17 = offsetDateTimeField6.getLeapAmount((long) 9);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("-00:00:00.001", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (short) 100, '4', (int) (short) 100, 8, (-1), false, (-28800000));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder11.setStandardOffset(8);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = dateTimeZoneBuilder13.setStandardOffset(43);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = dateTimeZoneBuilder15.setFixedSavings("dayOfWeek", (-100));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder15);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder18);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("-00:00:00.001", true);
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("+00:00:00.035", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone0.getShortName((long) '#', locale5);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withMinutesRemoved();
        org.joda.time.PeriodType periodType3 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withDaysRemoved();
        boolean boolean6 = periodType4.equals((java.lang.Object) 132L);
        org.joda.time.Period period8 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', chronology10);
        org.joda.time.Period period13 = period11.minusMonths((int) '#');
        int int14 = period13.getHours();
        org.joda.time.Period period16 = period13.minusSeconds((int) '#');
        boolean boolean17 = period8.equals((java.lang.Object) period13);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period13.toDurationTo(readableInstant18);
        long long20 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration19);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period(readableDuration23, readableInstant24);
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType27 = periodType26.withWeeksRemoved();
        org.joda.time.PeriodType periodType28 = periodType26.withMinutesRemoved();
        org.joda.time.Period period29 = period25.withPeriodType(periodType26);
        org.joda.time.Period period30 = new org.joda.time.Period((long) (short) -1, periodType26);
        org.joda.time.Period period31 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration19, readableInstant21, periodType26);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Period period36 = new org.joda.time.Period(readableDuration34, readableInstant35);
        org.joda.time.PeriodType periodType37 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType38 = periodType37.withWeeksRemoved();
        org.joda.time.PeriodType periodType39 = periodType37.withMinutesRemoved();
        org.joda.time.Period period40 = period36.withPeriodType(periodType37);
        org.joda.time.Period period41 = new org.joda.time.Period((long) (short) -1, periodType37);
        org.joda.time.ReadableDuration readableDuration42 = null;
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.Period period44 = new org.joda.time.Period(readableDuration42, readableInstant43);
        org.joda.time.PeriodType periodType45 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType46 = periodType45.withWeeksRemoved();
        org.joda.time.PeriodType periodType47 = periodType45.withMinutesRemoved();
        org.joda.time.Period period48 = period44.withPeriodType(periodType45);
        org.joda.time.Period period49 = period41.withPeriodType(periodType45);
        org.joda.time.Period period50 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration19, readableInstant32, periodType45);
        org.joda.time.ReadableDuration readableDuration51 = null;
        org.joda.time.ReadableInstant readableInstant52 = null;
        org.joda.time.Period period53 = new org.joda.time.Period(readableDuration51, readableInstant52);
        org.joda.time.Chronology chronology56 = null;
        org.joda.time.Period period57 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology56);
        org.joda.time.Period period58 = period53.withFields((org.joda.time.ReadablePeriod) period57);
        org.joda.time.Period period59 = period57.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType61 = period57.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField62 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType61);
        org.joda.time.ReadableDuration readableDuration63 = null;
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.Period period65 = new org.joda.time.Period(readableDuration63, readableInstant64);
        org.joda.time.Chronology chronology68 = null;
        org.joda.time.Period period69 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology68);
        org.joda.time.Period period70 = period65.withFields((org.joda.time.ReadablePeriod) period69);
        org.joda.time.Period period71 = period69.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType73 = period69.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField74 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType73);
        int int75 = unsupportedDurationField62.compareTo((org.joda.time.DurationField) unsupportedDurationField74);
        org.joda.time.DurationFieldType durationFieldType76 = unsupportedDurationField62.getType();
        int int77 = period50.get(durationFieldType76);
        int int78 = periodType4.indexOf(durationFieldType76);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-92015999903L) + "'", long20 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(periodType46);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertNotNull(durationFieldType61);
        org.junit.Assert.assertNotNull(unsupportedDurationField62);
        org.junit.Assert.assertNotNull(period70);
        org.junit.Assert.assertNotNull(period71);
        org.junit.Assert.assertNotNull(durationFieldType73);
        org.junit.Assert.assertNotNull(unsupportedDurationField74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(durationFieldType76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        int int2 = periodType1.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
//        long long10 = offsetDateTimeField6.roundHalfFloor((long) (-100));
//        java.lang.String str12 = offsetDateTimeField6.getAsShortText((long) '#');
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField6.getAsText(readablePartial13, (int) '4', locale15);
//        java.util.Locale locale17 = null;
//        int int18 = offsetDateTimeField6.getMaximumTextLength(locale17);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "12" + "'", str12.equals("12"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.millisOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 4, (-92015999903L), (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("years", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"years/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset(20L);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology10.minuteOfDay();
        boolean boolean15 = cachedDateTimeZone7.equals((java.lang.Object) dateTimeField14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period18 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) 'a', chronology20);
        org.joda.time.Period period23 = period21.minusMonths((int) '#');
        int int24 = period23.getHours();
        org.joda.time.Period period26 = period23.minusSeconds((int) '#');
        boolean boolean27 = period18.equals((java.lang.Object) period23);
        int[] intArray29 = gregorianChronology16.get((org.joda.time.ReadablePeriod) period23, 0L);
        boolean boolean30 = cachedDateTimeZone7.equals((java.lang.Object) period23);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
//        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
//        long long15 = offsetDateTimeField6.roundHalfFloor((long) 9700);
//        long long18 = offsetDateTimeField6.add(345600000L, (long) 9700);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 838425600000L + "'", long18 == 838425600000L);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DurationField durationField8 = gregorianChronology3.weeks();
        org.joda.time.Period period10 = org.joda.time.Period.days((-1));
        int[] intArray13 = gregorianChronology3.get((org.joda.time.ReadablePeriod) period10, (long) 200, (long) (short) 0);
        org.joda.time.Period period14 = period10.toPeriod();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        int int8 = period6.getWeeks();
        org.joda.time.Period period10 = org.joda.time.Period.millis(10);
        boolean boolean11 = period6.equals((java.lang.Object) period10);
        int int12 = period10.getYears();
        org.joda.time.DurationFieldType[] durationFieldTypeArray13 = period10.getFieldTypes();
        java.lang.String str14 = period10.toString();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(durationFieldTypeArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0.010S" + "'", str14.equals("PT0.010S"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 'a', chronology2);
        org.joda.time.Period period4 = period3.normalizedStandard();
        org.joda.time.Period period6 = period4.minusMonths((int) (byte) -1);
        int int7 = period4.getYears();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period4.toDurationFrom(readableInstant8);
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9, periodType10);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration9);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology7);
        org.joda.time.Period period9 = period4.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period11 = period4.withMillis((int) (short) 100);
        org.joda.time.Period period12 = period1.withFields((org.joda.time.ReadablePeriod) period11);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableDuration13, readableInstant14);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology18);
        org.joda.time.Period period20 = period15.withFields((org.joda.time.ReadablePeriod) period19);
        org.joda.time.Period period21 = period19.normalizedStandard();
        org.joda.time.Period period23 = period19.plusYears((-100));
        org.joda.time.DurationFieldType durationFieldType25 = period19.getFieldType((int) (short) 0);
        int int26 = period11.indexOf(durationFieldType25);
        org.joda.time.Seconds seconds27 = period11.toStandardSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(seconds27);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(20L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DurationField durationField8 = gregorianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.Chronology chronology10 = gregorianChronology3.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology10);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
//        org.joda.time.Period period4 = period2.minusMonths((int) '#');
//        org.joda.time.Period period6 = period2.withYears(0);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration8, readableInstant9);
//        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.seconds();
//        org.joda.time.PeriodType periodType12 = periodType11.withWeeksRemoved();
//        org.joda.time.PeriodType periodType13 = periodType11.withMinutesRemoved();
//        org.joda.time.Period period14 = period10.withPeriodType(periodType11);
//        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) -1, periodType11);
//        org.joda.time.PeriodType periodType16 = periodType11.withMinutesRemoved();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.secondOfMinute();
//        int int19 = gregorianChronology17.getMinimumDaysInFirstWeek();
//        int int20 = gregorianChronology17.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField21 = gregorianChronology17.weeks();
//        org.joda.time.DurationField durationField22 = gregorianChronology17.hours();
//        java.lang.String str23 = gregorianChronology17.toString();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology17.weekOfWeekyear();
//        try {
//            org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period6, periodType16, (org.joda.time.Chronology) gregorianChronology17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'millis'");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(period4);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(periodType11);
//        org.junit.Assert.assertNotNull(periodType12);
//        org.junit.Assert.assertNotNull(periodType13);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str23.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(dateTimeField24);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 100, (int) 'a', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period3 = period2.normalizedStandard();
        org.joda.time.Period period5 = period3.minusMonths((int) (byte) -1);
        int int6 = period3.getYears();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationFrom(readableInstant7);
        long long9 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.Period period1 = org.joda.time.Period.millis(10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray2 = period1.getFieldTypes();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.forFields(durationFieldTypeArray2);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(durationFieldTypeArray2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        boolean boolean12 = unsupportedDurationField11.isSupported();
        java.lang.String str13 = unsupportedDurationField11.getName();
        try {
            long long16 = unsupportedDurationField11.add(133L, (long) 43);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "years" + "'", str13.equals("years"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.Period period5 = org.joda.time.Period.months((int) (short) 1);
        org.joda.time.Period period6 = period5.normalizedStandard();
        org.joda.time.Period period8 = period5.plusMonths((int) '#');
        long long11 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period8, (long) (-28800000), (int) (short) -1);
        org.joda.time.DurationField durationField12 = gregorianChronology0.months();
        long long16 = gregorianChronology0.add((long) (-28800000), (-368200799611L), (int) (short) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-94723200000L) + "'", long11 == (-94723200000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-36820108761100L) + "'", long16 == (-36820108761100L));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        java.lang.String str25 = unsupportedDurationField23.getName();
        try {
            long long28 = unsupportedDurationField23.getMillis((-92015999893L), 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "years" + "'", str25.equals("years"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str7 = illegalFieldValueException2.getFieldName();
        java.lang.String str8 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number9 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) '4');
        org.joda.time.Period period3 = period1.withYears((int) (short) 10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[America/Los_Angeles]", "", (int) '#', 100);
        long long6 = fixedDateTimeZone4.nextTransition(100L);
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone4.getName((-92015999903L), locale8);
        int int11 = fixedDateTimeZone4.getOffset((-36000000L));
        java.lang.String str13 = fixedDateTimeZone4.getNameKey((-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.035" + "'", str9.equals("+00:00:00.035"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 10, (-25199800), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.minusYears((int) (byte) 0);
        org.joda.time.Period period11 = period2.plusHours((int) (byte) -1);
        org.joda.time.Period period13 = period11.withMinutes(4);
        org.joda.time.Period period14 = period11.normalizedStandard();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
//        long long10 = offsetDateTimeField6.roundHalfFloor((long) (-100));
//        long long12 = offsetDateTimeField6.roundCeiling(28800132L);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.Period period17 = new org.joda.time.Period(readableDuration15, readableInstant16);
//        int int18 = period17.getMinutes();
//        int int19 = period17.size();
//        org.joda.time.Period period21 = org.joda.time.Period.seconds(43);
//        org.joda.time.Period period22 = period17.minus((org.joda.time.ReadablePeriod) period21);
//        int[] intArray23 = period21.getValues();
//        try {
//            int[] intArray25 = offsetDateTimeField6.addWrapField(readablePartial13, 9, intArray23, (-25199800));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 86400001L + "'", long12 == 86400001L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 8 + "'", int19 == 8);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertNotNull(period22);
//        org.junit.Assert.assertNotNull(intArray23);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
//        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
//        java.lang.String str6 = gregorianChronology0.toString();
//        org.joda.time.Period period8 = org.joda.time.Period.weeks((-1));
//        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period8, (long) 'a', (long) 10);
//        java.lang.String str12 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.millisOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str12.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period2.toDurationFrom(readableInstant10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period21 = period14.withMillis((int) (short) 100);
        org.joda.time.Period period23 = period21.withDays((int) 'a');
        int int24 = period21.size();
        org.joda.time.Period period25 = period2.minus((org.joda.time.ReadablePeriod) period21);
        int int26 = period21.getMinutes();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.Period period4 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', chronology6);
        org.joda.time.Period period9 = period7.minusMonths((int) '#');
        int int10 = period9.getHours();
        org.joda.time.Period period12 = period9.minusSeconds((int) '#');
        boolean boolean13 = period4.equals((java.lang.Object) period9);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period9.toDurationTo(readableInstant14);
        long long16 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableDuration19, readableInstant20);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType23 = periodType22.withWeeksRemoved();
        org.joda.time.PeriodType periodType24 = periodType22.withMinutesRemoved();
        org.joda.time.Period period25 = period21.withPeriodType(periodType22);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) -1, periodType22);
        org.joda.time.Period period27 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration15, readableInstant17, periodType22);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType22, chronology28);
        org.joda.time.PeriodType periodType30 = periodType22.withDaysRemoved();
        try {
            org.joda.time.Period period31 = new org.joda.time.Period((java.lang.Object) 8553600010L, periodType30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-92015999903L) + "'", long16 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(periodType30);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.field.FieldUtils.verifyValueBounds("11", 4, (-100), 9700);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
//        org.joda.time.DurationField durationField11 = offsetDateTimeField6.getDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
//        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
//        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
//        java.util.Locale locale21 = null;
//        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField24 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType23);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, (long) 200);
        int[] intArray3 = period2.getValues();
        org.joda.time.Period period5 = period2.withMillis((int) (byte) -1);
        org.joda.time.Period period7 = period2.withMinutes(99);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
//        long long10 = offsetDateTimeField6.roundHalfFloor((long) (-100));
//        long long12 = offsetDateTimeField6.roundCeiling(28800132L);
//        long long14 = offsetDateTimeField6.roundCeiling(132L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 86400001L + "'", long12 == 86400001L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 86400001L + "'", long14 == 86400001L);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfHour();
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale13 = null;
        java.lang.String str14 = dateTimeZone11.getName(99L, locale13);
        org.joda.time.ReadableInstant readableInstant15 = null;
        int int16 = dateTimeZone11.getOffset(readableInstant15);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        int int19 = dateTimeZone11.getOffsetFromLocal(10L);
        long long21 = dateTimeZone9.getMillisKeepLocal(dateTimeZone11, (-368326799612L));
        org.joda.time.Chronology chronology22 = gregorianChronology0.withZone(dateTimeZone9);
        org.joda.time.ReadablePartial readablePartial23 = null;
        try {
            long long25 = gregorianChronology0.set(readablePartial23, (long) (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-00:00:00.001" + "'", str14.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-368200799611L) + "'", long21 == (-368200799611L));
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.Chronology chronology10 = iSOChronology6.withZone(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.dayOfWeek();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) 'a', chronology14);
        org.joda.time.Period period17 = period15.minusMonths((int) '#');
        org.joda.time.Period period19 = period17.minusMillis(10);
        org.joda.time.Period period21 = period19.plusMonths(0);
        org.joda.time.Period period22 = period19.normalizedStandard();
        int[] intArray25 = iSOChronology11.get((org.joda.time.ReadablePeriod) period22, (long) 200, 132L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(133L, (-25199800));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3351573400L) + "'", long2 == (-3351573400L));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) -1, 43);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-43) + "'", int2 == (-43));
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
//        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
//        org.joda.time.Chronology chronology10 = iSOChronology6.withZone(dateTimeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.yearOfCentury();
//        java.lang.String str15 = iSOChronology11.toString();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology11.minuteOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[-00:00:00.001]" + "'", str15.equals("ISOChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.centuryOfEra();
        long long10 = gregorianChronology0.add(25200020L, 259200002L, (int) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25945200220L + "'", long10 == 25945200220L);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
//        int int12 = offsetDateTimeField6.getLeapAmount(28800132L);
//        int int14 = offsetDateTimeField6.getMaximumValue(28800132L);
//        java.util.Locale locale15 = null;
//        int int16 = offsetDateTimeField6.getMaximumShortTextLength(locale15);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField6.getAsText(readablePartial17, (int) (byte) 10, locale19);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("12", (int) (byte) 0, 0, (-25199800));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for 12 must be in the range [0,-25199800]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName((long) 4, locale3);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "", "");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (Seconds)", "years");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "8", "PT0.097S");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[America/Los_Angeles]", "", (int) '#', 100);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        long long7 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone5, (long) 'a');
//        java.lang.String str9 = fixedDateTimeZone4.getNameKey((long) '4');
//        int int11 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
//        java.util.TimeZone timeZone12 = fixedDateTimeZone4.toTimeZone();
//        boolean boolean13 = fixedDateTimeZone4.isFixed();
//        org.joda.time.IllegalInstantException illegalInstantException16 = new org.joda.time.IllegalInstantException((long) 0, "Seconds");
//        org.joda.time.IllegalInstantException illegalInstantException19 = new org.joda.time.IllegalInstantException((long) 0, "Seconds");
//        illegalInstantException16.addSuppressed((java.lang.Throwable) illegalInstantException19);
//        boolean boolean21 = fixedDateTimeZone4.equals((java.lang.Object) illegalInstantException16);
//        int int23 = fixedDateTimeZone4.getOffsetFromLocal(8553600010L);
//        java.lang.String str25 = fixedDateTimeZone4.getNameKey((-368326799612L));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 133L + "'", long7 == 133L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 35 + "'", int23 == 35);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
//        java.lang.String str2 = gregorianChronology0.toString();
//        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str2.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = dateTimeZone1.getOffsetFromLocal(10L);
        java.util.TimeZone timeZone10 = dateTimeZone1.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        int int4 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.hourOfDay();
        org.joda.time.DurationField durationField7 = gregorianChronology1.weekyears();
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', (org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 8);
//        long long9 = offsetDateTimeField7.remainder((long) (byte) 1);
//        java.util.Locale locale10 = null;
//        int int11 = offsetDateTimeField7.getMaximumShortTextLength(locale10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField7.getType();
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Period period12 = org.joda.time.Period.days((-1));
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.Period period15 = new org.joda.time.Period((long) 'a', chronology14);
//        org.joda.time.Period period17 = period15.minusMonths((int) '#');
//        int int18 = period17.getHours();
//        org.joda.time.Period period20 = period17.minusSeconds((int) '#');
//        boolean boolean21 = period12.equals((java.lang.Object) period17);
//        int[] intArray23 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period17, 0L);
//        int int24 = offsetDateTimeField6.getMinimumValue(readablePartial9, intArray23);
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = offsetDateTimeField6.getAsText(readablePartial25, 0, locale27);
//        long long31 = offsetDateTimeField6.add(0L, (long) (-25199800));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(period20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(intArray23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-2177262720000000L) + "'", long31 == (-2177262720000000L));
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) 'a');
        org.joda.time.Period period5 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', chronology7);
        org.joda.time.Period period10 = period8.minusMonths((int) '#');
        int int11 = period10.getHours();
        org.joda.time.Period period13 = period10.minusSeconds((int) '#');
        boolean boolean14 = period5.equals((java.lang.Object) period10);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period10.toDurationTo(readableInstant15);
        long long17 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType24 = periodType23.withWeeksRemoved();
        org.joda.time.PeriodType periodType25 = periodType23.withMinutesRemoved();
        org.joda.time.Period period26 = period22.withPeriodType(periodType23);
        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.Period period28 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant18, periodType23);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType23, chronology29);
        org.joda.time.Period period34 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.Period period37 = new org.joda.time.Period((long) 'a', chronology36);
        org.joda.time.Period period39 = period37.minusMonths((int) '#');
        int int40 = period39.getHours();
        org.joda.time.Period period42 = period39.minusSeconds((int) '#');
        boolean boolean43 = period34.equals((java.lang.Object) period39);
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.Duration duration45 = period39.toDurationTo(readableInstant44);
        long long46 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration45);
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.ReadableDuration readableDuration49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Period period51 = new org.joda.time.Period(readableDuration49, readableInstant50);
        org.joda.time.PeriodType periodType52 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType53 = periodType52.withWeeksRemoved();
        org.joda.time.PeriodType periodType54 = periodType52.withMinutesRemoved();
        org.joda.time.Period period55 = period51.withPeriodType(periodType52);
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) -1, periodType52);
        org.joda.time.Period period57 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration45, readableInstant47, periodType52);
        org.joda.time.Chronology chronology58 = null;
        org.joda.time.Period period59 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType52, chronology58);
        java.lang.String str60 = periodType52.getName();
        org.joda.time.ReadableDuration readableDuration61 = null;
        org.joda.time.ReadableInstant readableInstant62 = null;
        org.joda.time.Period period63 = new org.joda.time.Period(readableDuration61, readableInstant62);
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.Period period67 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology66);
        org.joda.time.Period period68 = period63.withFields((org.joda.time.ReadablePeriod) period67);
        org.joda.time.Period period69 = period67.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType71 = period67.getFieldType(0);
        int int72 = periodType52.indexOf(durationFieldType71);
        int int73 = periodType23.indexOf(durationFieldType71);
        org.joda.time.Period period74 = period1.normalizedStandard(periodType23);
        int int75 = period1.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-92015999903L) + "'", long17 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(duration45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-92015999903L) + "'", long46 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Seconds" + "'", str60.equals("Seconds"));
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(period69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 8 + "'", int75 == 8);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale3 = null;
        java.lang.String str6 = defaultNameProvider0.getName(locale3, "dayOfWeek", "100");
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period7.minusHours((int) 'a');
        org.joda.time.Period period11 = period9.plusYears(0);
        org.joda.time.Period period13 = period11.withMinutes((int) '4');
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(10L, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number7 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(8, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-8) + "'", int2 == (-8));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset((long) 'a');
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        org.joda.time.ReadableInterval readableInterval12 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        boolean boolean13 = cachedDateTimeZone7.equals((java.lang.Object) readableInterval10);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        int int16 = cachedDateTimeZone7.getOffset((long) (byte) 100);
        java.lang.String str18 = cachedDateTimeZone7.getNameKey(838425600000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(readableInterval11);
        org.junit.Assert.assertNotNull(readableInterval12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
        long long13 = offsetDateTimeField6.add((long) 2, 99);
        java.lang.String str15 = offsetDateTimeField6.getAsShortText((-368326799612L));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, 99);
        int int18 = offsetDateTimeField6.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8553600002L + "'", long13 == 8553600002L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "11" + "'", str15.equals("11"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsText((long) (-1), locale10);
        long long14 = offsetDateTimeField6.add((long) (byte) 1, 2);
        boolean boolean16 = offsetDateTimeField6.isLeap((-2520000000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 172800001L + "'", long14 == 172800001L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.remainder((long) (byte) 1);
        long long10 = offsetDateTimeField6.remainder(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 86399999L + "'", long10 == 86399999L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str7 = illegalFieldValueException2.getFieldName();
        java.lang.Number number8 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.Number number9 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField7 = iSOChronology6.seconds();
        org.joda.time.DurationField durationField8 = iSOChronology6.halfdays();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone10.getName(99L, locale12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        int int15 = dateTimeZone10.getOffset(readableInstant14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        int int18 = cachedDateTimeZone16.getStandardOffset((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone16.getUncachedZone();
        boolean boolean20 = iSOChronology6.equals((java.lang.Object) cachedDateTimeZone16);
        org.joda.time.Period period22 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period(readableDuration23, readableInstant24);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology28);
        org.joda.time.Period period30 = period25.withFields((org.joda.time.ReadablePeriod) period29);
        org.joda.time.Period period32 = period25.withMillis((int) (short) 100);
        org.joda.time.Period period33 = period22.withFields((org.joda.time.ReadablePeriod) period32);
        org.joda.time.Period period35 = period22.plusSeconds(10);
        org.joda.time.Period period37 = period22.minusHours((int) ' ');
        org.joda.time.Period period39 = period37.minusHours((-28800000));
        boolean boolean40 = iSOChronology6.equals((java.lang.Object) period39);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-00:00:00.001" + "'", str13.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period2 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) '#');
        int int8 = period7.getHours();
        org.joda.time.Period period10 = period7.minusSeconds((int) '#');
        boolean boolean11 = period2.equals((java.lang.Object) period7);
        int[] intArray13 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.secondOfMinute();
        int int16 = gregorianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.millisOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology14.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology14.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology25);
        org.joda.time.Period period27 = period22.withFields((org.joda.time.ReadablePeriod) period26);
        org.joda.time.Period period29 = period22.withMillis((int) (short) 100);
        org.joda.time.Period period31 = period29.withDays((int) 'a');
        int int32 = period29.size();
        org.joda.time.Period period34 = period29.plusYears((int) (short) -1);
        int[] intArray37 = gregorianChronology14.get((org.joda.time.ReadablePeriod) period29, (long) 'a', (long) 'a');
        org.joda.time.Period period39 = period29.minusMonths((-1));
        org.joda.time.Period period40 = period7.plus((org.joda.time.ReadablePeriod) period29);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 8 + "'", int32 == 8);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period40);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField7 = iSOChronology6.seconds();
        org.joda.time.DurationField durationField8 = iSOChronology6.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.millisOfDay();
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.Chronology chronology13 = lenientChronology10.withZone(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("(\"org.joda.time.JodaTimePermission\" \"12\")", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-28800000));
        long long17 = offsetDateTimeField6.roundHalfFloor(0L);
        int int19 = offsetDateTimeField6.getLeapAmount(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.Period period11 = period9.withDays((int) 'a');
        org.joda.time.Period period13 = period11.minusMonths(0);
        org.joda.time.Period period15 = period13.withYears(15);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        int int2 = periodType1.size();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "GregorianChronology[America/Los_Angeles]", 0, (int) (short) 100);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long9 = fixedDateTimeZone4.convertLocalToUTC(172800001L, true, (-92015999903L));
        org.joda.time.LocalDateTime localDateTime10 = null;
        boolean boolean11 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime10);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 172800001L + "'", long9 == 172800001L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfDay();
        java.lang.Object obj3 = null;
        boolean boolean4 = iSOChronology1.equals(obj3);
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Period period7 = period5.plusHours(100);
        org.joda.time.Period period9 = org.joda.time.Period.hours((-1));
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableDuration10, readableInstant11);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology15);
        org.joda.time.Period period17 = period12.withFields((org.joda.time.ReadablePeriod) period16);
        org.joda.time.Period period18 = period16.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType20 = period16.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableDuration22, readableInstant23);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology27);
        org.joda.time.Period period29 = period24.withFields((org.joda.time.ReadablePeriod) period28);
        org.joda.time.Period period30 = period28.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType32 = period28.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField33 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType32);
        int int34 = unsupportedDurationField21.compareTo((org.joda.time.DurationField) unsupportedDurationField33);
        org.joda.time.DurationFieldType durationFieldType35 = unsupportedDurationField21.getType();
        org.joda.time.Period period37 = period9.withFieldAdded(durationFieldType35, 100);
        boolean boolean38 = period5.isSupported(durationFieldType35);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(unsupportedDurationField33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(durationFieldType35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey((long) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException2.getSuppressed();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number11 = illegalFieldValueException10.getIllegalNumberValue();
        java.lang.String str12 = illegalFieldValueException10.getFieldName();
        java.lang.String str13 = illegalFieldValueException10.getIllegalValueAsString();
        java.lang.String str14 = illegalFieldValueException10.getIllegalValueAsString();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period5 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', chronology7);
        org.joda.time.Period period10 = period8.minusMonths((int) '#');
        int int11 = period10.getHours();
        org.joda.time.Period period13 = period10.minusSeconds((int) '#');
        boolean boolean14 = period5.equals((java.lang.Object) period10);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period10.toDurationTo(readableInstant15);
        long long17 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType24 = periodType23.withWeeksRemoved();
        org.joda.time.PeriodType periodType25 = periodType23.withMinutesRemoved();
        org.joda.time.Period period26 = period22.withPeriodType(periodType23);
        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.Period period28 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant18, periodType23);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType23, chronology29);
        java.lang.String str31 = periodType23.getName();
        org.joda.time.PeriodType periodType32 = periodType23.withMillisRemoved();
        org.joda.time.Period period33 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType23);
        org.joda.time.PeriodType periodType34 = periodType23.withMillisRemoved();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-92015999903L) + "'", long17 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Seconds" + "'", str31.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(periodType34);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfEra();
        org.joda.time.ReadablePartial readablePartial2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration3, readableInstant4);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology8);
        org.joda.time.Period period10 = period5.withFields((org.joda.time.ReadablePeriod) period9);
        org.joda.time.Period period12 = period5.minusYears((int) (byte) 0);
        org.joda.time.Period period14 = period5.plusHours((int) (byte) -1);
        org.joda.time.Period period16 = period14.withMinutes(4);
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray18 = period16.getValues();
        try {
            gregorianChronology0.validate(readablePartial2, intArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException2.getSuppressed();
        java.lang.String str8 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.Period period5 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', chronology7);
        org.joda.time.Period period10 = period8.minusMonths((int) '#');
        int int11 = period10.getHours();
        org.joda.time.Period period13 = period10.minusSeconds((int) '#');
        boolean boolean14 = period5.equals((java.lang.Object) period10);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period10.toDurationTo(readableInstant15);
        long long17 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType24 = periodType23.withWeeksRemoved();
        org.joda.time.PeriodType periodType25 = periodType23.withMinutesRemoved();
        org.joda.time.Period period26 = period22.withPeriodType(periodType23);
        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.Period period28 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant18, periodType23);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType23, chronology29);
        org.joda.time.PeriodType periodType31 = periodType23.withDaysRemoved();
        try {
            org.joda.time.Period period32 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-92015999903L) + "'", long17 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType31);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.yearOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField10 = gregorianChronology9.weekyears();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology9.getZone();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone11);
        try {
            long long21 = zonedChronology13.getDateTimeMillis((int) (byte) 100, 0, 9700, (int) (byte) 100, 100, 8, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int7 = offsetDateTimeField6.getOffset();
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField6.getAsText((int) ' ', locale9);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32" + "'", str10.equals("32"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType2 = periodType1.withWeeksRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withMinutesRemoved();
        org.joda.time.PeriodType periodType4 = periodType1.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withDaysRemoved();
        org.joda.time.PeriodType periodType6 = periodType4.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.secondOfMinute();
        int int9 = gregorianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology7.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology7.getZone();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (-25199800), periodType6, (org.joda.time.Chronology) gregorianChronology7);
        try {
            long long20 = gregorianChronology7.getDateTimeMillis(0, 2, (int) (byte) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,29]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.Period period2 = period0.withMinutes(15);
        org.junit.Assert.assertNotNull(period2);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        org.joda.time.Period period6 = period4.minusMillis(10);
        org.joda.time.Period period8 = period6.plusMonths(0);
        org.joda.time.Period period9 = period6.normalizedStandard();
        java.lang.String str10 = period6.toString();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-35MT0.087S" + "'", str10.equals("P-35MT0.087S"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsText((long) (-1), locale10);
        boolean boolean13 = offsetDateTimeField6.isLeap((long) ' ');
        boolean boolean14 = offsetDateTimeField6.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        java.util.TimeZone timeZone4 = dateTimeZone1.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("UnsupportedDurationField[years]");
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long9 = cachedDateTimeZone7.nextTransition((-28799996L));
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        long long13 = dateTimeZone10.convertLocalToUTC((long) (-28800000), false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28799996L) + "'", long9 == (-28799996L));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-28799999L) + "'", long13 == (-28799999L));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        org.joda.time.Period period6 = period4.minusMillis(10);
        org.joda.time.Period period8 = period6.minusMinutes((-8));
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNull(dateTimeFieldType6);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(132L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 132L + "'", long2 == 132L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withMinutesRemoved();
        org.joda.time.PeriodType periodType5 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withDaysRemoved();
        org.joda.time.PeriodType periodType7 = periodType5.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfMinute();
        int int10 = gregorianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.millisOfDay();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology8.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology8.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology8.getZone();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (-25199800), periodType7, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.Period period17 = new org.joda.time.Period(86400000L, periodType7);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.remainder((long) (byte) 1);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumShortTextLength(locale9);
        org.joda.time.DurationField durationField11 = offsetDateTimeField6.getRangeDurationField();
        int int13 = offsetDateTimeField6.getMinimumValue(3L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period3 = period2.normalizedStandard();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration4, readableInstant5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType8 = periodType7.withWeeksRemoved();
        org.joda.time.PeriodType periodType9 = periodType7.withMinutesRemoved();
        org.joda.time.Period period10 = period6.withPeriodType(periodType7);
        org.joda.time.Period period11 = period2.withFields((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period12 = period10.negated();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.remainder((long) (byte) 1);
        java.lang.String str9 = offsetDateTimeField6.getName();
        int int11 = offsetDateTimeField6.getMinimumValue(86400000L);
        int int13 = offsetDateTimeField6.getMinimumValue(0L);
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period18 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) 'a', chronology20);
        org.joda.time.Period period23 = period21.minusMonths((int) '#');
        int int24 = period23.getHours();
        org.joda.time.Period period26 = period23.minusSeconds((int) '#');
        boolean boolean27 = period18.equals((java.lang.Object) period23);
        int[] intArray29 = gregorianChronology16.get((org.joda.time.ReadablePeriod) period23, 0L);
        org.joda.time.DurationField durationField30 = gregorianChronology16.eras();
        org.joda.time.Period period32 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period((long) 'a', chronology34);
        org.joda.time.Period period37 = period35.minusMonths((int) '#');
        int int38 = period37.getHours();
        org.joda.time.Period period40 = period37.minusSeconds((int) '#');
        boolean boolean41 = period32.equals((java.lang.Object) period37);
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.Duration duration43 = period37.toDurationTo(readableInstant42);
        long long44 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration43);
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.ReadableDuration readableDuration47 = null;
        org.joda.time.ReadableInstant readableInstant48 = null;
        org.joda.time.Period period49 = new org.joda.time.Period(readableDuration47, readableInstant48);
        org.joda.time.PeriodType periodType50 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType51 = periodType50.withWeeksRemoved();
        org.joda.time.PeriodType periodType52 = periodType50.withMinutesRemoved();
        org.joda.time.Period period53 = period49.withPeriodType(periodType50);
        org.joda.time.Period period54 = new org.joda.time.Period((long) (short) -1, periodType50);
        org.joda.time.Period period55 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration43, readableInstant45, periodType50);
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.ReadableDuration readableDuration58 = null;
        org.joda.time.ReadableInstant readableInstant59 = null;
        org.joda.time.Period period60 = new org.joda.time.Period(readableDuration58, readableInstant59);
        org.joda.time.PeriodType periodType61 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType62 = periodType61.withWeeksRemoved();
        org.joda.time.PeriodType periodType63 = periodType61.withMinutesRemoved();
        org.joda.time.Period period64 = period60.withPeriodType(periodType61);
        org.joda.time.Period period65 = new org.joda.time.Period((long) (short) -1, periodType61);
        org.joda.time.ReadableDuration readableDuration66 = null;
        org.joda.time.ReadableInstant readableInstant67 = null;
        org.joda.time.Period period68 = new org.joda.time.Period(readableDuration66, readableInstant67);
        org.joda.time.PeriodType periodType69 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType70 = periodType69.withWeeksRemoved();
        org.joda.time.PeriodType periodType71 = periodType69.withMinutesRemoved();
        org.joda.time.Period period72 = period68.withPeriodType(periodType69);
        org.joda.time.Period period73 = period65.withPeriodType(periodType69);
        org.joda.time.Period period74 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration43, readableInstant56, periodType69);
        int[] intArray77 = gregorianChronology16.get((org.joda.time.ReadablePeriod) period74, 11L, 10L);
        int[] intArray79 = offsetDateTimeField6.add(readablePartial14, 10, intArray77, 0);
        boolean boolean80 = offsetDateTimeField6.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "dayOfWeek" + "'", str9.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(duration43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-92015999903L) + "'", long44 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType50);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(periodType61);
        org.junit.Assert.assertNotNull(periodType62);
        org.junit.Assert.assertNotNull(periodType63);
        org.junit.Assert.assertNotNull(period64);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(periodType70);
        org.junit.Assert.assertNotNull(periodType71);
        org.junit.Assert.assertNotNull(period72);
        org.junit.Assert.assertNotNull(period73);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology7);
        org.joda.time.Period period9 = period4.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period11 = period4.withMillis((int) (short) 100);
        org.joda.time.Period period12 = period1.withFields((org.joda.time.ReadablePeriod) period11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period12.toDurationTo(readableInstant13);
        org.joda.time.Period period16 = period12.minusHours(100);
        boolean boolean18 = period16.equals((java.lang.Object) ' ');
        org.joda.time.Period period20 = period16.plusYears((-1));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(period20);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        java.lang.String str6 = gregorianChronology0.toString();
        org.joda.time.Period period8 = org.joda.time.Period.weeks((-1));
        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period8, (long) 'a', (long) 10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField13 = gregorianChronology0.months();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        long long10 = offsetDateTimeField6.roundHalfFloor((long) (-100));
        java.lang.String str12 = offsetDateTimeField6.getAsShortText((long) '#');
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField6.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
        int int17 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.millisOfDay();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology15.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 8);
        long long23 = offsetDateTimeField21.remainder((long) (byte) 1);
        java.util.Locale locale24 = null;
        int int25 = offsetDateTimeField21.getMaximumShortTextLength(locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField21.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType26, (int) (byte) 10);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType26, (-8), (int) '4', (-25199800));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -8 for dayOfWeek must be in the range [52,-25199800]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "12" + "'", str12.equals("12"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-28800000));
        long long17 = offsetDateTimeField15.roundHalfEven(86400000L);
        boolean boolean18 = offsetDateTimeField15.isSupported();
        long long21 = offsetDateTimeField15.add((long) (-10), (-10));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86400001L + "'", long17 == 86400001L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-864000010L) + "'", long21 == (-864000010L));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.PeriodType periodType14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
        int int17 = gregorianChronology15.getMinimumDaysInFirstWeek();
        int int18 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.Period period19 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType14, (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.DurationField durationField20 = gregorianChronology15.weeks();
        int int21 = unsupportedDurationField11.compareTo(durationField20);
        try {
            long long24 = unsupportedDurationField11.getValueAsLong((long) (byte) 10, (long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        java.lang.String str11 = cachedDateTimeZone7.getNameKey((long) (-1));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis((int) (short) 1, (-25200000), 99, (-25199800));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25199800 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 1, (int) (short) 1, (int) (byte) -1, 200);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.secondOfMinute();
        int int6 = gregorianChronology4.getMinimumDaysInFirstWeek();
        int int7 = gregorianChronology4.getMinimumDaysInFirstWeek();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType3, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology4.weekyearOfCentury();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 9, (org.joda.time.Chronology) gregorianChronology4);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
        boolean boolean13 = offsetDateTimeField6.isLeap((long) (byte) 10);
        int int15 = offsetDateTimeField6.getLeapAmount((long) (-43));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number6 = illegalFieldValueException2.getLowerBound();
        java.lang.Number number7 = illegalFieldValueException2.getUpperBound();
        illegalFieldValueException2.prependMessage("PeriodType[Seconds]");
        java.lang.Throwable[] throwableArray10 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.Period period3 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', chronology5);
        org.joda.time.Period period8 = period6.minusMonths((int) '#');
        int int9 = period8.getHours();
        org.joda.time.Period period11 = period8.minusSeconds((int) '#');
        boolean boolean12 = period3.equals((java.lang.Object) period8);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period8.toDurationTo(readableInstant13);
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withWeeksRemoved();
        org.joda.time.PeriodType periodType23 = periodType21.withMinutesRemoved();
        org.joda.time.Period period24 = period20.withPeriodType(periodType21);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) -1, periodType21);
        org.joda.time.Period period26 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant16, periodType21);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType21, chronology27);
        org.joda.time.Period period32 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period((long) 'a', chronology34);
        org.joda.time.Period period37 = period35.minusMonths((int) '#');
        int int38 = period37.getHours();
        org.joda.time.Period period40 = period37.minusSeconds((int) '#');
        boolean boolean41 = period32.equals((java.lang.Object) period37);
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.Duration duration43 = period37.toDurationTo(readableInstant42);
        long long44 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration43);
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.ReadableDuration readableDuration47 = null;
        org.joda.time.ReadableInstant readableInstant48 = null;
        org.joda.time.Period period49 = new org.joda.time.Period(readableDuration47, readableInstant48);
        org.joda.time.PeriodType periodType50 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType51 = periodType50.withWeeksRemoved();
        org.joda.time.PeriodType periodType52 = periodType50.withMinutesRemoved();
        org.joda.time.Period period53 = period49.withPeriodType(periodType50);
        org.joda.time.Period period54 = new org.joda.time.Period((long) (short) -1, periodType50);
        org.joda.time.Period period55 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration43, readableInstant45, periodType50);
        org.joda.time.Chronology chronology56 = null;
        org.joda.time.Period period57 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType50, chronology56);
        java.lang.String str58 = periodType50.getName();
        org.joda.time.ReadableDuration readableDuration59 = null;
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.Period period61 = new org.joda.time.Period(readableDuration59, readableInstant60);
        org.joda.time.Chronology chronology64 = null;
        org.joda.time.Period period65 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology64);
        org.joda.time.Period period66 = period61.withFields((org.joda.time.ReadablePeriod) period65);
        org.joda.time.Period period67 = period65.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType69 = period65.getFieldType(0);
        int int70 = periodType50.indexOf(durationFieldType69);
        int int71 = periodType21.indexOf(durationFieldType69);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField72 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType69);
        try {
            long long75 = unsupportedDurationField72.add((-3351573400L), (-36820108761100L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-92015999903L) + "'", long15 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(duration43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-92015999903L) + "'", long44 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType50);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Seconds" + "'", str58.equals("Seconds"));
        org.junit.Assert.assertNotNull(period66);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(durationFieldType69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField72);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("PeriodType[Seconds]");
        java.lang.String str2 = illegalInstantException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.joda.time.IllegalInstantException: PeriodType[Seconds]" + "'", str2.equals("org.joda.time.IllegalInstantException: PeriodType[Seconds]"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period3 = period2.normalizedStandard();
        org.joda.time.Period period5 = period3.minusMonths((int) (byte) -1);
        int int6 = period3.getYears();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationFrom(readableInstant7);
        org.joda.time.Hours hours9 = period3.toStandardHours();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(hours9);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.Period period10 = period8.withMillis(8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        java.lang.String str6 = gregorianChronology0.toString();
        org.joda.time.Period period8 = org.joda.time.Period.weeks((-1));
        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period8, (long) 'a', (long) 10);
        java.lang.String str12 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.secondOfDay();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableDuration15, readableInstant16);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology20);
        org.joda.time.Period period22 = period17.withFields((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period24 = period17.withMillis((int) (short) 100);
        org.joda.time.Period period26 = period24.plusWeeks((int) (byte) 100);
        long long29 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period24, 0L, (-25200000));
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str12.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-2520000000L) + "'", long29 == (-2520000000L));
        org.junit.Assert.assertNotNull(dateTimeField30);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
        int int12 = offsetDateTimeField6.getMinimumValue();
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField6.getAsText((long) 10, locale14);
        int int17 = offsetDateTimeField6.get(86400001L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "12" + "'", str15.equals("12"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 13 + "'", int17 == 13);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "GregorianChronology[America/Los_Angeles]", 0, (int) (short) 100);
        long long6 = fixedDateTimeZone4.previousTransition(11L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 11L + "'", long6 == 11L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("-00:00:00.001", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (short) 100, '4', (int) (short) 100, 8, (-1), false, (-28800000));
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addCutover(0, 'a', (int) '4', (-25200000), (int) (short) 1, false, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType4 = periodType3.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withMinutesRemoved();
        org.joda.time.Period period6 = period2.withPeriodType(periodType3);
        java.lang.String str7 = period2.toString();
        int int8 = period2.getMonths();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology14);
        org.joda.time.Period period16 = period11.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period17 = period15.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType19 = period15.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType19);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period(readableDuration21, readableInstant22);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology26);
        org.joda.time.Period period28 = period23.withFields((org.joda.time.ReadablePeriod) period27);
        org.joda.time.Period period29 = period27.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType31 = period27.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField32 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType31);
        int int33 = unsupportedDurationField20.compareTo((org.joda.time.DurationField) unsupportedDurationField32);
        org.joda.time.DurationFieldType durationFieldType34 = unsupportedDurationField20.getType();
        org.joda.time.Period period36 = period2.withFieldAdded(durationFieldType34, (-25200000));
        org.joda.time.PeriodType periodType38 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology39.secondOfMinute();
        int int41 = gregorianChronology39.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology39.monthOfYear();
        org.joda.time.Period period43 = new org.joda.time.Period((-36000000L), periodType38, (org.joda.time.Chronology) gregorianChronology39);
        boolean boolean44 = period2.equals((java.lang.Object) gregorianChronology39);
        try {
            long long52 = gregorianChronology39.getDateTimeMillis(10, (-43), (-8), (int) (byte) 100, 200, (int) (byte) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0S" + "'", str7.equals("PT0S"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertNotNull(unsupportedDurationField32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.minusYears((int) (byte) 0);
        org.joda.time.Period period11 = period2.plusHours((int) (byte) -1);
        org.joda.time.Period period13 = period11.plusYears(0);
        org.joda.time.Period period15 = period11.minusMonths((int) (byte) 10);
        org.joda.time.Period period17 = period15.multipliedBy((int) (byte) 100);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) '4');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (short) 0);
        boolean boolean9 = dateTimeZone5.isStandardOffset(1L);
        java.lang.String str11 = dateTimeZone5.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
        java.lang.Object obj13 = null;
        boolean boolean14 = zonedChronology12.equals(obj13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getName(99L, locale18);
        org.joda.time.ReadableInstant readableInstant20 = null;
        int int21 = dateTimeZone16.getOffset(readableInstant20);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        int int24 = cachedDateTimeZone22.getStandardOffset(20L);
        boolean boolean25 = cachedDateTimeZone22.isFixed();
        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period(readableDuration27, readableInstant28);
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology32);
        org.joda.time.Period period34 = period29.withFields((org.joda.time.ReadablePeriod) period33);
        org.joda.time.Period period36 = period29.withMillis((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.Duration duration38 = period29.toDurationFrom(readableInstant37);
        int[] intArray40 = zonedChronology12.get((org.joda.time.ReadablePeriod) period29, 36000100L);
        java.lang.String str41 = zonedChronology12.toString();
        java.lang.String str42 = zonedChronology12.toString();
        org.joda.time.Chronology chronology43 = zonedChronology12.withUTC();
        try {
            long long49 = zonedChronology12.getDateTimeMillis((long) 10, 2, (-100), (int) (byte) 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(duration38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ZonedChronology[GregorianChronology[UTC], -00:00:00.001]" + "'", str41.equals("ZonedChronology[GregorianChronology[UTC], -00:00:00.001]"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "ZonedChronology[GregorianChronology[UTC], -00:00:00.001]" + "'", str42.equals("ZonedChronology[GregorianChronology[UTC], -00:00:00.001]"));
        org.junit.Assert.assertNotNull(chronology43);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int7 = offsetDateTimeField6.getOffset();
        org.joda.time.DurationField durationField8 = offsetDateTimeField6.getRangeDurationField();
        long long11 = offsetDateTimeField6.add(86400000L, 3L);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField6.getAsText((int) '4', locale13);
        int int16 = offsetDateTimeField6.getLeapAmount((-2520000000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 345600000L + "'", long11 == 345600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "52" + "'", str14.equals("52"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period2 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) '#');
        int int8 = period7.getHours();
        org.joda.time.Period period10 = period7.minusSeconds((int) '#');
        boolean boolean11 = period2.equals((java.lang.Object) period7);
        int[] intArray13 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        org.joda.time.DurationField durationField14 = gregorianChronology0.eras();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType16 = periodType15.withHoursRemoved();
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableDuration17, readableInstant18);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology22);
        org.joda.time.Period period24 = period19.withFields((org.joda.time.ReadablePeriod) period23);
        org.joda.time.Period period25 = period23.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType27 = period23.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        org.joda.time.ReadableDuration readableDuration29 = null;
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period(readableDuration29, readableInstant30);
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology34);
        org.joda.time.Period period36 = period31.withFields((org.joda.time.ReadablePeriod) period35);
        org.joda.time.Period period37 = period35.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType39 = period35.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField40 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType39);
        int int41 = unsupportedDurationField28.compareTo((org.joda.time.DurationField) unsupportedDurationField40);
        org.joda.time.DurationFieldType durationFieldType42 = unsupportedDurationField28.getType();
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField43 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType42);
        boolean boolean44 = periodType15.isSupported(durationFieldType42);
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField45 = new org.joda.time.field.DecoratedDurationField(durationField14, durationFieldType42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(unsupportedDurationField40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(durationFieldType42);
        org.junit.Assert.assertNotNull(unsupportedDurationField43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset((long) 'a');
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        org.joda.time.ReadableInterval readableInterval12 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        boolean boolean13 = cachedDateTimeZone7.equals((java.lang.Object) readableInterval10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.secondOfMinute();
        int int16 = gregorianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.millisOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology14.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology14.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology14.minuteOfHour();
        org.joda.time.DurationField durationField21 = gregorianChronology14.weekyears();
        boolean boolean22 = cachedDateTimeZone7.equals((java.lang.Object) durationField21);
        long long24 = cachedDateTimeZone7.previousTransition((long) (-8));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(readableInterval11);
        org.junit.Assert.assertNotNull(readableInterval12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-8L) + "'", long24 == (-8L));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-2L), (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2L) + "'", long2 == (-2L));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.remainder((long) (byte) 1);
        boolean boolean10 = offsetDateTimeField6.isLeap(0L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableDuration13, readableInstant14);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology18);
        org.joda.time.Period period20 = period15.withFields((org.joda.time.ReadablePeriod) period19);
        int int21 = period19.getWeeks();
        org.joda.time.Period period23 = org.joda.time.Period.millis(10);
        boolean boolean24 = period19.equals((java.lang.Object) period23);
        int int25 = period23.getYears();
        org.joda.time.DurationFieldType[] durationFieldTypeArray26 = period23.getFieldTypes();
        int[] intArray27 = period23.getValues();
        java.util.Locale locale29 = null;
        try {
            int[] intArray30 = offsetDateTimeField6.set(readablePartial11, 53, intArray27, "PeriodType[Seconds]", locale29);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PeriodType[Seconds]\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(durationFieldTypeArray26);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DurationField durationField5 = gregorianChronology0.years();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.secondOfMinute();
        int int6 = gregorianChronology4.getMinimumDaysInFirstWeek();
        int int7 = gregorianChronology4.getMinimumDaysInFirstWeek();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType3, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.Chronology chronology11 = gregorianChronology4.withZone(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology4.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.secondOfMinute();
        int int15 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology13.millisOfDay();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology13.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 8);
        long long21 = offsetDateTimeField19.remainder((long) (byte) 1);
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField19.getMaximumShortTextLength(locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField19.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField26 = new org.joda.time.field.RemainderDateTimeField(dateTimeField12, dateTimeFieldType24, 99);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withMinutesRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.PeriodType periodType6 = periodType2.withWeeksRemoved();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableDuration7, readableInstant8);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology12);
        org.joda.time.Period period14 = period9.withFields((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period16 = period9.withMillis((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Duration duration18 = period9.toDurationFrom(readableInstant17);
        org.joda.time.Period period19 = period9.normalizedStandard();
        org.joda.time.Period period21 = org.joda.time.Period.hours((-1));
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableDuration22, readableInstant23);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology27);
        org.joda.time.Period period29 = period24.withFields((org.joda.time.ReadablePeriod) period28);
        org.joda.time.Period period30 = period28.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType32 = period28.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField33 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType32);
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Period period36 = new org.joda.time.Period(readableDuration34, readableInstant35);
        org.joda.time.Chronology chronology39 = null;
        org.joda.time.Period period40 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology39);
        org.joda.time.Period period41 = period36.withFields((org.joda.time.ReadablePeriod) period40);
        org.joda.time.Period period42 = period40.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType44 = period40.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField45 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType44);
        int int46 = unsupportedDurationField33.compareTo((org.joda.time.DurationField) unsupportedDurationField45);
        org.joda.time.DurationFieldType durationFieldType47 = unsupportedDurationField33.getType();
        org.joda.time.Period period49 = period21.withFieldAdded(durationFieldType47, 100);
        org.joda.time.Period period51 = period19.withFieldAdded(durationFieldType47, 100);
        int int52 = periodType6.indexOf(durationFieldType47);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(unsupportedDurationField33);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(durationFieldType44);
        org.junit.Assert.assertNotNull(unsupportedDurationField45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(durationFieldType47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period2.normalizedStandard();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.Period period4 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', chronology6);
        org.joda.time.Period period9 = period7.minusMonths((int) '#');
        int int10 = period9.getHours();
        org.joda.time.Period period12 = period9.minusSeconds((int) '#');
        boolean boolean13 = period4.equals((java.lang.Object) period9);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period9.toDurationTo(readableInstant14);
        long long16 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableDuration19, readableInstant20);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType23 = periodType22.withWeeksRemoved();
        org.joda.time.PeriodType periodType24 = periodType22.withMinutesRemoved();
        org.joda.time.Period period25 = period21.withPeriodType(periodType22);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) -1, periodType22);
        org.joda.time.Period period27 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration15, readableInstant17, periodType22);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType22, chronology28);
        org.joda.time.PeriodType periodType30 = periodType22.withDaysRemoved();
        java.lang.Object obj31 = null;
        boolean boolean32 = periodType22.equals(obj31);
        org.joda.time.PeriodType periodType33 = periodType22.withYearsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period35 = new org.joda.time.Period(0L, periodType22, (org.joda.time.Chronology) gregorianChronology34);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-92015999903L) + "'", long16 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField7 = iSOChronology6.seconds();
        org.joda.time.DurationField durationField8 = iSOChronology6.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.millisOfDay();
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology16);
        org.joda.time.Period period18 = period13.withFields((org.joda.time.ReadablePeriod) period17);
        int int19 = period17.getWeeks();
        org.joda.time.Period period21 = period17.withHours(4);
        int int22 = period17.getDays();
        int[] intArray24 = lenientChronology10.get((org.joda.time.ReadablePeriod) period17, (-92015999893L));
        java.lang.String str25 = lenientChronology10.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "LenientChronology[ISOChronology[-00:00:00.001]]" + "'", str25.equals("LenientChronology[ISOChronology[-00:00:00.001]]"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        long long27 = remainderDateTimeField25.roundHalfFloor((long) 0);
        int int29 = remainderDateTimeField25.get(86400000L);
        long long31 = remainderDateTimeField25.roundHalfFloor((long) 53);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 53 + "'", int29 == 53);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration6, readableInstant7);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology11);
        org.joda.time.Period period13 = period8.withFields((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period15 = period8.withMillis((int) (short) 100);
        org.joda.time.Period period17 = period15.withDays((int) 'a');
        int int18 = period15.size();
        org.joda.time.Period period20 = period15.plusYears((int) (short) -1);
        int[] intArray23 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period15, (long) 'a', (long) 'a');
        org.joda.time.DurationField durationField24 = gregorianChronology0.months();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType4 = periodType3.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withMinutesRemoved();
        org.joda.time.Period period6 = period2.withPeriodType(periodType3);
        java.lang.String str7 = period2.toString();
        org.joda.time.Period period9 = period2.minusMonths(0);
        int int10 = period2.getHours();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0S" + "'", str7.equals("PT0S"));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfHour();
        org.joda.time.Period period8 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology14);
        org.joda.time.Period period16 = period11.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period18 = period11.withMillis((int) (short) 100);
        org.joda.time.Period period19 = period8.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period19.toDurationTo(readableInstant20);
        org.joda.time.Period period23 = period19.minusHours(100);
        org.joda.time.Period period25 = period19.plusYears(0);
        long long28 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period19, (long) (-10), 35);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 3490L + "'", long28 == 3490L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("Seconds");
        java.lang.Throwable[] throwableArray2 = illegalInstantException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration6, readableInstant7);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology11);
        org.joda.time.Period period13 = period8.withFields((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period15 = period8.withMillis((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period8.toDurationFrom(readableInstant16);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology23);
        org.joda.time.Period period25 = period20.withFields((org.joda.time.ReadablePeriod) period24);
        org.joda.time.Period period27 = period20.withMillis((int) (short) 100);
        org.joda.time.Period period29 = period27.withDays((int) 'a');
        int int30 = period27.size();
        org.joda.time.Period period31 = period8.minus((org.joda.time.ReadablePeriod) period27);
        long long34 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period8, (long) (short) 1, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeUtils.getZone(dateTimeZone35);
        boolean boolean38 = dateTimeZone36.isStandardOffset((long) (short) 0);
        boolean boolean40 = dateTimeZone36.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
        org.joda.time.DurationField durationField42 = iSOChronology41.seconds();
        org.joda.time.DurationField durationField43 = iSOChronology41.halfdays();
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale47 = null;
        java.lang.String str48 = dateTimeZone45.getName(99L, locale47);
        org.joda.time.ReadableInstant readableInstant49 = null;
        int int50 = dateTimeZone45.getOffset(readableInstant49);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone51 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone45);
        int int53 = cachedDateTimeZone51.getStandardOffset((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone54 = cachedDateTimeZone51.getUncachedZone();
        boolean boolean55 = iSOChronology41.equals((java.lang.Object) cachedDateTimeZone51);
        org.joda.time.DurationField durationField56 = iSOChronology41.months();
        org.joda.time.Chronology chronology57 = iSOChronology41.withUTC();
        boolean boolean58 = gregorianChronology0.equals((java.lang.Object) chronology57);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "-00:00:00.001" + "'", str48.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("200", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"200/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("-00:00:00.001", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (short) 100, '4', (int) (short) 100, 8, (-1), false, (-28800000));
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder11.addCutover(100, ' ', (-25199800), 10, (int) '#', false, 43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.Period period7 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) 'a', chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) '#');
        int int13 = period12.getHours();
        org.joda.time.Period period15 = period12.minusSeconds((int) '#');
        boolean boolean16 = period7.equals((java.lang.Object) period12);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Duration duration18 = period12.toDurationTo(readableInstant17);
        long long19 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration18);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableDuration22, readableInstant23);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType26 = periodType25.withWeeksRemoved();
        org.joda.time.PeriodType periodType27 = periodType25.withMinutesRemoved();
        org.joda.time.Period period28 = period24.withPeriodType(periodType25);
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) -1, periodType25);
        org.joda.time.Period period30 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration18, readableInstant20, periodType25);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType25, chronology31);
        org.joda.time.Period period36 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.Period period39 = new org.joda.time.Period((long) 'a', chronology38);
        org.joda.time.Period period41 = period39.minusMonths((int) '#');
        int int42 = period41.getHours();
        org.joda.time.Period period44 = period41.minusSeconds((int) '#');
        boolean boolean45 = period36.equals((java.lang.Object) period41);
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Duration duration47 = period41.toDurationTo(readableInstant46);
        long long48 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration47);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableDuration readableDuration51 = null;
        org.joda.time.ReadableInstant readableInstant52 = null;
        org.joda.time.Period period53 = new org.joda.time.Period(readableDuration51, readableInstant52);
        org.joda.time.PeriodType periodType54 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType55 = periodType54.withWeeksRemoved();
        org.joda.time.PeriodType periodType56 = periodType54.withMinutesRemoved();
        org.joda.time.Period period57 = period53.withPeriodType(periodType54);
        org.joda.time.Period period58 = new org.joda.time.Period((long) (short) -1, periodType54);
        org.joda.time.Period period59 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration47, readableInstant49, periodType54);
        org.joda.time.Chronology chronology60 = null;
        org.joda.time.Period period61 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType54, chronology60);
        java.lang.String str62 = periodType54.getName();
        org.joda.time.ReadableDuration readableDuration63 = null;
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.Period period65 = new org.joda.time.Period(readableDuration63, readableInstant64);
        org.joda.time.Chronology chronology68 = null;
        org.joda.time.Period period69 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology68);
        org.joda.time.Period period70 = period65.withFields((org.joda.time.ReadablePeriod) period69);
        org.joda.time.Period period71 = period69.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType73 = period69.getFieldType(0);
        int int74 = periodType54.indexOf(durationFieldType73);
        int int75 = periodType25.indexOf(durationFieldType73);
        org.joda.time.PeriodType periodType76 = periodType25.withHoursRemoved();
        org.joda.time.Period period77 = new org.joda.time.Period(1L, (long) 'a', periodType25);
        org.joda.time.Period period78 = new org.joda.time.Period((-368200799611L), (long) 15, periodType25);
        org.joda.time.PeriodType periodType79 = periodType25.withMillisRemoved();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-92015999903L) + "'", long19 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(duration47);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-92015999903L) + "'", long48 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType56);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Seconds" + "'", str62.equals("Seconds"));
        org.junit.Assert.assertNotNull(period70);
        org.junit.Assert.assertNotNull(period71);
        org.junit.Assert.assertNotNull(durationFieldType73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(periodType76);
        org.junit.Assert.assertNotNull(periodType79);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(15);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-15) + "'", int1 == (-15));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.minuteOfHour();
        org.joda.time.Chronology chronology8 = gregorianChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period10 = new org.joda.time.Period(20L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Chronology chronology11 = gregorianChronology1.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        long long10 = offsetDateTimeField6.roundHalfFloor((long) (-100));
        java.lang.String str12 = offsetDateTimeField6.getAsShortText((long) '#');
        int int13 = offsetDateTimeField6.getMaximumValue();
        long long15 = offsetDateTimeField6.roundCeiling(0L);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = offsetDateTimeField6.getAsShortText(readablePartial16, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "12" + "'", str12.equals("12"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField7 = iSOChronology6.seconds();
        org.joda.time.DurationField durationField8 = iSOChronology6.halfdays();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone10.getName(99L, locale12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        int int15 = dateTimeZone10.getOffset(readableInstant14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        int int18 = cachedDateTimeZone16.getStandardOffset((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone16.getUncachedZone();
        boolean boolean20 = iSOChronology6.equals((java.lang.Object) cachedDateTimeZone16);
        int int22 = cachedDateTimeZone16.getOffset(100L);
        java.lang.String str24 = cachedDateTimeZone16.getNameKey(22184013326400000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-00:00:00.001" + "'", str13.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[America/Los_Angeles]", "", (int) '#', 100);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        long long7 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone5, (long) 'a');
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 43");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 133L + "'", long7 == 133L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology7);
        org.joda.time.Period period9 = period4.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period11 = period4.withMillis((int) (short) 100);
        org.joda.time.Period period12 = period1.withFields((org.joda.time.ReadablePeriod) period11);
        org.joda.time.Minutes minutes13 = period11.toStandardMinutes();
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, (long) 200);
        int[] intArray18 = period17.getValues();
        boolean boolean19 = period11.equals((java.lang.Object) period17);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        org.joda.time.Period period3 = period1.plusHours((int) (byte) 100);
        org.joda.time.Period period5 = period3.plusHours(8);
        org.joda.time.Period period7 = period5.plusSeconds(35);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.weekyears();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
        org.joda.time.DurationField durationField12 = iSOChronology6.halfdays();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("GregorianChronology[-00:00:00.001]");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("12");
        jodaTimePermission3.checkGuard((java.lang.Object) (short) -1);
        java.security.PermissionCollection permissionCollection6 = jodaTimePermission3.newPermissionCollection();
        boolean boolean7 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.String str8 = jodaTimePermission1.toString();
        org.joda.time.JodaTimePermission jodaTimePermission10 = new org.joda.time.JodaTimePermission("GregorianChronology[-00:00:00.001]");
        org.joda.time.JodaTimePermission jodaTimePermission12 = new org.joda.time.JodaTimePermission("12");
        jodaTimePermission12.checkGuard((java.lang.Object) (short) -1);
        java.security.PermissionCollection permissionCollection15 = jodaTimePermission12.newPermissionCollection();
        boolean boolean16 = jodaTimePermission10.implies((java.security.Permission) jodaTimePermission12);
        java.lang.String str17 = jodaTimePermission10.toString();
        boolean boolean18 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission10);
        org.junit.Assert.assertNotNull(permissionCollection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"GregorianChronology[-00:00:00.001]\")" + "'", str8.equals("(\"org.joda.time.JodaTimePermission\" \"GregorianChronology[-00:00:00.001]\")"));
        org.junit.Assert.assertNotNull(permissionCollection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"GregorianChronology[-00:00:00.001]\")" + "'", str17.equals("(\"org.joda.time.JodaTimePermission\" \"GregorianChronology[-00:00:00.001]\")"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-8), (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-8) + "'", int2 == (-8));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.Period period3 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', chronology5);
        org.joda.time.Period period8 = period6.minusMonths((int) '#');
        int int9 = period8.getHours();
        org.joda.time.Period period11 = period8.minusSeconds((int) '#');
        boolean boolean12 = period3.equals((java.lang.Object) period8);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period8.toDurationTo(readableInstant13);
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withWeeksRemoved();
        org.joda.time.PeriodType periodType23 = periodType21.withMinutesRemoved();
        org.joda.time.Period period24 = period20.withPeriodType(periodType21);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) -1, periodType21);
        org.joda.time.Period period26 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant16, periodType21);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType21, chronology27);
        java.lang.String str29 = periodType21.getName();
        org.joda.time.PeriodType periodType30 = periodType21.withMonthsRemoved();
        org.joda.time.PeriodType periodType31 = periodType21.withSecondsRemoved();
        org.joda.time.PeriodType periodType32 = periodType21.withMillisRemoved();
        org.joda.time.PeriodType periodType33 = periodType21.withMinutesRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType35 = periodType33.getFieldType(15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-92015999903L) + "'", long15 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Seconds" + "'", str29.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(periodType33);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        boolean boolean6 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsText((long) (-1), locale10);
        long long14 = offsetDateTimeField6.addWrapField(172800001L, 2);
        int int15 = offsetDateTimeField6.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259199999L) + "'", long14 == (-259199999L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int7 = cachedDateTimeZone5.getOffset((-36000000L));
        int int9 = cachedDateTimeZone5.getOffsetFromLocal((-210866760000000L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        long long26 = unsupportedDurationField11.getUnitMillis();
        boolean boolean27 = unsupportedDurationField11.isPrecise();
        long long28 = unsupportedDurationField11.getUnitMillis();
        try {
            long long31 = unsupportedDurationField11.subtract((long) (-8), 9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.remainder((long) (byte) 1);
        java.lang.String str9 = offsetDateTimeField6.getName();
        int int11 = offsetDateTimeField6.getMinimumValue(86400000L);
        int int13 = offsetDateTimeField6.getMinimumValue(0L);
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period18 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) 'a', chronology20);
        org.joda.time.Period period23 = period21.minusMonths((int) '#');
        int int24 = period23.getHours();
        org.joda.time.Period period26 = period23.minusSeconds((int) '#');
        boolean boolean27 = period18.equals((java.lang.Object) period23);
        int[] intArray29 = gregorianChronology16.get((org.joda.time.ReadablePeriod) period23, 0L);
        org.joda.time.DurationField durationField30 = gregorianChronology16.eras();
        org.joda.time.Period period32 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period((long) 'a', chronology34);
        org.joda.time.Period period37 = period35.minusMonths((int) '#');
        int int38 = period37.getHours();
        org.joda.time.Period period40 = period37.minusSeconds((int) '#');
        boolean boolean41 = period32.equals((java.lang.Object) period37);
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.Duration duration43 = period37.toDurationTo(readableInstant42);
        long long44 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration43);
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.ReadableDuration readableDuration47 = null;
        org.joda.time.ReadableInstant readableInstant48 = null;
        org.joda.time.Period period49 = new org.joda.time.Period(readableDuration47, readableInstant48);
        org.joda.time.PeriodType periodType50 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType51 = periodType50.withWeeksRemoved();
        org.joda.time.PeriodType periodType52 = periodType50.withMinutesRemoved();
        org.joda.time.Period period53 = period49.withPeriodType(periodType50);
        org.joda.time.Period period54 = new org.joda.time.Period((long) (short) -1, periodType50);
        org.joda.time.Period period55 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration43, readableInstant45, periodType50);
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.ReadableDuration readableDuration58 = null;
        org.joda.time.ReadableInstant readableInstant59 = null;
        org.joda.time.Period period60 = new org.joda.time.Period(readableDuration58, readableInstant59);
        org.joda.time.PeriodType periodType61 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType62 = periodType61.withWeeksRemoved();
        org.joda.time.PeriodType periodType63 = periodType61.withMinutesRemoved();
        org.joda.time.Period period64 = period60.withPeriodType(periodType61);
        org.joda.time.Period period65 = new org.joda.time.Period((long) (short) -1, periodType61);
        org.joda.time.ReadableDuration readableDuration66 = null;
        org.joda.time.ReadableInstant readableInstant67 = null;
        org.joda.time.Period period68 = new org.joda.time.Period(readableDuration66, readableInstant67);
        org.joda.time.PeriodType periodType69 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType70 = periodType69.withWeeksRemoved();
        org.joda.time.PeriodType periodType71 = periodType69.withMinutesRemoved();
        org.joda.time.Period period72 = period68.withPeriodType(periodType69);
        org.joda.time.Period period73 = period65.withPeriodType(periodType69);
        org.joda.time.Period period74 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration43, readableInstant56, periodType69);
        int[] intArray77 = gregorianChronology16.get((org.joda.time.ReadablePeriod) period74, 11L, 10L);
        int[] intArray79 = offsetDateTimeField6.add(readablePartial14, 10, intArray77, 0);
        long long82 = offsetDateTimeField6.addWrapField((long) (byte) 1, (int) (byte) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "dayOfWeek" + "'", str9.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(duration43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-92015999903L) + "'", long44 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType50);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(periodType61);
        org.junit.Assert.assertNotNull(periodType62);
        org.junit.Assert.assertNotNull(periodType63);
        org.junit.Assert.assertNotNull(period64);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(periodType70);
        org.junit.Assert.assertNotNull(periodType71);
        org.junit.Assert.assertNotNull(period72);
        org.junit.Assert.assertNotNull(period73);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 86400001L + "'", long82 == 86400001L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 172800001L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        int int3 = period2.getMinutes();
        int int4 = period2.size();
        org.joda.time.Period period6 = org.joda.time.Period.seconds(43);
        org.joda.time.Period period7 = period2.minus((org.joda.time.ReadablePeriod) period6);
        org.joda.time.DurationFieldType[] durationFieldTypeArray8 = period7.getFieldTypes();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(durationFieldTypeArray8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-28800000));
        boolean boolean16 = offsetDateTimeField15.isLenient();
        int int19 = offsetDateTimeField15.getDifference(3024000001L, (-94723200000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1131 + "'", int19 == 1131);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        org.joda.time.PeriodType periodType6 = periodType4.withMinutesRemoved();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        org.joda.time.PeriodType periodType8 = periodType4.withWeeksRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType8);
        int int10 = periodType8.size();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-1));
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.addCutover(2, '4', (int) '4', 35, (int) (byte) 100, false, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.remainder((long) (byte) 1);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumShortTextLength(locale9);
        org.joda.time.DurationField durationField11 = offsetDateTimeField6.getRangeDurationField();
        long long14 = offsetDateTimeField6.add((-2177262720000000L), (long) (short) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2177254080000000L) + "'", long14 == (-2177254080000000L));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.Period period4 = new org.joda.time.Period((-43), 8, 100, 8);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        java.lang.String str25 = unsupportedDurationField23.getName();
        org.joda.time.DurationFieldType durationFieldType26 = unsupportedDurationField23.getType();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "years" + "'", str25.equals("years"));
        org.junit.Assert.assertNotNull(durationFieldType26);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        int int8 = period6.getWeeks();
        org.joda.time.Period period10 = period6.withHours(4);
        int int11 = period6.getDays();
        org.joda.time.Period period13 = period6.minusMinutes((int) (byte) 1);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        int int7 = dateTimeZone1.getOffsetFromLocal(36000100L);
        int int9 = dateTimeZone1.getOffsetFromLocal((-210863044800000L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        long long13 = cachedDateTimeZone10.adjustOffset(22184013326400000L, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 22184013326400000L + "'", long13 == 22184013326400000L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.Period period9 = period7.plusYears(0);
        org.joda.time.Period period11 = period9.minusDays(43);
        org.joda.time.Period period12 = period9.negated();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType14 = periodType13.withWeeksRemoved();
        org.joda.time.PeriodType periodType15 = periodType13.withMinutesRemoved();
        org.joda.time.PeriodType periodType16 = periodType13.withWeeksRemoved();
        org.joda.time.PeriodType periodType17 = periodType16.withMillisRemoved();
        try {
            org.joda.time.Period period18 = period9.withPeriodType(periodType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'millis'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        long long26 = unsupportedDurationField11.getUnitMillis();
        try {
            long long29 = unsupportedDurationField11.getMillis((int) (short) 1, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField11.getType();
        java.lang.String str13 = unsupportedDurationField11.getName();
        long long14 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableDuration15, readableInstant16);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology20);
        org.joda.time.Period period22 = period17.withFields((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period23 = period21.normalizedStandard();
        org.joda.time.Period period25 = period21.plusYears((-100));
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(durationFieldType27, "hi!");
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField30 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) unsupportedDurationField11, durationFieldType27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "years" + "'", str13.equals("years"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText(200, locale10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField6.getAsShortText((long) (byte) 1, locale13);
        long long16 = offsetDateTimeField6.roundHalfCeiling(172800001L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "200" + "'", str11.equals("200"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "12" + "'", str14.equals("12"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 172800001L + "'", long16 == 172800001L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(15);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-28800000));
        long long17 = offsetDateTimeField15.roundHalfEven(86400000L);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int int19 = offsetDateTimeField15.getMaximumValue(readablePartial18);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86400001L + "'", long17 == 86400001L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28799985) + "'", int19 == (-28799985));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.Period period5 = org.joda.time.Period.months((int) (short) 1);
        org.joda.time.Period period6 = period5.normalizedStandard();
        org.joda.time.Period period8 = period5.plusMonths((int) '#');
        long long11 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period8, (long) (-28800000), (int) (short) -1);
        org.joda.time.Period period13 = org.joda.time.Period.hours((-1));
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period(readableDuration14, readableInstant15);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology19);
        org.joda.time.Period period21 = period16.withFields((org.joda.time.ReadablePeriod) period20);
        org.joda.time.Period period22 = period20.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType24 = period20.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType24);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableDuration26, readableInstant27);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.Period period32 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology31);
        org.joda.time.Period period33 = period28.withFields((org.joda.time.ReadablePeriod) period32);
        org.joda.time.Period period34 = period32.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType36 = period32.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField37 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
        int int38 = unsupportedDurationField25.compareTo((org.joda.time.DurationField) unsupportedDurationField37);
        org.joda.time.DurationFieldType durationFieldType39 = unsupportedDurationField25.getType();
        org.joda.time.Period period41 = period13.withFieldAdded(durationFieldType39, 100);
        org.joda.time.Period period43 = period8.withFieldAdded(durationFieldType39, 9700);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-94723200000L) + "'", long11 == (-94723200000L));
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(durationFieldType36);
        org.junit.Assert.assertNotNull(unsupportedDurationField37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period43);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        long long27 = remainderDateTimeField25.roundHalfFloor((long) 0);
        long long29 = remainderDateTimeField25.remainder(25945200220L);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 219L + "'", long29 == 219L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        org.joda.time.PeriodType periodType6 = periodType4.withMinutesRemoved();
        org.joda.time.Period period7 = period3.withPeriodType(periodType4);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) -1, periodType4);
        int int9 = periodType4.size();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField7 = iSOChronology6.seconds();
        org.joda.time.DurationField durationField8 = iSOChronology6.halfdays();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone10.getName(99L, locale12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        int int15 = dateTimeZone10.getOffset(readableInstant14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        int int18 = cachedDateTimeZone16.getStandardOffset((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone16.getUncachedZone();
        boolean boolean20 = iSOChronology6.equals((java.lang.Object) cachedDateTimeZone16);
        long long22 = cachedDateTimeZone16.nextTransition((long) (short) 1);
        java.util.TimeZone timeZone23 = cachedDateTimeZone16.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-00:00:00.001" + "'", str13.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(timeZone23);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.Period period4 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', chronology6);
        org.joda.time.Period period9 = period7.minusMonths((int) '#');
        int int10 = period9.getHours();
        org.joda.time.Period period12 = period9.minusSeconds((int) '#');
        boolean boolean13 = period4.equals((java.lang.Object) period9);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period9.toDurationTo(readableInstant14);
        long long16 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableDuration19, readableInstant20);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType23 = periodType22.withWeeksRemoved();
        org.joda.time.PeriodType periodType24 = periodType22.withMinutesRemoved();
        org.joda.time.Period period25 = period21.withPeriodType(periodType22);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) -1, periodType22);
        org.joda.time.Period period27 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration15, readableInstant17, periodType22);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType22, chronology28);
        java.lang.String str30 = periodType22.getName();
        org.joda.time.PeriodType periodType31 = periodType22.withMillisRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period33 = new org.joda.time.Period((long) 8, periodType22, (org.joda.time.Chronology) gregorianChronology32);
        org.joda.time.PeriodType periodType34 = periodType22.withDaysRemoved();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-92015999903L) + "'", long16 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Seconds" + "'", str30.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(periodType34);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        long long10 = offsetDateTimeField6.roundHalfFloor((long) (-100));
        java.lang.String str12 = offsetDateTimeField6.getAsShortText((long) '#');
        int int13 = offsetDateTimeField6.getMaximumValue();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, 99);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "12" + "'", str12.equals("12"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        java.lang.String str6 = gregorianChronology0.toString();
        org.joda.time.Period period8 = org.joda.time.Period.weeks((-1));
        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period8, (long) 'a', (long) 10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology0.getZone();
        java.util.Locale locale15 = null;
        java.lang.String str16 = dateTimeZone13.getShortName((long) (-10), locale15);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-00:00:00.001" + "'", str16.equals("-00:00:00.001"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfDay();
        java.lang.Object obj3 = null;
        boolean boolean4 = iSOChronology1.equals(obj3);
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Period period7 = period5.plusHours(100);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfMinute();
        int int10 = gregorianChronology8.getMinimumDaysInFirstWeek();
        int int11 = gregorianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField12 = gregorianChronology8.weeks();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology8.yearOfEra();
        org.joda.time.DurationField durationField14 = gregorianChronology8.weeks();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.secondOfMinute();
        org.joda.time.Period period18 = new org.joda.time.Period(0L, (org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableDuration19, readableInstant20);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology24);
        org.joda.time.Period period26 = period21.withFields((org.joda.time.ReadablePeriod) period25);
        org.joda.time.Period period28 = period21.withMillis((int) (short) 100);
        org.joda.time.Period period30 = period28.withDays((int) 'a');
        int int31 = period28.size();
        org.joda.time.Period period33 = period28.plusYears((int) (short) -1);
        org.joda.time.Period period34 = period18.plus((org.joda.time.ReadablePeriod) period33);
        boolean boolean35 = gregorianChronology8.equals((java.lang.Object) period33);
        try {
            org.joda.time.Period period36 = new org.joda.time.Period((java.lang.Object) 100, (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 8 + "'", int31 == 8);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[America/Los_Angeles]", "", (int) '#', 100);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        long long7 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone5, (long) 'a');
        java.lang.String str9 = fixedDateTimeZone4.getNameKey((long) '4');
        int int11 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.util.TimeZone timeZone12 = fixedDateTimeZone4.toTimeZone();
        boolean boolean13 = fixedDateTimeZone4.isFixed();
        org.joda.time.IllegalInstantException illegalInstantException16 = new org.joda.time.IllegalInstantException((long) 0, "Seconds");
        org.joda.time.IllegalInstantException illegalInstantException19 = new org.joda.time.IllegalInstantException((long) 0, "Seconds");
        illegalInstantException16.addSuppressed((java.lang.Throwable) illegalInstantException19);
        boolean boolean21 = fixedDateTimeZone4.equals((java.lang.Object) illegalInstantException16);
        java.lang.String str22 = fixedDateTimeZone4.getID();
        int int24 = fixedDateTimeZone4.getOffset(99L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 133L + "'", long7 == 133L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str22.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 35 + "'", int24 == 35);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        long long27 = remainderDateTimeField25.roundHalfFloor((long) 0);
        int int29 = remainderDateTimeField25.get(86400000L);
        int int30 = remainderDateTimeField25.getMaximumValue();
        org.joda.time.DurationField durationField31 = remainderDateTimeField25.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 53 + "'", int29 == 53);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 98 + "'", int30 == 98);
        org.junit.Assert.assertNotNull(durationField31);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("-00:00:00.001", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("", (int) (byte) 0, (int) (short) 0, (-25200000), '#', (int) (byte) 10, (-100), (int) (byte) 10, false, 43);
        java.io.OutputStream outputStream16 = null;
        try {
            dateTimeZoneBuilder14.writeTo("0", outputStream16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset((long) 'a');
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        org.joda.time.ReadableInterval readableInterval12 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        boolean boolean13 = cachedDateTimeZone7.equals((java.lang.Object) readableInterval10);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        int int16 = cachedDateTimeZone7.getOffset((long) (byte) 100);
        long long19 = cachedDateTimeZone7.convertLocalToUTC(259200001L, true);
        long long21 = cachedDateTimeZone7.convertUTCToLocal((long) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(readableInterval11);
        org.junit.Assert.assertNotNull(readableInterval12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 259200002L + "'", long19 == 259200002L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2L) + "'", long21 == (-2L));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-28799996L), (-28799996L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "org.joda.time.IllegalInstantException: PeriodType[Seconds]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (short) 0);
        boolean boolean9 = dateTimeZone5.isStandardOffset(1L);
        java.lang.String str11 = dateTimeZone5.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.year();
        org.joda.time.Chronology chronology14 = zonedChronology12.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology7);
        org.joda.time.Period period9 = period4.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period10 = period8.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType12 = period8.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField13 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType12);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period(readableDuration14, readableInstant15);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology19);
        org.joda.time.Period period21 = period16.withFields((org.joda.time.ReadablePeriod) period20);
        org.joda.time.Period period22 = period20.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType24 = period20.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType24);
        int int26 = unsupportedDurationField13.compareTo((org.joda.time.DurationField) unsupportedDurationField25);
        org.joda.time.DurationFieldType durationFieldType27 = unsupportedDurationField13.getType();
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        boolean boolean29 = periodType0.isSupported(durationFieldType27);
        java.lang.Number number30 = null;
        java.lang.Number number32 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(durationFieldType27, number30, (java.lang.Number) 9700, number32);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertNotNull(unsupportedDurationField13);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset((long) 'a');
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        org.joda.time.ReadableInterval readableInterval12 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        boolean boolean13 = cachedDateTimeZone7.equals((java.lang.Object) readableInterval10);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone7, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(readableInterval11);
        org.junit.Assert.assertNotNull(readableInterval12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period2 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) '#');
        int int8 = period7.getHours();
        org.joda.time.Period period10 = period7.minusSeconds((int) '#');
        boolean boolean11 = period2.equals((java.lang.Object) period7);
        int[] intArray13 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        org.joda.time.DurationField durationField14 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        illegalFieldValueException2.prependMessage("200");
        org.joda.time.IllegalInstantException illegalInstantException8 = new org.joda.time.IllegalInstantException("");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalInstantException8);
        java.lang.Number number10 = illegalFieldValueException2.getLowerBound();
        java.lang.Number number11 = illegalFieldValueException2.getUpperBound();
        illegalFieldValueException2.prependMessage("org.joda.time.IllegalInstantException: PeriodType[Seconds]");
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        illegalFieldValueException2.prependMessage("PeriodType[Seconds]");
        illegalFieldValueException2.prependMessage("11");
        java.lang.String str10 = illegalFieldValueException2.getIllegalStringValue();
        org.joda.time.DurationFieldType durationFieldType11 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNull(durationFieldType11);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        java.lang.String str7 = dateTimeZone1.getName(0L);
        org.joda.time.LocalDateTime localDateTime8 = null;
        boolean boolean9 = dateTimeZone1.isLocalDateTimeGap(localDateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-00:00:00.001" + "'", str7.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset(20L);
        boolean boolean10 = cachedDateTimeZone7.isFixed();
        java.lang.String str12 = cachedDateTimeZone7.getNameKey(97L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("(\"org.joda.time.JodaTimePermission\" \"12\")", "");
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "100");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.Minutes minutes9 = period6.toStandardMinutes();
        org.joda.time.Period period11 = period6.multipliedBy(10);
        org.joda.time.Period period13 = period6.multipliedBy(0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(minutes9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
        int int12 = offsetDateTimeField6.getLeapAmount(28800132L);
        long long14 = offsetDateTimeField6.roundHalfFloor(8L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.centuryOfEra();
        org.joda.time.DurationField durationField7 = gregorianChronology0.halfdays();
        try {
            long long15 = gregorianChronology0.getDateTimeMillis((-1), (-10), 13, 1, (-10), 43, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) '#');
        int int8 = period7.getHours();
        org.joda.time.Period period10 = period7.minusSeconds((int) '#');
        boolean boolean11 = period2.equals((java.lang.Object) period7);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period7.toDurationTo(readableInstant12);
        long long14 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration13);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableDuration17, readableInstant18);
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType21 = periodType20.withWeeksRemoved();
        org.joda.time.PeriodType periodType22 = periodType20.withMinutesRemoved();
        org.joda.time.Period period23 = period19.withPeriodType(periodType20);
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType20);
        org.joda.time.Period period25 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration13, readableInstant15, periodType20);
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period(readableDuration27, readableInstant28);
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType31 = periodType30.withWeeksRemoved();
        org.joda.time.PeriodType periodType32 = periodType30.withMinutesRemoved();
        org.joda.time.Period period33 = period29.withPeriodType(periodType30);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (short) -1, periodType30);
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.Period period37 = new org.joda.time.Period(readableDuration35, readableInstant36);
        org.joda.time.PeriodType periodType38 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType39 = periodType38.withWeeksRemoved();
        org.joda.time.PeriodType periodType40 = periodType38.withMinutesRemoved();
        org.joda.time.Period period41 = period37.withPeriodType(periodType38);
        org.joda.time.Period period42 = period34.withPeriodType(periodType38);
        int int43 = periodType38.size();
        org.joda.time.PeriodType periodType44 = periodType38.withWeeksRemoved();
        org.joda.time.Period period45 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration13, periodType38);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-92015999903L) + "'", long14 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(periodType44);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.Period period10 = period6.plusYears((-100));
        int int11 = period10.size();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "GregorianChronology[America/Los_Angeles]", 0, (int) (short) 100);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long9 = fixedDateTimeZone4.convertLocalToUTC(172800001L, true, (-92015999903L));
        int int11 = fixedDateTimeZone4.getOffsetFromLocal((long) 2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 172800001L + "'", long9 == 172800001L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.File file4 = null;
        java.io.File[] fileArray5 = null;
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = zoneInfoCompiler0.compile(file4, fileArray5);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(strMap6);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[America/Los_Angeles]", (-100));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (Seconds)", 2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.Chronology chronology10 = iSOChronology6.withZone(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.dayOfWeek();
        try {
            long long18 = iSOChronology11.getDateTimeMillis((-28799996L), 0, (-8), 0, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -8 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("GregorianChronology[-00:00:00.001]");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology(chronology2);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField26 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType25);
        java.lang.String str27 = unsupportedDurationField26.getName();
        try {
            int int30 = unsupportedDurationField26.getDifference(2440588L, (long) 98);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertNotNull(unsupportedDurationField26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "years" + "'", str27.equals("years"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
        int int12 = offsetDateTimeField6.getLeapAmount(28800132L);
        int int14 = offsetDateTimeField6.getMaximumValue(28800132L);
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField6.getMaximumShortTextLength(locale15);
        long long19 = offsetDateTimeField6.add(132L, 8L);
        java.util.Locale locale22 = null;
        try {
            long long23 = offsetDateTimeField6.set((long) 9700, "PeriodType[Seconds]", locale22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PeriodType[Seconds]\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200132L + "'", long19 == 691200132L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
        org.joda.time.DurationField durationField11 = offsetDateTimeField6.getDurationField();
        org.joda.time.ReadablePartial readablePartial12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.secondOfMinute();
        int int16 = gregorianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.millisOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology14.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology14.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology25);
        org.joda.time.Period period27 = period22.withFields((org.joda.time.ReadablePeriod) period26);
        org.joda.time.Period period29 = period22.withMillis((int) (short) 100);
        org.joda.time.Period period31 = period29.withDays((int) 'a');
        int int32 = period29.size();
        org.joda.time.Period period34 = period29.plusYears((int) (short) -1);
        int[] intArray37 = gregorianChronology14.get((org.joda.time.ReadablePeriod) period29, (long) 'a', (long) 'a');
        int[] intArray39 = offsetDateTimeField6.addWrapPartial(readablePartial12, 99, intArray37, 0);
        java.lang.String str41 = offsetDateTimeField6.getAsShortText(25945200220L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 8 + "'", int32 == 8);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "11" + "'", str41.equals("11"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration3, readableInstant4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType7 = periodType6.withWeeksRemoved();
        org.joda.time.PeriodType periodType8 = periodType6.withMinutesRemoved();
        org.joda.time.Period period9 = period5.withPeriodType(periodType6);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) -1, periodType6);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType15 = periodType14.withWeeksRemoved();
        org.joda.time.PeriodType periodType16 = periodType14.withMinutesRemoved();
        org.joda.time.Period period17 = period13.withPeriodType(periodType14);
        org.joda.time.Period period18 = period10.withPeriodType(periodType14);
        org.joda.time.Period period19 = new org.joda.time.Period((long) (-1), (long) (-1), periodType14);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology25);
        org.joda.time.Period period27 = period22.withFields((org.joda.time.ReadablePeriod) period26);
        org.joda.time.Period period28 = period26.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType30 = period26.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField31 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType30);
        org.joda.time.DurationFieldType durationFieldType32 = unsupportedDurationField31.getType();
        int int33 = periodType14.indexOf(durationFieldType32);
        org.joda.time.PeriodType periodType34 = periodType14.withMonthsRemoved();
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertNotNull(unsupportedDurationField31);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(periodType34);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText(200, locale10);
        int int13 = offsetDateTimeField6.getLeapAmount(2440588L);
        long long15 = offsetDateTimeField6.roundHalfCeiling((long) 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "200" + "'", str11.equals("200"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[America/Los_Angeles]", "", (int) '#', 100);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        long long7 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone5, (long) 'a');
        java.lang.String str9 = fixedDateTimeZone4.getNameKey((long) '4');
        int int11 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.util.TimeZone timeZone12 = fixedDateTimeZone4.toTimeZone();
        boolean boolean13 = fixedDateTimeZone4.isFixed();
        org.joda.time.IllegalInstantException illegalInstantException16 = new org.joda.time.IllegalInstantException((long) 0, "Seconds");
        org.joda.time.IllegalInstantException illegalInstantException19 = new org.joda.time.IllegalInstantException((long) 0, "Seconds");
        illegalInstantException16.addSuppressed((java.lang.Throwable) illegalInstantException19);
        boolean boolean21 = fixedDateTimeZone4.equals((java.lang.Object) illegalInstantException16);
        long long24 = fixedDateTimeZone4.adjustOffset((long) 43, false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 133L + "'", long7 == 133L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43L + "'", long24 == 43L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset((long) 'a');
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        org.joda.time.ReadableInterval readableInterval12 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        boolean boolean13 = cachedDateTimeZone7.equals((java.lang.Object) readableInterval10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.secondOfMinute();
        int int16 = gregorianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.millisOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology14.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology14.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology14.minuteOfHour();
        org.joda.time.DurationField durationField21 = gregorianChronology14.weekyears();
        boolean boolean22 = cachedDateTimeZone7.equals((java.lang.Object) durationField21);
        int int24 = cachedDateTimeZone7.getStandardOffset(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(readableInterval11);
        org.junit.Assert.assertNotNull(readableInterval12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-28800000));
        long long17 = offsetDateTimeField15.roundHalfEven(86400000L);
        boolean boolean18 = offsetDateTimeField15.isSupported();
        java.lang.String str19 = offsetDateTimeField15.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86400001L + "'", long17 == 86400001L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[dayOfWeek]" + "'", str19.equals("DateTimeField[dayOfWeek]"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("GregorianChronology[-00:00:00.001]");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("12");
        jodaTimePermission3.checkGuard((java.lang.Object) (short) -1);
        java.security.PermissionCollection permissionCollection6 = jodaTimePermission3.newPermissionCollection();
        boolean boolean7 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) 'a', chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) '#');
        org.joda.time.Period period14 = period12.minusMillis(10);
        org.joda.time.Period period16 = period12.plusMinutes((int) (short) 1);
        org.joda.time.Period period18 = period12.minusMonths((int) (short) 0);
        jodaTimePermission1.checkGuard((java.lang.Object) period12);
        java.security.PermissionCollection permissionCollection20 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(permissionCollection20);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        long long27 = remainderDateTimeField25.roundHalfFloor((long) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.secondOfMinute();
        int int30 = gregorianChronology28.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology28.millisOfDay();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology28.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, 8);
        int int35 = offsetDateTimeField34.getOffset();
        org.joda.time.DurationField durationField36 = offsetDateTimeField34.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.secondOfMinute();
        int int39 = gregorianChronology37.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.millisOfDay();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, 8);
        long long45 = offsetDateTimeField43.roundHalfEven((long) 100);
        int int48 = offsetDateTimeField43.getDifference((long) (byte) 1, (long) (byte) 10);
        long long50 = offsetDateTimeField43.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField43, (-28800000));
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = offsetDateTimeField43.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType53, (-43));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField25, dateTimeFieldType53, (int) 'a', (-28799985), 35);
        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, (java.lang.Number) 25945200220L, "PST");
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 8 + "'", int35 == 8);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1L + "'", long45 == 1L);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1L + "'", long50 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.secondOfMinute();
        int int13 = gregorianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.millisOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology11.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
        int int18 = offsetDateTimeField17.getOffset();
        org.joda.time.DurationField durationField19 = offsetDateTimeField17.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.secondOfMinute();
        int int22 = gregorianChronology20.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology20.millisOfDay();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology20.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 8);
        long long28 = offsetDateTimeField26.roundHalfEven((long) 100);
        int int31 = offsetDateTimeField26.getDifference((long) (byte) 1, (long) (byte) 10);
        long long33 = offsetDateTimeField26.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField26, (-28800000));
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField26.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, dateTimeFieldType36, (-43));
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1L + "'", long33 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.Chronology chronology10 = iSOChronology6.withZone(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.dayOfYear();
        org.joda.time.Chronology chronology13 = iSOChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.Period period1 = new org.joda.time.Period(3024000001L);
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = periodType3.indexOf(durationFieldType4);
        try {
            org.joda.time.Period period6 = period1.withPeriodType(periodType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'hours'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.Period period3 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', chronology5);
        org.joda.time.Period period8 = period6.minusMonths((int) '#');
        int int9 = period8.getHours();
        org.joda.time.Period period11 = period8.minusSeconds((int) '#');
        boolean boolean12 = period3.equals((java.lang.Object) period8);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period8.toDurationTo(readableInstant13);
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withWeeksRemoved();
        org.joda.time.PeriodType periodType23 = periodType21.withMinutesRemoved();
        org.joda.time.Period period24 = period20.withPeriodType(periodType21);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) -1, periodType21);
        org.joda.time.Period period26 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant16, periodType21);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType21, chronology27);
        java.lang.String str29 = periodType21.getName();
        org.joda.time.Period period33 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.Period period36 = new org.joda.time.Period((long) 'a', chronology35);
        org.joda.time.Period period38 = period36.minusMonths((int) '#');
        int int39 = period38.getHours();
        org.joda.time.Period period41 = period38.minusSeconds((int) '#');
        boolean boolean42 = period33.equals((java.lang.Object) period38);
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.Duration duration44 = period38.toDurationTo(readableInstant43);
        long long45 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration44);
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.ReadableDuration readableDuration48 = null;
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.Period period50 = new org.joda.time.Period(readableDuration48, readableInstant49);
        org.joda.time.PeriodType periodType51 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType52 = periodType51.withWeeksRemoved();
        org.joda.time.PeriodType periodType53 = periodType51.withMinutesRemoved();
        org.joda.time.Period period54 = period50.withPeriodType(periodType51);
        org.joda.time.Period period55 = new org.joda.time.Period((long) (short) -1, periodType51);
        org.joda.time.Period period56 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration44, readableInstant46, periodType51);
        org.joda.time.Chronology chronology57 = null;
        org.joda.time.Period period58 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType51, chronology57);
        java.lang.String str59 = periodType51.getName();
        org.joda.time.ReadableDuration readableDuration60 = null;
        org.joda.time.ReadableInstant readableInstant61 = null;
        org.joda.time.Period period62 = new org.joda.time.Period(readableDuration60, readableInstant61);
        org.joda.time.Chronology chronology65 = null;
        org.joda.time.Period period66 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology65);
        org.joda.time.Period period67 = period62.withFields((org.joda.time.ReadablePeriod) period66);
        org.joda.time.Period period68 = period66.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType70 = period66.getFieldType(0);
        int int71 = periodType51.indexOf(durationFieldType70);
        int int72 = periodType21.indexOf(durationFieldType70);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-92015999903L) + "'", long15 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Seconds" + "'", str29.equals("Seconds"));
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(duration44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-92015999903L) + "'", long45 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Seconds" + "'", str59.equals("Seconds"));
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(durationFieldType70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("-00:00:00.001", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (short) 100, '4', (int) (short) 100, 8, (-1), false, (-28800000));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder11.setStandardOffset(8);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder24 = dateTimeZoneBuilder13.addRecurringSavings("8", (-43), 0, 53, '#', (-28800000), (-28799985), 0, false, 1131);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.weekyears();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.weekyearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField7 = iSOChronology6.seconds();
        org.joda.time.DurationField durationField8 = iSOChronology6.months();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', chronology3);
        org.joda.time.Period period6 = period4.minusMonths((int) '#');
        int int7 = period6.getHours();
        org.joda.time.Period period9 = period6.minusSeconds((int) '#');
        boolean boolean10 = period1.equals((java.lang.Object) period6);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period6.toDurationTo(readableInstant11);
        long long13 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration12);
        java.lang.Class<?> wildcardClass14 = duration12.getClass();
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType17 = periodType16.withWeeksRemoved();
        org.joda.time.PeriodType periodType18 = periodType16.withMinutesRemoved();
        org.joda.time.PeriodType periodType19 = periodType16.withWeeksRemoved();
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant15, periodType16);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType23 = periodType22.withWeeksRemoved();
        org.joda.time.PeriodType periodType24 = periodType23.withHoursRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant21, periodType23);
        java.lang.Class<?> wildcardClass26 = period25.getClass();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-92015999903L) + "'", long13 == (-92015999903L));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText(200, locale10);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField6.getMaximumTextLength(locale12);
        long long16 = offsetDateTimeField6.add((long) '4', (-15));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "200" + "'", str11.equals("200"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1295999948L) + "'", long16 == (-1295999948L));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsText((long) (-1), locale10);
        boolean boolean13 = offsetDateTimeField6.isLeap((long) ' ');
        org.joda.time.ReadablePartial readablePartial14 = null;
        int int15 = offsetDateTimeField6.getMinimumValue(readablePartial14);
        boolean boolean16 = offsetDateTimeField6.isLenient();
        boolean boolean17 = offsetDateTimeField6.isLenient();
        org.joda.time.DurationField durationField18 = offsetDateTimeField6.getLeapDurationField();
        int int19 = offsetDateTimeField6.getMinimumValue();
        int int20 = offsetDateTimeField6.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', chronology3);
        org.joda.time.Period period6 = period4.minusMonths((int) '#');
        int int7 = period6.getHours();
        org.joda.time.Period period9 = period6.minusSeconds((int) '#');
        boolean boolean10 = period1.equals((java.lang.Object) period6);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period6.toDurationTo(readableInstant11);
        long long13 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableDuration16, readableInstant17);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType20 = periodType19.withWeeksRemoved();
        org.joda.time.PeriodType periodType21 = periodType19.withMinutesRemoved();
        org.joda.time.Period period22 = period18.withPeriodType(periodType19);
        org.joda.time.Period period23 = new org.joda.time.Period((long) (short) -1, periodType19);
        org.joda.time.Period period24 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant14, periodType19);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period(readableDuration27, readableInstant28);
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType31 = periodType30.withWeeksRemoved();
        org.joda.time.PeriodType periodType32 = periodType30.withMinutesRemoved();
        org.joda.time.Period period33 = period29.withPeriodType(periodType30);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (short) -1, periodType30);
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.Period period37 = new org.joda.time.Period(readableDuration35, readableInstant36);
        org.joda.time.PeriodType periodType38 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType39 = periodType38.withWeeksRemoved();
        org.joda.time.PeriodType periodType40 = periodType38.withMinutesRemoved();
        org.joda.time.Period period41 = period37.withPeriodType(periodType38);
        org.joda.time.Period period42 = period34.withPeriodType(periodType38);
        org.joda.time.Period period43 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant25, periodType38);
        long long44 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration12);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-92015999903L) + "'", long13 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-92015999903L) + "'", long44 == (-92015999903L));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        try {
            long long14 = unsupportedDurationField11.getDifferenceAsLong((long) 1131, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(99L, locale6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        int int10 = cachedDateTimeZone8.getOffset((-36000000L));
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone8.getUncachedZone();
        org.joda.time.Chronology chronology12 = iSOChronology0.withZone(dateTimeZone11);
        long long15 = dateTimeZone11.adjustOffset(3024000000L, false);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-00:00:00.001" + "'", str7.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3024000000L + "'", long15 == 3024000000L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology0.millis();
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            long long8 = gregorianChronology0.set(readablePartial6, 3L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsText((long) (-1), locale10);
        long long14 = offsetDateTimeField6.addWrapField(172800001L, 2);
        int int15 = offsetDateTimeField6.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259199999L) + "'", long14 == (-259199999L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale3 = null;
        java.lang.String str6 = defaultNameProvider0.getName(locale3, "", "ZonedChronology[GregorianChronology[UTC], -00:00:00.001]");
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = new org.joda.time.Period(99L, (long) 1, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField7 = iSOChronology6.seconds();
        org.joda.time.DurationField durationField8 = iSOChronology6.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.millisOfDay();
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology16);
        org.joda.time.Period period18 = period13.withFields((org.joda.time.ReadablePeriod) period17);
        int int19 = period17.getWeeks();
        org.joda.time.Period period21 = period17.withHours(4);
        int int22 = period17.getDays();
        int[] intArray24 = lenientChronology10.get((org.joda.time.ReadablePeriod) period17, (-92015999893L));
        org.joda.time.DateTimeField dateTimeField25 = lenientChronology10.era();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.secondOfMinute();
        int int28 = gregorianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology26.millisOfDay();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology26.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 8);
        long long34 = offsetDateTimeField32.roundHalfEven((long) 100);
        java.util.Locale locale35 = null;
        int int36 = offsetDateTimeField32.getMaximumTextLength(locale35);
        long long39 = offsetDateTimeField32.add((long) 2, 99);
        boolean boolean40 = lenientChronology10.equals((java.lang.Object) long39);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 8553600002L + "'", long39 == 8553600002L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        illegalFieldValueException2.prependMessage("200");
        org.joda.time.IllegalInstantException illegalInstantException8 = new org.joda.time.IllegalInstantException("");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalInstantException8);
        java.lang.Number number10 = illegalFieldValueException2.getLowerBound();
        java.lang.String str11 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period3 = period2.normalizedStandard();
        org.joda.time.Period period5 = period3.minusMonths((int) (byte) -1);
        int int6 = period3.getYears();
        org.joda.time.Period period8 = period3.withHours((int) (byte) 10);
        org.joda.time.Period period10 = period8.plusSeconds((-28800000));
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[America/Los_Angeles]", "", (int) '#', 100);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        long long7 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone5, (long) 'a');
        long long9 = fixedDateTimeZone4.nextTransition(2488331404800008L);
        long long11 = fixedDateTimeZone4.nextTransition(0L);
        long long13 = fixedDateTimeZone4.nextTransition((-92015999903L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 133L + "'", long7 == 133L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2488331404800008L + "'", long9 == 2488331404800008L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-92015999903L) + "'", long13 == (-92015999903L));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        java.lang.String str25 = unsupportedDurationField23.getName();
        java.lang.String str26 = unsupportedDurationField23.getName();
        long long27 = unsupportedDurationField23.getUnitMillis();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "years" + "'", str25.equals("years"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "years" + "'", str26.equals("years"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        int int5 = period4.getHours();
        org.joda.time.Period period7 = period4.minusSeconds((int) '#');
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = period7.indexOf(durationFieldType8);
        org.joda.time.Period period11 = period7.minusSeconds(53);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.Period period1 = org.joda.time.Period.years(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
        long long12 = offsetDateTimeField6.roundHalfCeiling(0L);
        boolean boolean13 = offsetDateTimeField6.isLenient();
        long long15 = offsetDateTimeField6.roundHalfCeiling((long) (-28800000));
        int int17 = offsetDateTimeField6.getLeapAmount((long) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, "hi!");
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.Period period1 = org.joda.time.Period.millis(53);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfHour();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Period period9 = period7.minusDays((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableDuration10, readableInstant11);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology15);
        org.joda.time.Period period17 = period12.withFields((org.joda.time.ReadablePeriod) period16);
        org.joda.time.Period period19 = period12.withMillis((int) (short) 100);
        org.joda.time.Period period21 = period19.plusWeeks((int) (byte) 100);
        org.joda.time.Period period22 = period7.withFields((org.joda.time.ReadablePeriod) period19);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period22);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 15, (-8L));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        long long27 = remainderDateTimeField25.roundHalfFloor((long) 0);
        int int29 = remainderDateTimeField25.get(86400000L);
        int int30 = remainderDateTimeField25.getMaximumValue();
        int int32 = remainderDateTimeField25.get((-259199999L));
        int int34 = remainderDateTimeField25.get((-94723200000L));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 53 + "'", int29 == 53);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 98 + "'", int30 == 98);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 68 + "'", int34 == 68);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfHour();
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.secondOfDay();
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        boolean boolean13 = dateTimeZone11.isStandardOffset((long) (short) 0);
        boolean boolean15 = dateTimeZone11.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField17 = iSOChronology16.seconds();
        org.joda.time.DurationField durationField18 = iSOChronology16.halfdays();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.millisOfDay();
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period(readableDuration21, readableInstant22);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology26);
        org.joda.time.Period period28 = period23.withFields((org.joda.time.ReadablePeriod) period27);
        int int29 = period27.getWeeks();
        org.joda.time.Period period31 = period27.withHours(4);
        int int32 = period27.getDays();
        int[] intArray34 = lenientChronology20.get((org.joda.time.ReadablePeriod) period27, (-92015999893L));
        try {
            gregorianChronology0.validate(readablePartial9, intArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.Period period1 = org.joda.time.Period.years((-28799985));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(200, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.remainder((long) (byte) 1);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumShortTextLength(locale9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField6.getType();
        java.lang.String str12 = offsetDateTimeField6.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[dayOfWeek]" + "'", str12.equals("DateTimeField[dayOfWeek]"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        java.lang.String str6 = gregorianChronology0.toString();
        org.joda.time.Period period8 = org.joda.time.Period.weeks((-1));
        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period8, (long) 'a', (long) 10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology0.getZone();
        java.lang.String str15 = dateTimeZone13.getShortName((long) (short) 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-00:00:00.001" + "'", str15.equals("-00:00:00.001"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Minutes minutes8 = period7.toStandardMinutes();
        org.joda.time.Period period10 = period7.plusYears(0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = null;
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        int int8 = period6.getWeeks();
        org.joda.time.Period period10 = org.joda.time.Period.millis(10);
        boolean boolean11 = period6.equals((java.lang.Object) period10);
        int int12 = period6.getWeeks();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(259200002L, 2440588L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 261640590L + "'", long2 == 261640590L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-28800000));
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField15.getAsText(readablePartial16, 8, locale18);
        long long21 = offsetDateTimeField15.roundCeiling(3628800001L);
        long long24 = offsetDateTimeField15.getDifferenceAsLong(36000100L, 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "8" + "'", str19.equals("8"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 3628800001L + "'", long21 == 3628800001L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 10);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.addCutover((-15), 'a', (int) (byte) 1, (int) (byte) 0, (int) (short) 1, false, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (short) 0);
        boolean boolean9 = dateTimeZone5.isStandardOffset(1L);
        java.lang.String str11 = dateTimeZone5.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
        java.lang.Object obj13 = null;
        boolean boolean14 = zonedChronology12.equals(obj13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getName(99L, locale18);
        org.joda.time.ReadableInstant readableInstant20 = null;
        int int21 = dateTimeZone16.getOffset(readableInstant20);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        int int24 = cachedDateTimeZone22.getStandardOffset(20L);
        boolean boolean25 = cachedDateTimeZone22.isFixed();
        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone22, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField7 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfDay();
        java.lang.Object obj3 = null;
        boolean boolean4 = iSOChronology1.equals(obj3);
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) -1, (int) 'a', (-8));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology3.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        int int5 = period4.getHours();
        org.joda.time.Period period7 = period4.minusSeconds((int) '#');
        org.joda.time.Period period9 = period7.minusMonths((-10));
        org.joda.time.format.PeriodFormatter periodFormatter10 = null;
        java.lang.String str11 = period9.toString(periodFormatter10);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "P-25MT-34.903S" + "'", str11.equals("P-25MT-34.903S"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(4);
        org.joda.time.Chronology chronology6 = iSOChronology0.withZone(dateTimeZone5);
        java.lang.String str7 = dateTimeZone5.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        java.util.TimeZone timeZone9 = cachedDateTimeZone8.toTimeZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.004" + "'", str7.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        java.util.Locale locale11 = null;
        java.lang.String str12 = cachedDateTimeZone7.getShortName(100L, locale11);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-00:00:00.001" + "'", str12.equals("-00:00:00.001"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset((long) 'a');
        org.joda.time.IllegalInstantException illegalInstantException12 = new org.joda.time.IllegalInstantException((long) 0, "Seconds");
        boolean boolean13 = cachedDateTimeZone7.equals((java.lang.Object) illegalInstantException12);
        long long16 = cachedDateTimeZone7.adjustOffset((long) (short) 0, true);
        boolean boolean17 = cachedDateTimeZone7.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.millisOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 4, (-92015999903L), (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, (long) 200);
        org.joda.time.Period period4 = period2.minusMinutes((-25200000));
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.Period period4 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', chronology6);
        org.joda.time.Period period9 = period7.minusMonths((int) '#');
        int int10 = period9.getHours();
        org.joda.time.Period period12 = period9.minusSeconds((int) '#');
        boolean boolean13 = period4.equals((java.lang.Object) period9);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period9.toDurationTo(readableInstant14);
        long long16 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableDuration19, readableInstant20);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType23 = periodType22.withWeeksRemoved();
        org.joda.time.PeriodType periodType24 = periodType22.withMinutesRemoved();
        org.joda.time.Period period25 = period21.withPeriodType(periodType22);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) -1, periodType22);
        org.joda.time.Period period27 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration15, readableInstant17, periodType22);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType22, chronology28);
        java.lang.String str30 = periodType22.getName();
        org.joda.time.PeriodType periodType31 = periodType22.withMillisRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period33 = new org.joda.time.Period((long) 8, periodType22, (org.joda.time.Chronology) gregorianChronology32);
        java.lang.String str34 = gregorianChronology32.toString();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.yearOfCentury();
        java.lang.String str36 = gregorianChronology32.toString();
        long long40 = gregorianChronology32.add((-2520000000L), (long) (short) 10, (-28799985));
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-92015999903L) + "'", long16 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Seconds" + "'", str30.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str34.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str36.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-2807999850L) + "'", long40 == (-2807999850L));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset((long) 'a');
        org.joda.time.IllegalInstantException illegalInstantException12 = new org.joda.time.IllegalInstantException((long) 0, "Seconds");
        boolean boolean13 = cachedDateTimeZone7.equals((java.lang.Object) illegalInstantException12);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number17 = illegalFieldValueException16.getIllegalNumberValue();
        java.lang.String str18 = illegalFieldValueException16.getFieldName();
        java.lang.String str19 = illegalFieldValueException16.getIllegalValueAsString();
        java.lang.Number number20 = illegalFieldValueException16.getLowerBound();
        java.lang.Number number21 = illegalFieldValueException16.getUpperBound();
        illegalFieldValueException16.prependMessage("PeriodType[Seconds]");
        illegalInstantException12.addSuppressed((java.lang.Throwable) illegalFieldValueException16);
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number28 = illegalFieldValueException27.getIllegalNumberValue();
        java.lang.Number number29 = illegalFieldValueException27.getUpperBound();
        illegalFieldValueException27.prependMessage("200");
        org.joda.time.IllegalInstantException illegalInstantException33 = new org.joda.time.IllegalInstantException("");
        illegalFieldValueException27.addSuppressed((java.lang.Throwable) illegalInstantException33);
        java.lang.String str35 = illegalFieldValueException27.getIllegalValueAsString();
        illegalFieldValueException16.addSuppressed((java.lang.Throwable) illegalFieldValueException27);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DurationField durationField8 = gregorianChronology3.weeks();
        org.joda.time.Period period10 = org.joda.time.Period.days((-1));
        int[] intArray13 = gregorianChronology3.get((org.joda.time.ReadablePeriod) period10, (long) 200, (long) (short) 0);
        org.joda.time.Period period15 = period10.minusMonths((int) (byte) 10);
        org.joda.time.format.PeriodFormatter periodFormatter16 = null;
        java.lang.String str17 = period15.toString(periodFormatter16);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "P-10M-1D" + "'", str17.equals("P-10M-1D"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology3.yearOfCentury();
        org.joda.time.Chronology chronology9 = gregorianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology3.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
        int int12 = offsetDateTimeField6.getMinimumValue();
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField6.getAsText((long) 10, locale14);
        org.joda.time.DurationField durationField16 = offsetDateTimeField6.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "12" + "'", str15.equals("12"));
        org.junit.Assert.assertNull(durationField16);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(4);
        org.joda.time.Chronology chronology6 = iSOChronology0.withZone(dateTimeZone5);
        java.lang.String str7 = dateTimeZone5.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.004" + "'", str7.equals("+00:00:00.004"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-28800000));
        long long17 = offsetDateTimeField15.roundHalfEven(86400000L);
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField15.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86400001L + "'", long17 == 86400001L);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        int int8 = period6.getWeeks();
        org.joda.time.Period period10 = period6.withHours(4);
        org.joda.time.Minutes minutes11 = period6.toStandardMinutes();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(minutes11);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
        long long13 = offsetDateTimeField6.add((long) 2, 99);
        java.lang.String str15 = offsetDateTimeField6.getAsShortText((-368326799612L));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, 99);
        java.lang.String str19 = offsetDateTimeField17.getAsText((long) 43);
        int int20 = offsetDateTimeField17.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8553600002L + "'", long13 == 8553600002L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "11" + "'", str15.equals("11"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "111" + "'", str19.equals("111"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 114 + "'", int20 == 114);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DurationField durationField8 = gregorianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology3.clockhourOfHalfday();
        long long13 = gregorianChronology3.add(0L, (long) (short) 10, 13);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 130L + "'", long13 == 130L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.remainder((long) (byte) 1);
        boolean boolean10 = offsetDateTimeField6.isLeap(0L);
        int int12 = offsetDateTimeField6.getMaximumValue((long) (-28800000));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 10, (int) '4');
        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "PST", "");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "years", "PeriodType[Seconds]");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getShortName(locale9, "100", "P-10M-1D");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        long long10 = offsetDateTimeField6.roundHalfFloor((long) (-100));
        java.lang.String str12 = offsetDateTimeField6.getAsShortText((long) '#');
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField6.getAsText(readablePartial13, 2, locale15);
        java.lang.String str18 = offsetDateTimeField6.getAsText((long) 15);
        org.joda.time.ReadablePartial readablePartial19 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.secondOfMinute();
        int int23 = gregorianChronology21.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.millisOfDay();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology21.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 8);
        long long29 = offsetDateTimeField27.roundHalfEven((long) 100);
        java.util.Locale locale30 = null;
        int int31 = offsetDateTimeField27.getMaximumTextLength(locale30);
        org.joda.time.DurationField durationField32 = offsetDateTimeField27.getDurationField();
        org.joda.time.ReadablePartial readablePartial33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.secondOfMinute();
        int int37 = gregorianChronology35.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology35.millisOfDay();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology35.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology35.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.Period period43 = new org.joda.time.Period(readableDuration41, readableInstant42);
        org.joda.time.Chronology chronology46 = null;
        org.joda.time.Period period47 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology46);
        org.joda.time.Period period48 = period43.withFields((org.joda.time.ReadablePeriod) period47);
        org.joda.time.Period period50 = period43.withMillis((int) (short) 100);
        org.joda.time.Period period52 = period50.withDays((int) 'a');
        int int53 = period50.size();
        org.joda.time.Period period55 = period50.plusYears((int) (short) -1);
        int[] intArray58 = gregorianChronology35.get((org.joda.time.ReadablePeriod) period50, (long) 'a', (long) 'a');
        int[] intArray60 = offsetDateTimeField27.addWrapPartial(readablePartial33, 99, intArray58, 0);
        try {
            int[] intArray62 = offsetDateTimeField6.addWrapPartial(readablePartial19, 1131, intArray60, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1131");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "12" + "'", str12.equals("12"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2" + "'", str16.equals("2"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "12" + "'", str18.equals("12"));
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 8 + "'", int53 == 8);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray60);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.remainder((long) (byte) 1);
        boolean boolean10 = offsetDateTimeField6.isLeap(0L);
        int int12 = offsetDateTimeField6.getLeapAmount((long) (-10));
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField6.getAsText((long) (-10), locale14);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "11" + "'", str15.equals("11"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.Period period3 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', chronology5);
        org.joda.time.Period period8 = period6.minusMonths((int) '#');
        int int9 = period8.getHours();
        org.joda.time.Period period11 = period8.minusSeconds((int) '#');
        boolean boolean12 = period3.equals((java.lang.Object) period8);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period8.toDurationTo(readableInstant13);
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withWeeksRemoved();
        org.joda.time.PeriodType periodType23 = periodType21.withMinutesRemoved();
        org.joda.time.Period period24 = period20.withPeriodType(periodType21);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) -1, periodType21);
        org.joda.time.Period period26 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant16, periodType21);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType21, chronology27);
        java.lang.String str29 = periodType21.getName();
        org.joda.time.PeriodType periodType30 = periodType21.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType31 = null;
        boolean boolean32 = periodType30.isSupported(durationFieldType31);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-92015999903L) + "'", long15 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Seconds" + "'", str29.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.remainder((long) (byte) 1);
        boolean boolean10 = offsetDateTimeField6.isLeap(0L);
        int int12 = offsetDateTimeField6.getLeapAmount((long) (-10));
        long long14 = offsetDateTimeField6.roundCeiling(345600000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345600001L + "'", long14 == 345600001L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfEra();
        org.joda.time.DurationField durationField5 = gregorianChronology0.eras();
        int int6 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("PeriodType[Seconds]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'PeriodType[Seconds]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        long long26 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period(readableDuration27, readableInstant28);
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology32);
        org.joda.time.Period period34 = period29.withFields((org.joda.time.ReadablePeriod) period33);
        org.joda.time.Period period35 = period33.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType37 = period33.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField38 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType37);
        int int39 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField38);
        java.lang.String str40 = unsupportedDurationField11.toString();
        try {
            long long43 = unsupportedDurationField11.getValueAsLong((long) 53, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(durationFieldType37);
        org.junit.Assert.assertNotNull(unsupportedDurationField38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "UnsupportedDurationField[years]" + "'", str40.equals("UnsupportedDurationField[years]"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.yearOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField10 = gregorianChronology9.weekyears();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology9.getZone();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone11);
        org.joda.time.ReadablePartial readablePartial14 = null;
        try {
            int[] intArray16 = zonedChronology13.get(readablePartial14, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        long long27 = remainderDateTimeField25.roundHalfFloor((long) 0);
        long long29 = remainderDateTimeField25.roundHalfCeiling((-28799999L));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-28799999L) + "'", long29 == (-28799999L));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period5 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', chronology7);
        org.joda.time.Period period10 = period8.minusMonths((int) '#');
        int int11 = period10.getHours();
        org.joda.time.Period period13 = period10.minusSeconds((int) '#');
        boolean boolean14 = period5.equals((java.lang.Object) period10);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period10.toDurationTo(readableInstant15);
        long long17 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType24 = periodType23.withWeeksRemoved();
        org.joda.time.PeriodType periodType25 = periodType23.withMinutesRemoved();
        org.joda.time.Period period26 = period22.withPeriodType(periodType23);
        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.Period period28 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant18, periodType23);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType23, chronology29);
        org.joda.time.Period period34 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.Period period37 = new org.joda.time.Period((long) 'a', chronology36);
        org.joda.time.Period period39 = period37.minusMonths((int) '#');
        int int40 = period39.getHours();
        org.joda.time.Period period42 = period39.minusSeconds((int) '#');
        boolean boolean43 = period34.equals((java.lang.Object) period39);
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.Duration duration45 = period39.toDurationTo(readableInstant44);
        long long46 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration45);
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.ReadableDuration readableDuration49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Period period51 = new org.joda.time.Period(readableDuration49, readableInstant50);
        org.joda.time.PeriodType periodType52 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType53 = periodType52.withWeeksRemoved();
        org.joda.time.PeriodType periodType54 = periodType52.withMinutesRemoved();
        org.joda.time.Period period55 = period51.withPeriodType(periodType52);
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) -1, periodType52);
        org.joda.time.Period period57 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration45, readableInstant47, periodType52);
        org.joda.time.Chronology chronology58 = null;
        org.joda.time.Period period59 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType52, chronology58);
        java.lang.String str60 = periodType52.getName();
        org.joda.time.ReadableDuration readableDuration61 = null;
        org.joda.time.ReadableInstant readableInstant62 = null;
        org.joda.time.Period period63 = new org.joda.time.Period(readableDuration61, readableInstant62);
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.Period period67 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology66);
        org.joda.time.Period period68 = period63.withFields((org.joda.time.ReadablePeriod) period67);
        org.joda.time.Period period69 = period67.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType71 = period67.getFieldType(0);
        int int72 = periodType52.indexOf(durationFieldType71);
        int int73 = periodType23.indexOf(durationFieldType71);
        org.joda.time.Period period74 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType23);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-92015999903L) + "'", long17 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(duration45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-92015999903L) + "'", long46 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Seconds" + "'", str60.equals("Seconds"));
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(period69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset(20L);
        int int11 = cachedDateTimeZone7.getStandardOffset((-8L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset(0L);
        java.lang.String str5 = dateTimeZone1.getShortName(43L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[America/Los_Angeles]", "", (int) '#', 100);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        long long7 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone5, (long) 'a');
        java.lang.String str9 = fixedDateTimeZone4.getNameKey((long) '4');
        int int11 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.util.TimeZone timeZone12 = fixedDateTimeZone4.toTimeZone();
        boolean boolean13 = fixedDateTimeZone4.isFixed();
        org.joda.time.IllegalInstantException illegalInstantException16 = new org.joda.time.IllegalInstantException((long) 0, "Seconds");
        org.joda.time.IllegalInstantException illegalInstantException19 = new org.joda.time.IllegalInstantException((long) 0, "Seconds");
        illegalInstantException16.addSuppressed((java.lang.Throwable) illegalInstantException19);
        boolean boolean21 = fixedDateTimeZone4.equals((java.lang.Object) illegalInstantException16);
        java.lang.String str22 = fixedDateTimeZone4.getID();
        java.util.Locale locale24 = null;
        java.lang.String str25 = fixedDateTimeZone4.getShortName((long) 1, locale24);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 133L + "'", long7 == 133L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str22.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.035" + "'", str25.equals("+00:00:00.035"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        int int4 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.hourOfDay();
        org.joda.time.DurationField durationField7 = gregorianChronology1.weekyears();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology1.yearOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField11 = gregorianChronology10.weekyears();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology10.getZone();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone12);
        java.util.Locale locale16 = null;
        java.lang.String str17 = dateTimeZone12.getName(0L, locale16);
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-00:00:00.001" + "'", str17.equals("-00:00:00.001"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("12");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 8);
        long long11 = offsetDateTimeField9.roundHalfEven((long) 100);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField9.getMaximumTextLength(locale12);
        long long16 = offsetDateTimeField9.add((long) 2, 99);
        boolean boolean17 = jodaTimePermission1.equals((java.lang.Object) 99);
        java.lang.String str18 = jodaTimePermission1.toString();
        java.lang.String str19 = jodaTimePermission1.getActions();
        java.lang.String str20 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12" + "'", str2.equals("12"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 8553600002L + "'", long16 == 8553600002L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"12\")" + "'", str18.equals("(\"org.joda.time.JodaTimePermission\" \"12\")"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) 'a');
        org.joda.time.Period period5 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', chronology7);
        org.joda.time.Period period10 = period8.minusMonths((int) '#');
        int int11 = period10.getHours();
        org.joda.time.Period period13 = period10.minusSeconds((int) '#');
        boolean boolean14 = period5.equals((java.lang.Object) period10);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period10.toDurationTo(readableInstant15);
        long long17 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType24 = periodType23.withWeeksRemoved();
        org.joda.time.PeriodType periodType25 = periodType23.withMinutesRemoved();
        org.joda.time.Period period26 = period22.withPeriodType(periodType23);
        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.Period period28 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant18, periodType23);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType23, chronology29);
        org.joda.time.Period period34 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.Period period37 = new org.joda.time.Period((long) 'a', chronology36);
        org.joda.time.Period period39 = period37.minusMonths((int) '#');
        int int40 = period39.getHours();
        org.joda.time.Period period42 = period39.minusSeconds((int) '#');
        boolean boolean43 = period34.equals((java.lang.Object) period39);
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.Duration duration45 = period39.toDurationTo(readableInstant44);
        long long46 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration45);
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.ReadableDuration readableDuration49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Period period51 = new org.joda.time.Period(readableDuration49, readableInstant50);
        org.joda.time.PeriodType periodType52 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType53 = periodType52.withWeeksRemoved();
        org.joda.time.PeriodType periodType54 = periodType52.withMinutesRemoved();
        org.joda.time.Period period55 = period51.withPeriodType(periodType52);
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) -1, periodType52);
        org.joda.time.Period period57 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration45, readableInstant47, periodType52);
        org.joda.time.Chronology chronology58 = null;
        org.joda.time.Period period59 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType52, chronology58);
        java.lang.String str60 = periodType52.getName();
        org.joda.time.ReadableDuration readableDuration61 = null;
        org.joda.time.ReadableInstant readableInstant62 = null;
        org.joda.time.Period period63 = new org.joda.time.Period(readableDuration61, readableInstant62);
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.Period period67 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology66);
        org.joda.time.Period period68 = period63.withFields((org.joda.time.ReadablePeriod) period67);
        org.joda.time.Period period69 = period67.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType71 = period67.getFieldType(0);
        int int72 = periodType52.indexOf(durationFieldType71);
        int int73 = periodType23.indexOf(durationFieldType71);
        org.joda.time.Period period74 = period1.normalizedStandard(periodType23);
        try {
            org.joda.time.Period period76 = period74.withMonths(200);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-92015999903L) + "'", long17 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(duration45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-92015999903L) + "'", long46 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Seconds" + "'", str60.equals("Seconds"));
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(period69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNotNull(period74);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-864000010L), (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-864000009L) + "'", long2 == (-864000009L));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int7 = offsetDateTimeField6.getOffset();
        org.joda.time.DurationField durationField8 = offsetDateTimeField6.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField6.getType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
        long long13 = offsetDateTimeField6.add((long) 2, 99);
        java.lang.String str15 = offsetDateTimeField6.getAsShortText((-368326799612L));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, 99);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int[] intArray24 = new int[] { 68, (byte) 0, 13, 53 };
        try {
            int[] intArray26 = offsetDateTimeField6.addWrapField(readablePartial18, (-1), intArray24, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8553600002L + "'", long13 == 8553600002L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "11" + "'", str15.equals("11"));
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        boolean boolean12 = unsupportedDurationField11.isSupported();
        java.lang.String str13 = unsupportedDurationField11.getName();
        boolean boolean14 = unsupportedDurationField11.isPrecise();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "years" + "'", str13.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.yearOfCentury();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period3 = period2.normalizedStandard();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration4, readableInstant5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType8 = periodType7.withWeeksRemoved();
        org.joda.time.PeriodType periodType9 = periodType7.withMinutesRemoved();
        org.joda.time.Period period10 = period6.withPeriodType(periodType7);
        org.joda.time.Period period11 = period2.withFields((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period13 = period2.plusSeconds((int) '4');
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        long long26 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period(readableDuration27, readableInstant28);
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology32);
        org.joda.time.Period period34 = period29.withFields((org.joda.time.ReadablePeriod) period33);
        org.joda.time.Period period35 = period33.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType37 = period33.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField38 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType37);
        int int39 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField38);
        org.joda.time.DurationFieldType durationFieldType40 = unsupportedDurationField38.getType();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(durationFieldType37);
        org.junit.Assert.assertNotNull(unsupportedDurationField38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(durationFieldType40);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        long long27 = remainderDateTimeField25.roundHalfFloor((long) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.secondOfMinute();
        int int30 = gregorianChronology28.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology28.millisOfDay();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology28.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, 8);
        int int35 = offsetDateTimeField34.getOffset();
        org.joda.time.DurationField durationField36 = offsetDateTimeField34.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.secondOfMinute();
        int int39 = gregorianChronology37.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.millisOfDay();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, 8);
        long long45 = offsetDateTimeField43.roundHalfEven((long) 100);
        int int48 = offsetDateTimeField43.getDifference((long) (byte) 1, (long) (byte) 10);
        long long50 = offsetDateTimeField43.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField43, (-28800000));
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = offsetDateTimeField43.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType53, (-43));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField25, dateTimeFieldType53, (int) 'a', (-28799985), 35);
        long long61 = remainderDateTimeField25.roundHalfEven(25945200220L);
        long long64 = remainderDateTimeField25.addWrapField((long) 200, 0);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 8 + "'", int35 == 8);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1L + "'", long45 == 1L);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1L + "'", long50 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 25945200001L + "'", long61 == 25945200001L);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 200L + "'", long64 == 200L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField7 = iSOChronology6.seconds();
        org.joda.time.DurationField durationField8 = iSOChronology6.halfdays();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone10.getName(99L, locale12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        int int15 = dateTimeZone10.getOffset(readableInstant14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        int int18 = cachedDateTimeZone16.getStandardOffset((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone16.getUncachedZone();
        boolean boolean20 = iSOChronology6.equals((java.lang.Object) cachedDateTimeZone16);
        org.joda.time.DurationField durationField21 = iSOChronology6.months();
        org.joda.time.Chronology chronology22 = iSOChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology6.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-00:00:00.001" + "'", str13.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        org.joda.time.Period period6 = period4.minusMillis(10);
        org.joda.time.Period period8 = period4.plusMinutes((int) (short) 1);
        org.joda.time.Period period10 = period4.plusDays(4);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.Period period10 = period6.plusHours((-25199800));
        org.joda.time.Weeks weeks11 = period6.toStandardWeeks();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(weeks11);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period7.minusHours((int) 'a');
        org.joda.time.PeriodType periodType10 = period9.getPeriodType();
        org.joda.time.PeriodType periodType11 = org.joda.time.DateTimeUtils.getPeriodType(periodType10);
        org.joda.time.PeriodType periodType12 = periodType10.withMonthsRemoved();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField11.getType();
        java.lang.String str13 = unsupportedDurationField11.getName();
        long long14 = unsupportedDurationField11.getUnitMillis();
        try {
            int int17 = unsupportedDurationField11.getDifference((-368326799612L), (-210863044800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "years" + "'", str13.equals("years"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-25199800), 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology3.yearOfCentury();
        org.joda.time.Chronology chronology9 = gregorianChronology3.withUTC();
        try {
            long long14 = gregorianChronology3.getDateTimeMillis((int) ' ', 99, 100, 98);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.Period period7 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) 'a', chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) '#');
        int int13 = period12.getHours();
        org.joda.time.Period period15 = period12.minusSeconds((int) '#');
        boolean boolean16 = period7.equals((java.lang.Object) period12);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Duration duration18 = period12.toDurationTo(readableInstant17);
        long long19 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration18);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableDuration22, readableInstant23);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType26 = periodType25.withWeeksRemoved();
        org.joda.time.PeriodType periodType27 = periodType25.withMinutesRemoved();
        org.joda.time.Period period28 = period24.withPeriodType(periodType25);
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) -1, periodType25);
        org.joda.time.Period period30 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration18, readableInstant20, periodType25);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType25, chronology31);
        org.joda.time.Period period36 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.Period period39 = new org.joda.time.Period((long) 'a', chronology38);
        org.joda.time.Period period41 = period39.minusMonths((int) '#');
        int int42 = period41.getHours();
        org.joda.time.Period period44 = period41.minusSeconds((int) '#');
        boolean boolean45 = period36.equals((java.lang.Object) period41);
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Duration duration47 = period41.toDurationTo(readableInstant46);
        long long48 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration47);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableDuration readableDuration51 = null;
        org.joda.time.ReadableInstant readableInstant52 = null;
        org.joda.time.Period period53 = new org.joda.time.Period(readableDuration51, readableInstant52);
        org.joda.time.PeriodType periodType54 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType55 = periodType54.withWeeksRemoved();
        org.joda.time.PeriodType periodType56 = periodType54.withMinutesRemoved();
        org.joda.time.Period period57 = period53.withPeriodType(periodType54);
        org.joda.time.Period period58 = new org.joda.time.Period((long) (short) -1, periodType54);
        org.joda.time.Period period59 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration47, readableInstant49, periodType54);
        org.joda.time.Chronology chronology60 = null;
        org.joda.time.Period period61 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType54, chronology60);
        java.lang.String str62 = periodType54.getName();
        org.joda.time.ReadableDuration readableDuration63 = null;
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.Period period65 = new org.joda.time.Period(readableDuration63, readableInstant64);
        org.joda.time.Chronology chronology68 = null;
        org.joda.time.Period period69 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology68);
        org.joda.time.Period period70 = period65.withFields((org.joda.time.ReadablePeriod) period69);
        org.joda.time.Period period71 = period69.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType73 = period69.getFieldType(0);
        int int74 = periodType54.indexOf(durationFieldType73);
        int int75 = periodType25.indexOf(durationFieldType73);
        org.joda.time.PeriodType periodType76 = periodType25.withHoursRemoved();
        org.joda.time.Period period77 = new org.joda.time.Period(1L, (long) 'a', periodType25);
        try {
            org.joda.time.Period period78 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-92015999903L) + "'", long19 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(duration47);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-92015999903L) + "'", long48 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType56);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Seconds" + "'", str62.equals("Seconds"));
        org.junit.Assert.assertNotNull(period70);
        org.junit.Assert.assertNotNull(period71);
        org.junit.Assert.assertNotNull(durationFieldType73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(periodType76);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.Period period1 = org.joda.time.Period.months(8);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getShortName((long) '#', locale3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.100" + "'", str4.equals("+00:00:00.100"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology3.minuteOfHour();
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 0, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.Period period11 = period9.minusDays((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period11.toDurationFrom(readableInstant12);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period16 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 'a', chronology18);
        org.joda.time.Period period21 = period19.minusMonths((int) '#');
        int int22 = period21.getHours();
        org.joda.time.Period period24 = period21.minusSeconds((int) '#');
        boolean boolean25 = period16.equals((java.lang.Object) period21);
        int[] intArray27 = gregorianChronology14.get((org.joda.time.ReadablePeriod) period21, 0L);
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration28, readableInstant29);
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology33);
        org.joda.time.Period period35 = period30.withFields((org.joda.time.ReadablePeriod) period34);
        org.joda.time.Period period36 = period34.normalizedStandard();
        org.joda.time.Period period38 = period34.plusYears((-100));
        org.joda.time.DurationFieldType durationFieldType40 = period34.getFieldType((int) (short) 0);
        boolean boolean41 = period21.isSupported(durationFieldType40);
        org.joda.time.PeriodType periodType42 = period21.getPeriodType();
        org.joda.time.Period period43 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration13, periodType42);
        org.joda.time.Period period47 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology49 = null;
        org.joda.time.Period period50 = new org.joda.time.Period((long) 'a', chronology49);
        org.joda.time.Period period52 = period50.minusMonths((int) '#');
        int int53 = period52.getHours();
        org.joda.time.Period period55 = period52.minusSeconds((int) '#');
        boolean boolean56 = period47.equals((java.lang.Object) period52);
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.Duration duration58 = period52.toDurationTo(readableInstant57);
        long long59 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration58);
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.ReadableDuration readableDuration62 = null;
        org.joda.time.ReadableInstant readableInstant63 = null;
        org.joda.time.Period period64 = new org.joda.time.Period(readableDuration62, readableInstant63);
        org.joda.time.PeriodType periodType65 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType66 = periodType65.withWeeksRemoved();
        org.joda.time.PeriodType periodType67 = periodType65.withMinutesRemoved();
        org.joda.time.Period period68 = period64.withPeriodType(periodType65);
        org.joda.time.Period period69 = new org.joda.time.Period((long) (short) -1, periodType65);
        org.joda.time.Period period70 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration58, readableInstant60, periodType65);
        org.joda.time.Chronology chronology71 = null;
        org.joda.time.Period period72 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType65, chronology71);
        java.lang.String str73 = periodType65.getName();
        org.joda.time.PeriodType periodType74 = periodType65.withMonthsRemoved();
        org.joda.time.PeriodType periodType75 = periodType65.withSecondsRemoved();
        org.joda.time.PeriodType periodType76 = periodType65.withMillisRemoved();
        org.joda.time.PeriodType periodType77 = periodType65.withMinutesRemoved();
        org.joda.time.Period period78 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration13, periodType77);
        int int79 = period78.getDays();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(periodType42);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(duration58);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-92015999903L) + "'", long59 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType65);
        org.junit.Assert.assertNotNull(periodType66);
        org.junit.Assert.assertNotNull(periodType67);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "Seconds" + "'", str73.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType74);
        org.junit.Assert.assertNotNull(periodType75);
        org.junit.Assert.assertNotNull(periodType76);
        org.junit.Assert.assertNotNull(periodType77);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.yearOfEra();
        org.joda.time.DurationField durationField9 = gregorianChronology0.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 130L, (java.lang.Number) 130L, (java.lang.Number) 100);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period2 = new org.joda.time.Period((long) 4, periodType1);
        org.joda.time.DurationFieldType durationFieldType4 = periodType1.getFieldType(0);
        org.joda.time.PeriodType periodType5 = periodType1.withDaysRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withMillisRemoved();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        long long11 = offsetDateTimeField6.addWrapField(11L, 98);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 11L + "'", long11 == 11L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
        long long13 = offsetDateTimeField6.roundHalfEven((long) 35);
        long long16 = offsetDateTimeField6.add((long) 10, (long) 99);
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField6.getMaximumTextLength(locale17);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 8553600010L + "'", long16 == 8553600010L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.Chronology chronology10 = iSOChronology6.withZone(dateTimeZone9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[America/Los_Angeles]", "", (int) '#', 100);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        long long18 = fixedDateTimeZone15.getMillisKeepLocal(dateTimeZone16, (long) 'a');
        org.joda.time.Chronology chronology19 = iSOChronology6.withZone(dateTimeZone16);
        long long23 = iSOChronology6.add(345600000L, (long) ' ', (-28799985));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 133L + "'", long18 == 133L);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-575999520L) + "'", long23 == (-575999520L));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.millisOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 4, (-92015999903L), (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period7 = period5.plusHours((int) (short) -1);
        try {
            org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        int int3 = period2.getMinutes();
        int int4 = period2.size();
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period2.getFieldTypes();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.forFields(durationFieldTypeArray5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfDay();
        java.lang.Object obj3 = null;
        boolean boolean4 = iSOChronology1.equals(obj3);
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.millisOfSecond();
        org.joda.time.DurationField durationField7 = iSOChronology1.millis();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfHour();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Period period9 = period7.minusDays((int) (short) 1);
        int int10 = period7.getMinutes();
        try {
            int int12 = period7.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
        long long12 = offsetDateTimeField6.roundHalfCeiling(0L);
        long long15 = offsetDateTimeField6.add((long) 8, (long) 0);
        org.joda.time.DurationField durationField16 = offsetDateTimeField6.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 8L + "'", long15 == 8L);
        org.junit.Assert.assertNull(durationField16);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = new org.joda.time.Period(99L, (long) 1, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.halfdayOfDay();
        org.joda.time.DurationField durationField5 = iSOChronology2.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology2.withZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DurationField durationField8 = gregorianChronology3.weeks();
        long long12 = gregorianChronology3.add(0L, 0L, 10);
        java.lang.String str13 = gregorianChronology3.toString();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[UTC]" + "'", str13.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = new org.joda.time.Period(99L, (long) 1, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration4, readableInstant5);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology9);
        org.joda.time.Period period11 = period6.withFields((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period12 = period10.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType14 = period10.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField15 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType14);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField16 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType14);
        int int17 = period3.get(durationFieldType14);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertNotNull(unsupportedDurationField15);
        org.junit.Assert.assertNotNull(unsupportedDurationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfDay();
        java.lang.Object obj3 = null;
        boolean boolean4 = iSOChronology1.equals(obj3);
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Period period7 = period5.plusHours(100);
        org.joda.time.Hours hours8 = period7.toStandardHours();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(hours8);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.minusWeeks((int) '#');
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField7 = iSOChronology6.seconds();
        org.joda.time.DurationField durationField8 = iSOChronology6.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.millisOfDay();
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder11.toDateTimeZone("-00:00:00.001", true);
        org.joda.time.Chronology chronology15 = lenientChronology10.withZone(dateTimeZone14);
        org.joda.time.Chronology chronology16 = lenientChronology10.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology7);
        org.joda.time.Period period9 = period4.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period11 = period4.withMillis((int) (short) 100);
        org.joda.time.Period period12 = period1.withFields((org.joda.time.ReadablePeriod) period11);
        org.joda.time.Minutes minutes13 = period11.toStandardMinutes();
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.Period period16 = period11.minusMillis((int) (byte) 0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(minutes13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[America/Los_Angeles]", "", (int) '#', 100);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        long long7 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone5, (long) 'a');
        long long9 = fixedDateTimeZone4.nextTransition(2488331404800008L);
        long long11 = fixedDateTimeZone4.nextTransition(0L);
        java.util.TimeZone timeZone12 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 132L + "'", long7 == 132L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2488331404800008L + "'", long9 == 2488331404800008L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField6 = gregorianChronology0.minutes();
        org.joda.time.Period period8 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology14);
        org.joda.time.Period period16 = period11.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period18 = period11.withMillis((int) (short) 100);
        org.joda.time.Period period19 = period8.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology25);
        org.joda.time.Period period27 = period22.withFields((org.joda.time.ReadablePeriod) period26);
        org.joda.time.Period period28 = period26.normalizedStandard();
        org.joda.time.Period period30 = period26.plusYears((-100));
        org.joda.time.DurationFieldType durationFieldType32 = period26.getFieldType((int) (short) 0);
        int int33 = period18.indexOf(durationFieldType32);
        org.joda.time.field.DecoratedDurationField decoratedDurationField34 = new org.joda.time.field.DecoratedDurationField(durationField6, durationFieldType32);
        int int36 = decoratedDurationField34.getValue((long) (-15));
        org.joda.time.DurationField durationField37 = decoratedDurationField34.getWrappedField();
        int int40 = decoratedDurationField34.getDifference((long) 1131, (-575999520L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 9600 + "'", int40 == 9600);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField6 = gregorianChronology0.minutes();
        org.joda.time.DurationField durationField7 = gregorianChronology0.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Hours hours8 = period7.toStandardHours();
        org.joda.time.Period period10 = org.joda.time.Period.seconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.secondOfMinute();
        int int13 = gregorianChronology11.getMinimumDaysInFirstWeek();
        int int14 = gregorianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology11.weeks();
        org.joda.time.DurationField durationField16 = gregorianChronology11.hours();
        java.lang.String str17 = gregorianChronology11.toString();
        org.joda.time.Period period19 = org.joda.time.Period.weeks((-1));
        int[] intArray22 = gregorianChronology11.get((org.joda.time.ReadablePeriod) period19, (long) 'a', (long) 10);
        org.joda.time.Period period23 = period10.withFields((org.joda.time.ReadablePeriod) period19);
        org.joda.time.Period period24 = period7.minus((org.joda.time.ReadablePeriod) period10);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(hours8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[UTC]" + "'", str17.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        org.joda.time.Period period3 = new org.joda.time.Period(0L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableDuration7, readableInstant8);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType11 = periodType10.withWeeksRemoved();
        org.joda.time.PeriodType periodType12 = periodType10.withMinutesRemoved();
        org.joda.time.Period period13 = period9.withPeriodType(periodType10);
        org.joda.time.Period period14 = new org.joda.time.Period((long) (short) -1, periodType10);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableDuration15, readableInstant16);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType19 = periodType18.withWeeksRemoved();
        org.joda.time.PeriodType periodType20 = periodType18.withMinutesRemoved();
        org.joda.time.Period period21 = period17.withPeriodType(periodType18);
        org.joda.time.Period period22 = period14.withPeriodType(periodType18);
        org.joda.time.Period period23 = new org.joda.time.Period((long) (-1), (long) (-1), periodType18);
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period(readableDuration24, readableInstant25);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology29);
        org.joda.time.Period period31 = period26.withFields((org.joda.time.ReadablePeriod) period30);
        org.joda.time.Period period32 = period30.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType34 = period30.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField35 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType34);
        org.joda.time.DurationFieldType durationFieldType36 = unsupportedDurationField35.getType();
        int int37 = periodType18.indexOf(durationFieldType36);
        int int38 = period3.indexOf(durationFieldType36);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(unsupportedDurationField35);
        org.junit.Assert.assertNotNull(durationFieldType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int7 = offsetDateTimeField6.getOffset();
        org.joda.time.DurationField durationField8 = offsetDateTimeField6.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        int int11 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology9.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 8);
        long long17 = offsetDateTimeField15.roundHalfEven((long) 100);
        int int20 = offsetDateTimeField15.getDifference((long) (byte) 1, (long) (byte) 10);
        long long22 = offsetDateTimeField15.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, (-28800000));
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField15.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType25, (-43));
        org.joda.time.DateTimeField dateTimeField28 = offsetDateTimeField27.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField7 = iSOChronology6.seconds();
        org.joda.time.DurationField durationField8 = iSOChronology6.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.millisOfDay();
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder11.toDateTimeZone("-00:00:00.001", true);
        org.joda.time.Chronology chronology15 = lenientChronology10.withZone(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = lenientChronology10.getZone();
        org.joda.time.DurationField durationField17 = lenientChronology10.hours();
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology23);
        org.joda.time.Period period25 = period20.withFields((org.joda.time.ReadablePeriod) period24);
        int int26 = period24.getWeeks();
        org.joda.time.Period period28 = org.joda.time.Period.millis(10);
        boolean boolean29 = period24.equals((java.lang.Object) period28);
        boolean boolean30 = lenientChronology10.equals((java.lang.Object) period24);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfEra();
        org.joda.time.ReadablePartial readablePartial5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration6, readableInstant7);
        int int9 = period8.getMinutes();
        int int10 = period8.size();
        org.joda.time.Period period12 = org.joda.time.Period.seconds(43);
        org.joda.time.Period period13 = period8.minus((org.joda.time.ReadablePeriod) period12);
        int[] intArray14 = period12.getValues();
        try {
            gregorianChronology0.validate(readablePartial5, intArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.joda.time.Period period4 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', chronology6);
        org.joda.time.Period period9 = period7.minusMonths((int) '#');
        int int10 = period9.getHours();
        org.joda.time.Period period12 = period9.minusSeconds((int) '#');
        boolean boolean13 = period4.equals((java.lang.Object) period9);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period9.toDurationTo(readableInstant14);
        long long16 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableDuration19, readableInstant20);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType23 = periodType22.withWeeksRemoved();
        org.joda.time.PeriodType periodType24 = periodType22.withMinutesRemoved();
        org.joda.time.Period period25 = period21.withPeriodType(periodType22);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) -1, periodType22);
        org.joda.time.Period period27 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration15, readableInstant17, periodType22);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType22, chronology28);
        java.lang.String str30 = periodType22.getName();
        org.joda.time.PeriodType periodType31 = periodType22.withMonthsRemoved();
        org.joda.time.PeriodType periodType32 = periodType22.withSecondsRemoved();
        org.joda.time.PeriodType periodType33 = periodType22.withMillisRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology35 = gregorianChronology34.withUTC();
        org.joda.time.Period period36 = new org.joda.time.Period((-864000010L), periodType22, (org.joda.time.Chronology) gregorianChronology34);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-92015999903L) + "'", long16 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Seconds" + "'", str30.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(chronology35);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField6 = gregorianChronology0.minutes();
        org.joda.time.Period period8 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology14);
        org.joda.time.Period period16 = period11.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period18 = period11.withMillis((int) (short) 100);
        org.joda.time.Period period19 = period8.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology25);
        org.joda.time.Period period27 = period22.withFields((org.joda.time.ReadablePeriod) period26);
        org.joda.time.Period period28 = period26.normalizedStandard();
        org.joda.time.Period period30 = period26.plusYears((-100));
        org.joda.time.DurationFieldType durationFieldType32 = period26.getFieldType((int) (short) 0);
        int int33 = period18.indexOf(durationFieldType32);
        org.joda.time.field.DecoratedDurationField decoratedDurationField34 = new org.joda.time.field.DecoratedDurationField(durationField6, durationFieldType32);
        org.joda.time.DurationFieldType durationFieldType35 = decoratedDurationField34.getType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(durationFieldType35);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.Period period11 = period9.plusWeeks((int) (byte) 100);
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(duration12);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology7);
        org.joda.time.Period period9 = period4.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period11 = period4.withMillis((int) (short) 100);
        org.joda.time.Period period12 = period1.withFields((org.joda.time.ReadablePeriod) period11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period12.toDurationTo(readableInstant13);
        org.joda.time.Period period16 = period12.minusHours(100);
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableDuration17, readableInstant18);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology22);
        org.joda.time.Period period24 = period19.withFields((org.joda.time.ReadablePeriod) period23);
        org.joda.time.Period period25 = period23.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType27 = period23.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        org.joda.time.ReadableDuration readableDuration29 = null;
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period(readableDuration29, readableInstant30);
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology34);
        org.joda.time.Period period36 = period31.withFields((org.joda.time.ReadablePeriod) period35);
        org.joda.time.Period period37 = period35.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType39 = period35.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField40 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType39);
        int int41 = unsupportedDurationField28.compareTo((org.joda.time.DurationField) unsupportedDurationField40);
        org.joda.time.DurationFieldType durationFieldType42 = unsupportedDurationField28.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType42, "Seconds");
        int int45 = period16.indexOf(durationFieldType42);
        int int46 = period16.getHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertNotNull(unsupportedDurationField40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(durationFieldType42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-100) + "'", int46 == (-100));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[America/Los_Angeles]", "", (int) '#', 100);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        long long7 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone5, (long) 'a');
        long long9 = fixedDateTimeZone4.nextTransition(2488331404800008L);
        long long11 = fixedDateTimeZone4.convertUTCToLocal((long) 98);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 132L + "'", long7 == 132L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2488331404800008L + "'", long9 == 2488331404800008L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 133L + "'", long11 == 133L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        long long27 = remainderDateTimeField25.roundHalfFloor((long) 0);
        int int29 = remainderDateTimeField25.get(86400000L);
        int int30 = remainderDateTimeField25.getMaximumValue();
        int int32 = remainderDateTimeField25.get((-259199999L));
        int int33 = remainderDateTimeField25.getMaximumValue();
        boolean boolean34 = remainderDateTimeField25.isLenient();
        long long36 = remainderDateTimeField25.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 98 + "'", int30 == 98);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 98 + "'", int33 == 98);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test382");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (short) 0);
//        boolean boolean9 = dateTimeZone5.isStandardOffset(1L);
//        java.lang.String str11 = dateTimeZone5.getName(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
//        java.lang.Object obj13 = null;
//        boolean boolean14 = zonedChronology12.equals(obj13);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone16.getName(99L, locale18);
//        org.joda.time.ReadableInstant readableInstant20 = null;
//        int int21 = dateTimeZone16.getOffset(readableInstant20);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
//        int int24 = cachedDateTimeZone22.getStandardOffset(20L);
//        boolean boolean25 = cachedDateTimeZone22.isFixed();
//        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.ReadableInstant readableInstant28 = null;
//        org.joda.time.Period period29 = new org.joda.time.Period(readableDuration27, readableInstant28);
//        org.joda.time.Chronology chronology32 = null;
//        org.joda.time.Period period33 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology32);
//        org.joda.time.Period period34 = period29.withFields((org.joda.time.ReadablePeriod) period33);
//        org.joda.time.Period period36 = period29.withMillis((int) (short) 100);
//        org.joda.time.ReadableInstant readableInstant37 = null;
//        org.joda.time.Duration duration38 = period29.toDurationFrom(readableInstant37);
//        int[] intArray40 = zonedChronology12.get((org.joda.time.ReadablePeriod) period29, 36000100L);
//        org.joda.time.ReadablePartial readablePartial41 = null;
//        try {
//            long long43 = zonedChronology12.set(readablePartial41, (long) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(period34);
//        org.junit.Assert.assertNotNull(period36);
//        org.junit.Assert.assertNotNull(duration38);
//        org.junit.Assert.assertNotNull(intArray40);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        long long27 = remainderDateTimeField25.roundHalfFloor((long) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.secondOfMinute();
        int int30 = gregorianChronology28.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology28.millisOfDay();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology28.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, 8);
        int int35 = offsetDateTimeField34.getOffset();
        org.joda.time.DurationField durationField36 = offsetDateTimeField34.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.secondOfMinute();
        int int39 = gregorianChronology37.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.millisOfDay();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, 8);
        long long45 = offsetDateTimeField43.roundHalfEven((long) 100);
        int int48 = offsetDateTimeField43.getDifference((long) (byte) 1, (long) (byte) 10);
        long long50 = offsetDateTimeField43.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField43, (-28800000));
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = offsetDateTimeField43.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType53, (-43));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField25, dateTimeFieldType53, (int) 'a', (-28799985), 35);
        long long61 = remainderDateTimeField25.roundHalfEven(25945200220L);
        long long63 = remainderDateTimeField25.remainder((long) '4');
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 8 + "'", int35 == 8);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 25945200000L + "'", long61 == 25945200000L);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 52L + "'", long63 == 52L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-28800000));
        long long17 = offsetDateTimeField15.roundHalfEven(86400000L);
        int int18 = offsetDateTimeField15.getOffset();
        long long20 = offsetDateTimeField15.roundCeiling(172800000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86400000L + "'", long17 == 86400000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800000) + "'", int18 == (-28800000));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 172800000L + "'", long20 == 172800000L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.Chronology chronology10 = iSOChronology6.withZone(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.dayOfYear();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.yearOfEra();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology11.weekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int7 = offsetDateTimeField6.getOffset();
        org.joda.time.DurationField durationField8 = offsetDateTimeField6.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField6.getAsText(readablePartial9, 0, locale11);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.remainder((long) (byte) 1);
        java.lang.String str9 = offsetDateTimeField6.getName();
        int int11 = offsetDateTimeField6.getMinimumValue(86400000L);
        java.lang.String str13 = offsetDateTimeField6.getAsShortText((-575999520L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "dayOfWeek" + "'", str9.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "12" + "'", str13.equals("12"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-368326799612L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-9223372036854775808L) + "'", long1 == (-9223372036854775808L));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (short) 100, "PT0.097S");
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 0, "Seconds");
        org.joda.time.IllegalInstantException illegalInstantException5 = new org.joda.time.IllegalInstantException((long) 0, "Seconds");
        illegalInstantException2.addSuppressed((java.lang.Throwable) illegalInstantException5);
        java.lang.Throwable[] throwableArray7 = illegalInstantException5.getSuppressed();
        java.lang.String str8 = illegalInstantException5.toString();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (Seconds)" + "'", str8.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (Seconds)"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (Seconds)");
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField6 = gregorianChronology0.minutes();
        org.joda.time.Period period8 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology14);
        org.joda.time.Period period16 = period11.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period18 = period11.withMillis((int) (short) 100);
        org.joda.time.Period period19 = period8.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology25);
        org.joda.time.Period period27 = period22.withFields((org.joda.time.ReadablePeriod) period26);
        org.joda.time.Period period28 = period26.normalizedStandard();
        org.joda.time.Period period30 = period26.plusYears((-100));
        org.joda.time.DurationFieldType durationFieldType32 = period26.getFieldType((int) (short) 0);
        int int33 = period18.indexOf(durationFieldType32);
        org.joda.time.field.DecoratedDurationField decoratedDurationField34 = new org.joda.time.field.DecoratedDurationField(durationField6, durationFieldType32);
        int int36 = decoratedDurationField34.getValue((long) (-15));
        long long37 = decoratedDurationField34.getUnitMillis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 60000L + "'", long37 == 60000L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.Period period3 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration4, readableInstant5);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology9);
        org.joda.time.Period period11 = period6.withFields((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period13 = period6.withMillis((int) (short) 100);
        org.joda.time.Period period14 = period3.withFields((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period16 = period3.plusSeconds(10);
        org.joda.time.Period period18 = period3.minusHours((int) ' ');
        org.joda.time.Period period20 = period18.minusHours((-28800000));
        boolean boolean21 = gregorianChronology0.equals((java.lang.Object) period18);
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeZone22);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period3 = period2.normalizedStandard();
        org.joda.time.Period period5 = period3.minusMonths((int) (byte) -1);
        org.joda.time.Period period7 = period3.minusMillis((int) '#');
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.joda.time.Period period1 = new org.joda.time.Period((long) ' ');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology7);
        org.joda.time.Period period9 = period4.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period11 = period4.withMillis((int) (short) 100);
        org.joda.time.Period period13 = period11.withDays((int) 'a');
        org.joda.time.Period period15 = period13.minusMonths(0);
        org.joda.time.Period period16 = period1.minus((org.joda.time.ReadablePeriod) period13);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-28800000));
        long long17 = offsetDateTimeField15.roundHalfEven(86400000L);
        int int18 = offsetDateTimeField15.getOffset();
        long long20 = offsetDateTimeField15.roundHalfCeiling(99L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86400000L + "'", long17 == 86400000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800000) + "'", int18 == (-28800000));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[America/Los_Angeles]", "", (int) '#', 100);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        long long7 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone5, (long) 'a');
        java.lang.String str9 = fixedDateTimeZone4.getNameKey((long) '4');
        int int11 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.util.TimeZone timeZone12 = fixedDateTimeZone4.toTimeZone();
        long long14 = fixedDateTimeZone4.previousTransition(130L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 132L + "'", long7 == 132L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 130L + "'", long14 == 130L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.remainder((long) (byte) 1);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumShortTextLength(locale9);
        org.joda.time.DurationField durationField11 = offsetDateTimeField6.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField6.getMinimumValue(readablePartial12);
        long long15 = offsetDateTimeField6.roundFloor(52L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.era();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.joda.time.Period period3 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', chronology5);
        org.joda.time.Period period8 = period6.minusMonths((int) '#');
        int int9 = period8.getHours();
        org.joda.time.Period period11 = period8.minusSeconds((int) '#');
        boolean boolean12 = period3.equals((java.lang.Object) period8);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period8.toDurationTo(readableInstant13);
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withWeeksRemoved();
        org.joda.time.PeriodType periodType23 = periodType21.withMinutesRemoved();
        org.joda.time.Period period24 = period20.withPeriodType(periodType21);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) -1, periodType21);
        org.joda.time.Period period26 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant16, periodType21);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType21, chronology27);
        org.joda.time.Period period32 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period((long) 'a', chronology34);
        org.joda.time.Period period37 = period35.minusMonths((int) '#');
        int int38 = period37.getHours();
        org.joda.time.Period period40 = period37.minusSeconds((int) '#');
        boolean boolean41 = period32.equals((java.lang.Object) period37);
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.Duration duration43 = period37.toDurationTo(readableInstant42);
        long long44 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration43);
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.ReadableDuration readableDuration47 = null;
        org.joda.time.ReadableInstant readableInstant48 = null;
        org.joda.time.Period period49 = new org.joda.time.Period(readableDuration47, readableInstant48);
        org.joda.time.PeriodType periodType50 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType51 = periodType50.withWeeksRemoved();
        org.joda.time.PeriodType periodType52 = periodType50.withMinutesRemoved();
        org.joda.time.Period period53 = period49.withPeriodType(periodType50);
        org.joda.time.Period period54 = new org.joda.time.Period((long) (short) -1, periodType50);
        org.joda.time.Period period55 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration43, readableInstant45, periodType50);
        org.joda.time.Chronology chronology56 = null;
        org.joda.time.Period period57 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType50, chronology56);
        java.lang.String str58 = periodType50.getName();
        org.joda.time.ReadableDuration readableDuration59 = null;
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.Period period61 = new org.joda.time.Period(readableDuration59, readableInstant60);
        org.joda.time.Chronology chronology64 = null;
        org.joda.time.Period period65 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology64);
        org.joda.time.Period period66 = period61.withFields((org.joda.time.ReadablePeriod) period65);
        org.joda.time.Period period67 = period65.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType69 = period65.getFieldType(0);
        int int70 = periodType50.indexOf(durationFieldType69);
        int int71 = periodType21.indexOf(durationFieldType69);
        org.joda.time.IllegalFieldValueException illegalFieldValueException75 = new org.joda.time.IllegalFieldValueException(durationFieldType69, (java.lang.Number) 9, (java.lang.Number) (-1L), (java.lang.Number) 100.0d);
        org.joda.time.IllegalFieldValueException illegalFieldValueException78 = new org.joda.time.IllegalFieldValueException("", "hi!");
        illegalFieldValueException75.addSuppressed((java.lang.Throwable) illegalFieldValueException78);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-92015999903L) + "'", long15 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(duration43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-92015999903L) + "'", long44 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType50);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Seconds" + "'", str58.equals("Seconds"));
        org.junit.Assert.assertNotNull(period66);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(durationFieldType69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 99);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period12 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) 'a', chronology14);
        org.joda.time.Period period17 = period15.minusMonths((int) '#');
        int int18 = period17.getHours();
        org.joda.time.Period period20 = period17.minusSeconds((int) '#');
        boolean boolean21 = period12.equals((java.lang.Object) period17);
        int[] intArray23 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period17, 0L);
        int int24 = offsetDateTimeField6.getMinimumValue(readablePartial9, intArray23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField6.getAsText(readablePartial25, 0, locale27);
        long long30 = offsetDateTimeField6.remainder((long) 2);
        int int31 = offsetDateTimeField6.getMinimumValue();
        org.joda.time.DurationField durationField32 = offsetDateTimeField6.getDurationField();
        java.lang.String str34 = offsetDateTimeField6.getAsText(691200132L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2L + "'", long30 == 2L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 9 + "'", int31 == 9);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13" + "'", str34.equals("13"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration6, readableInstant7);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology11);
        org.joda.time.Period period13 = period8.withFields((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period15 = period8.withMillis((int) (short) 100);
        org.joda.time.Period period17 = period15.withDays((int) 'a');
        int int18 = period15.size();
        org.joda.time.Period period20 = period15.plusYears((int) (short) -1);
        int[] intArray23 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period15, (long) 'a', (long) 'a');
        org.joda.time.Period period25 = period15.minusMonths((-1));
        int int26 = period25.getWeeks();
        org.joda.time.Period period28 = period25.plusMillis((-25200000));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(period28);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        int int2 = period1.getMonths();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField3 = gregorianChronology2.eras();
        org.joda.time.Period period5 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration6, readableInstant7);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology11);
        org.joda.time.Period period13 = period8.withFields((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period15 = period8.withMillis((int) (short) 100);
        org.joda.time.Period period16 = period5.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period18 = period5.plusSeconds(10);
        org.joda.time.Period period20 = period5.minusHours((int) ' ');
        org.joda.time.Period period22 = period20.minusHours((-28800000));
        boolean boolean23 = gregorianChronology2.equals((java.lang.Object) period20);
        org.joda.time.Period period24 = new org.joda.time.Period((long) 9, 1439L, (org.joda.time.Chronology) gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.joda.time.Period period3 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', chronology5);
        org.joda.time.Period period8 = period6.minusMonths((int) '#');
        int int9 = period8.getHours();
        org.joda.time.Period period11 = period8.minusSeconds((int) '#');
        boolean boolean12 = period3.equals((java.lang.Object) period8);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period8.toDurationTo(readableInstant13);
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withWeeksRemoved();
        org.joda.time.PeriodType periodType23 = periodType21.withMinutesRemoved();
        org.joda.time.Period period24 = period20.withPeriodType(periodType21);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) -1, periodType21);
        org.joda.time.Period period26 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant16, periodType21);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType21, chronology27);
        java.lang.String str29 = periodType21.getName();
        org.joda.time.PeriodType periodType30 = periodType21.withMonthsRemoved();
        org.joda.time.PeriodType periodType31 = periodType21.withSecondsRemoved();
        org.joda.time.PeriodType periodType32 = periodType21.withMillisRemoved();
        org.joda.time.PeriodType periodType33 = periodType21.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType35 = periodType21.getFieldType(0);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-92015999903L) + "'", long15 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Seconds" + "'", str29.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(durationFieldType35);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology0.minutes();
        org.joda.time.DurationField durationField4 = iSOChronology0.years();
        org.joda.time.DurationField durationField5 = iSOChronology0.days();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "GregorianChronology[America/Los_Angeles]", 0, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) -1);
        int int8 = fixedDateTimeZone4.getStandardOffset(2L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset((long) 'a');
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        org.joda.time.ReadableInterval readableInterval12 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        boolean boolean13 = cachedDateTimeZone7.equals((java.lang.Object) readableInterval10);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        int int16 = cachedDateTimeZone7.getOffset((long) (byte) 100);
        long long19 = cachedDateTimeZone7.convertLocalToUTC(259200001L, true);
        boolean boolean20 = cachedDateTimeZone7.isFixed();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(readableInterval11);
        org.junit.Assert.assertNotNull(readableInterval12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 259200002L + "'", long19 == 259200002L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(iSOChronology21);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology0.seconds();
        org.joda.time.Period period5 = org.joda.time.Period.months((int) (short) 1);
        long long8 = iSOChronology0.add((org.joda.time.ReadablePeriod) period5, (long) (short) 10, 0);
        try {
            long long14 = iSOChronology0.getDateTimeMillis((long) (-1), (int) ' ', (-25200000), 9, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        org.joda.time.Period period6 = period4.minusMillis(10);
        org.joda.time.Period period7 = period4.toPeriod();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        int int12 = cachedDateTimeZone10.getStandardOffset((long) 9700);
        org.joda.time.ReadableInstant readableInstant13 = null;
        int int14 = cachedDateTimeZone10.getOffset(readableInstant13);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology0.seconds();
        org.joda.time.Period period5 = org.joda.time.Period.months((int) (short) 1);
        long long8 = iSOChronology0.add((org.joda.time.ReadablePeriod) period5, (long) (short) 10, 0);
        org.joda.time.Period period10 = period5.withMillis(0);
        org.joda.time.Period period11 = period5.negated();
        org.joda.time.Period period13 = period5.withSeconds(0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-28800000));
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField15.getAsText(readablePartial16, 8, locale18);
        java.lang.String str20 = offsetDateTimeField15.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "8" + "'", str19.equals("8"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[dayOfWeek]" + "'", str20.equals("DateTimeField[dayOfWeek]"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-28800000));
        long long17 = offsetDateTimeField15.roundCeiling(133L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86400001L + "'", long17 == 86400001L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period2.toDurationFrom(readableInstant10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period21 = period14.withMillis((int) (short) 100);
        org.joda.time.Period period23 = period21.withDays((int) 'a');
        int int24 = period21.size();
        org.joda.time.Period period25 = period2.minus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period27 = period21.withMillis((int) (short) 1);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((-25199800));
        int int2 = period1.getWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-25199800) + "'", int2 == (-25199800));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfDay();
        java.lang.Object obj3 = null;
        boolean boolean4 = iSOChronology1.equals(obj3);
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Period period7 = period5.plusHours(100);
        org.joda.time.Period period9 = period5.withHours((int) (short) 0);
        int[] intArray10 = period5.getValues();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 1);
        org.joda.time.Seconds seconds2 = period1.toStandardSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(seconds2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period12 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) 'a', chronology14);
        org.joda.time.Period period17 = period15.minusMonths((int) '#');
        int int18 = period17.getHours();
        org.joda.time.Period period20 = period17.minusSeconds((int) '#');
        boolean boolean21 = period12.equals((java.lang.Object) period17);
        int[] intArray23 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period17, 0L);
        int int24 = offsetDateTimeField6.getMinimumValue(readablePartial9, intArray23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField6.getAsText(readablePartial25, 0, locale27);
        long long31 = offsetDateTimeField6.addWrapField((-92015999893L), 1);
        int int32 = offsetDateTimeField6.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-91929599893L) + "'", long31 == (-91929599893L));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int7 = offsetDateTimeField6.getOffset();
        java.lang.String str9 = offsetDateTimeField6.getAsShortText(99L);
        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField6.getWrappedField();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField6.getType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "12" + "'", str9.equals("12"));
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = new org.joda.time.Period(99L, (long) 1, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.halfdayOfDay();
        org.joda.time.DurationField durationField5 = iSOChronology2.minutes();
        org.joda.time.DurationField durationField6 = iSOChronology2.years();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        int int2 = periodType1.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period2.toDurationFrom(readableInstant10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period21 = period14.withMillis((int) (short) 100);
        org.joda.time.Period period23 = period21.withDays((int) 'a');
        int int24 = period21.size();
        org.joda.time.Period period25 = period2.minus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period26 = period25.toPeriod();
        int int27 = period25.getMillis();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-100) + "'", int27 == (-100));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        int int3 = period2.getMinutes();
        int int4 = period2.size();
        org.joda.time.Period period6 = org.joda.time.Period.seconds(43);
        org.joda.time.Period period7 = period2.minus((org.joda.time.ReadablePeriod) period6);
        int[] intArray8 = period6.getValues();
        org.joda.time.Period period10 = period6.minusMinutes(1);
        int int11 = period6.getMillis();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (byte) 100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withMinutesRemoved();
        org.joda.time.PeriodType periodType3 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withDaysRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str7 = illegalFieldValueException2.getFieldName();
        java.lang.Number number8 = illegalFieldValueException2.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str10 = illegalFieldValueException2.toString();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported" + "'", str10.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.joda.time.Period period2 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) '#');
        int int8 = period7.getHours();
        org.joda.time.Period period10 = period7.minusSeconds((int) '#');
        boolean boolean11 = period2.equals((java.lang.Object) period7);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period7.toDurationTo(readableInstant12);
        long long14 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration13);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableDuration17, readableInstant18);
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType21 = periodType20.withWeeksRemoved();
        org.joda.time.PeriodType periodType22 = periodType20.withMinutesRemoved();
        org.joda.time.Period period23 = period19.withPeriodType(periodType20);
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType20);
        org.joda.time.Period period25 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration13, readableInstant15, periodType20);
        org.joda.time.Period period26 = new org.joda.time.Period((-1295999948L), periodType20);
        org.joda.time.format.PeriodFormatter periodFormatter27 = null;
        java.lang.String str28 = period26.toString(periodFormatter27);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-92015999903L) + "'", long14 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "PT-1295999S" + "'", str28.equals("PT-1295999S"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        org.joda.time.PeriodType periodType6 = periodType4.withMinutesRemoved();
        org.joda.time.Period period7 = period3.withPeriodType(periodType4);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) -1, periodType4);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType13 = periodType12.withWeeksRemoved();
        org.joda.time.PeriodType periodType14 = periodType12.withMinutesRemoved();
        org.joda.time.Period period15 = period11.withPeriodType(periodType12);
        org.joda.time.Period period16 = period8.withPeriodType(periodType12);
        java.lang.String str17 = periodType12.toString();
        org.joda.time.PeriodType periodType18 = periodType12.withMillisRemoved();
        org.joda.time.PeriodType periodType19 = periodType12.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PeriodType[Seconds]" + "'", str17.equals("PeriodType[Seconds]"));
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        java.lang.String str6 = gregorianChronology0.toString();
        org.joda.time.Period period8 = org.joda.time.Period.weeks((-1));
        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period8, (long) 'a', (long) 10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.weekOfWeekyear();
        boolean boolean14 = gregorianChronology0.equals((java.lang.Object) (short) 1);
        java.lang.String str15 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str15.equals("GregorianChronology[-00:00:00.001]"));
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test432");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (short) 0);
//        boolean boolean9 = dateTimeZone5.isStandardOffset(1L);
//        java.lang.String str11 = dateTimeZone5.getName(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
//        java.lang.Object obj13 = null;
//        boolean boolean14 = zonedChronology12.equals(obj13);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone16.getName(99L, locale18);
//        org.joda.time.ReadableInstant readableInstant20 = null;
//        int int21 = dateTimeZone16.getOffset(readableInstant20);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
//        int int24 = cachedDateTimeZone22.getStandardOffset(20L);
//        boolean boolean25 = cachedDateTimeZone22.isFixed();
//        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.ReadableInstant readableInstant28 = null;
//        org.joda.time.Period period29 = new org.joda.time.Period(readableDuration27, readableInstant28);
//        org.joda.time.Chronology chronology32 = null;
//        org.joda.time.Period period33 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology32);
//        org.joda.time.Period period34 = period29.withFields((org.joda.time.ReadablePeriod) period33);
//        org.joda.time.Period period36 = period29.withMillis((int) (short) 100);
//        org.joda.time.ReadableInstant readableInstant37 = null;
//        org.joda.time.Duration duration38 = period29.toDurationFrom(readableInstant37);
//        int[] intArray40 = zonedChronology12.get((org.joda.time.ReadablePeriod) period29, 36000100L);
//        org.joda.time.DateTimeField dateTimeField41 = zonedChronology12.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str44 = dateTimeZone42.getName((long) (byte) 10);
//        org.joda.time.Chronology chronology45 = zonedChronology12.withZone(dateTimeZone42);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(period34);
//        org.junit.Assert.assertNotNull(period36);
//        org.junit.Assert.assertNotNull(duration38);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Coordinated Universal Time" + "'", str44.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology45);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.joda.time.Period period4 = new org.joda.time.Period(0, (int) (short) 100, 0, (int) ' ');
        int int5 = period4.size();
        org.joda.time.Period period7 = period4.withDays((int) (short) 0);
        org.joda.time.Period period9 = period7.plusDays(13);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period3 = period2.normalizedStandard();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration4, readableInstant5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType8 = periodType7.withWeeksRemoved();
        org.joda.time.PeriodType periodType9 = periodType7.withMinutesRemoved();
        org.joda.time.Period period10 = period6.withPeriodType(periodType7);
        org.joda.time.Period period11 = period2.withFields((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period13 = period2.minusMinutes(9700);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType1 = periodType0.withMillisRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField6 = gregorianChronology0.minutes();
        org.joda.time.Period period8 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology14);
        org.joda.time.Period period16 = period11.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period18 = period11.withMillis((int) (short) 100);
        org.joda.time.Period period19 = period8.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology25);
        org.joda.time.Period period27 = period22.withFields((org.joda.time.ReadablePeriod) period26);
        org.joda.time.Period period28 = period26.normalizedStandard();
        org.joda.time.Period period30 = period26.plusYears((-100));
        org.joda.time.DurationFieldType durationFieldType32 = period26.getFieldType((int) (short) 0);
        int int33 = period18.indexOf(durationFieldType32);
        org.joda.time.field.DecoratedDurationField decoratedDurationField34 = new org.joda.time.field.DecoratedDurationField(durationField6, durationFieldType32);
        int int36 = decoratedDurationField34.getValue((long) (-15));
        long long38 = decoratedDurationField34.getMillis((int) (short) 0);
        java.lang.String str39 = decoratedDurationField34.getName();
        int int41 = decoratedDurationField34.getValue((long) (short) 100);
        java.lang.String str42 = decoratedDurationField34.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "years" + "'", str39.equals("years"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "years" + "'", str42.equals("years"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        org.joda.time.Period period3 = new org.joda.time.Period(0L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration4, readableInstant5);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology9);
        org.joda.time.Period period11 = period6.withFields((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period13 = period6.withMillis((int) (short) 100);
        org.joda.time.Period period15 = period13.withDays((int) 'a');
        int int16 = period13.size();
        org.joda.time.Period period18 = period13.plusYears((int) (short) -1);
        org.joda.time.Period period19 = period3.plus((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period21 = period3.plusWeeks((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType22 = null;
        try {
            org.joda.time.Period period24 = period21.withFieldAdded(durationFieldType22, 9700);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        java.lang.String str25 = unsupportedDurationField23.getName();
        try {
            int int28 = unsupportedDurationField23.getDifference((long) (-1), (-2177262720000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "years" + "'", str25.equals("years"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-210866760000000L), 53);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-11175938280000000L) + "'", long2 == (-11175938280000000L));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        long long26 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period(readableDuration27, readableInstant28);
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology32);
        org.joda.time.Period period34 = period29.withFields((org.joda.time.ReadablePeriod) period33);
        org.joda.time.Period period35 = period33.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType37 = period33.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField38 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType37);
        int int39 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField38);
        java.lang.String str40 = unsupportedDurationField11.toString();
        try {
            long long42 = unsupportedDurationField11.getMillis(100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(durationFieldType37);
        org.junit.Assert.assertNotNull(unsupportedDurationField38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "UnsupportedDurationField[years]" + "'", str40.equals("UnsupportedDurationField[years]"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period2 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) '#');
        int int8 = period7.getHours();
        org.joda.time.Period period10 = period7.minusSeconds((int) '#');
        boolean boolean11 = period2.equals((java.lang.Object) period7);
        int[] intArray13 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        org.joda.time.DurationField durationField14 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        long long26 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period(readableDuration27, readableInstant28);
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology32);
        org.joda.time.Period period34 = period29.withFields((org.joda.time.ReadablePeriod) period33);
        org.joda.time.Period period35 = period33.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType37 = period33.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField38 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType37);
        int int39 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField38);
        java.lang.String str40 = unsupportedDurationField11.toString();
        try {
            long long42 = unsupportedDurationField11.getMillis(20L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(durationFieldType37);
        org.junit.Assert.assertNotNull(unsupportedDurationField38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "UnsupportedDurationField[years]" + "'", str40.equals("UnsupportedDurationField[years]"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.joda.time.Period period3 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', chronology5);
        org.joda.time.Period period8 = period6.minusMonths((int) '#');
        int int9 = period8.getHours();
        org.joda.time.Period period11 = period8.minusSeconds((int) '#');
        boolean boolean12 = period3.equals((java.lang.Object) period8);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period8.toDurationTo(readableInstant13);
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withWeeksRemoved();
        org.joda.time.PeriodType periodType23 = periodType21.withMinutesRemoved();
        org.joda.time.Period period24 = period20.withPeriodType(periodType21);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) -1, periodType21);
        org.joda.time.Period period26 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant16, periodType21);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType21, chronology27);
        java.lang.String str29 = periodType21.getName();
        org.joda.time.PeriodType periodType30 = periodType21.withMonthsRemoved();
        org.joda.time.PeriodType periodType31 = periodType21.withSecondsRemoved();
        org.joda.time.PeriodType periodType32 = periodType21.withMillisRemoved();
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period(readableDuration33, readableInstant34);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.Period period39 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology38);
        org.joda.time.Period period40 = period35.withFields((org.joda.time.ReadablePeriod) period39);
        org.joda.time.Period period42 = period40.minusHours((int) 'a');
        org.joda.time.PeriodType periodType43 = period42.getPeriodType();
        org.joda.time.ReadableDuration readableDuration44 = null;
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.Period period46 = new org.joda.time.Period(readableDuration44, readableInstant45);
        org.joda.time.Chronology chronology49 = null;
        org.joda.time.Period period50 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology49);
        org.joda.time.Period period51 = period46.withFields((org.joda.time.ReadablePeriod) period50);
        org.joda.time.Period period52 = period50.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType54 = period50.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField55 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType54);
        org.joda.time.ReadableDuration readableDuration56 = null;
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.Period period58 = new org.joda.time.Period(readableDuration56, readableInstant57);
        org.joda.time.Chronology chronology61 = null;
        org.joda.time.Period period62 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology61);
        org.joda.time.Period period63 = period58.withFields((org.joda.time.ReadablePeriod) period62);
        org.joda.time.Period period64 = period62.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType66 = period62.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField67 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType66);
        int int68 = unsupportedDurationField55.compareTo((org.joda.time.DurationField) unsupportedDurationField67);
        java.lang.String str69 = unsupportedDurationField67.getName();
        java.lang.String str70 = unsupportedDurationField67.getName();
        org.joda.time.DurationFieldType durationFieldType71 = unsupportedDurationField67.getType();
        int int72 = period42.get(durationFieldType71);
        boolean boolean73 = periodType32.isSupported(durationFieldType71);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-92015999903L) + "'", long15 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Seconds" + "'", str29.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(periodType43);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(durationFieldType54);
        org.junit.Assert.assertNotNull(unsupportedDurationField55);
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertNotNull(period64);
        org.junit.Assert.assertNotNull(durationFieldType66);
        org.junit.Assert.assertNotNull(unsupportedDurationField67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "years" + "'", str69.equals("years"));
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "years" + "'", str70.equals("years"));
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) 1);
        org.joda.time.Period period3 = period1.minusMonths(100);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField7 = iSOChronology6.seconds();
        org.joda.time.DurationField durationField8 = iSOChronology6.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.millisOfDay();
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("PST", "GregorianChronology[America/Los_Angeles]", 0, (int) (short) 100);
        java.util.TimeZone timeZone16 = fixedDateTimeZone15.toTimeZone();
        long long20 = fixedDateTimeZone15.convertLocalToUTC(172800001L, true, (-92015999903L));
        org.joda.time.Chronology chronology21 = lenientChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 172800001L + "'", long20 == 172800001L);
        org.junit.Assert.assertNotNull(chronology21);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.yearOfEra();
        org.joda.time.DurationField durationField6 = gregorianChronology0.weeks();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfMinute();
        org.joda.time.Period period10 = new org.joda.time.Period(0L, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology16);
        org.joda.time.Period period18 = period13.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period20 = period13.withMillis((int) (short) 100);
        org.joda.time.Period period22 = period20.withDays((int) 'a');
        int int23 = period20.size();
        org.joda.time.Period period25 = period20.plusYears((int) (short) -1);
        org.joda.time.Period period26 = period10.plus((org.joda.time.ReadablePeriod) period25);
        boolean boolean27 = gregorianChronology0.equals((java.lang.Object) period25);
        org.joda.time.Period period29 = period25.plusHours(9);
        org.joda.time.Period period31 = period25.withYears((int) (short) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period31);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
        int int11 = offsetDateTimeField6.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        java.lang.String str7 = offsetDateTimeField6.getName();
        java.lang.String str8 = offsetDateTimeField6.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfWeek" + "'", str7.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DateTimeField[dayOfWeek]" + "'", str8.equals("DateTimeField[dayOfWeek]"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.joda.time.Period period1 = org.joda.time.Period.years(43);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField6 = gregorianChronology0.minutes();
        org.joda.time.Period period8 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology14);
        org.joda.time.Period period16 = period11.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period18 = period11.withMillis((int) (short) 100);
        org.joda.time.Period period19 = period8.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology25);
        org.joda.time.Period period27 = period22.withFields((org.joda.time.ReadablePeriod) period26);
        org.joda.time.Period period28 = period26.normalizedStandard();
        org.joda.time.Period period30 = period26.plusYears((-100));
        org.joda.time.DurationFieldType durationFieldType32 = period26.getFieldType((int) (short) 0);
        int int33 = period18.indexOf(durationFieldType32);
        org.joda.time.field.DecoratedDurationField decoratedDurationField34 = new org.joda.time.field.DecoratedDurationField(durationField6, durationFieldType32);
        int int36 = decoratedDurationField34.getValue((long) (-15));
        int int39 = decoratedDurationField34.getValue((long) 9700, (long) (-10));
        long long40 = decoratedDurationField34.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType41 = decoratedDurationField34.getType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 60000L + "'", long40 == 60000L);
        org.junit.Assert.assertNotNull(durationFieldType41);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        int int26 = remainderDateTimeField25.getDivisor();
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = remainderDateTimeField25.getMinimumValue(readablePartial27);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        long long27 = remainderDateTimeField25.roundHalfFloor((long) 0);
        long long29 = remainderDateTimeField25.roundHalfEven((long) (byte) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.secondOfMinute();
        int int32 = gregorianChronology30.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology30.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 8);
        long long38 = offsetDateTimeField36.roundHalfEven((long) 100);
        int int41 = offsetDateTimeField36.getDifference((long) (byte) 1, (long) (byte) 10);
        long long43 = offsetDateTimeField36.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField36, (-28800000));
        long long47 = offsetDateTimeField36.roundHalfFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.secondOfMinute();
        int int50 = gregorianChronology48.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology48.millisOfDay();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology48.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, 8);
        long long56 = offsetDateTimeField54.roundHalfEven((long) 100);
        int int59 = offsetDateTimeField54.getDifference((long) (byte) 1, (long) (byte) 10);
        long long61 = offsetDateTimeField54.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField54, (-28800000));
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField54.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField36, dateTimeFieldType64, (-25199800));
        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, (java.lang.Number) (short) 10, (java.lang.Number) (byte) 0, (java.lang.Number) 100L);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField71 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType64);
        org.joda.time.DateTimeFieldType dateTimeFieldType72 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField73 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField71, dateTimeFieldType72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1L + "'", long43 == 1L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1L + "'", long47 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1L + "'", long56 == 1L);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1L + "'", long61 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration3, readableInstant4);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology8);
        org.joda.time.Period period10 = period5.withFields((org.joda.time.ReadablePeriod) period9);
        org.joda.time.Period period11 = period9.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType13 = period9.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField14 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType13);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableDuration15, readableInstant16);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology20);
        org.joda.time.Period period22 = period17.withFields((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period23 = period21.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType25 = period21.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField26 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType25);
        int int27 = unsupportedDurationField14.compareTo((org.joda.time.DurationField) unsupportedDurationField26);
        java.lang.String str28 = unsupportedDurationField26.getName();
        java.lang.String str29 = unsupportedDurationField26.getName();
        org.joda.time.DurationFieldType durationFieldType30 = unsupportedDurationField26.getType();
        boolean boolean31 = org.joda.time.field.FieldUtils.equals((java.lang.Object) chronology2, (java.lang.Object) unsupportedDurationField26);
        try {
            long long34 = unsupportedDurationField26.subtract(97L, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertNotNull(unsupportedDurationField14);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertNotNull(unsupportedDurationField26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "years" + "'", str28.equals("years"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "years" + "'", str29.equals("years"));
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField6 = gregorianChronology0.minutes();
        org.joda.time.Period period8 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology14);
        org.joda.time.Period period16 = period11.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period18 = period11.withMillis((int) (short) 100);
        org.joda.time.Period period19 = period8.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology25);
        org.joda.time.Period period27 = period22.withFields((org.joda.time.ReadablePeriod) period26);
        org.joda.time.Period period28 = period26.normalizedStandard();
        org.joda.time.Period period30 = period26.plusYears((-100));
        org.joda.time.DurationFieldType durationFieldType32 = period26.getFieldType((int) (short) 0);
        int int33 = period18.indexOf(durationFieldType32);
        org.joda.time.field.DecoratedDurationField decoratedDurationField34 = new org.joda.time.field.DecoratedDurationField(durationField6, durationFieldType32);
        int int36 = decoratedDurationField34.getValue((long) (-15));
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.secondOfMinute();
        int int39 = gregorianChronology37.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.millisOfDay();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, 8);
        int int45 = offsetDateTimeField43.getLeapAmount((long) (byte) 0);
        java.util.Locale locale47 = null;
        java.lang.String str48 = offsetDateTimeField43.getAsText((long) (-1), locale47);
        boolean boolean50 = offsetDateTimeField43.isLeap((long) ' ');
        org.joda.time.ReadablePartial readablePartial51 = null;
        int int52 = offsetDateTimeField43.getMinimumValue(readablePartial51);
        org.joda.time.DurationField durationField53 = offsetDateTimeField43.getDurationField();
        int int54 = decoratedDurationField34.compareTo(durationField53);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "11" + "'", str48.equals("11"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 9 + "'", int52 == 9);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        int int3 = period2.getMinutes();
        int int4 = period2.size();
        org.joda.time.Period period6 = org.joda.time.Period.seconds(43);
        org.joda.time.Period period7 = period2.minus((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period7.plusMonths((int) (byte) 100);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.weekOfWeekyear();
        try {
            org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) (byte) 100, (org.joda.time.Chronology) iSOChronology10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        long long27 = remainderDateTimeField25.roundHalfFloor((long) 0);
        int int29 = remainderDateTimeField25.get(86400000L);
        int int30 = remainderDateTimeField25.getDivisor();
        org.joda.time.ReadablePartial readablePartial31 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.secondOfMinute();
        int int35 = gregorianChronology33.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.millisOfDay();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology33.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, 8);
        long long41 = offsetDateTimeField39.roundHalfEven((long) 100);
        java.util.Locale locale42 = null;
        int int43 = offsetDateTimeField39.getMaximumTextLength(locale42);
        org.joda.time.DurationField durationField44 = offsetDateTimeField39.getDurationField();
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.secondOfMinute();
        int int49 = gregorianChronology47.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology47.millisOfDay();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology47.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology47.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration53 = null;
        org.joda.time.ReadableInstant readableInstant54 = null;
        org.joda.time.Period period55 = new org.joda.time.Period(readableDuration53, readableInstant54);
        org.joda.time.Chronology chronology58 = null;
        org.joda.time.Period period59 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology58);
        org.joda.time.Period period60 = period55.withFields((org.joda.time.ReadablePeriod) period59);
        org.joda.time.Period period62 = period55.withMillis((int) (short) 100);
        org.joda.time.Period period64 = period62.withDays((int) 'a');
        int int65 = period62.size();
        org.joda.time.Period period67 = period62.plusYears((int) (short) -1);
        int[] intArray70 = gregorianChronology47.get((org.joda.time.ReadablePeriod) period62, (long) 'a', (long) 'a');
        int[] intArray72 = offsetDateTimeField39.addWrapPartial(readablePartial45, 99, intArray70, 0);
        try {
            int[] intArray74 = remainderDateTimeField25.add(readablePartial31, (int) (byte) -1, intArray70, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 53 + "'", int29 == 53);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 99 + "'", int30 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1L + "'", long41 == 1L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(period64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 8 + "'", int65 == 8);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray72);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        illegalFieldValueException2.prependMessage("200");
        org.joda.time.IllegalInstantException illegalInstantException8 = new org.joda.time.IllegalInstantException("");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalInstantException8);
        java.lang.Number number10 = illegalFieldValueException2.getLowerBound();
        java.lang.Number number11 = illegalFieldValueException2.getUpperBound();
        java.lang.String str12 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        long long27 = remainderDateTimeField25.roundHalfFloor((long) 0);
        long long29 = remainderDateTimeField25.roundHalfEven((long) (byte) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.secondOfMinute();
        int int32 = gregorianChronology30.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology30.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 8);
        long long38 = offsetDateTimeField36.roundHalfEven((long) 100);
        int int41 = offsetDateTimeField36.getDifference((long) (byte) 1, (long) (byte) 10);
        long long43 = offsetDateTimeField36.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField36, (-28800000));
        long long47 = offsetDateTimeField36.roundHalfFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.secondOfMinute();
        int int50 = gregorianChronology48.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology48.millisOfDay();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology48.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, 8);
        long long56 = offsetDateTimeField54.roundHalfEven((long) 100);
        int int59 = offsetDateTimeField54.getDifference((long) (byte) 1, (long) (byte) 10);
        long long61 = offsetDateTimeField54.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField54, (-28800000));
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField54.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField36, dateTimeFieldType64, (-25199800));
        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, (java.lang.Number) (short) 10, (java.lang.Number) (byte) 0, (java.lang.Number) 100L);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField71 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType64);
        int int74 = dividedDateTimeField71.getDifference(99L, 691200132L);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1L + "'", long43 == 1L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1L + "'", long47 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1L + "'", long56 == 1L);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1L + "'", long61 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-116) + "'", int74 == (-116));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsText((long) (-1), locale10);
        long long14 = offsetDateTimeField6.add((long) (byte) 1, 2);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = offsetDateTimeField6.getMaximumValue(readablePartial15);
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        boolean boolean22 = dateTimeZone20.isStandardOffset((long) (short) 0);
        boolean boolean24 = dateTimeZone20.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField26 = iSOChronology25.seconds();
        org.joda.time.DurationField durationField27 = iSOChronology25.halfdays();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology25.millisOfDay();
        org.joda.time.chrono.LenientChronology lenientChronology29 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology25);
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Period period32 = new org.joda.time.Period(readableDuration30, readableInstant31);
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.Period period36 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology35);
        org.joda.time.Period period37 = period32.withFields((org.joda.time.ReadablePeriod) period36);
        int int38 = period36.getWeeks();
        org.joda.time.Period period40 = period36.withHours(4);
        int int41 = period36.getDays();
        int[] intArray43 = lenientChronology29.get((org.joda.time.ReadablePeriod) period36, (-92015999893L));
        try {
            int[] intArray45 = offsetDateTimeField6.addWrapField(readablePartial17, 43, intArray43, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 43");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 172800001L + "'", long14 == 172800001L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(lenientChronology29);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray43);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.Period period10 = period6.plusYears((-100));
        org.joda.time.DurationFieldType durationFieldType12 = period6.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(durationFieldType12, "hi!");
        java.lang.String str15 = illegalFieldValueException14.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.PeriodType periodType14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
        int int17 = gregorianChronology15.getMinimumDaysInFirstWeek();
        int int18 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.Period period19 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType14, (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.DurationField durationField20 = gregorianChronology15.weeks();
        int int21 = unsupportedDurationField11.compareTo(durationField20);
        try {
            long long24 = unsupportedDurationField11.getMillis(13, 200L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField7 = iSOChronology6.seconds();
        org.joda.time.DurationField durationField8 = iSOChronology6.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.millisOfDay();
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology16);
        org.joda.time.Period period18 = period13.withFields((org.joda.time.ReadablePeriod) period17);
        int int19 = period17.getWeeks();
        org.joda.time.Period period21 = period17.withHours(4);
        int int22 = period17.getDays();
        int[] intArray24 = lenientChronology10.get((org.joda.time.ReadablePeriod) period17, (-92015999893L));
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.millisOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.millisOfDay();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology25.dayOfWeek();
        boolean boolean29 = lenientChronology10.equals((java.lang.Object) dateTimeField28);
        org.joda.time.DateTimeField dateTimeField30 = lenientChronology10.hourOfHalfday();
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) 'a', chronology32);
        org.joda.time.Period period35 = period33.minusMonths((int) '#');
        org.joda.time.Period period37 = period33.withYears(0);
        org.joda.time.Period period39 = period37.minusHours((int) (byte) 1);
        int[] intArray42 = lenientChronology10.get((org.joda.time.ReadablePeriod) period39, 172800001L, 130L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(intArray42);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.joda.time.Period period1 = org.joda.time.Period.months((-25199800));
        try {
            org.joda.time.Hours hours2 = period1.toStandardHours();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Hours as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField6 = gregorianChronology0.minutes();
        org.joda.time.Period period8 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology14);
        org.joda.time.Period period16 = period11.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period18 = period11.withMillis((int) (short) 100);
        org.joda.time.Period period19 = period8.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology25);
        org.joda.time.Period period27 = period22.withFields((org.joda.time.ReadablePeriod) period26);
        org.joda.time.Period period28 = period26.normalizedStandard();
        org.joda.time.Period period30 = period26.plusYears((-100));
        org.joda.time.DurationFieldType durationFieldType32 = period26.getFieldType((int) (short) 0);
        int int33 = period18.indexOf(durationFieldType32);
        org.joda.time.field.DecoratedDurationField decoratedDurationField34 = new org.joda.time.field.DecoratedDurationField(durationField6, durationFieldType32);
        int int36 = decoratedDurationField34.getValue((long) (-15));
        long long38 = decoratedDurationField34.getMillis((int) (short) 0);
        boolean boolean39 = decoratedDurationField34.isPrecise();
        long long42 = decoratedDurationField34.getDifferenceAsLong(2488331404800008L, (long) '#');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 41472190079L + "'", long42 == 41472190079L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.millisOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 4, (-92015999903L), (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.secondOfMinute();
        int int9 = gregorianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology7.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 8);
        int int14 = offsetDateTimeField13.getOffset();
        org.joda.time.DurationField durationField15 = offsetDateTimeField13.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.secondOfMinute();
        int int18 = gregorianChronology16.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology16.millisOfDay();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, 8);
        long long24 = offsetDateTimeField22.roundHalfEven((long) 100);
        int int27 = offsetDateTimeField22.getDifference((long) (byte) 1, (long) (byte) 10);
        long long29 = offsetDateTimeField22.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField22, (-28800000));
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField22.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType32, (-43));
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period2 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) '#');
        int int8 = period7.getHours();
        org.joda.time.Period period10 = period7.minusSeconds((int) '#');
        boolean boolean11 = period2.equals((java.lang.Object) period7);
        int[] intArray13 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        org.joda.time.DurationField durationField14 = gregorianChronology0.eras();
        org.joda.time.Period period16 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 'a', chronology18);
        org.joda.time.Period period21 = period19.minusMonths((int) '#');
        int int22 = period21.getHours();
        org.joda.time.Period period24 = period21.minusSeconds((int) '#');
        boolean boolean25 = period16.equals((java.lang.Object) period21);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Duration duration27 = period21.toDurationTo(readableInstant26);
        long long28 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration27);
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.ReadableDuration readableDuration31 = null;
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period(readableDuration31, readableInstant32);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType35 = periodType34.withWeeksRemoved();
        org.joda.time.PeriodType periodType36 = periodType34.withMinutesRemoved();
        org.joda.time.Period period37 = period33.withPeriodType(periodType34);
        org.joda.time.Period period38 = new org.joda.time.Period((long) (short) -1, periodType34);
        org.joda.time.Period period39 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration27, readableInstant29, periodType34);
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.ReadableDuration readableDuration42 = null;
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.Period period44 = new org.joda.time.Period(readableDuration42, readableInstant43);
        org.joda.time.PeriodType periodType45 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType46 = periodType45.withWeeksRemoved();
        org.joda.time.PeriodType periodType47 = periodType45.withMinutesRemoved();
        org.joda.time.Period period48 = period44.withPeriodType(periodType45);
        org.joda.time.Period period49 = new org.joda.time.Period((long) (short) -1, periodType45);
        org.joda.time.ReadableDuration readableDuration50 = null;
        org.joda.time.ReadableInstant readableInstant51 = null;
        org.joda.time.Period period52 = new org.joda.time.Period(readableDuration50, readableInstant51);
        org.joda.time.PeriodType periodType53 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType54 = periodType53.withWeeksRemoved();
        org.joda.time.PeriodType periodType55 = periodType53.withMinutesRemoved();
        org.joda.time.Period period56 = period52.withPeriodType(periodType53);
        org.joda.time.Period period57 = period49.withPeriodType(periodType53);
        org.joda.time.Period period58 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration27, readableInstant40, periodType53);
        int[] intArray61 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period58, 11L, 10L);
        org.joda.time.DateTimeZone dateTimeZone62 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(duration27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-92015999903L) + "'", long28 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(periodType46);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertNotNull(dateTimeField63);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.joda.time.Period period1 = org.joda.time.Period.years((-1));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration3, readableInstant4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType7 = periodType6.withWeeksRemoved();
        org.joda.time.PeriodType periodType8 = periodType6.withMinutesRemoved();
        org.joda.time.Period period9 = period5.withPeriodType(periodType6);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) -1, periodType6);
        org.joda.time.PeriodType periodType11 = periodType6.withMinutesRemoved();
        int int12 = periodType11.size();
        java.lang.Object obj13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfDay();
        java.lang.Object obj16 = null;
        boolean boolean17 = iSOChronology14.equals(obj16);
        org.joda.time.Period period18 = new org.joda.time.Period(obj13, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology14.clockhourOfHalfday();
        org.joda.time.Period period20 = new org.joda.time.Period((long) (short) 1, (-368200799611L), periodType11, (org.joda.time.Chronology) iSOChronology14);
        java.lang.String str21 = periodType11.toString();
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PeriodType[Seconds]" + "'", str21.equals("PeriodType[Seconds]"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) '#', 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration6, readableInstant7);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology11);
        org.joda.time.Period period13 = period8.withFields((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period15 = period8.withMillis((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period8.toDurationFrom(readableInstant16);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology23);
        org.joda.time.Period period25 = period20.withFields((org.joda.time.ReadablePeriod) period24);
        org.joda.time.Period period27 = period20.withMillis((int) (short) 100);
        org.joda.time.Period period29 = period27.withDays((int) 'a');
        int int30 = period27.size();
        org.joda.time.Period period31 = period8.minus((org.joda.time.ReadablePeriod) period27);
        long long34 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period8, (long) (short) 1, (int) 'a');
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Duration duration36 = period8.toDurationFrom(readableInstant35);
        java.lang.String str37 = period8.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(duration36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PT0S" + "'", str37.equals("PT0S"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[America/Los_Angeles]", "", (int) '#', 100);
        long long6 = fixedDateTimeZone4.nextTransition(28800132L);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28800132L + "'", long6 == 28800132L);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        java.lang.String str25 = unsupportedDurationField23.getName();
        long long26 = unsupportedDurationField23.getUnitMillis();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "years" + "'", str25.equals("years"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
        long long13 = offsetDateTimeField6.add((long) 2, 99);
        java.lang.String str15 = offsetDateTimeField6.getAsShortText((-368326799612L));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, 99);
        java.lang.String str19 = offsetDateTimeField17.getAsText((long) 43);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone22);
        boolean boolean25 = dateTimeZone23.isStandardOffset((long) (short) 0);
        boolean boolean27 = dateTimeZone23.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField29 = iSOChronology28.seconds();
        org.joda.time.DurationField durationField30 = iSOChronology28.halfdays();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology28.millisOfDay();
        org.joda.time.chrono.LenientChronology lenientChronology32 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology28);
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period(readableDuration33, readableInstant34);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.Period period39 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology38);
        org.joda.time.Period period40 = period35.withFields((org.joda.time.ReadablePeriod) period39);
        int int41 = period39.getWeeks();
        org.joda.time.Period period43 = period39.withHours(4);
        int int44 = period39.getDays();
        int[] intArray46 = lenientChronology32.get((org.joda.time.ReadablePeriod) period39, (-92015999893L));
        try {
            int[] intArray48 = offsetDateTimeField17.set(readablePartial20, 0, intArray46, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [108,114]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8553600002L + "'", long13 == 8553600002L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "11" + "'", str15.equals("11"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "111" + "'", str19.equals("111"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(lenientChronology32);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray46);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) 13, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "GregorianChronology[America/Los_Angeles]", 0, (int) (short) 100);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long9 = fixedDateTimeZone4.convertLocalToUTC(172800001L, true, (-92015999903L));
        int int11 = fixedDateTimeZone4.getOffset(20L);
        boolean boolean12 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 172800001L + "'", long9 == 172800001L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField7 = iSOChronology6.seconds();
        org.joda.time.DurationField durationField8 = iSOChronology6.halfdays();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone10.getName(99L, locale12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        int int15 = dateTimeZone10.getOffset(readableInstant14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        int int18 = cachedDateTimeZone16.getStandardOffset((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone16.getUncachedZone();
        boolean boolean20 = iSOChronology6.equals((java.lang.Object) cachedDateTimeZone16);
        long long22 = cachedDateTimeZone16.nextTransition((long) (short) 1);
        int int24 = cachedDateTimeZone16.getOffset((long) 98);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-00:00:00.001" + "'", str13.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 132L, (java.lang.Number) 14, (java.lang.Number) 86400001L);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.remainder((long) (byte) 1);
        java.lang.String str9 = offsetDateTimeField6.getName();
        long long11 = offsetDateTimeField6.roundHalfFloor((long) 200);
        long long14 = offsetDateTimeField6.add(0L, 2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "dayOfWeek" + "'", str9.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 172800000L + "'", long14 == 172800000L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.joda.time.Period period3 = org.joda.time.Period.weeks((int) 'a');
        org.joda.time.Period period7 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) 'a', chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) '#');
        int int13 = period12.getHours();
        org.joda.time.Period period15 = period12.minusSeconds((int) '#');
        boolean boolean16 = period7.equals((java.lang.Object) period12);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Duration duration18 = period12.toDurationTo(readableInstant17);
        long long19 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration18);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableDuration22, readableInstant23);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType26 = periodType25.withWeeksRemoved();
        org.joda.time.PeriodType periodType27 = periodType25.withMinutesRemoved();
        org.joda.time.Period period28 = period24.withPeriodType(periodType25);
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) -1, periodType25);
        org.joda.time.Period period30 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration18, readableInstant20, periodType25);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType25, chronology31);
        org.joda.time.Period period36 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.Period period39 = new org.joda.time.Period((long) 'a', chronology38);
        org.joda.time.Period period41 = period39.minusMonths((int) '#');
        int int42 = period41.getHours();
        org.joda.time.Period period44 = period41.minusSeconds((int) '#');
        boolean boolean45 = period36.equals((java.lang.Object) period41);
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Duration duration47 = period41.toDurationTo(readableInstant46);
        long long48 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration47);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableDuration readableDuration51 = null;
        org.joda.time.ReadableInstant readableInstant52 = null;
        org.joda.time.Period period53 = new org.joda.time.Period(readableDuration51, readableInstant52);
        org.joda.time.PeriodType periodType54 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType55 = periodType54.withWeeksRemoved();
        org.joda.time.PeriodType periodType56 = periodType54.withMinutesRemoved();
        org.joda.time.Period period57 = period53.withPeriodType(periodType54);
        org.joda.time.Period period58 = new org.joda.time.Period((long) (short) -1, periodType54);
        org.joda.time.Period period59 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration47, readableInstant49, periodType54);
        org.joda.time.Chronology chronology60 = null;
        org.joda.time.Period period61 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType54, chronology60);
        java.lang.String str62 = periodType54.getName();
        org.joda.time.ReadableDuration readableDuration63 = null;
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.Period period65 = new org.joda.time.Period(readableDuration63, readableInstant64);
        org.joda.time.Chronology chronology68 = null;
        org.joda.time.Period period69 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology68);
        org.joda.time.Period period70 = period65.withFields((org.joda.time.ReadablePeriod) period69);
        org.joda.time.Period period71 = period69.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType73 = period69.getFieldType(0);
        int int74 = periodType54.indexOf(durationFieldType73);
        int int75 = periodType25.indexOf(durationFieldType73);
        org.joda.time.Period period76 = period3.normalizedStandard(periodType25);
        org.joda.time.chrono.GregorianChronology gregorianChronology77 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField78 = gregorianChronology77.secondOfMinute();
        int int79 = gregorianChronology77.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField80 = gregorianChronology77.millisOfDay();
        org.joda.time.DateTimeField dateTimeField81 = gregorianChronology77.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField82 = gregorianChronology77.minuteOfHour();
        long long86 = gregorianChronology77.add(20L, (long) (-25200000), (int) (byte) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone91 = new org.joda.time.tz.FixedDateTimeZone("PST", "GregorianChronology[America/Los_Angeles]", 0, (int) (short) 100);
        java.util.TimeZone timeZone92 = fixedDateTimeZone91.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone93 = org.joda.time.DateTimeZone.forTimeZone(timeZone92);
        org.joda.time.chrono.ZonedChronology zonedChronology94 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology77, dateTimeZone93);
        org.joda.time.Chronology chronology95 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology94);
        org.joda.time.Period period96 = new org.joda.time.Period((long) (-10), (long) 1131, periodType25, (org.joda.time.Chronology) zonedChronology94);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-92015999903L) + "'", long19 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(duration47);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-92015999903L) + "'", long48 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType56);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Seconds" + "'", str62.equals("Seconds"));
        org.junit.Assert.assertNotNull(period70);
        org.junit.Assert.assertNotNull(period71);
        org.junit.Assert.assertNotNull(durationFieldType73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(period76);
        org.junit.Assert.assertNotNull(gregorianChronology77);
        org.junit.Assert.assertNotNull(dateTimeField78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 4 + "'", int79 == 4);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertNotNull(dateTimeField82);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 25200020L + "'", long86 == 25200020L);
        org.junit.Assert.assertNotNull(timeZone92);
        org.junit.Assert.assertNotNull(dateTimeZone93);
        org.junit.Assert.assertNotNull(zonedChronology94);
        org.junit.Assert.assertNotNull(chronology95);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType2 = periodType1.withWeeksRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withMinutesRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.secondOfMinute();
        int int6 = gregorianChronology4.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.millisOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology4.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology4.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.minuteOfHour();
        org.joda.time.DurationField durationField11 = gregorianChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology4.yearOfCentury();
        org.joda.time.Period period13 = new org.joda.time.Period(100L, periodType3, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology4.dayOfWeek();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfHour();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Period period9 = period7.minusDays((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period9.toDurationFrom(readableInstant10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration11, readableInstant12);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
        boolean boolean13 = offsetDateTimeField6.isLeap((long) (byte) 10);
        boolean boolean15 = offsetDateTimeField6.isLeap((long) 15);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology7);
        org.joda.time.Period period9 = period4.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period11 = period4.withMillis((int) (short) 100);
        org.joda.time.Period period12 = period1.withFields((org.joda.time.ReadablePeriod) period11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period12.toDurationTo(readableInstant13);
        org.joda.time.Period period16 = period12.minusHours(100);
        org.joda.time.Period period18 = period12.plusYears(0);
        org.joda.time.MutablePeriod mutablePeriod19 = period18.toMutablePeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(mutablePeriod19);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[America/Los_Angeles]", "", (int) '#', 100);
        long long6 = fixedDateTimeZone4.nextTransition(100L);
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone4.getName((-92015999903L), locale8);
        org.joda.time.LocalDateTime localDateTime10 = null;
        boolean boolean11 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime10);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.035" + "'", str9.equals("+00:00:00.035"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
        long long13 = offsetDateTimeField6.roundHalfEven((long) 35);
        int int15 = offsetDateTimeField6.getMinimumValue((-91929599893L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.joda.time.Period period4 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', chronology6);
        org.joda.time.Period period9 = period7.minusMonths((int) '#');
        int int10 = period9.getHours();
        org.joda.time.Period period12 = period9.minusSeconds((int) '#');
        boolean boolean13 = period4.equals((java.lang.Object) period9);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period9.toDurationTo(readableInstant14);
        long long16 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableDuration19, readableInstant20);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType23 = periodType22.withWeeksRemoved();
        org.joda.time.PeriodType periodType24 = periodType22.withMinutesRemoved();
        org.joda.time.Period period25 = period21.withPeriodType(periodType22);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) -1, periodType22);
        org.joda.time.Period period27 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration15, readableInstant17, periodType22);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType22, chronology28);
        org.joda.time.PeriodType periodType30 = periodType22.withDaysRemoved();
        java.lang.Object obj31 = null;
        boolean boolean32 = periodType22.equals(obj31);
        org.joda.time.PeriodType periodType33 = periodType22.withYearsRemoved();
        java.lang.Object obj34 = null;
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.millisOfDay();
        java.lang.Object obj37 = null;
        boolean boolean38 = iSOChronology35.equals(obj37);
        org.joda.time.Period period39 = new org.joda.time.Period(obj34, (org.joda.time.Chronology) iSOChronology35);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology35.millisOfSecond();
        org.joda.time.Period period41 = new org.joda.time.Period((long) 114, periodType33, (org.joda.time.Chronology) iSOChronology35);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-92015999903L) + "'", long16 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeField40);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("12");
        jodaTimePermission1.checkGuard((java.lang.Object) (short) -1);
        java.security.PermissionCollection permissionCollection4 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str5 = jodaTimePermission1.toString();
        java.lang.String str6 = jodaTimePermission1.getName();
        org.junit.Assert.assertNotNull(permissionCollection4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"12\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"12\")"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "12" + "'", str6.equals("12"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("LenientChronology[ISOChronology[-00:00:00.001]]", (java.lang.Number) 2, (java.lang.Number) (-8L), (java.lang.Number) (-36000000L));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology1.centuries();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology1.getZone();
        org.joda.time.Period period8 = new org.joda.time.Period(36000100L, (org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        int int3 = dateTimeZone1.getOffsetFromLocal((-94723200000L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long7 = dateTimeZone1.convertLocalToUTC(41472190079L, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 41472189979L + "'", long7 == 41472189979L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period2 = new org.joda.time.Period((long) 4, periodType1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration3, readableInstant4);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology8);
        org.joda.time.Period period10 = period5.withFields((org.joda.time.ReadablePeriod) period9);
        org.joda.time.Period period11 = period9.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType13 = period9.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField14 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType13);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableDuration15, readableInstant16);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology20);
        org.joda.time.Period period22 = period17.withFields((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period23 = period21.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType25 = period21.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField26 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType25);
        int int27 = unsupportedDurationField14.compareTo((org.joda.time.DurationField) unsupportedDurationField26);
        java.lang.String str28 = unsupportedDurationField26.getName();
        java.lang.String str29 = unsupportedDurationField26.getName();
        org.joda.time.DurationFieldType durationFieldType30 = unsupportedDurationField26.getType();
        boolean boolean31 = period2.isSupported(durationFieldType30);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField32 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType30);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertNotNull(unsupportedDurationField14);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertNotNull(unsupportedDurationField26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "years" + "'", str28.equals("years"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "years" + "'", str29.equals("years"));
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField32);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        java.lang.String str6 = gregorianChronology0.toString();
        org.joda.time.Period period8 = org.joda.time.Period.weeks((-1));
        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period8, (long) 'a', (long) 10);
        java.lang.String str12 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.secondOfDay();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableDuration15, readableInstant16);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology20);
        org.joda.time.Period period22 = period17.withFields((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period24 = period17.withMillis((int) (short) 100);
        org.joda.time.Period period26 = period24.plusWeeks((int) (byte) 100);
        long long29 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period24, 0L, (-25200000));
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology0.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.secondOfMinute();
        int int33 = gregorianChronology31.getMinimumDaysInFirstWeek();
        int int34 = gregorianChronology31.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField35 = gregorianChronology31.weeks();
        org.joda.time.DurationField durationField36 = gregorianChronology31.hours();
        boolean boolean37 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeField30, (java.lang.Object) gregorianChronology31);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str12.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-2520000000L) + "'", long29 == (-2520000000L));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology0.minutes();
        org.joda.time.DurationField durationField3 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '0' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfHour();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Period period9 = period7.minusDays(1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray10 = period7.getFieldTypes();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(durationFieldTypeArray10);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField6 = gregorianChronology0.minutes();
        org.joda.time.Period period8 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology14);
        org.joda.time.Period period16 = period11.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period18 = period11.withMillis((int) (short) 100);
        org.joda.time.Period period19 = period8.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology25);
        org.joda.time.Period period27 = period22.withFields((org.joda.time.ReadablePeriod) period26);
        org.joda.time.Period period28 = period26.normalizedStandard();
        org.joda.time.Period period30 = period26.plusYears((-100));
        org.joda.time.DurationFieldType durationFieldType32 = period26.getFieldType((int) (short) 0);
        int int33 = period18.indexOf(durationFieldType32);
        org.joda.time.field.DecoratedDurationField decoratedDurationField34 = new org.joda.time.field.DecoratedDurationField(durationField6, durationFieldType32);
        int int36 = decoratedDurationField34.getValue((long) (-15));
        long long38 = decoratedDurationField34.getMillis((int) (short) 0);
        java.lang.String str39 = decoratedDurationField34.getName();
        int int41 = decoratedDurationField34.getValue((long) (short) 100);
        long long44 = decoratedDurationField34.getDifferenceAsLong(97L, 11L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "years" + "'", str39.equals("years"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
    }
}

