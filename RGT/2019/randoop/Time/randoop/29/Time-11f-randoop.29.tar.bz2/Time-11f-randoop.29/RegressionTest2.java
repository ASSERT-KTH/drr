import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = cachedDateTimeZone7.isLocalDateTimeGap(localDateTime11);
        boolean boolean13 = cachedDateTimeZone7.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.joda.time.Period period1 = org.joda.time.Period.millis(98);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 43);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000498d + "'", double1 == 2440587.500000498d);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (short) 0);
        boolean boolean9 = dateTimeZone5.isStandardOffset(1L);
        java.lang.String str11 = dateTimeZone5.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
        java.lang.Object obj13 = null;
        boolean boolean14 = zonedChronology12.equals(obj13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getName(99L, locale18);
        org.joda.time.ReadableInstant readableInstant20 = null;
        int int21 = dateTimeZone16.getOffset(readableInstant20);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        int int24 = cachedDateTimeZone22.getStandardOffset(20L);
        boolean boolean25 = cachedDateTimeZone22.isFixed();
        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period(readableDuration27, readableInstant28);
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology32);
        org.joda.time.Period period34 = period29.withFields((org.joda.time.ReadablePeriod) period33);
        org.joda.time.Period period36 = period29.withMillis((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.Duration duration38 = period29.toDurationFrom(readableInstant37);
        int[] intArray40 = zonedChronology12.get((org.joda.time.ReadablePeriod) period29, 36000100L);
        java.lang.String str41 = zonedChronology12.toString();
        java.lang.String str42 = zonedChronology12.toString();
        org.joda.time.chrono.LenientChronology lenientChronology43 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology12);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(duration38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ZonedChronology[GregorianChronology[UTC], -00:00:00.001]" + "'", str41.equals("ZonedChronology[GregorianChronology[UTC], -00:00:00.001]"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "ZonedChronology[GregorianChronology[UTC], -00:00:00.001]" + "'", str42.equals("ZonedChronology[GregorianChronology[UTC], -00:00:00.001]"));
        org.junit.Assert.assertNotNull(lenientChronology43);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        long long27 = remainderDateTimeField25.roundHalfFloor((long) 0);
        long long29 = remainderDateTimeField25.roundHalfEven((long) (byte) -1);
        long long31 = remainderDateTimeField25.remainder((-11175938280000000L));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 59999L + "'", long31 == 59999L);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        long long27 = remainderDateTimeField25.roundHalfFloor((long) 0);
        long long29 = remainderDateTimeField25.roundHalfEven((long) (byte) -1);
        org.joda.time.DateTimeField dateTimeField30 = remainderDateTimeField25.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField30);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int7 = cachedDateTimeZone5.getOffset((-36000000L));
        boolean boolean8 = cachedDateTimeZone5.isFixed();
        long long10 = cachedDateTimeZone5.nextTransition((long) 8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 8L + "'", long10 == 8L);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsText((long) (-1), locale10);
        boolean boolean13 = offsetDateTimeField6.isLeap((long) ' ');
        long long15 = offsetDateTimeField6.roundCeiling((long) (short) 0);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = offsetDateTimeField6.getMaximumValue(readablePartial16);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 10, 43);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53 + "'", int2 == 53);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period2 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) '#');
        int int8 = period7.getHours();
        org.joda.time.Period period10 = period7.minusSeconds((int) '#');
        boolean boolean11 = period2.equals((java.lang.Object) period7);
        int[] intArray13 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        org.joda.time.DurationField durationField14 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.millisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        try {
            int[] intArray19 = gregorianChronology0.get(readablePeriod16, 8553600002L, (long) 200);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        long long27 = remainderDateTimeField25.roundHalfFloor((long) 0);
        long long29 = remainderDateTimeField25.roundHalfEven((long) (byte) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.secondOfMinute();
        int int32 = gregorianChronology30.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology30.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 8);
        long long38 = offsetDateTimeField36.roundHalfEven((long) 100);
        int int41 = offsetDateTimeField36.getDifference((long) (byte) 1, (long) (byte) 10);
        long long43 = offsetDateTimeField36.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField36, (-28800000));
        long long47 = offsetDateTimeField36.roundHalfFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.secondOfMinute();
        int int50 = gregorianChronology48.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology48.millisOfDay();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology48.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, 8);
        long long56 = offsetDateTimeField54.roundHalfEven((long) 100);
        int int59 = offsetDateTimeField54.getDifference((long) (byte) 1, (long) (byte) 10);
        long long61 = offsetDateTimeField54.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField54, (-28800000));
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField54.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField36, dateTimeFieldType64, (-25199800));
        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, (java.lang.Number) (short) 10, (java.lang.Number) (byte) 0, (java.lang.Number) 100L);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField71 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType64);
        long long73 = dividedDateTimeField71.roundFloor(172800001L);
        int int75 = dividedDateTimeField71.get(0L);
        int int76 = dividedDateTimeField71.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1L + "'", long43 == 1L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1L + "'", long47 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1L + "'", long56 == 1L);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1L + "'", long61 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 172800001L + "'", long73 == 172800001L);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 14 + "'", int75 == 14);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 14 + "'", int76 == 14);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("12");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int7 = offsetDateTimeField6.getOffset();
        org.joda.time.DurationField durationField8 = offsetDateTimeField6.getRangeDurationField();
        long long11 = offsetDateTimeField6.add(86400000L, 3L);
        java.lang.String str13 = offsetDateTimeField6.getAsText(25945200000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 345600000L + "'", long11 == 345600000L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "11" + "'", str13.equals("11"));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType4 = periodType3.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withMinutesRemoved();
        org.joda.time.Period period6 = period2.withPeriodType(periodType3);
        java.lang.String str7 = period2.toString();
        int int8 = period2.getMonths();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology14);
        org.joda.time.Period period16 = period11.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period17 = period15.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType19 = period15.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType19);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period(readableDuration21, readableInstant22);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology26);
        org.joda.time.Period period28 = period23.withFields((org.joda.time.ReadablePeriod) period27);
        org.joda.time.Period period29 = period27.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType31 = period27.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField32 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType31);
        int int33 = unsupportedDurationField20.compareTo((org.joda.time.DurationField) unsupportedDurationField32);
        org.joda.time.DurationFieldType durationFieldType34 = unsupportedDurationField20.getType();
        org.joda.time.Period period36 = period2.withFieldAdded(durationFieldType34, (-25200000));
        org.joda.time.Period period37 = period36.negated();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0S" + "'", str7.equals("PT0S"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertNotNull(unsupportedDurationField32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period37);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period2 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) '#');
        int int8 = period7.getHours();
        org.joda.time.Period period10 = period7.minusSeconds((int) '#');
        boolean boolean11 = period2.equals((java.lang.Object) period7);
        int[] intArray13 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        org.joda.time.DurationField durationField14 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.millisOfSecond();
        try {
            long long20 = gregorianChronology0.getDateTimeMillis((-43), 0, 50, (-43));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -43 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Minutes minutes8 = period7.toStandardMinutes();
        org.joda.time.Period period10 = period7.minusWeeks((-25200000));
        org.joda.time.Period period12 = period10.plusMinutes((int) (short) 100);
        org.joda.time.Period period14 = period10.plusSeconds(1131);
        org.joda.time.Period period16 = period10.plusMinutes((int) (byte) 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration3, readableInstant4);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology8);
        org.joda.time.Period period10 = period5.withFields((org.joda.time.ReadablePeriod) period9);
        org.joda.time.Period period12 = period5.withMillis((int) (short) 100);
        org.joda.time.Period period13 = period2.withFields((org.joda.time.ReadablePeriod) period12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period13.toDurationTo(readableInstant14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType17 = periodType16.withWeeksRemoved();
        org.joda.time.PeriodType periodType18 = periodType16.withMinutesRemoved();
        org.joda.time.PeriodType periodType19 = periodType16.withWeeksRemoved();
        java.lang.String str20 = periodType16.getName();
        org.joda.time.PeriodType periodType21 = periodType16.withDaysRemoved();
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration15, periodType21);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Seconds" + "'", str20.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType21);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField6 = gregorianChronology0.minutes();
        org.joda.time.Period period8 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology14);
        org.joda.time.Period period16 = period11.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period18 = period11.withMillis((int) (short) 100);
        org.joda.time.Period period19 = period8.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology25);
        org.joda.time.Period period27 = period22.withFields((org.joda.time.ReadablePeriod) period26);
        org.joda.time.Period period28 = period26.normalizedStandard();
        org.joda.time.Period period30 = period26.plusYears((-100));
        org.joda.time.DurationFieldType durationFieldType32 = period26.getFieldType((int) (short) 0);
        int int33 = period18.indexOf(durationFieldType32);
        org.joda.time.field.DecoratedDurationField decoratedDurationField34 = new org.joda.time.field.DecoratedDurationField(durationField6, durationFieldType32);
        int int36 = decoratedDurationField34.getValue((long) (-15));
        int int39 = decoratedDurationField34.getValue((long) 9700, (long) (-10));
        long long40 = decoratedDurationField34.getUnitMillis();
        boolean boolean41 = decoratedDurationField34.isSupported();
        long long43 = decoratedDurationField34.getMillis((int) ' ');
        long long45 = decoratedDurationField34.getValueAsLong((-575999520L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 60000L + "'", long40 == 60000L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1920000L + "'", long43 == 1920000L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-9599L) + "'", long45 == (-9599L));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        long long27 = remainderDateTimeField25.roundHalfFloor((long) 0);
        long long29 = remainderDateTimeField25.roundHalfEven((long) (byte) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.secondOfMinute();
        int int32 = gregorianChronology30.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology30.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 8);
        long long38 = offsetDateTimeField36.roundHalfEven((long) 100);
        int int41 = offsetDateTimeField36.getDifference((long) (byte) 1, (long) (byte) 10);
        long long43 = offsetDateTimeField36.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField36, (-28800000));
        long long47 = offsetDateTimeField36.roundHalfFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.secondOfMinute();
        int int50 = gregorianChronology48.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology48.millisOfDay();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology48.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, 8);
        long long56 = offsetDateTimeField54.roundHalfEven((long) 100);
        int int59 = offsetDateTimeField54.getDifference((long) (byte) 1, (long) (byte) 10);
        long long61 = offsetDateTimeField54.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField54, (-28800000));
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField54.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField36, dateTimeFieldType64, (-25199800));
        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, (java.lang.Number) (short) 10, (java.lang.Number) (byte) 0, (java.lang.Number) 100L);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField71 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType64);
        long long73 = dividedDateTimeField71.remainder(1L);
        long long75 = dividedDateTimeField71.roundFloor((long) (short) 0);
        long long78 = dividedDateTimeField71.set(41472189979L, 0);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1L + "'", long43 == 1L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1L + "'", long47 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1L + "'", long56 == 1L);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1L + "'", long61 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 83160001L + "'", long73 == 83160001L);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-3239999L) + "'", long75 == (-3239999L));
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 41472189979L + "'", long78 == 41472189979L);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        long long27 = remainderDateTimeField25.roundHalfFloor((long) 0);
        long long29 = remainderDateTimeField25.roundHalfEven((long) (byte) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.secondOfMinute();
        int int32 = gregorianChronology30.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology30.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 8);
        long long38 = offsetDateTimeField36.roundHalfEven((long) 100);
        int int41 = offsetDateTimeField36.getDifference((long) (byte) 1, (long) (byte) 10);
        long long43 = offsetDateTimeField36.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField36, (-28800000));
        long long47 = offsetDateTimeField36.roundHalfFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.secondOfMinute();
        int int50 = gregorianChronology48.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology48.millisOfDay();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology48.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, 8);
        long long56 = offsetDateTimeField54.roundHalfEven((long) 100);
        int int59 = offsetDateTimeField54.getDifference((long) (byte) 1, (long) (byte) 10);
        long long61 = offsetDateTimeField54.roundHalfFloor((long) 43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField54, (-28800000));
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField54.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField36, dateTimeFieldType64, (-25199800));
        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, (java.lang.Number) (short) 10, (java.lang.Number) (byte) 0, (java.lang.Number) 100L);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField71 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType64);
        long long73 = dividedDateTimeField71.roundFloor(172800001L);
        org.joda.time.ReadablePartial readablePartial74 = null;
        org.joda.time.ReadableDuration readableDuration75 = null;
        org.joda.time.ReadableInstant readableInstant76 = null;
        org.joda.time.Period period77 = new org.joda.time.Period(readableDuration75, readableInstant76);
        org.joda.time.Chronology chronology80 = null;
        org.joda.time.Period period81 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology80);
        org.joda.time.Period period82 = period77.withFields((org.joda.time.ReadablePeriod) period81);
        int int83 = period81.getWeeks();
        org.joda.time.Period period85 = org.joda.time.Period.millis(10);
        boolean boolean86 = period81.equals((java.lang.Object) period85);
        int int87 = period85.getYears();
        org.joda.time.DurationFieldType[] durationFieldTypeArray88 = period85.getFieldTypes();
        int[] intArray89 = period85.getValues();
        int int90 = dividedDateTimeField71.getMaximumValue(readablePartial74, intArray89);
        long long92 = dividedDateTimeField71.remainder((-11175938280000000L));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1L + "'", long43 == 1L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1L + "'", long47 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1L + "'", long56 == 1L);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1L + "'", long61 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 172800001L + "'", long73 == 172800001L);
        org.junit.Assert.assertNotNull(period82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(period85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertNotNull(durationFieldTypeArray88);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 14 + "'", int90 == 14);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + (-11175938321580000L) + "'", long92 == (-11175938321580000L));
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (short) 1);
        org.joda.time.Period period2 = period1.normalizedStandard();
        org.joda.time.Period period3 = period2.toPeriod();
        org.joda.time.Period period5 = period2.withDays((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfMinute();
        int int14 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 8);
        long long20 = offsetDateTimeField18.remainder((long) (byte) 1);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField18.getMaximumShortTextLength(locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType23, 99);
        int int26 = remainderDateTimeField25.getDivisor();
        int int27 = remainderDateTimeField25.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 98 + "'", int27 == 98);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("12");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfDay();
        java.lang.Object obj3 = null;
        boolean boolean4 = iSOChronology1.equals(obj3);
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        long long26 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((long) 'a', chronology28);
        org.joda.time.Period period31 = period29.minusMonths((int) '#');
        org.joda.time.Period period33 = period31.minusMillis(10);
        org.joda.time.Period period35 = period31.minusYears((int) (short) 10);
        boolean boolean36 = unsupportedDurationField11.equals((java.lang.Object) period31);
        try {
            long long39 = unsupportedDurationField11.add((long) 'a', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.joda.time.Period period3 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', chronology5);
        org.joda.time.Period period8 = period6.minusMonths((int) '#');
        int int9 = period8.getHours();
        org.joda.time.Period period11 = period8.minusSeconds((int) '#');
        boolean boolean12 = period3.equals((java.lang.Object) period8);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period8.toDurationTo(readableInstant13);
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withWeeksRemoved();
        org.joda.time.PeriodType periodType23 = periodType21.withMinutesRemoved();
        org.joda.time.Period period24 = period20.withPeriodType(periodType21);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) -1, periodType21);
        org.joda.time.Period period26 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant16, periodType21);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType21, chronology27);
        org.joda.time.PeriodType periodType29 = periodType21.withDaysRemoved();
        org.joda.time.PeriodType periodType30 = periodType29.withMinutesRemoved();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-92015999903L) + "'", long15 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 10, 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsText((long) (-1), locale10);
        long long14 = offsetDateTimeField6.add((long) (byte) 1, 2);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = offsetDateTimeField6.getMaximumValue(readablePartial15);
        long long18 = offsetDateTimeField6.roundHalfFloor((-2L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 172800001L + "'", long14 == 172800001L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        int int5 = period4.getHours();
        org.joda.time.Period period7 = period4.minusSeconds((int) '#');
        org.joda.time.Period period9 = period7.minusDays((int) (short) 100);
        org.joda.time.Period period11 = period7.minusMonths((int) 'a');
        int int12 = period7.size();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.Chronology chronology10 = iSOChronology6.withZone(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.dayOfYear();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.yearOfEra();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfHour();
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology0.years();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology9.minuteOfDay();
        boolean boolean14 = gregorianChronology0.equals((java.lang.Object) dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withMinutesRemoved();
        org.joda.time.PeriodType periodType3 = periodType0.withWeeksRemoved();
        java.lang.String str4 = periodType0.getName();
        org.joda.time.PeriodType periodType5 = periodType0.withDaysRemoved();
        org.joda.time.Period period7 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) 'a', chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) '#');
        int int13 = period12.getHours();
        org.joda.time.Period period15 = period12.minusSeconds((int) '#');
        boolean boolean16 = period7.equals((java.lang.Object) period12);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Duration duration18 = period12.toDurationTo(readableInstant17);
        long long19 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration18);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableDuration22, readableInstant23);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType26 = periodType25.withWeeksRemoved();
        org.joda.time.PeriodType periodType27 = periodType25.withMinutesRemoved();
        org.joda.time.Period period28 = period24.withPeriodType(periodType25);
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) -1, periodType25);
        org.joda.time.Period period30 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration18, readableInstant20, periodType25);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period(readableDuration33, readableInstant34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType37 = periodType36.withWeeksRemoved();
        org.joda.time.PeriodType periodType38 = periodType36.withMinutesRemoved();
        org.joda.time.Period period39 = period35.withPeriodType(periodType36);
        org.joda.time.Period period40 = new org.joda.time.Period((long) (short) -1, periodType36);
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.Period period43 = new org.joda.time.Period(readableDuration41, readableInstant42);
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType45 = periodType44.withWeeksRemoved();
        org.joda.time.PeriodType periodType46 = periodType44.withMinutesRemoved();
        org.joda.time.Period period47 = period43.withPeriodType(periodType44);
        org.joda.time.Period period48 = period40.withPeriodType(periodType44);
        org.joda.time.Period period49 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration18, readableInstant31, periodType44);
        org.joda.time.Period period51 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration52 = null;
        org.joda.time.ReadableInstant readableInstant53 = null;
        org.joda.time.Period period54 = new org.joda.time.Period(readableDuration52, readableInstant53);
        org.joda.time.Chronology chronology57 = null;
        org.joda.time.Period period58 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology57);
        org.joda.time.Period period59 = period54.withFields((org.joda.time.ReadablePeriod) period58);
        org.joda.time.Period period61 = period54.withMillis((int) (short) 100);
        org.joda.time.Period period62 = period51.withFields((org.joda.time.ReadablePeriod) period61);
        org.joda.time.ReadableDuration readableDuration63 = null;
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.Period period65 = new org.joda.time.Period(readableDuration63, readableInstant64);
        org.joda.time.Chronology chronology68 = null;
        org.joda.time.Period period69 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology68);
        org.joda.time.Period period70 = period65.withFields((org.joda.time.ReadablePeriod) period69);
        org.joda.time.Period period71 = period69.normalizedStandard();
        org.joda.time.Period period73 = period69.plusYears((-100));
        org.joda.time.DurationFieldType durationFieldType75 = period69.getFieldType((int) (short) 0);
        int int76 = period61.indexOf(durationFieldType75);
        int int77 = period49.indexOf(durationFieldType75);
        boolean boolean78 = periodType0.equals((java.lang.Object) period49);
        org.joda.time.PeriodType periodType79 = period49.getPeriodType();
        org.joda.time.Period period81 = period49.minusHours((int) (short) 0);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Seconds" + "'", str4.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-92015999903L) + "'", long19 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(periodType46);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertNotNull(period61);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(period70);
        org.junit.Assert.assertNotNull(period71);
        org.junit.Assert.assertNotNull(period73);
        org.junit.Assert.assertNotNull(durationFieldType75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(periodType79);
        org.junit.Assert.assertNotNull(period81);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology0.millis();
        org.joda.time.Period period7 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) 'a', chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) '#');
        int int13 = period12.getHours();
        org.joda.time.Period period15 = period12.minusSeconds((int) '#');
        boolean boolean16 = period7.equals((java.lang.Object) period12);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Duration duration18 = period12.toDurationTo(readableInstant17);
        long long19 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration18);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableDuration22, readableInstant23);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType26 = periodType25.withWeeksRemoved();
        org.joda.time.PeriodType periodType27 = periodType25.withMinutesRemoved();
        org.joda.time.Period period28 = period24.withPeriodType(periodType25);
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) -1, periodType25);
        org.joda.time.Period period30 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration18, readableInstant20, periodType25);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period(readableDuration33, readableInstant34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType37 = periodType36.withWeeksRemoved();
        org.joda.time.PeriodType periodType38 = periodType36.withMinutesRemoved();
        org.joda.time.Period period39 = period35.withPeriodType(periodType36);
        org.joda.time.Period period40 = new org.joda.time.Period((long) (short) -1, periodType36);
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.Period period43 = new org.joda.time.Period(readableDuration41, readableInstant42);
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType45 = periodType44.withWeeksRemoved();
        org.joda.time.PeriodType periodType46 = periodType44.withMinutesRemoved();
        org.joda.time.Period period47 = period43.withPeriodType(periodType44);
        org.joda.time.Period period48 = period40.withPeriodType(periodType44);
        org.joda.time.Period period49 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration18, readableInstant31, periodType44);
        org.joda.time.Period period51 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration52 = null;
        org.joda.time.ReadableInstant readableInstant53 = null;
        org.joda.time.Period period54 = new org.joda.time.Period(readableDuration52, readableInstant53);
        org.joda.time.Chronology chronology57 = null;
        org.joda.time.Period period58 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology57);
        org.joda.time.Period period59 = period54.withFields((org.joda.time.ReadablePeriod) period58);
        org.joda.time.Period period61 = period54.withMillis((int) (short) 100);
        org.joda.time.Period period62 = period51.withFields((org.joda.time.ReadablePeriod) period61);
        org.joda.time.ReadableDuration readableDuration63 = null;
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.Period period65 = new org.joda.time.Period(readableDuration63, readableInstant64);
        org.joda.time.Chronology chronology68 = null;
        org.joda.time.Period period69 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology68);
        org.joda.time.Period period70 = period65.withFields((org.joda.time.ReadablePeriod) period69);
        org.joda.time.Period period71 = period69.normalizedStandard();
        org.joda.time.Period period73 = period69.plusYears((-100));
        org.joda.time.DurationFieldType durationFieldType75 = period69.getFieldType((int) (short) 0);
        int int76 = period61.indexOf(durationFieldType75);
        int int77 = period49.indexOf(durationFieldType75);
        long long80 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period49, (long) 13, (int) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-92015999903L) + "'", long19 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(periodType46);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertNotNull(period61);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(period70);
        org.junit.Assert.assertNotNull(period71);
        org.junit.Assert.assertNotNull(period73);
        org.junit.Assert.assertNotNull(durationFieldType75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-9201599899987L) + "'", long80 == (-9201599899987L));
    }
}

