import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        long long7 = delegatedDateTimeField5.roundFloor((long) 100);
        java.util.Locale locale9 = null;
        java.lang.String str10 = delegatedDateTimeField5.getAsText(259200020, locale9);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = delegatedDateTimeField5.getAsShortText(readablePartial11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-259200000L) + "'", long7 == (-259200000L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "259200020" + "'", str10.equals("259200020"));
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        java.util.Date date10 = localDate9.toDate();
//        int int11 = localDate9.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property12 = localDate9.weekyear();
//        org.joda.time.LocalDate localDate13 = property12.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology14 = localDate13.getChronology();
//        org.joda.time.LocalDate localDate16 = localDate13.withCenturyOfEra(19);
//        org.joda.time.LocalDate localDate17 = localDate2.withFields((org.joda.time.ReadablePartial) localDate16);
//        int int18 = localDate16.getYearOfEra();
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "1970-W01-3");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendEraText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str16 = dateTimeFormatter14.print(101L);
        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatter14.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.append(dateTimePrinter17);
        org.joda.time.format.DateTimeParser dateTimeParser19 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray20 = new org.joda.time.format.DateTimeParser[] { dateTimeParser19 };
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.append(dateTimePrinter17, dateTimeParserArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970-W01-3" + "'", str16.equals("1970-W01-3"));
        org.junit.Assert.assertNotNull(dateTimePrinter17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeParserArray20);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate6, locale7);
//        java.lang.String str9 = delegatedDateTimeField5.toString();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forID("UTC");
//        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone11);
//        int[] intArray17 = new int[] { 2019, 100, 69, 365 };
//        int int18 = delegatedDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate12, intArray17);
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj20 = null;
//        boolean boolean21 = gJChronology19.equals(obj20);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology19);
//        org.joda.time.Chronology chronology23 = dateTime22.getChronology();
//        org.joda.time.Chronology chronology24 = dateTime22.getChronology();
//        org.joda.time.DateTime.Property property25 = dateTime22.secondOfMinute();
//        org.joda.time.DateTime dateTime26 = property25.roundHalfCeilingCopy();
//        long long27 = property25.remainder();
//        org.joda.time.DateTimeField dateTimeField28 = property25.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property25.getFieldType();
//        try {
//            int int30 = localDate12.get(dateTimeFieldType29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfMinute' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str9.equals("DateTimeField[weekOfWeekyear]"));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj3 = null;
        boolean boolean4 = gJChronology2.equals(obj3);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.Chronology chronology6 = dateTime5.getChronology();
        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) (byte) 100);
        org.joda.time.DateTime dateTime10 = dateTime5.plusWeeks(2000);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        java.lang.String str2 = dateTimeFormatter0.print(101L);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
//        java.util.Date date6 = localDate5.toDate();
//        int int7 = localDate5.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property8 = localDate5.weekyear();
//        org.joda.time.LocalDate localDate9 = property8.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology10 = localDate9.getChronology();
//        org.joda.time.LocalDate localDate12 = localDate9.withYear((int) (short) 10);
//        org.joda.time.LocalTime localTime13 = null;
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology14.getZone();
//        org.joda.time.DateTime dateTime16 = localDate12.toDateTime(localTime13, dateTimeZone15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withZone(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        long long20 = dateTimeZone15.convertUTCToLocal((long) '4');
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-W01-3" + "'", str2.equals("1970-W01-3"));
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate6, locale7);
//        int int9 = delegatedDateTimeField5.getMaximumValue();
//        org.joda.time.DurationField durationField10 = delegatedDateTimeField5.getRangeDurationField();
//        long long13 = delegatedDateTimeField5.add((long) 57600, 0);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 57600L + "'", long13 == 57600L);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(69);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        java.io.Writer writer4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = iSOChronology6.weeks();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 10.0d);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
        long long14 = dateTimeZone10.convertLocalToUTC(0L, false);
        long long18 = dateTimeZone10.convertLocalToUTC((long) (byte) 1, true, 1560640820478L);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj20 = null;
        boolean boolean21 = gJChronology19.equals(obj20);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology19);
        org.joda.time.Chronology chronology23 = dateTime22.getChronology();
        org.joda.time.DateTime dateTime25 = dateTime22.minusYears((int) (byte) 100);
        org.joda.time.DateTime dateTime27 = dateTime22.plusWeeks(2000);
        int int28 = dateTimeZone10.getOffset((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime.Property property29 = dateTime27.millisOfSecond();
        try {
            dateTimeFormatter3.printTo(writer4, (org.joda.time.ReadableInstant) dateTime27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(property29);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
//        int int2 = dateTime1.getSecondOfDay();
//        try {
//            org.joda.time.DateTime dateTime4 = dateTime1.withSecondOfMinute((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        boolean boolean4 = iSOChronology1.equals((java.lang.Object) 10.0d);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology6 = iSOChronology1.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.era();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DurationField durationField10 = gJChronology8.years();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendWeekOfWeekyear(53);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime20 = dateTime19.toLocalDateTime();
        org.joda.time.DateTime.Property property21 = dateTime19.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime23.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property26 = dateTime25.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        boolean boolean28 = dateTime19.isSupported(dateTimeFieldType27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendFixedSignedDecimal(dateTimeFieldType27, 365);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField7, durationField10, dateTimeFieldType27, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str2 = dateTimeFormatter0.print(101L);
        java.util.Locale locale3 = dateTimeFormatter0.getLocale();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-W01-3" + "'", str2.equals("1970-W01-3"));
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNull(dateTimeZone4);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 100);
//        org.joda.time.DateMidnight dateMidnight2 = dateTime1.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime1.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        java.util.Date date8 = localDate7.toDate();
//        int int9 = localDate7.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property10 = localDate7.weekyear();
//        org.joda.time.LocalDate localDate11 = property10.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology12 = localDate11.getChronology();
//        boolean boolean13 = cachedDateTimeZone4.equals((java.lang.Object) chronology12);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        java.lang.String str5 = partial3.toString();
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType7 = partial3.getFieldType((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField10);
        int int12 = skipUndoDateTimeField11.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 10);
        boolean boolean15 = gregorianChronology3.equals((java.lang.Object) skipUndoDateTimeField11);
        long long17 = skipUndoDateTimeField11.roundHalfEven((long) 746);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1000L + "'", long17 == 1000L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("Property[monthOfYear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[monthOfYear]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField10);
        int int12 = skipUndoDateTimeField11.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 10);
        boolean boolean15 = gregorianChronology3.equals((java.lang.Object) skipUndoDateTimeField11);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipUndoDateTimeField11, 20, 1843, 70);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20 for secondOfMinute must be in the range [1843,70]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        boolean boolean5 = dateTime3.isEqual(1044883541620800000L);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "BuddhistChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMinuteOfHour((int) '4');
        org.joda.time.DateMidnight dateMidnight6 = dateTime3.toDateMidnight();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateMidnight6);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.yearOfCentury();
        org.joda.time.LocalDate localDate3 = property2.roundHalfFloorCopy();
        int int4 = property2.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property2.getField();
        org.joda.time.LocalDate localDate6 = property2.roundHalfEvenCopy();
        int int7 = property2.getMaximumValue();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 99 + "'", int7 == 99);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate6, locale7);
//        java.lang.String str9 = delegatedDateTimeField5.toString();
//        org.joda.time.DurationField durationField10 = delegatedDateTimeField5.getLeapDurationField();
//        org.joda.time.DurationField durationField11 = delegatedDateTimeField5.getRangeDurationField();
//        java.lang.String str13 = delegatedDateTimeField5.getAsText((long) (short) 0);
//        org.joda.time.DurationField durationField14 = delegatedDateTimeField5.getRangeDurationField();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str9.equals("DateTimeField[weekOfWeekyear]"));
//        org.junit.Assert.assertNull(durationField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(durationField14);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.minusMonths(10);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readablePeriod6);
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime3.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime dateTime5 = dateTime1.minusWeeks(24);
//        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(784);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        java.lang.String str9 = dateTime7.toString(dateTimeFormatter8);
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTimeFormatter8.getZone();
//        java.lang.Appendable appendable11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = iSOChronology13.days();
//        org.joda.time.DurationField durationField15 = iSOChronology13.centuries();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.era();
//        org.joda.time.Partial partial17 = new org.joda.time.Partial((org.joda.time.Chronology) iSOChronology13);
//        try {
//            dateTimeFormatter8.printTo(appendable11, (org.joda.time.ReadablePartial) partial17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-W06-5" + "'", str9.equals("1970-W06-5"));
//        org.junit.Assert.assertNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj4 = null;
        boolean boolean5 = gJChronology3.equals(obj4);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.Instant instant7 = gJChronology3.getGregorianCutover();
        org.joda.time.DurationField durationField8 = gJChronology3.millis();
        boolean boolean9 = gJChronology0.equals((java.lang.Object) gJChronology3);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.secondOfDay();
        org.joda.time.Instant instant9 = gJChronology4.getGregorianCutover();
        try {
            org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(70, 10, (-2020), (org.joda.time.Chronology) gJChronology4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2020 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(instant9);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.LocalDate localDate4 = localDate2.withYearOfCentury((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateMidnight dateMidnight6 = localDate4.toDateMidnight(dateTimeZone5);
//        int int7 = localDate4.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
//    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
//        java.util.Locale locale9 = null;
//        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
//        java.util.Locale locale19 = null;
//        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
//        long long22 = offsetDateTimeField18.roundHalfCeiling((long) 4);
//        org.joda.time.DurationField durationField23 = offsetDateTimeField18.getLeapDurationField();
//        java.lang.String str25 = offsetDateTimeField18.getAsText(1546300799999L);
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology26);
//        org.joda.time.DurationField durationField28 = gJChronology26.minutes();
//        org.joda.time.Partial partial29 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology26);
//        org.joda.time.ReadablePeriod readablePeriod30 = null;
//        org.joda.time.Partial partial31 = partial29.minus(readablePeriod30);
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj34 = null;
//        boolean boolean35 = gJChronology33.equals(obj34);
//        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology33);
//        org.joda.time.DateTimeField dateTimeField37 = gJChronology33.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37);
//        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate();
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = delegatedDateTimeField38.getAsText((org.joda.time.ReadablePartial) localDate39, locale40);
//        java.lang.String str42 = delegatedDateTimeField38.toString();
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forID("UTC");
//        org.joda.time.LocalDate localDate45 = org.joda.time.LocalDate.now(dateTimeZone44);
//        int[] intArray50 = new int[] { 2019, 100, 69, 365 };
//        int int51 = delegatedDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate45, intArray50);
//        java.util.Locale locale53 = null;
//        try {
//            int[] intArray54 = offsetDateTimeField18.set((org.joda.time.ReadablePartial) partial31, 100, intArray50, "", locale53);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for monthOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200000L) + "'", long22 == (-259200000L));
//        org.junit.Assert.assertNull(durationField23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "3" + "'", str25.equals("3"));
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(partial31);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str42.equals("DateTimeField[weekOfWeekyear]"));
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 52 + "'", int51 == 52);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendPattern("1");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendYearOfCentury((int) (byte) 10, (-2020));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder17.appendPattern("1");
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime24.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime27 = dateTime26.toLocalDateTime();
        org.joda.time.DateTime.Property property28 = dateTime26.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        boolean boolean35 = dateTime26.isSupported(dateTimeFieldType34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType34, 563);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder9.appendShortText(dateTimeFieldType34);
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 100, "19700104");
        org.joda.time.DurationFieldType durationFieldType42 = illegalFieldValueException41.getDurationFieldType();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localDateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNull(durationFieldType42);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.LocalDate localDate5 = dateTime3.toLocalDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatterBuilder10.toFormatter();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime13.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property16 = dateTime15.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property16.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType17);
        int int19 = localDate5.indexOf(dateTimeFieldType17);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType17, 0, (-2020), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [-2020,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        boolean boolean4 = iSOChronology1.equals((java.lang.Object) 10.0d);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology6 = iSOChronology1.withZone(dateTimeZone5);
        long long9 = dateTimeZone5.convertLocalToUTC(0L, false);
        long long13 = dateTimeZone5.convertLocalToUTC((long) (byte) 1, true, 1560640820478L);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj15 = null;
        boolean boolean16 = gJChronology14.equals(obj15);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology14);
        org.joda.time.Chronology chronology18 = dateTime17.getChronology();
        org.joda.time.DateTime dateTime20 = dateTime17.minusYears((int) (byte) 100);
        org.joda.time.DateTime dateTime22 = dateTime17.plusWeeks(2000);
        int int23 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime22.toMutableDateTime();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime24);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 16);
        org.joda.time.LocalDate localDate3 = localDate1.withWeekyear((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property14 = dateTime13.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
        boolean boolean16 = dateTime7.isSupported(dateTimeFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, "DateTimeField[weekOfWeekyear]");
        try {
            org.joda.time.LocalDate localDate20 = localDate3.withField(dateTimeFieldType15, (-11));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -11 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField5.getAsShortText(2000, locale12);
        long long16 = delegatedDateTimeField5.add((long) 69, (long) 365);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2000" + "'", str13.equals("2000"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 220752000069L + "'", long16 == 220752000069L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField10);
        int int12 = skipUndoDateTimeField11.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 10);
        boolean boolean15 = gregorianChronology3.equals((java.lang.Object) skipUndoDateTimeField11);
        long long18 = skipUndoDateTimeField11.set(0L, 10);
        int int19 = skipUndoDateTimeField11.getMinimumValue();
        java.util.Locale locale21 = null;
        java.lang.String str22 = skipUndoDateTimeField11.getAsText(0L, locale21);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10000L + "'", long18 == 10000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(1546300799999L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2458484L + "'", long1 == 2458484L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str3 = illegalFieldValueException2.toString();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str6 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported"));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(3, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.minusMonths(10);
        int int6 = dateTime3.getSecondOfDay();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 86399 + "'", int6 == 86399);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str8 = dateTimeZone6.getShortName(31535999999L);
//        try {
//            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(3, 1969, 86399, 0, 12, (int) (short) -1, dateTimeZone6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("DateTimeField[weekOfWeekyear]");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        boolean boolean4 = jodaTimePermission1.equals((java.lang.Object) 18L);
        java.security.PermissionCollection permissionCollection5 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(permissionCollection5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.yearOfCentury();
        org.joda.time.Instant instant4 = new org.joda.time.Instant(0L);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.plus(readableDuration5);
        org.joda.time.Instant instant8 = instant6.withMillis((-259200000L));
        int int9 = property2.getDifference((org.joda.time.ReadableInstant) instant8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj11 = null;
        boolean boolean12 = gJChronology10.equals(obj11);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeField dateTimeField14 = gJChronology10.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 19, (long) 19);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField15.getDurationField();
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField15.getAsShortText((int) 'a', locale21);
        java.lang.String str24 = delegatedDateTimeField15.getAsText((long) 69);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField15, 365);
        int int27 = instant8.get((org.joda.time.DateTimeField) delegatedDateTimeField15);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "97" + "'", str22.equals("97"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
//        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
//        int int6 = property4.getMaximumValue();
//        int int7 = property4.getMaximumValueOverall();
//        org.joda.time.DateTime dateTime9 = property4.addWrapFieldToCopy((int) (short) 10);
//        int int10 = dateTime9.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1012 + "'", int10 == 1012);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
//        org.joda.time.Chronology chronology4 = julianChronology0.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology0.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone6.getUncachedZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
//        java.util.Date date11 = localDate10.toDate();
//        int int12 = localDate10.getCenturyOfEra();
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate();
//        boolean boolean14 = localDate10.isAfter((org.joda.time.ReadablePartial) localDate13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
//        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
//        java.util.Date date18 = localDate17.toDate();
//        int int19 = localDate17.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property20 = localDate17.weekyear();
//        org.joda.time.LocalDate localDate21 = property20.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology22 = localDate21.getChronology();
//        org.joda.time.LocalDate localDate24 = localDate21.withCenturyOfEra(19);
//        org.joda.time.LocalDate localDate25 = localDate10.withFields((org.joda.time.ReadablePartial) localDate24);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime27 = localDate10.toDateTimeAtStartOfDay(dateTimeZone26);
//        boolean boolean28 = cachedDateTimeZone6.equals((java.lang.Object) dateTime27);
//        java.lang.String str30 = cachedDateTimeZone6.getNameKey((long) 2);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
        org.joda.time.LocalDate localDate3 = property2.withMinimumValue();
        org.joda.time.LocalDate localDate4 = property2.roundFloorCopy();
        java.lang.String str5 = localDate4.toString();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-31" + "'", str5.equals("1969-12-31"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField3 = gJChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField6);
        int int8 = skipUndoDateTimeField7.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 10);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipUndoDateTimeField10.getAsShortText((int) (short) 0, locale12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now(dateTimeZone15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        java.lang.String str18 = gregorianChronology17.toString();
        org.joda.time.DurationField durationField19 = gregorianChronology17.months();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime21.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property24 = dateTime23.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, durationField19, dateTimeFieldType25, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "GregorianChronology[UTC]" + "'", str18.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = gJChronology1.equals(obj2);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = delegatedDateTimeField6.getAsText((org.joda.time.ReadablePartial) localDate7, locale8);
//        java.lang.String str10 = delegatedDateTimeField6.toString();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forID("UTC");
//        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.now(dateTimeZone12);
//        int[] intArray18 = new int[] { 2019, 100, 69, 365 };
//        int int19 = delegatedDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate13, intArray18);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        org.joda.time.DurationField durationField22 = iSOChronology21.weeks();
//        boolean boolean24 = iSOChronology21.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology26 = iSOChronology21.withZone(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str29 = dateTimeZone27.getShortName(31535999999L);
//        org.joda.time.Chronology chronology30 = iSOChronology21.withZone(dateTimeZone27);
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology21.secondOfMinute();
//        try {
//            org.joda.time.Partial partial32 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray18, (org.joda.time.Chronology) iSOChronology21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str10.equals("DateTimeField[weekOfWeekyear]"));
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52 + "'", int19 == 52);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UTC" + "'", str29.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.Partial partial5 = partial3.minus(readablePeriod4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getMillisOfSecond();
//        org.joda.time.DateTime dateTime9 = partial3.toDateTime((org.joda.time.ReadableInstant) dateTime7);
//        try {
//            org.joda.time.DateTimeFieldType dateTimeFieldType11 = partial3.getFieldType((int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(partial5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
//        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology7 = localDate6.getChronology();
//        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
//        org.joda.time.DurationFieldType durationFieldType10 = null;
//        boolean boolean11 = localDate9.isSupported(durationFieldType10);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) '#');
//        org.joda.time.LocalDate.Property property7 = localDate6.dayOfYear();
//        int int8 = localDate6.getYear();
//        java.lang.String str9 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) localDate6);
//        try {
//            org.joda.time.LocalTime localTime11 = dateTimeFormatter3.parseLocalTime("24");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"24\" is too short");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969365" + "'", str9.equals("1969365"));
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        java.util.Locale locale7 = null;
        int int8 = skipUndoDateTimeField6.getMaximumTextLength(locale7);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property11 = localDate10.dayOfYear();
        org.joda.time.LocalDate localDate12 = property11.withMinimumValue();
        org.joda.time.DateTimeField[] dateTimeFieldArray13 = localDate12.getFields();
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipUndoDateTimeField6.getAsText((org.joda.time.ReadablePartial) localDate12, 563, locale15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder17.appendTwoDigitYear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatterBuilder17.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder24.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder28.toFormatter();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
        org.joda.time.DateTime dateTime33 = dateTime31.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property34 = dateTime33.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder28.appendShortText(dateTimeFieldType35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder17.appendFixedDecimal(dateTimeFieldType35, 1012);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, dateTimeFieldType35, (-259200000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(dateTimeFieldArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "563" + "'", str16.equals("563"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        org.joda.time.Interval interval6 = property4.toInterval();
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(readableInterval7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj2 = null;
        boolean boolean3 = gJChronology1.equals(obj2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        boolean boolean9 = dateTime7.isEqual((-63713260799968L));
        org.joda.time.Instant instant11 = new org.joda.time.Instant(0L);
        org.joda.time.MutableDateTime mutableDateTime12 = instant11.toMutableDateTimeISO();
        boolean boolean13 = dateTime7.isBefore((org.joda.time.ReadableInstant) instant11);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        java.lang.String str2 = dateTimeFormatter0.print(101L);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
//        java.util.Date date6 = localDate5.toDate();
//        int int7 = localDate5.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property8 = localDate5.weekyear();
//        org.joda.time.LocalDate localDate9 = property8.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology10 = localDate9.getChronology();
//        org.joda.time.LocalDate localDate12 = localDate9.withYear((int) (short) 10);
//        org.joda.time.LocalTime localTime13 = null;
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology14.getZone();
//        org.joda.time.DateTime dateTime16 = localDate12.toDateTime(localTime13, dateTimeZone15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withZone(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField20 = iSOChronology19.weekyears();
//        long long23 = durationField20.subtract(0L, 1L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-W01-3" + "'", str2.equals("1970-W01-3"));
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-31449600000L) + "'", long23 == (-31449600000L));
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder9.toFormatter();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTimeZoneShortName(strMap11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder4.appendTimeZoneName(strMap11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendLiteral('4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(strMap11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property17 = dateTime16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType18, 1012);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendLiteral('a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property4.getFieldType();
        org.joda.time.DateTime dateTime6 = property4.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        java.util.Date date9 = localDate8.toDate();
//        int int10 = localDate8.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property11 = localDate8.weekyear();
//        org.joda.time.LocalDate localDate12 = property11.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology13 = localDate12.getChronology();
//        org.joda.time.LocalDate localDate15 = localDate12.withYear((int) (short) 10);
//        org.joda.time.LocalTime localTime16 = null;
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone18 = gJChronology17.getZone();
//        org.joda.time.DateTime dateTime19 = localDate15.toDateTime(localTime16, dateTimeZone18);
//        org.joda.time.LocalTime localTime20 = null;
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone22 = gJChronology21.getZone();
//        org.joda.time.DateTime dateTime23 = localDate15.toDateTime(localTime20, dateTimeZone22);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(1018L, dateTimeZone22);
//        try {
//            org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((int) (short) -1, 0, 3, (-1), (int) (byte) -1, dateTimeZone22);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str3 = illegalFieldValueException2.toString();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str8 = illegalFieldValueException7.toString();
        java.lang.String str9 = illegalFieldValueException7.toString();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        java.lang.String str11 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported"));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported" + "'", str8.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported" + "'", str9.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendPattern("1");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.minutes();
        java.lang.String str5 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str5.equals("JulianChronology[America/Los_Angeles]"));
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) ' ');
//        java.io.Writer writer3 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = gJChronology4.equals(obj5);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.Chronology chronology8 = dateTime7.getChronology();
//        int int9 = dateTime7.getSecondOfDay();
//        org.joda.time.DateTime.Property property10 = dateTime7.yearOfCentury();
//        try {
//            dateTimeFormatter2.printTo(writer3, (org.joda.time.ReadableInstant) dateTime7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(property10);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.Chronology chronology5 = dateTime3.getChronology();
        org.joda.time.DateTime.Property property6 = dateTime3.secondOfMinute();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.withMaximumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Interval interval8 = localDate5.toInterval(dateTimeZone7);
//        int int10 = dateTimeZone7.getOffsetFromLocal((long) 12);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        org.joda.time.Chronology chronology12 = buddhistChronology11.withUTC();
//        org.joda.time.Chronology chronology13 = buddhistChronology11.withUTC();
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(interval8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.years();
        try {
            long long7 = gJChronology0.getDateTimeMillis(10, 0, 69, 70);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DurationField durationField5 = property4.getRangeDurationField();
        java.lang.String str6 = property4.toString();
        int int7 = property4.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[monthOfYear]" + "'", str6.equals("Property[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        long long7 = delegatedDateTimeField5.roundFloor((long) 100);
        java.lang.String str9 = delegatedDateTimeField5.getAsText((-60479999900L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-259200000L) + "'", long7 == (-259200000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "5" + "'", str9.equals("5"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
//        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology7 = localDate6.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime9.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.LocalDate localDate13 = dateTime11.toLocalDate();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendDayOfMonth(18);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendSecondOfMinute(100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatterBuilder18.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
//        org.joda.time.DateTime dateTime23 = dateTime21.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property24 = dateTime23.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder18.appendShortText(dateTimeFieldType25);
//        int int27 = localDate13.indexOf(dateTimeFieldType25);
//        org.joda.time.LocalDate localDate29 = localDate6.withField(dateTimeFieldType25, 12);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
//        try {
//            org.joda.time.Partial partial32 = new org.joda.time.Partial(dateTimeFieldType25, 99, (org.joda.time.Chronology) iSOChronology31);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for monthOfYear must not be larger than 12");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.DateTimeField dateTimeField0 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forID("UTC");
//        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        java.lang.String str5 = gregorianChronology4.toString();
//        org.joda.time.DurationField durationField6 = gregorianChronology4.months();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        java.util.Date date10 = localDate9.toDate();
//        int int11 = localDate9.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property12 = localDate9.weekyear();
//        org.joda.time.LocalDate localDate13 = property12.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology14 = localDate13.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
//        org.joda.time.DateTime dateTime18 = dateTime16.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property19 = dateTime18.monthOfYear();
//        org.joda.time.LocalDate localDate20 = dateTime18.toLocalDate();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendDayOfMonth(18);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder21.appendSecondOfMinute(100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatterBuilder25.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone27);
//        org.joda.time.DateTime dateTime30 = dateTime28.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property31 = dateTime30.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property31.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder25.appendShortText(dateTimeFieldType32);
//        int int34 = localDate20.indexOf(dateTimeFieldType32);
//        org.joda.time.LocalDate localDate36 = localDate13.withField(dateTimeFieldType32, 12);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, durationField6, dateTimeFieldType32, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[UTC]" + "'", str5.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(localDate36);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate6, locale7);
//        java.lang.String str9 = delegatedDateTimeField5.toString();
//        long long11 = delegatedDateTimeField5.roundHalfFloor((long) 12);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        org.joda.time.LocalDate localDate14 = dateTime13.toLocalDate();
//        java.util.Date date15 = localDate14.toDate();
//        int int16 = localDate14.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property17 = localDate14.weekyear();
//        org.joda.time.LocalDate localDate18 = property17.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology19 = localDate18.getChronology();
//        org.joda.time.LocalDate localDate21 = localDate18.withYear((int) (short) 10);
//        int int22 = localDate21.getYearOfEra();
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj25 = null;
//        boolean boolean26 = gJChronology24.equals(obj25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology24);
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology24.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate();
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = delegatedDateTimeField29.getAsText((org.joda.time.ReadablePartial) localDate30, locale31);
//        java.lang.String str33 = delegatedDateTimeField29.toString();
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forID("UTC");
//        org.joda.time.LocalDate localDate36 = org.joda.time.LocalDate.now(dateTimeZone35);
//        int[] intArray41 = new int[] { 2019, 100, 69, 365 };
//        int int42 = delegatedDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate36, intArray41);
//        try {
//            int[] intArray44 = delegatedDateTimeField5.set((org.joda.time.ReadablePartial) localDate21, 99, intArray41, 18);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 99");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str9.equals("DateTimeField[weekOfWeekyear]"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 19 + "'", int16 == 19);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1" + "'", str32.equals("1"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str33.equals("DateTimeField[weekOfWeekyear]"));
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(intArray41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 52 + "'", int42 == 52);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.DurationFieldType durationFieldType5 = null;
//        boolean boolean6 = localDate2.isSupported(durationFieldType5);
//        try {
//            org.joda.time.LocalDate localDate8 = localDate2.withDayOfWeek(794);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 794 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.LocalDate localDate3 = dateTime2.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str5 = localDate3.toString(dateTimeFormatter4);
//        org.joda.time.LocalDate localDate7 = localDate3.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate9 = localDate7.withWeekyear((int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.LocalDate localDate12 = localDate7.withPeriodAdded(readablePeriod10, (int) '#');
//        int[] intArray14 = buddhistChronology0.get((org.joda.time.ReadablePartial) localDate12, (long) 20);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
//        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
//        java.util.Date date18 = localDate17.toDate();
//        int int19 = localDate17.getCenturyOfEra();
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate();
//        boolean boolean21 = localDate17.isAfter((org.joda.time.ReadablePartial) localDate20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
//        org.joda.time.LocalDate localDate24 = dateTime23.toLocalDate();
//        java.util.Date date25 = localDate24.toDate();
//        int int26 = localDate24.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property27 = localDate24.weekyear();
//        org.joda.time.LocalDate localDate28 = property27.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology29 = localDate28.getChronology();
//        org.joda.time.LocalDate localDate31 = localDate28.withCenturyOfEra(19);
//        org.joda.time.LocalDate localDate32 = localDate17.withFields((org.joda.time.ReadablePartial) localDate31);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
//        org.joda.time.DurationField durationField35 = iSOChronology34.weeks();
//        boolean boolean37 = iSOChronology34.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology39 = iSOChronology34.withZone(dateTimeZone38);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str42 = dateTimeZone40.getShortName(31535999999L);
//        org.joda.time.Chronology chronology43 = iSOChronology34.withZone(dateTimeZone40);
//        org.joda.time.DateTime dateTime44 = localDate32.toDateTimeAtMidnight(dateTimeZone40);
//        org.joda.time.Chronology chronology45 = buddhistChronology0.withZone(dateTimeZone40);
//        boolean boolean47 = buddhistChronology0.equals((java.lang.Object) 1.0f);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970004" + "'", str5.equals("1970004"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(chronology39);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "UTC" + "'", str42.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        java.util.Date date5 = localDate4.toDate();
//        int int6 = localDate4.getCenturyOfEra();
//        long long8 = gJChronology0.set((org.joda.time.ReadablePartial) localDate4, (long) 20);
//        org.joda.time.LocalDate.Property property9 = localDate4.yearOfCentury();
//        org.joda.time.LocalDate.Property property10 = localDate4.monthOfYear();
//        org.joda.time.LocalDate localDate11 = property10.roundCeilingCopy();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 259200020L + "'", long8 == 259200020L);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(localDate11);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property3 = localDate2.yearOfCentury();
        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate2);
        java.util.Locale locale6 = null;
        try {
            java.lang.String str7 = localDate2.toString("ZonedChronology[GJChronology[UTC], UTC]", locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-365T��:��:��" + "'", str4.equals("1969-365T��:��:��"));
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = localDate8.toDateTimeAtCurrentTime();
//        org.joda.time.DateTime dateTime11 = dateTime9.withYear(259200020);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder9.toFormatter();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTimeZoneShortName(strMap11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder4.appendTimeZoneName(strMap11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendFractionOfHour((int) (short) 1, (int) (byte) -1);
        org.joda.time.format.DateTimeParser dateTimeParser17 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendOptional(dateTimeParser17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(strMap11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.LocalDate localDate7 = localDate2.withPeriodAdded(readablePeriod5, (int) (byte) 100);
//        org.joda.time.DateTime dateTime8 = localDate2.toDateTimeAtMidnight();
//        org.joda.time.DateTime dateTime10 = dateTime8.minusMillis(0);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTimeZoneShortName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendClockhourOfDay((int) (byte) 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap12 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder7.appendTimeZoneName(strMap12);
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray15 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.append(dateTimePrinter14, dateTimeParserArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parsers supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        java.util.Date date10 = localDate9.toDate();
//        int int11 = localDate9.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property12 = localDate9.weekyear();
//        org.joda.time.LocalDate localDate13 = property12.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology14 = localDate13.getChronology();
//        org.joda.time.LocalDate localDate16 = localDate13.withCenturyOfEra(19);
//        org.joda.time.LocalDate localDate17 = localDate2.withFields((org.joda.time.ReadablePartial) localDate16);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime19 = localDate2.toDateTimeAtStartOfDay(dateTimeZone18);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        java.lang.String str22 = dateTimeFormatter20.print(101L);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
//        org.joda.time.LocalDate localDate25 = dateTime24.toLocalDate();
//        java.util.Date date26 = localDate25.toDate();
//        int int27 = localDate25.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property28 = localDate25.weekyear();
//        org.joda.time.LocalDate localDate29 = property28.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology30 = localDate29.getChronology();
//        org.joda.time.LocalDate localDate32 = localDate29.withYear((int) (short) 10);
//        org.joda.time.LocalTime localTime33 = null;
//        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone35 = gJChronology34.getZone();
//        org.joda.time.DateTime dateTime36 = localDate32.toDateTime(localTime33, dateTimeZone35);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter20.withZone(dateTimeZone35);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeUtils.getZone(dateTimeZone35);
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
//        try {
//            org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((java.lang.Object) localDate2, (org.joda.time.Chronology) iSOChronology39);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.LocalDate");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970-W01-3" + "'", str22.equals("1970-W01-3"));
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 19 + "'", int27 == 19);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(gJChronology34);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        java.lang.String str5 = partial3.toString();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.yearOfCentury();
        org.joda.time.Partial partial10 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology6);
        java.lang.String str11 = partial10.toString();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Partial partial13 = partial10.withChronologyRetainFields(chronology12);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "[]" + "'", str11.equals("[]"));
        org.junit.Assert.assertNotNull(partial13);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
//        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
//        int int7 = property5.getMinimumValue();
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292275054) + "'", int7 == (-292275054));
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("PST", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PST/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
//        int int5 = dateTime3.getSecondOfDay();
//        org.joda.time.DateTime dateTime7 = dateTime3.withWeekyear(100);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsShortText(locale5);
//        java.lang.String str7 = property4.getAsShortText();
//        int int8 = property4.get();
//        org.joda.time.DateTime dateTime9 = property4.withMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property14 = dateTime13.monthOfYear();
//        org.joda.time.DateTime dateTime15 = property14.withMaximumValue();
//        org.joda.time.DateTime dateTime16 = dateTime15.withEarlierOffsetAtOverlap();
//        int int17 = property4.getDifference((org.joda.time.ReadableInstant) dateTime16);
//        int int18 = dateTime16.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jan" + "'", str6.equals("Jan"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jan" + "'", str7.equals("Jan"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-11) + "'", int17 == (-11));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("DateTimeField[weekOfWeekyear]");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        boolean boolean4 = jodaTimePermission1.equals((java.lang.Object) 18L);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.now(dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.Chronology chronology11 = gregorianChronology9.withUTC();
        jodaTimePermission1.checkGuard((java.lang.Object) chronology11);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) ' ', 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.yearOfCentury();
        org.joda.time.LocalDate localDate3 = property2.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate5 = property2.addWrapFieldToCopy(1969);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
//        java.util.Locale locale9 = null;
//        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
//        java.util.Locale locale19 = null;
//        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
//        java.lang.Class<?> wildcardClass21 = offsetDateTimeField18.getClass();
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
//        boolean boolean24 = julianChronology22.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeField dateTimeField25 = julianChronology22.year();
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((long) '#');
//        org.joda.time.LocalDate.Property property28 = localDate27.yearOfCentury();
//        boolean boolean29 = julianChronology22.equals((java.lang.Object) property28);
//        org.joda.time.LocalDate localDate31 = property28.addToCopy((int) '4');
//        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone34);
//        org.joda.time.LocalDate localDate36 = dateTime35.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str38 = localDate36.toString(dateTimeFormatter37);
//        org.joda.time.LocalDate localDate40 = localDate36.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate42 = localDate40.withWeekyear((int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod43 = null;
//        org.joda.time.LocalDate localDate45 = localDate40.withPeriodAdded(readablePeriod43, (int) '#');
//        int[] intArray47 = buddhistChronology33.get((org.joda.time.ReadablePartial) localDate45, (long) 20);
//        try {
//            int[] intArray49 = offsetDateTimeField18.set((org.joda.time.ReadablePartial) localDate31, 18, intArray47, 20);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 18");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(buddhistChronology33);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970004" + "'", str38.equals("1970004"));
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(intArray47);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
        java.util.Locale locale19 = null;
        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
        long long22 = offsetDateTimeField18.roundHalfCeiling((long) 4);
        org.joda.time.DurationField durationField23 = offsetDateTimeField18.getLeapDurationField();
        java.lang.String str25 = offsetDateTimeField18.getAsText(1546300799999L);
        java.util.Locale locale28 = null;
        try {
            long long29 = offsetDateTimeField18.set(0L, "PST", locale28);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PST\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200000L) + "'", long22 == (-259200000L));
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "3" + "'", str25.equals("3"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.LocalDate localDate11 = localDate6.withPeriodAdded(readablePeriod9, (int) '#');
//        org.joda.time.LocalDate.Property property12 = localDate11.weekyear();
//        org.joda.time.LocalDate localDate14 = localDate11.withEra((int) (short) 1);
//        int int15 = localDate11.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.LocalDate localDate18 = dateTime17.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str20 = localDate18.toString(dateTimeFormatter19);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.LocalDate localDate23 = localDate18.withPeriodAdded(readablePeriod21, (int) (byte) 100);
//        boolean boolean24 = localDate11.isBefore((org.joda.time.ReadablePartial) localDate23);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 70 + "'", int15 == 70);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970004" + "'", str20.equals("1970004"));
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0L, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime1.minusWeeks(24);
        org.joda.time.DateTime dateTime7 = dateTime1.minusYears((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime1.plusMillis(563);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        java.util.Locale locale6 = null;
        java.lang.String str7 = partial3.toString("3", locale6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.Partial partial10 = partial3.withFieldAdded(durationFieldType8, 86399);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3" + "'", str7.equals("3"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(0);
        org.joda.time.DateTime dateTime8 = dateTime6.withHourOfDay(19);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime6.withPeriodAdded(readablePeriod9, 2000);
        org.joda.time.DateTime dateTime13 = dateTime11.plusSeconds(26);
        try {
            org.joda.time.DateTime dateTime15 = dateTime11.withYearOfEra((-2020));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2020 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.DateTime dateTime6 = dateTime3.plusHours(57600);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime3.toMutableDateTime();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.months();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.year();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) ' ');
        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes(0);
        int int8 = dateTime5.getYear();
        org.joda.time.TimeOfDay timeOfDay9 = dateTime5.toTimeOfDay();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
        org.junit.Assert.assertNotNull(timeOfDay9);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 1970);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        int int2 = property1.getMinimumValueOverall();
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            int int4 = property1.compareTo(readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.io.Writer writer1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj3 = null;
        boolean boolean4 = gJChronology2.equals(obj3);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.Chronology chronology6 = dateTime5.getChronology();
        org.joda.time.Chronology chronology7 = dateTime5.getChronology();
        org.joda.time.DateTime.Property property8 = dateTime5.secondOfMinute();
        org.joda.time.DateTime dateTime9 = property8.roundHalfCeilingCopy();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
//        org.joda.time.Chronology chronology5 = dateTime3.getChronology();
//        org.joda.time.DateTime.Property property6 = dateTime3.secondOfMinute();
//        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
//        long long8 = property6.remainder();
//        org.joda.time.DateTimeField dateTimeField9 = property6.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property6.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendDayOfMonth(18);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendSecondOfMinute(100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendDayOfMonth(18);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendSecondOfMinute(100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatterBuilder20.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
//        org.joda.time.DateTime dateTime25 = dateTime23.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property26 = dateTime25.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder20.appendShortText(dateTimeFieldType27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder11.appendFraction(dateTimeFieldType27, 12, 24);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray32 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType10, dateTimeFieldType27 };
//        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone34);
//        org.joda.time.LocalDate localDate36 = dateTime35.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str38 = localDate36.toString(dateTimeFormatter37);
//        org.joda.time.LocalDate localDate40 = localDate36.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate42 = localDate40.withWeekyear((int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod43 = null;
//        org.joda.time.LocalDate localDate45 = localDate40.withPeriodAdded(readablePeriod43, (int) '#');
//        int[] intArray47 = buddhistChronology33.get((org.joda.time.ReadablePartial) localDate45, (long) 20);
//        try {
//            org.joda.time.Partial partial48 = new org.joda.time.Partial(dateTimeFieldTypeArray32, intArray47);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray32);
//        org.junit.Assert.assertNotNull(buddhistChronology33);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970004" + "'", str38.equals("1970004"));
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(intArray47);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = gregorianChronology3.toString();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        java.lang.String str5 = partial3.toString();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.yearOfCentury();
        org.joda.time.Partial partial10 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology6.hourOfHalfday();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.Chronology chronology5 = dateTime3.getChronology();
        org.joda.time.DateTime.Property property6 = dateTime3.secondOfMinute();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = property6.roundCeilingCopy();
        boolean boolean11 = dateTime9.isEqual((long) (byte) 1);
        org.joda.time.DateTime dateTime12 = dateTime9.toDateTime();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.LocalDate localDate3 = dateTime2.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str5 = localDate3.toString(dateTimeFormatter4);
//        org.joda.time.LocalDate localDate7 = localDate3.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate9 = localDate7.withWeekyear((int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.LocalDate localDate12 = localDate7.withPeriodAdded(readablePeriod10, (int) '#');
//        int[] intArray14 = buddhistChronology0.get((org.joda.time.ReadablePartial) localDate12, (long) 20);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
//        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
//        java.util.Date date18 = localDate17.toDate();
//        int int19 = localDate17.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property20 = localDate17.weekyear();
//        boolean boolean21 = buddhistChronology0.equals((java.lang.Object) localDate17);
//        org.joda.time.Chronology chronology22 = buddhistChronology0.withUTC();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970004" + "'", str5.equals("1970004"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(chronology22);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.LocalDate localDate11 = localDate6.withPeriodAdded(readablePeriod9, (int) '#');
//        org.joda.time.LocalDate.Property property12 = localDate11.weekyear();
//        org.joda.time.LocalDate localDate14 = localDate11.withEra((int) (short) 1);
//        java.util.Date date15 = localDate14.toDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        java.lang.String str18 = dateTimeFormatter16.print(101L);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        org.joda.time.LocalDate localDate21 = dateTime20.toLocalDate();
//        java.util.Date date22 = localDate21.toDate();
//        int int23 = localDate21.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property24 = localDate21.weekyear();
//        org.joda.time.LocalDate localDate25 = property24.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology26 = localDate25.getChronology();
//        org.joda.time.LocalDate localDate28 = localDate25.withYear((int) (short) 10);
//        org.joda.time.LocalTime localTime29 = null;
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone31 = gJChronology30.getZone();
//        org.joda.time.DateTime dateTime32 = localDate28.toDateTime(localTime29, dateTimeZone31);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter16.withZone(dateTimeZone31);
//        boolean boolean35 = dateTimeZone31.isStandardOffset((-54L));
//        org.joda.time.DateMidnight dateMidnight36 = localDate14.toDateMidnight(dateTimeZone31);
//        try {
//            org.joda.time.DateTimeFieldType dateTimeFieldType38 = localDate14.getFieldType(1970);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 1970");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-W01-3" + "'", str18.equals("1970-W01-3"));
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19 + "'", int23 == 19);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(dateMidnight36);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(0);
        org.joda.time.DateTime dateTime7 = dateTime6.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
//        java.util.Locale locale9 = null;
//        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
//        java.util.Locale locale19 = null;
//        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
//        long long22 = offsetDateTimeField18.roundHalfCeiling((long) 4);
//        org.joda.time.DurationField durationField23 = offsetDateTimeField18.getLeapDurationField();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.LocalDate localDate26 = dateTime25.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str28 = localDate26.toString(dateTimeFormatter27);
//        int int29 = localDate26.getCenturyOfEra();
//        org.joda.time.DateTime dateTime30 = localDate26.toDateTimeAtMidnight();
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology32);
//        org.joda.time.DurationField durationField34 = gJChronology32.minutes();
//        org.joda.time.Partial partial35 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology32);
//        org.joda.time.Chronology chronology36 = partial35.getChronology();
//        int[] intArray37 = partial35.getValues();
//        try {
//            int[] intArray39 = offsetDateTimeField18.add((org.joda.time.ReadablePartial) localDate26, 1012, intArray37, 4);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1012");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200000L) + "'", long22 == (-259200000L));
//        org.junit.Assert.assertNull(durationField23);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970004" + "'", str28.equals("1970004"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 19 + "'", int29 == 19);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(intArray37);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
//        int int6 = localDate2.getDayOfMonth();
//        java.lang.Object obj7 = null;
//        boolean boolean8 = localDate2.equals(obj7);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        java.lang.String str2 = dateTimeFormatter0.print(101L);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
//        java.util.Date date6 = localDate5.toDate();
//        int int7 = localDate5.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property8 = localDate5.weekyear();
//        org.joda.time.LocalDate localDate9 = property8.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology10 = localDate9.getChronology();
//        org.joda.time.LocalDate localDate12 = localDate9.withYear((int) (short) 10);
//        org.joda.time.LocalTime localTime13 = null;
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology14.getZone();
//        org.joda.time.DateTime dateTime16 = localDate12.toDateTime(localTime13, dateTimeZone15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withZone(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
//        org.joda.time.DateTime dateTime21 = dateTime19.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property22 = dateTime21.monthOfYear();
//        org.joda.time.DateTime dateTime24 = dateTime21.minusMonths(0);
//        org.joda.time.DateTime dateTime26 = dateTime24.withHourOfDay(19);
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime29 = dateTime24.withPeriodAdded(readablePeriod27, 2000);
//        org.joda.time.LocalTime localTime30 = dateTime24.toLocalTime();
//        try {
//            org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime24, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-W01-3" + "'", str2.equals("1970-W01-3"));
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localTime30);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
//        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusWeeks((int) (byte) 10);
//        boolean boolean9 = dateTime6.isAfterNow();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
//        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology7 = localDate6.getChronology();
//        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
//        org.joda.time.LocalTime localTime10 = null;
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
//        org.joda.time.DateTime dateTime13 = localDate9.toDateTime(localTime10, dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        java.util.Date date10 = localDate9.toDate();
//        int int11 = localDate9.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property12 = localDate9.weekyear();
//        org.joda.time.LocalDate localDate13 = property12.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology14 = localDate13.getChronology();
//        org.joda.time.LocalDate localDate16 = localDate13.withCenturyOfEra(19);
//        org.joda.time.LocalDate localDate17 = localDate2.withFields((org.joda.time.ReadablePartial) localDate16);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime19 = localDate2.toDateTimeAtStartOfDay(dateTimeZone18);
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.plus(readablePeriod20);
//        int int22 = dateTime19.getYear();
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1970 + "'", int22 == 1970);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
//        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology7 = localDate6.getChronology();
//        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
//        org.joda.time.LocalTime localTime10 = null;
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
//        org.joda.time.DateTime dateTime13 = localDate9.toDateTime(localTime10, dateTimeZone12);
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime13.withDayOfWeek((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Partial partial6 = new org.joda.time.Partial((org.joda.time.Chronology) julianChronology5);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(52, 10, 69, (int) '4', 2019, (org.joda.time.Chronology) julianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology5);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
//        org.joda.time.Chronology chronology5 = dateTime3.getChronology();
//        org.joda.time.DateTime.Property property6 = dateTime3.secondOfMinute();
//        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
//        int int8 = dateTime7.getYearOfCentury();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 70 + "'", int8 == 70);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.DurationField durationField3 = gJChronology0.halfdays();
        long long6 = durationField3.subtract((long) 5, 1);
        long long9 = durationField3.subtract((long) (short) 100, 84032);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-43199995L) + "'", long6 == (-43199995L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-3630182399900L) + "'", long9 == (-3630182399900L));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Instant instant4 = gJChronology0.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology0.millis();
        org.joda.time.DurationField durationField6 = gJChronology0.halfdays();
        try {
            long long14 = gJChronology0.getDateTimeMillis(1012, (int) (short) 0, 9, 5, 563, 69, 99);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 563 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfMinute((int) (short) 0, 32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "+00:00:00.012");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        java.lang.String str6 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMillisOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendLiteral('a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfCentury(86399, 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 100);
        org.joda.time.DateMidnight dateMidnight2 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime1.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        int int6 = cachedDateTimeZone4.getOffsetFromLocal((-60479999900L));
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.joda.time.Instant instant1 = new org.joda.time.Instant(0L);
//        org.joda.time.ReadableDuration readableDuration2 = null;
//        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
//        org.joda.time.Instant instant4 = instant1.toInstant();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = gJChronology5.equals(obj6);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology5.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField10.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
//        java.lang.String str14 = delegatedDateTimeField10.toString();
//        long long16 = delegatedDateTimeField10.roundHalfFloor((long) 12);
//        int int17 = instant4.get((org.joda.time.DateTimeField) delegatedDateTimeField10);
//        java.lang.String str18 = delegatedDateTimeField10.toString();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        org.joda.time.LocalDate localDate21 = dateTime20.toLocalDate();
//        java.util.Date date22 = localDate21.toDate();
//        int int23 = localDate21.getCenturyOfEra();
//        int int24 = localDate21.getYearOfCentury();
//        int[] intArray32 = new int[] { (-2020), 53, (-259200000), '#', 3, (byte) 100 };
//        try {
//            int[] intArray34 = delegatedDateTimeField10.add((org.joda.time.ReadablePartial) localDate21, 86399, intArray32, 18);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str14.equals("DateTimeField[weekOfWeekyear]"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200000L) + "'", long16 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str18.equals("DateTimeField[weekOfWeekyear]"));
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19 + "'", int23 == 19);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 70 + "'", int24 == 70);
//        org.junit.Assert.assertNotNull(intArray32);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("1970004");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970004\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        int int4 = dateTime3.getDayOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.plus(0L);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
//        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology7 = localDate6.getChronology();
//        org.joda.time.LocalDate.Property property8 = localDate6.yearOfEra();
//        org.joda.time.LocalDate localDate9 = property8.withMaximumValue();
//        org.joda.time.Interval interval10 = localDate9.toInterval();
//        org.joda.time.LocalDate localDate12 = localDate9.minusYears(2000);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(interval10);
//        org.junit.Assert.assertNotNull(localDate12);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder6.appendText(dateTimeFieldType12);
        try {
            org.joda.time.LocalDate localDate15 = localDate0.withField(dateTimeFieldType12, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean3 = julianChronology1.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.year();
        org.joda.time.DurationField durationField5 = julianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property10 = dateTime9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField12 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField5, dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
//        org.joda.time.Chronology chronology5 = dateTime3.getChronology();
//        org.joda.time.DateTime.Property property6 = dateTime3.secondOfMinute();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime3.minus(readablePeriod7);
//        org.joda.time.DateTime dateTime10 = dateTime3.plusSeconds((int) ' ');
//        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) (byte) 1);
//        int int13 = dateTime12.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 32 + "'", int13 == 32);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField10);
        int int12 = skipUndoDateTimeField11.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 10);
        boolean boolean15 = gregorianChronology3.equals((java.lang.Object) skipUndoDateTimeField11);
        boolean boolean17 = skipUndoDateTimeField11.isLeap((long) 6);
        java.util.Locale locale18 = null;
        int int19 = skipUndoDateTimeField11.getMaximumShortTextLength(locale18);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.DateTime dateTime6 = dateTime3.minusYears((int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.plusWeeks(2000);
        boolean boolean10 = dateTime8.equals((java.lang.Object) 115200L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj2 = null;
        boolean boolean3 = gJChronology1.equals(obj2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        boolean boolean9 = dateTime7.isEqual((-63713260799968L));
        try {
            org.joda.time.DateTime dateTime11 = dateTime7.withYearOfEra((-2020));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2020 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        org.joda.time.DurationField durationField7 = gJChronology0.weeks();
        java.lang.String str8 = gJChronology0.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GJChronology[UTC]" + "'", str8.equals("GJChronology[UTC]"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Partial partial1 = new org.joda.time.Partial((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology3 = julianChronology0.withZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.weeks();
        org.joda.time.DurationField durationField2 = gJChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.centuryOfEra();
        try {
            long long8 = gJChronology0.getDateTimeMillis(2000, (int) (byte) -1, 1969, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        java.util.Date date10 = localDate9.toDate();
//        int int11 = localDate9.getCenturyOfEra();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate();
//        boolean boolean13 = localDate9.isAfter((org.joda.time.ReadablePartial) localDate12);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Interval interval15 = localDate12.toInterval(dateTimeZone14);
//        int int17 = dateTimeZone14.getOffsetFromLocal((long) 12);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
//        try {
//            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(563, (int) (short) 0, 1969, (int) '4', 1969, 69, 2019, dateTimeZone14);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(interval15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 100, 86399, 960, 794);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
//        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str8 = localDate6.toString(dateTimeFormatter7);
//        org.joda.time.LocalDate localDate10 = localDate6.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate12 = localDate10.withWeekyear((int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.LocalDate localDate15 = localDate10.withPeriodAdded(readablePeriod13, (int) '#');
//        org.joda.time.LocalDate.Property property16 = localDate15.weekyear();
//        org.joda.time.LocalDate localDate18 = localDate15.withEra((int) (short) 1);
//        java.util.Date date19 = localDate18.toDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        java.lang.String str22 = dateTimeFormatter20.print(101L);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
//        org.joda.time.LocalDate localDate25 = dateTime24.toLocalDate();
//        java.util.Date date26 = localDate25.toDate();
//        int int27 = localDate25.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property28 = localDate25.weekyear();
//        org.joda.time.LocalDate localDate29 = property28.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology30 = localDate29.getChronology();
//        org.joda.time.LocalDate localDate32 = localDate29.withYear((int) (short) 10);
//        org.joda.time.LocalTime localTime33 = null;
//        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone35 = gJChronology34.getZone();
//        org.joda.time.DateTime dateTime36 = localDate32.toDateTime(localTime33, dateTimeZone35);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter20.withZone(dateTimeZone35);
//        boolean boolean39 = dateTimeZone35.isStandardOffset((-54L));
//        org.joda.time.DateMidnight dateMidnight40 = localDate18.toDateMidnight(dateTimeZone35);
//        boolean boolean41 = dateTime3.equals((java.lang.Object) dateTimeZone35);
//        org.junit.Assert.assertNotNull(gregorianCalendar2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970004" + "'", str8.equals("1970004"));
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970-W01-3" + "'", str22.equals("1970-W01-3"));
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 19 + "'", int27 == 19);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(gJChronology34);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(dateMidnight40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-1), (int) (short) 10, 10, (int) (byte) 0, 0, (int) ' ', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime7.withEarlierOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withMonthOfYear(53);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property6 = localDate5.yearOfCentury();
        boolean boolean7 = julianChronology0.equals((java.lang.Object) property6);
        try {
            long long12 = julianChronology0.getDateTimeMillis((-259200000), 26, 6, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 26 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        int int3 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = gJChronology1.equals(obj2);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1L, (org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        java.util.Date date9 = localDate8.toDate();
//        int int10 = localDate8.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property11 = localDate8.weekyear();
//        org.joda.time.LocalDate localDate12 = property11.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology13 = localDate12.getChronology();
//        long long15 = gJChronology1.set((org.joda.time.ReadablePartial) localDate12, (-1L));
//        try {
//            org.joda.time.Instant instant16 = new org.joda.time.Instant((java.lang.Object) localDate12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.LocalDate");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-172800001L) + "'", long15 == (-172800001L));
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DurationField durationField6 = gJChronology4.minutes();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField9);
        int int11 = skipUndoDateTimeField10.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 10);
        java.lang.String str14 = skipUndoDateTimeField13.toString();
        int int16 = skipUndoDateTimeField13.getMinimumValue((long) (byte) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField13, 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str14.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property6 = localDate5.yearOfCentury();
        boolean boolean7 = julianChronology0.equals((java.lang.Object) property6);
        org.joda.time.Chronology chronology8 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000011576d + "'", double1 == 2440587.5000011576d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTime dateTime4 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime3.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = iSOChronology7.days();
        org.joda.time.DurationField durationField9 = iSOChronology7.centuries();
        org.joda.time.DateTime dateTime10 = dateTime3.withChronology((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.Chronology chronology11 = dateTime10.getChronology();
        org.joda.time.DateTime dateTime13 = dateTime10.withYearOfEra(6);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(960);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-960) + "'", int1 == (-960));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "Property[monthOfYear]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.joda.time.DateTimeField dateTimeField0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.LocalDate localDate3 = dateTime2.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str5 = localDate3.toString(dateTimeFormatter4);
//        org.joda.time.LocalDate localDate7 = localDate3.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate9 = localDate7.withWeekyear((int) (short) 1);
//        org.joda.time.DateTime dateTime10 = localDate9.toDateTimeAtCurrentTime();
//        org.joda.time.LocalDate.Property property11 = localDate9.dayOfYear();
//        org.joda.time.DurationField durationField12 = property11.getDurationField();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
//        java.util.Date date16 = localDate15.toDate();
//        int int17 = localDate15.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property18 = localDate15.weekyear();
//        org.joda.time.LocalDate localDate19 = property18.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology20 = localDate19.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
//        org.joda.time.DateTime dateTime24 = dateTime22.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property25 = dateTime24.monthOfYear();
//        org.joda.time.LocalDate localDate26 = dateTime24.toLocalDate();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendDayOfMonth(18);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder27.appendSecondOfMinute(100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatterBuilder31.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
//        org.joda.time.DateTime dateTime36 = dateTime34.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property37 = dateTime36.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder31.appendShortText(dateTimeFieldType38);
//        int int40 = localDate26.indexOf(dateTimeFieldType38);
//        org.joda.time.LocalDate localDate42 = localDate19.withField(dateTimeFieldType38, 12);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, durationField12, dateTimeFieldType38, (int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970004" + "'", str5.equals("1970004"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(localDate42);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField5.getDurationField();
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField5.getAsShortText((int) 'a', locale11);
        java.lang.String str13 = delegatedDateTimeField5.toString();
        try {
            org.joda.time.Instant instant14 = new org.joda.time.Instant((java.lang.Object) delegatedDateTimeField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.DelegatedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97" + "'", str12.equals("97"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str13.equals("DateTimeField[weekOfWeekyear]"));
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
//        java.util.Date date6 = localDate5.toDate();
//        int int7 = localDate5.getCenturyOfEra();
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        boolean boolean9 = localDate5.isAfter((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Interval interval11 = localDate8.toInterval(dateTimeZone10);
//        long long15 = dateTimeZone10.convertLocalToUTC(0L, true, (long) (-11));
//        org.joda.time.Chronology chronology16 = julianChronology0.withZone(dateTimeZone10);
//        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField18 = copticChronology17.dayOfYear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField18);
//        org.joda.time.DateTimeField dateTimeField20 = julianChronology0.minuteOfDay();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(interval11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(copticChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
//        java.util.Locale locale9 = null;
//        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
//        java.util.Locale locale19 = null;
//        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
//        long long22 = offsetDateTimeField18.roundHalfCeiling((long) 4);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
//        org.joda.time.LocalDate localDate25 = dateTime24.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str27 = localDate25.toString(dateTimeFormatter26);
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.LocalDate localDate30 = localDate25.withPeriodAdded(readablePeriod28, (int) (byte) 100);
//        org.joda.time.LocalDate.Property property31 = localDate30.weekyear();
//        org.joda.time.Chronology chronology32 = localDate30.getChronology();
//        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj35 = null;
//        boolean boolean36 = gJChronology34.equals(obj35);
//        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology34);
//        org.joda.time.DateTimeField dateTimeField38 = gJChronology34.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField39 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField38);
//        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate();
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = delegatedDateTimeField39.getAsText((org.joda.time.ReadablePartial) localDate40, locale41);
//        java.lang.String str43 = delegatedDateTimeField39.toString();
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forID("UTC");
//        org.joda.time.LocalDate localDate46 = org.joda.time.LocalDate.now(dateTimeZone45);
//        int[] intArray51 = new int[] { 2019, 100, 69, 365 };
//        int int52 = delegatedDateTimeField39.getMaximumValue((org.joda.time.ReadablePartial) localDate46, intArray51);
//        try {
//            int[] intArray54 = offsetDateTimeField18.set((org.joda.time.ReadablePartial) localDate30, (int) (short) 100, intArray51, 19);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200000L) + "'", long22 == (-259200000L));
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970004" + "'", str27.equals("1970004"));
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(gJChronology34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1" + "'", str42.equals("1"));
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str43.equals("DateTimeField[weekOfWeekyear]"));
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertNotNull(intArray51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 52 + "'", int52 == 52);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property11 = localDate10.yearOfCentury();
        org.joda.time.LocalDate localDate12 = property11.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate13 = property11.roundCeilingCopy();
        int int14 = localDate13.getWeekOfWeekyear();
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate13, locale15);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField5.getDurationField();
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField5.getAsShortText((int) 'a', locale11);
        java.lang.String str14 = delegatedDateTimeField5.getAsText((long) 69);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, 365);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField5.getAsShortText(373L, locale18);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) delegatedDateTimeField5, 69, 0, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for weekOfWeekyear must be in the range [0,19]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97" + "'", str12.equals("97"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.LocalDate localDate7 = localDate2.withPeriodAdded(readablePeriod5, (int) (byte) 100);
//        boolean boolean8 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate7);
//        org.joda.time.LocalDate.Property property9 = localDate7.weekyear();
//        org.joda.time.LocalDate localDate11 = property9.setCopy((int) ' ');
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(localDate11);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTime dateTime4 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime3.withMillisOfSecond((int) (short) 10);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.minusMonths(10);
        org.joda.time.DateTime dateTime7 = dateTime3.withSecondOfMinute(4);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay(57600);
        org.joda.time.DateTime.Property property10 = dateTime7.dayOfYear();
        org.joda.time.Chronology chronology11 = dateTime7.getChronology();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial3.minus(readablePeriod4);
        try {
            int int7 = partial5.getValue(746);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 746");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(partial5);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Interval interval8 = localDate5.toInterval(dateTimeZone7);
//        long long12 = dateTimeZone7.convertLocalToUTC(32L, true, 0L);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(interval8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(784);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatterBuilder7.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(69);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        boolean boolean4 = dateTimeFormatter3.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("[]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"[]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str9 = localDate7.toString(dateTimeFormatter8);
//        org.joda.time.LocalDate localDate11 = localDate7.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate13 = localDate11.withWeekyear((int) (short) 1);
//        org.joda.time.DateTime dateTime14 = localDate13.toDateTimeAtCurrentTime();
//        boolean boolean15 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime17 = dateTime14.plusDays((-28800000));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970004" + "'", str9.equals("1970004"));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendPattern("1");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendYearOfCentury((int) (byte) 10, (-2020));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder17.appendPattern("1");
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime24.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime27 = dateTime26.toLocalDateTime();
        org.joda.time.DateTime.Property property28 = dateTime26.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        boolean boolean35 = dateTime26.isSupported(dateTimeFieldType34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType34, 563);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder9.appendShortText(dateTimeFieldType34);
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 100, "19700104");
        java.lang.Throwable[] throwableArray42 = illegalFieldValueException41.getSuppressed();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localDateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(throwableArray42);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DateTime dateTime4 = dateTime3.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property5 = dateTime3.monthOfYear();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy((int) (byte) -1);
//        java.lang.String str8 = property5.getAsString();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.Chronology chronology3 = julianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Chronology chronology5 = julianChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
        org.joda.time.DateTime.Property property11 = dateTime9.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime13.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property16 = dateTime15.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property16.getFieldType();
        boolean boolean18 = dateTime9.isSupported(dateTimeFieldType17);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, "DateTimeField[weekOfWeekyear]");
        boolean boolean21 = julianChronology0.equals((java.lang.Object) illegalFieldValueException20);
        java.lang.Throwable throwable22 = null;
        try {
            illegalFieldValueException20.addSuppressed(throwable22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime dateTime5 = dateTime1.minusWeeks(24);
//        org.joda.time.DateTime dateTime7 = dateTime1.minusYears((int) '#');
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime1.plus(readableDuration8);
//        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
//        int int11 = dateTime9.getDayOfWeek();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 7 + "'", int11 == 7);
//    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str11 = localDate9.toString(dateTimeFormatter10);
//        org.joda.time.LocalDate localDate13 = localDate9.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate15 = localDate13.withWeekyear((int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.LocalDate localDate18 = localDate13.withPeriodAdded(readablePeriod16, (int) '#');
//        org.joda.time.LocalDate.Property property19 = localDate18.weekyear();
//        org.joda.time.LocalDate localDate21 = localDate18.withEra((int) (short) 1);
//        java.util.Date date22 = localDate21.toDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        java.lang.String str25 = dateTimeFormatter23.print(101L);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        org.joda.time.LocalDate localDate28 = dateTime27.toLocalDate();
//        java.util.Date date29 = localDate28.toDate();
//        int int30 = localDate28.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property31 = localDate28.weekyear();
//        org.joda.time.LocalDate localDate32 = property31.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology33 = localDate32.getChronology();
//        org.joda.time.LocalDate localDate35 = localDate32.withYear((int) (short) 10);
//        org.joda.time.LocalTime localTime36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone38 = gJChronology37.getZone();
//        org.joda.time.DateTime dateTime39 = localDate35.toDateTime(localTime36, dateTimeZone38);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter23.withZone(dateTimeZone38);
//        boolean boolean42 = dateTimeZone38.isStandardOffset((-54L));
//        org.joda.time.DateMidnight dateMidnight43 = localDate21.toDateMidnight(dateTimeZone38);
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
//        try {
//            org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((int) (byte) 1, (int) (short) 1, (int) (short) 100, 784, 57600, 794, 32, (org.joda.time.Chronology) iSOChronology44);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 784 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970004" + "'", str11.equals("1970004"));
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970-W01-3" + "'", str25.equals("1970-W01-3"));
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 19 + "'", int30 == 19);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNotNull(dateMidnight43);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.Partial partial5 = partial3.minus(readablePeriod4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getMillisOfSecond();
//        org.joda.time.DateTime dateTime9 = partial3.toDateTime((org.joda.time.ReadableInstant) dateTime7);
//        java.util.Locale locale11 = null;
//        try {
//            java.lang.String str12 = partial3.toString("PST", locale11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(partial5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        int int5 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime7 = property4.setCopy("Jun");
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
//        java.util.Date date11 = localDate10.toDate();
//        int int12 = localDate10.getCenturyOfEra();
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate();
//        boolean boolean14 = localDate10.isAfter((org.joda.time.ReadablePartial) localDate13);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Interval interval16 = localDate13.toInterval(dateTimeZone15);
//        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology7, dateTimeZone15);
//        boolean boolean19 = dateTimeZone15.isStandardOffset(0L);
//        try {
//            org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((int) (short) 0, 20, 0, 0, 84032, 12, dateTimeZone15);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 84032 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(interval16);
//        org.junit.Assert.assertNotNull(zonedChronology17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendPattern("1");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendYearOfCentury((int) (byte) 10, (-2020));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder17.appendPattern("1");
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime24.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime27 = dateTime26.toLocalDateTime();
        org.joda.time.DateTime.Property property28 = dateTime26.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        boolean boolean35 = dateTime26.isSupported(dateTimeFieldType34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType34, 563);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder9.appendShortText(dateTimeFieldType34);
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 100, "19700104");
        java.lang.Number number42 = illegalFieldValueException41.getIllegalNumberValue();
        java.lang.Number number43 = illegalFieldValueException41.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localDateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 100 + "'", number42.equals(100));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 100 + "'", number43.equals(100));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.io.Writer writer1 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property4 = localDate3.yearOfCentury();
        org.joda.time.LocalDate localDate5 = property4.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate7 = property4.addToCopy((int) ' ');
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (-172799900L), 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField3 = gJChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField6);
        int int8 = skipUndoDateTimeField7.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 10);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipUndoDateTimeField10.getAsShortText((int) (short) 0, locale12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder18.appendDayOfWeekText();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime21.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property24 = dateTime23.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType25);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
//        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(0);
//        org.joda.time.DateTime dateTime8 = dateTime6.withHourOfDay(19);
//        int int9 = dateTime6.getYearOfEra();
//        org.joda.time.DateTime dateTime11 = dateTime6.minusMonths(1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        java.lang.Number number5 = illegalFieldValueException2.getLowerBound();
        java.lang.Number number6 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number6);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
//        org.joda.time.Chronology chronology4 = julianChronology0.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology0.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone6.getUncachedZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
//        java.util.Date date11 = localDate10.toDate();
//        int int12 = localDate10.getCenturyOfEra();
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate();
//        boolean boolean14 = localDate10.isAfter((org.joda.time.ReadablePartial) localDate13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
//        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
//        java.util.Date date18 = localDate17.toDate();
//        int int19 = localDate17.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property20 = localDate17.weekyear();
//        org.joda.time.LocalDate localDate21 = property20.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology22 = localDate21.getChronology();
//        org.joda.time.LocalDate localDate24 = localDate21.withCenturyOfEra(19);
//        org.joda.time.LocalDate localDate25 = localDate10.withFields((org.joda.time.ReadablePartial) localDate24);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime27 = localDate10.toDateTimeAtStartOfDay(dateTimeZone26);
//        boolean boolean28 = cachedDateTimeZone6.equals((java.lang.Object) dateTime27);
//        boolean boolean29 = dateTime27.isBeforeNow();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        boolean boolean4 = iSOChronology1.equals((java.lang.Object) 10.0d);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology6 = iSOChronology1.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime dateTime13 = property12.roundHalfCeilingCopy();
        int int14 = dateTime13.getMinuteOfDay();
        boolean boolean15 = iSOChronology1.equals((java.lang.Object) dateTime13);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.lang.StringBuffer stringBuffer2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (long) (-11));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
//        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology7 = localDate6.getChronology();
//        org.joda.time.LocalDate.Property property8 = localDate6.yearOfEra();
//        org.joda.time.LocalDate localDate10 = property8.setCopy(563);
//        int int11 = localDate10.getDayOfYear();
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 363 + "'", int11 == 363);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTime dateTime4 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime7 = dateTime3.plusYears(52);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
//        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology7 = localDate6.getChronology();
//        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
//        org.joda.time.LocalTime localTime10 = null;
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
//        org.joda.time.DateTime dateTime13 = localDate9.toDateTime(localTime10, dateTimeZone12);
//        org.joda.time.LocalTime localTime14 = null;
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology15.getZone();
//        org.joda.time.DateTime dateTime17 = localDate9.toDateTime(localTime14, dateTimeZone16);
//        org.joda.time.LocalDate localDate19 = localDate9.minusDays((int) (short) 100);
//        org.joda.time.DateMidnight dateMidnight20 = localDate19.toDateMidnight();
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(dateMidnight20);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField10);
        int int12 = skipUndoDateTimeField11.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 10);
        boolean boolean15 = gregorianChronology3.equals((java.lang.Object) skipUndoDateTimeField11);
        long long18 = skipUndoDateTimeField11.set(0L, 10);
        java.lang.String str19 = skipUndoDateTimeField11.toString();
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale21 = null;
        try {
            java.lang.String str22 = skipUndoDateTimeField11.getAsShortText(readablePartial20, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10000L + "'", long18 == 10000L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str19.equals("DateTimeField[secondOfMinute]"));
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
//        boolean boolean4 = iSOChronology1.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology6 = iSOChronology1.withZone(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str9 = dateTimeZone7.getShortName(31535999999L);
//        org.joda.time.Chronology chronology10 = iSOChronology1.withZone(dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology1.yearOfEra();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.LocalDate localDate0 = org.joda.time.LocalDate.now();
        org.junit.Assert.assertNotNull(localDate0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        java.lang.String str12 = delegatedDateTimeField5.getAsText((long) 960);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime7 = dateTime5.withHourOfDay(0);
        org.joda.time.DateTime dateTime9 = dateTime5.withWeekOfWeekyear((int) ' ');
        try {
            org.joda.time.DateTime dateTime11 = dateTime5.withMillisOfSecond(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.minusMonths(10);
        org.joda.time.DateTime dateTime7 = dateTime3.withSecondOfMinute(4);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay(57600);
        org.joda.time.DateTime.Property property10 = dateTime7.dayOfYear();
        org.joda.time.DateTime dateTime12 = property10.addToCopy((long) 86399);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        try {
            long long9 = copticChronology0.getDateTimeMillis(1, 9, 0, (int) (byte) 10, 1969, (int) (byte) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
//        java.util.Locale locale5 = null;
//        int int6 = property4.getMaximumShortTextLength(locale5);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        int int10 = dateTime8.getSecondOfDay();
//        int int11 = dateTime8.getMinuteOfDay();
//        int int12 = property4.getDifference((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime14 = property4.addWrapFieldToCopy((int) '#');
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600 + "'", int10 == 57600);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 960 + "'", int11 == 960);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        boolean boolean4 = iSOChronology1.equals((java.lang.Object) 10.0d);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology6 = iSOChronology1.withZone(dateTimeZone5);
        try {
            long long12 = iSOChronology1.getDateTimeMillis(0L, 99, 10, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
//        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology7 = localDate6.getChronology();
//        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
//        org.joda.time.LocalTime localTime10 = null;
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
//        org.joda.time.DateTime dateTime13 = localDate9.toDateTime(localTime10, dateTimeZone12);
//        int int14 = localDate9.getMonthOfYear();
//        org.joda.time.LocalDate.Property property15 = localDate9.weekyear();
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
//        org.junit.Assert.assertNotNull(property15);
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getMillisOfSecond();
//        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
//        int int5 = dateTimeFormatter0.getDefaultYear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "160000-0800" + "'", str4.equals("160000-0800"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2000 + "'", int5 == 2000);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(obj0, dateTimeZone1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
        org.joda.time.Chronology chronology3 = iSOChronology1.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getMillisOfSecond();
//        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
//        java.lang.String str6 = dateTimeFormatter0.print((long) (byte) 100);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "160000-0800" + "'", str4.equals("160000-0800"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "160000-0800" + "'", str6.equals("160000-0800"));
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.DurationField durationField8 = iSOChronology7.weeks();
//        boolean boolean10 = iSOChronology7.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology12 = iSOChronology7.withZone(dateTimeZone11);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone11.getName((long) 16, locale14);
//        try {
//            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(794, 12, 0, 1843, 84032, (int) (short) 0, dateTimeZone11);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1843 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(69);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
//        java.io.Writer writer4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = gJChronology5.equals(obj6);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
//        org.joda.time.Chronology chronology10 = dateTime8.getChronology();
//        org.joda.time.DateTime.Property property11 = dateTime8.secondOfMinute();
//        org.joda.time.DateTime dateTime12 = property11.roundHalfCeilingCopy();
//        int int13 = dateTime12.getMinuteOfHour();
//        try {
//            dateTimeFormatter3.printTo(writer4, (org.joda.time.ReadableInstant) dateTime12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(1100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(101L, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 563);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Interval interval8 = localDate5.toInterval(dateTimeZone7);
//        int int10 = dateTimeZone7.getOffsetFromLocal((long) 12);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        org.joda.time.Chronology chronology12 = buddhistChronology11.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DurationField durationField15 = iSOChronology14.weeks();
//        boolean boolean17 = iSOChronology14.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology19 = iSOChronology14.withZone(dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology14.hourOfHalfday();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology11, dateTimeField20);
//        java.lang.Object obj22 = null;
//        boolean boolean23 = buddhistChronology11.equals(obj22);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(interval8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.LocalDate localDate6 = localDate2.plus(readablePeriod5);
//        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(localDate6);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 10);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.LocalDate localDate7 = localDate2.withPeriodAdded(readablePeriod5, (int) (byte) 100);
//        org.joda.time.LocalDate localDate9 = localDate7.plusDays((int) (short) 10);
//        org.joda.time.LocalDate.Property property10 = localDate7.dayOfMonth();
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property10);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.minusYears(20);
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        long long7 = property6.remainder();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 31535999999L + "'", long7 == 31535999999L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField3 = gJChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField6);
        int int8 = skipUndoDateTimeField7.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 10);
        java.lang.String str11 = skipUndoDateTimeField10.toString();
        int int13 = skipUndoDateTimeField10.getMinimumValue((long) (byte) 1);
        java.util.Locale locale16 = null;
        try {
            long long17 = skipUndoDateTimeField10.set(1L, "[]", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"[]\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str11.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.days();
        org.joda.time.DurationField durationField3 = iSOChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.era();
        org.joda.time.Partial partial5 = new org.joda.time.Partial((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatterBuilder6.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatterBuilder17.toFormatter();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime20.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property23 = dateTime22.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder17.appendShortText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder6.appendFixedDecimal(dateTimeFieldType24, 1012);
        try {
            org.joda.time.Partial partial29 = partial5.withField(dateTimeFieldType24, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'monthOfYear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 2);
//        long long7 = gregorianChronology3.add((long) 18, 100L, 10);
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
//        boolean boolean10 = julianChronology8.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology8.year();
//        org.joda.time.Chronology chronology12 = julianChronology8.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology8.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
//        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance();
//        boolean boolean17 = julianChronology15.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeField dateTimeField18 = julianChronology15.year();
//        org.joda.time.Chronology chronology19 = julianChronology15.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology15.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone20);
//        org.joda.time.DateTimeZone dateTimeZone22 = cachedDateTimeZone21.getUncachedZone();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
//        org.joda.time.LocalDate localDate25 = dateTime24.toLocalDate();
//        java.util.Date date26 = localDate25.toDate();
//        int int27 = localDate25.getCenturyOfEra();
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate();
//        boolean boolean29 = localDate25.isAfter((org.joda.time.ReadablePartial) localDate28);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        org.joda.time.LocalDate localDate32 = dateTime31.toLocalDate();
//        java.util.Date date33 = localDate32.toDate();
//        int int34 = localDate32.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property35 = localDate32.weekyear();
//        org.joda.time.LocalDate localDate36 = property35.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology37 = localDate36.getChronology();
//        org.joda.time.LocalDate localDate39 = localDate36.withCenturyOfEra(19);
//        org.joda.time.LocalDate localDate40 = localDate25.withFields((org.joda.time.ReadablePartial) localDate39);
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime42 = localDate25.toDateTimeAtStartOfDay(dateTimeZone41);
//        boolean boolean43 = cachedDateTimeZone21.equals((java.lang.Object) dateTime42);
//        long long45 = dateTimeZone13.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone21, (long) ' ');
//        org.joda.time.Chronology chronology46 = gregorianChronology3.withZone(dateTimeZone13);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1018L + "'", long7 == 1018L);
//        org.junit.Assert.assertNotNull(julianChronology8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertNotNull(julianChronology15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 19 + "'", int27 == 19);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 19 + "'", int34 == 19);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 32L + "'", long45 == 32L);
//        org.junit.Assert.assertNotNull(chronology46);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("563");
        org.junit.Assert.assertNotNull(localDate1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.yearOfCentury();
        org.joda.time.LocalDate localDate3 = property2.roundHalfFloorCopy();
        int int4 = property2.getLeapAmount();
        org.joda.time.LocalDate localDate5 = property2.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property10 = dateTime9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        boolean boolean12 = dateTime3.isSupported(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, "DateTimeField[weekOfWeekyear]");
        java.lang.String str15 = illegalFieldValueException14.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str15.equals("DateTimeField[weekOfWeekyear]"));
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
//        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology7 = localDate6.getChronology();
//        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
//        org.joda.time.LocalTime localTime10 = null;
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
//        org.joda.time.DateTime dateTime13 = localDate9.toDateTime(localTime10, dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        org.joda.time.LocalDate localDate16 = dateTime15.toLocalDate();
//        org.joda.time.LocalDate localDate18 = localDate16.withYearOfCentury((int) (short) 10);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.LocalDate localDate20 = localDate16.plus(readablePeriod19);
//        int int21 = localDate16.getEra();
//        int int22 = localDate9.compareTo((org.joda.time.ReadablePartial) localDate16);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTimeFormatter0.parseMutableDateTime("1970-W06-5");
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 10);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        java.io.Writer writer2 = null;
        try {
            dateTimeFormatter0.printTo(writer2, (long) 32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimePrinter1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        org.joda.time.Interval interval6 = property4.toInterval();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval6);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(chronology7);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology1.getZone();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property9 = dateTime8.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str14 = localDate12.toString(dateTimeFormatter13);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate18 = localDate16.withWeekyear((int) (short) 1);
//        org.joda.time.DateTime dateTime19 = localDate18.toDateTimeAtCurrentTime();
//        boolean boolean20 = dateTime8.isAfter((org.joda.time.ReadableInstant) dateTime19);
//        int int21 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime19);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019166" + "'", str14.equals("2019166"));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime1.minusWeeks(24);
        org.joda.time.DateTime dateTime7 = dateTime1.minusMinutes(70);
        org.joda.time.DateTime.Property property8 = dateTime7.minuteOfHour();
        org.joda.time.DateTime dateTime10 = dateTime7.withYearOfEra(363);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTime(localTime10, dateTimeZone12);
        int int14 = localDate9.getMonthOfYear();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        boolean boolean16 = localDate9.isSupported(durationFieldType15);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.yearOfCentury();
        org.joda.time.LocalDate localDate3 = property2.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate4 = property2.roundCeilingCopy();
        org.joda.time.DateMidnight dateMidnight5 = localDate4.toDateMidnight();
        java.util.Date date6 = localDate4.toDate();
        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.fromDateFields(date6);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property17 = dateTime16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType18, 1012);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.LocalDate localDate24 = dateTime23.toLocalDate();
        java.util.Date date25 = localDate24.toDate();
        int int26 = localDate24.getCenturyOfEra();
        org.joda.time.LocalDate.Property property27 = localDate24.weekyear();
        org.joda.time.LocalDate localDate28 = property27.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology29 = localDate28.getChronology();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
        org.joda.time.DateTime dateTime33 = dateTime31.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property34 = dateTime33.monthOfYear();
        org.joda.time.LocalDate localDate35 = dateTime33.toLocalDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder36.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder36.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatterBuilder40.toFormatter();
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(dateTimeZone42);
        org.joda.time.DateTime dateTime45 = dateTime43.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property46 = dateTime45.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property46.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder40.appendShortText(dateTimeFieldType47);
        int int49 = localDate35.indexOf(dateTimeFieldType47);
        org.joda.time.LocalDate localDate51 = localDate28.withField(dateTimeFieldType47, 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType47, (int) 'a', 52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
        long long21 = offsetDateTimeField18.add((long) 'a', (long) 20);
        long long23 = offsetDateTimeField18.roundHalfEven(100L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 12096000097L + "'", long21 == 12096000097L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-259200000L) + "'", long23 == (-259200000L));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        java.lang.String str5 = partial3.toString();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.yearOfCentury();
        org.joda.time.Partial partial10 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.Partial partial13 = partial3.withFieldAddWrapped(durationFieldType11, (-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(partial10);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        java.lang.Number number5 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj2 = null;
        boolean boolean3 = gJChronology1.equals(obj2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendDayOfWeekText();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property18 = dateTime17.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType19);
        org.joda.time.DateTime.Property property21 = dateTime7.property(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = gregorianChronology3.withZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.DateTime dateTime6 = dateTime3.minusYears((int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime3.plusWeeks(2000);
        org.joda.time.DateTime.Property property9 = dateTime3.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        boolean boolean4 = iSOChronology1.equals((java.lang.Object) 10.0d);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField6 = iSOChronology1.hours();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str9 = localDate7.toString(dateTimeFormatter8);
//        org.joda.time.LocalDate localDate11 = localDate7.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate13 = localDate11.withWeekyear((int) (short) 1);
//        org.joda.time.DateTime dateTime14 = localDate13.toDateTimeAtCurrentTime();
//        boolean boolean15 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime17 = dateTime3.withCenturyOfEra(86399);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019166" + "'", str9.equals("2019166"));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.minusMonths(10);
        org.joda.time.DateTime dateTime7 = dateTime3.withSecondOfMinute(4);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay(57600);
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(32);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test259");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.LocalDate localDate3 = dateTime2.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str5 = localDate3.toString(dateTimeFormatter4);
//        org.joda.time.LocalDate localDate7 = localDate3.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate9 = localDate7.withWeekyear((int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.LocalDate localDate12 = localDate7.withPeriodAdded(readablePeriod10, (int) '#');
//        int[] intArray14 = buddhistChronology0.get((org.joda.time.ReadablePartial) localDate12, (long) 20);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = null;
//        java.lang.String str16 = localDate12.toString(dateTimeFormatter15);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        org.joda.time.LocalDate localDate21 = dateTime20.toLocalDate();
//        java.util.Date date22 = localDate21.toDate();
//        int int23 = localDate21.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property24 = localDate21.weekyear();
//        org.joda.time.LocalDate localDate25 = property24.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology26 = localDate25.getChronology();
//        org.joda.time.LocalDate localDate28 = localDate25.withYear((int) (short) 10);
//        org.joda.time.DateTime dateTime29 = dateTime18.withFields((org.joda.time.ReadablePartial) localDate25);
//        boolean boolean30 = localDate12.isEqual((org.joda.time.ReadablePartial) localDate25);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019166" + "'", str5.equals("2019166"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019-05-11" + "'", str16.equals("2019-05-11"));
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 20 + "'", int23 == 20);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial3.minus(readablePeriod4);
        try {
            java.lang.String str7 = partial5.toString("BuddhistChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: B");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(partial5);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.yearOfCentury();
        org.joda.time.LocalDate localDate3 = property2.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate5 = localDate3.withWeekyear((int) '#');
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendPattern("1");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendYearOfCentury((int) (byte) 10, (-2020));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendMillisOfSecond(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
//        org.joda.time.DateMidnight dateMidnight4 = dateTime1.toDateMidnight();
//        org.joda.time.DateTime.Property property5 = dateTime1.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime6 = dateTime1.toMutableDateTime();
//        int int7 = mutableDateTime6.getSecondOfDay();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateMidnight4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 58889 + "'", int7 == 58889);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.Instant instant2 = new org.joda.time.Instant(0L);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(dateTimeZone3);
        try {
            org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) instant2, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField5.getDurationField();
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField5.getAsShortText((int) 'a', locale11);
        java.lang.String str14 = delegatedDateTimeField5.getAsText((long) 69);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, 365);
        java.lang.String str17 = offsetDateTimeField16.toString();
        long long19 = offsetDateTimeField16.roundCeiling((long) 2000);
        int int21 = offsetDateTimeField16.getMaximumValue((long) 7);
        try {
            long long24 = offsetDateTimeField16.set((-172799900L), "1970-05-10");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970-05-10\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97" + "'", str12.equals("97"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str17.equals("DateTimeField[weekOfWeekyear]"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 345600000L + "'", long19 == 345600000L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 418 + "'", int21 == 418);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
        org.joda.time.LocalDate.Property property10 = localDate6.weekOfWeekyear();
        org.joda.time.LocalDate localDate12 = localDate6.minusMonths(52);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime5.era();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.LocalDate localDate4 = localDate2.withYearOfCentury((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate2.plus(readablePeriod5);
        org.joda.time.LocalDate.Property property7 = localDate2.monthOfYear();
        java.util.Locale locale9 = null;
        java.lang.String str10 = localDate2.toString("+00:00:00.012", locale9);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.012" + "'", str10.equals("+00:00:00.012"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.yearOfCentury();
        org.joda.time.LocalDate localDate3 = property2.roundHalfFloorCopy();
        int int4 = property2.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property2.getField();
        java.lang.String str6 = property2.getName();
        org.joda.time.LocalDate localDate8 = property2.addWrapFieldToCopy((int) (short) 0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "yearOfCentury" + "'", str6.equals("yearOfCentury"));
        org.junit.Assert.assertNotNull(localDate8);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.LocalDate localDate11 = localDate6.withPeriodAdded(readablePeriod9, (int) '#');
//        org.joda.time.LocalDate.Property property12 = localDate11.weekyear();
//        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.LocalDate localDate15 = localDate13.minus(readablePeriod14);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019166" + "'", str4.equals("2019166"));
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(localDate15);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.DateTime dateTime6 = dateTime3.minusYears((int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime3.isSupported(dateTimeFieldType7);
        org.joda.time.DateTime.Property property9 = dateTime3.era();
        int int10 = dateTime3.getMonthOfYear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = localDate8.toDateTimeAtCurrentTime();
//        org.joda.time.LocalDate.Property property10 = localDate8.dayOfYear();
//        org.joda.time.DurationField durationField11 = property10.getDurationField();
//        org.joda.time.LocalDate localDate12 = property10.roundHalfEvenCopy();
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019166" + "'", str4.equals("2019166"));
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(localDate12);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateMidnight dateMidnight4 = dateTime1.toDateMidnight();
        org.joda.time.DateTime.Property property5 = dateTime1.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime1.toMutableDateTime();
        org.joda.time.Instant instant7 = mutableDateTime6.toInstant();
        org.joda.time.Instant instant10 = instant7.withDurationAdded(57600L, 10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 60720);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField5.getDurationField();
        org.joda.time.DurationField durationField10 = delegatedDateTimeField5.getDurationField();
        boolean boolean12 = delegatedDateTimeField5.isLeap((-63713260799968L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.yearOfCentury();
        org.joda.time.LocalDate localDate3 = property2.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate4 = property2.roundCeilingCopy();
        org.joda.time.Interval interval5 = property2.toInterval();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(interval5);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(gJChronology3);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendPattern("1");
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
        org.joda.time.DateTime.Property property15 = dateTime13.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property20 = dateTime19.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
        boolean boolean22 = dateTime13.isSupported(dateTimeFieldType21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder9.appendFixedDecimal(dateTimeFieldType21, 563);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendFractionOfMinute(6, (int) (byte) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendPattern("+00:00:00.012");
        org.joda.time.format.DateTimeParser dateTimeParser30 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder27.append(dateTimeParser30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval8 = localDate5.toInterval(dateTimeZone7);
        int int10 = dateTimeZone7.getOffsetFromLocal((long) 12);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology12 = buddhistChronology11.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = iSOChronology14.weeks();
        boolean boolean17 = iSOChronology14.equals((java.lang.Object) 10.0d);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology19 = iSOChronology14.withZone(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology14.hourOfHalfday();
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology11, dateTimeField20);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime23.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property26 = dateTime25.monthOfYear();
        java.util.Locale locale27 = null;
        java.lang.String str28 = property26.getAsShortText(locale27);
        java.lang.String str29 = property26.getAsShortText();
        int int30 = property26.get();
        org.joda.time.DateTime dateTime31 = property26.withMaximumValue();
        boolean boolean32 = buddhistChronology11.equals((java.lang.Object) dateTime31);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Jun" + "'", str28.equals("Jun"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Jun" + "'", str29.equals("Jun"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.secondOfMinute();
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean7 = julianChronology5.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
        java.util.Date date11 = localDate10.toDate();
        int int12 = localDate10.getCenturyOfEra();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate();
        boolean boolean14 = localDate10.isAfter((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval16 = localDate13.toInterval(dateTimeZone15);
        long long20 = dateTimeZone15.convertLocalToUTC(0L, true, (long) (-11));
        org.joda.time.Chronology chronology21 = julianChronology5.withZone(dateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology0, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology22.getZone();
        java.lang.String str24 = zonedChronology22.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 20 + "'", int12 == 20);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(interval16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ZonedChronology[JulianChronology[UTC], UTC]" + "'", str24.equals("ZonedChronology[JulianChronology[UTC], UTC]"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.minusYears(20);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
        long long21 = offsetDateTimeField18.add((long) 'a', (long) 20);
        int int23 = offsetDateTimeField18.getLeapAmount(32L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 12096000097L + "'", long21 == 12096000097L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.append(dateTimeFormatter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendHourOfHalfday(259200020);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Jun", "1969-365T��:��:��", false, 784, 784);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendWeekOfWeekyear(9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
//        org.joda.time.LocalDate localDate10 = localDate6.plusMonths((-259200000));
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019166" + "'", str4.equals("2019166"));
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
//        boolean boolean4 = iSOChronology1.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology6 = iSOChronology1.withZone(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str9 = dateTimeZone7.getShortName(31535999999L);
//        org.joda.time.Chronology chronology10 = iSOChronology1.withZone(dateTimeZone7);
//        boolean boolean12 = dateTimeZone7.isStandardOffset((long) 970);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DurationField durationField7 = gJChronology5.years();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) -1, 100, 1, 794, 1012, (org.joda.time.Chronology) gJChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 794 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.withYear((int) ' ');
        org.joda.time.DateTime.Property property4 = dateTime1.monthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfCentury(784, 784);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendFractionOfSecond(3, 52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.LocalDate localDate13 = dateTime11.toLocalDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatterBuilder18.toFormatter();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime21.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property24 = dateTime23.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder18.appendShortText(dateTimeFieldType25);
        int int27 = localDate13.indexOf(dateTimeFieldType25);
        org.joda.time.LocalDate localDate29 = localDate6.withField(dateTimeFieldType25, 12);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology30);
        org.joda.time.DurationField durationField32 = gJChronology30.minutes();
        org.joda.time.DateTimeField dateTimeField33 = gJChronology30.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gJChronology34.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology30, dateTimeField35);
        org.joda.time.DurationField durationField37 = gJChronology30.weeks();
        long long40 = durationField37.subtract(0L, (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate43 = org.joda.time.LocalDate.now(dateTimeZone42);
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone42);
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology46);
        org.joda.time.DurationField durationField48 = gJChronology46.minutes();
        org.joda.time.DateTimeField dateTimeField49 = gJChronology46.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology46, dateTimeField51);
        int int53 = skipUndoDateTimeField52.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField55 = new org.joda.time.field.SkipUndoDateTimeField(chronology45, (org.joda.time.DateTimeField) skipUndoDateTimeField52, 10);
        boolean boolean56 = gregorianChronology44.equals((java.lang.Object) skipUndoDateTimeField52);
        long long59 = skipUndoDateTimeField52.set(0L, 10);
        java.lang.String str60 = skipUndoDateTimeField52.toString();
        org.joda.time.LocalDate localDate62 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property63 = localDate62.dayOfYear();
        org.joda.time.LocalDate localDate64 = property63.withMinimumValue();
        org.joda.time.LocalDate localDate66 = property63.setCopy(10);
        int int67 = localDate66.getDayOfYear();
        int int68 = skipUndoDateTimeField52.getMinimumValue((org.joda.time.ReadablePartial) localDate66);
        org.joda.time.DurationField durationField69 = skipUndoDateTimeField52.getDurationField();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField70 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField37, durationField69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The effective range must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-19353600000L) + "'", long40 == (-19353600000L));
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10000L + "'", long59 == 10000L);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str60.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(localDate66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 10 + "'", int67 == 10);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(durationField69);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj2 = null;
        boolean boolean3 = gJChronology1.equals(obj2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime.Property property6 = dateTime5.centuryOfEra();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.withYear((int) ' ');
        org.joda.time.DateTime.Property property10 = dateTime7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        boolean boolean12 = gregorianChronology4.equals((java.lang.Object) property10);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 100);
        int int2 = dateTime1.getDayOfYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendPattern("1");
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
        org.joda.time.DateTime.Property property15 = dateTime13.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property20 = dateTime19.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
        boolean boolean22 = dateTime13.isSupported(dateTimeFieldType21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder9.appendFixedDecimal(dateTimeFieldType21, 563);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendFractionOfMinute(6, (int) (byte) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendLiteral('a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        java.util.Date date5 = localDate4.toDate();
        int int6 = localDate4.getCenturyOfEra();
        org.joda.time.LocalDate.Property property7 = localDate4.weekyear();
        org.joda.time.LocalDate localDate8 = property7.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology9 = localDate8.getChronology();
        org.joda.time.LocalDate localDate11 = localDate8.withYear((int) (short) 10);
        org.joda.time.DateTime dateTime12 = dateTime1.withFields((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeField[] dateTimeFieldArray13 = localDate8.getFields();
        org.joda.time.LocalDate localDate15 = localDate8.minusMonths(1);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 20 + "'", int6 == 20);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldArray13);
        org.junit.Assert.assertNotNull(localDate15);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test298");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
//        java.util.Date date6 = localDate5.toDate();
//        int int7 = localDate5.getCenturyOfEra();
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        boolean boolean9 = localDate5.isAfter((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Interval interval11 = localDate8.toInterval(dateTimeZone10);
//        long long15 = dateTimeZone10.convertLocalToUTC(0L, true, (long) (-11));
//        org.joda.time.Chronology chronology16 = julianChronology0.withZone(dateTimeZone10);
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        org.joda.time.LocalDate localDate21 = dateTime20.toLocalDate();
//        int int22 = dateTime20.getSecondOfDay();
//        org.joda.time.DateTime dateTime24 = dateTime20.minusHours((int) '#');
//        org.joda.time.DateTime dateTime26 = dateTime24.withCenturyOfEra(0);
//        boolean boolean27 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeField18, (java.lang.Object) dateTime26);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(interval11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 58891 + "'", int22 == 58891);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.secondOfDay();
        org.joda.time.Instant instant6 = gJChronology1.getGregorianCutover();
        org.joda.time.DurationField durationField7 = gJChronology1.minutes();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendPattern("1");
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
        org.joda.time.DateTime.Property property15 = dateTime13.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property20 = dateTime19.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
        boolean boolean22 = dateTime13.isSupported(dateTimeFieldType21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder9.appendFixedDecimal(dateTimeFieldType21, 563);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendFractionOfMinute(6, (int) (byte) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendMinuteOfHour((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder27.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.secondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("6", "Jan", (int) (short) 1, 19);
        boolean boolean9 = fixedDateTimeZone8.isFixed();
        org.joda.time.Chronology chronology10 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField5.getDurationField();
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField5.getAsShortText((int) 'a', locale11);
        java.lang.String str14 = delegatedDateTimeField5.getAsText((long) 69);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, 365);
        int int18 = offsetDateTimeField16.getLeapAmount((long) (-292275054));
        boolean boolean19 = offsetDateTimeField16.isSupported();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97" + "'", str12.equals("97"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.Chronology chronology3 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.era();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
        java.util.Locale locale19 = null;
        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
        long long22 = offsetDateTimeField18.roundHalfCeiling((long) 4);
        org.joda.time.DurationField durationField23 = offsetDateTimeField18.getLeapDurationField();
        java.lang.String str25 = offsetDateTimeField18.getAsText(1546300799999L);
        long long28 = offsetDateTimeField18.add((long) 10, (int) (byte) 10);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200000L) + "'", long22 == (-259200000L));
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "3" + "'", str25.equals("3"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 6048000010L + "'", long28 == 6048000010L);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test305");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DurationField durationField3 = gJChronology1.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.yearOfCentury();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField6);
//        int int8 = skipUndoDateTimeField7.getMinimumValue();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 10);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str15 = localDate13.toString(dateTimeFormatter14);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.LocalDate localDate18 = localDate13.withPeriodAdded(readablePeriod16, (int) (byte) 100);
//        boolean boolean19 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate18);
//        org.joda.time.LocalDate.Property property20 = localDate18.weekyear();
//        int[] intArray22 = null;
//        java.util.Locale locale24 = null;
//        try {
//            int[] intArray25 = skipUndoDateTimeField10.set((org.joda.time.ReadablePartial) localDate18, 57600, intArray22, "2000", locale24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019166" + "'", str15.equals("2019166"));
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property20);
//    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.LocalDate localDate7 = localDate2.withPeriodAdded(readablePeriod5, (int) (byte) 100);
//        org.joda.time.LocalDate localDate9 = localDate7.plusDays((int) (short) 10);
//        int int10 = localDate9.getDayOfWeek();
//        org.joda.time.LocalDate.Property property11 = localDate9.year();
//        try {
//            org.joda.time.LocalDate localDate13 = property11.setCopy("");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for year is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019166" + "'", str4.equals("2019166"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertNotNull(property11);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.yearOfCentury();
        org.joda.time.LocalDate localDate3 = property2.roundHalfFloorCopy();
        int int4 = property2.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property2.getField();
        org.joda.time.LocalDate localDate6 = property2.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate7 = property2.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField5.getDurationField();
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField5.getAsShortText((int) 'a', locale11);
        java.lang.String str14 = delegatedDateTimeField5.getAsText((long) 69);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, 365);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsText(readablePartial17, 563, locale19);
        long long22 = offsetDateTimeField16.roundHalfFloor((long) (short) 1);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97" + "'", str12.equals("97"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "563" + "'", str20.equals("563"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200000L) + "'", long22 == (-259200000L));
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
//        int int5 = dateTime3.getSecondOfDay();
//        org.joda.time.LocalDateTime localDateTime6 = dateTime3.toLocalDateTime();
//        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDateTime6);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 84091 + "'", int5 == 84091);
//        org.junit.Assert.assertNotNull(localDateTime6);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 16, 1401);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        java.lang.String str5 = partial3.toString();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.yearOfCentury();
        org.joda.time.Partial partial10 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology6);
        int int11 = partial3.size();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray12 = partial3.getFieldTypes();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray12);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        int int7 = skipUndoDateTimeField6.getMinimumValue();
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField6.getMaximumShortTextLength(locale8);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.LocalDate localDate11 = localDate6.withPeriodAdded(readablePeriod9, (int) '#');
//        org.joda.time.LocalDate.Property property12 = localDate11.weekyear();
//        org.joda.time.LocalDate localDate14 = property12.setCopy((int) (short) 10);
//        org.joda.time.DateTime dateTime15 = localDate14.toDateTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property16 = dateTime15.era();
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019166" + "'", str4.equals("2019166"));
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test314");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.LocalDate localDate7 = localDate2.withPeriodAdded(readablePeriod5, (int) (byte) 100);
//        org.joda.time.LocalDate localDate9 = localDate7.plusDays((int) (short) 10);
//        int int10 = localDate9.getDayOfWeek();
//        org.joda.time.LocalDate.Property property11 = localDate9.year();
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology12);
//        org.joda.time.DateTime dateTime15 = dateTime13.withYear((int) ' ');
//        org.joda.time.DateTime dateTime17 = dateTime15.plusMinutes(0);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
//        int int19 = property11.getDifference((org.joda.time.ReadableInstant) dateTime17);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019166" + "'", str4.equals("2019166"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1987 + "'", int19 == 1987);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        java.lang.String str5 = partial3.toString();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.yearOfCentury();
        org.joda.time.Partial partial10 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology6);
        java.lang.String str11 = partial3.toStringList();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.Partial partial13 = partial3.minus(readablePeriod12);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "[]" + "'", str11.equals("[]"));
        org.junit.Assert.assertNotNull(partial13);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property6 = localDate5.yearOfCentury();
        boolean boolean7 = julianChronology0.equals((java.lang.Object) property6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendEraText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str17 = dateTimeFormatter15.print(101L);
        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatter15.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder13.append(dateTimePrinter18);
        boolean boolean20 = dateTime8.equals((java.lang.Object) dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1970-W01-3" + "'", str17.equals("1970-W01-3"));
        org.junit.Assert.assertNotNull(dateTimePrinter18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.Chronology chronology5 = dateTime3.getChronology();
        org.joda.time.DateTime.Property property6 = dateTime3.secondOfMinute();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.roundCeilingCopy();
        try {
            org.joda.time.DateTime dateTime10 = property6.setCopy(58891);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58891 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
        org.joda.time.LocalDate localDate3 = property2.roundCeilingCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime1.minusWeeks(24);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(784);
        org.joda.time.DateTime dateTime9 = dateTime1.minusDays(84032);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(19, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 119 + "'", int2 == 119);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("DateTimeField[weekOfWeekyear]");
        java.security.Permission permission2 = null;
        boolean boolean3 = jodaTimePermission1.implies(permission2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        boolean boolean4 = iSOChronology1.equals((java.lang.Object) 10.0d);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        java.util.Date date8 = localDate7.toDate();
        int int9 = localDate7.getCenturyOfEra();
        org.joda.time.LocalDate.Property property10 = localDate7.weekyear();
        org.joda.time.LocalDate localDate11 = property10.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology12 = localDate11.getChronology();
        org.joda.time.LocalDate.Property property13 = localDate11.yearOfEra();
        long long15 = iSOChronology1.set((org.joda.time.ReadablePartial) localDate11, (long) (short) 100);
        org.joda.time.DurationField durationField16 = iSOChronology1.months();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546300800100L + "'", long15 == 1546300800100L);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsShortText(locale5);
        java.lang.String str7 = property4.getAsShortText();
        int int8 = property4.get();
        org.joda.time.DateTime dateTime9 = property4.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property14 = dateTime13.monthOfYear();
        org.joda.time.DateTime dateTime15 = property14.withMaximumValue();
        org.joda.time.DateTime dateTime16 = dateTime15.withEarlierOffsetAtOverlap();
        int int17 = property4.getDifference((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        java.util.GregorianCalendar gregorianCalendar20 = dateTime19.toGregorianCalendar();
        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime();
        int int22 = property4.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime23 = property4.roundHalfFloorCopy();
        int int24 = property4.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun" + "'", str6.equals("Jun"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jun" + "'", str7.equals("Jun"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-6) + "'", int17 == (-6));
        org.junit.Assert.assertNotNull(gregorianCalendar20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial3.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 100);
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        java.lang.Object obj9 = null;
        boolean boolean10 = dateTime7.equals(obj9);
        boolean boolean11 = partial5.isMatch((org.joda.time.ReadableInstant) dateTime7);
        java.lang.String str12 = partial5.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(partial5);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "[]" + "'", str12.equals("[]"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField5.getAsShortText(2000, locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField5.getAsText(6, locale15);
        long long18 = delegatedDateTimeField5.roundHalfCeiling(220752000069L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2000" + "'", str13.equals("2000"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "6" + "'", str16.equals("6"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 220492800000L + "'", long18 == 220492800000L);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
//        boolean boolean7 = iSOChronology4.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology9 = iSOChronology4.withZone(dateTimeZone8);
//        java.lang.String str11 = dateTimeZone8.getName((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone8);
//        java.lang.String str13 = zonedChronology12.toString();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        org.joda.time.LocalDate localDate16 = dateTime15.toLocalDate();
//        org.joda.time.LocalDate localDate18 = localDate16.withYearOfCentury((int) (short) 10);
//        int[] intArray20 = zonedChronology12.get((org.joda.time.ReadablePartial) localDate18, 319920000L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ZonedChronology[GJChronology[UTC], UTC]" + "'", str13.equals("ZonedChronology[GJChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(intArray20);
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test329");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
//        org.joda.time.DurationField durationField9 = delegatedDateTimeField5.getDurationField();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = delegatedDateTimeField5.getAsShortText((int) 'a', locale11);
//        java.lang.String str14 = delegatedDateTimeField5.getAsText((long) 69);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, 365);
//        long long19 = offsetDateTimeField16.add((-172799900L), 5);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
//        org.joda.time.LocalDate localDate22 = dateTime21.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str24 = localDate22.toString(dateTimeFormatter23);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.LocalDate localDate27 = localDate22.withPeriodAdded(readablePeriod25, (int) (byte) 100);
//        boolean boolean28 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate27);
//        org.joda.time.LocalDate.Property property29 = localDate27.weekyear();
//        org.joda.time.LocalDate.Property property30 = localDate27.era();
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology32);
//        org.joda.time.DurationField durationField34 = gJChronology32.minutes();
//        org.joda.time.Partial partial35 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology32);
//        org.joda.time.Chronology chronology36 = partial35.getChronology();
//        int[] intArray37 = partial35.getValues();
//        try {
//            int[] intArray39 = offsetDateTimeField16.addWrapField((org.joda.time.ReadablePartial) localDate27, 1843, intArray37, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1843");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97" + "'", str12.equals("97"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2851200100L + "'", long19 == 2851200100L);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019166" + "'", str24.equals("2019166"));
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(intArray37);
//    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test330");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.LocalDate localDate4 = localDate2.withYearOfCentury((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str9 = localDate7.toString(dateTimeFormatter8);
//        org.joda.time.LocalDate localDate11 = localDate7.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate13 = localDate11.withWeekyear((int) (short) 1);
//        org.joda.time.DateTime dateTime14 = localDate13.toDateTimeAtCurrentTime();
//        boolean boolean15 = localDate4.isEqual((org.joda.time.ReadablePartial) localDate13);
//        org.joda.time.LocalDate localDate17 = localDate13.withWeekyear((-292275054));
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019166" + "'", str9.equals("2019166"));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(localDate17);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendPattern("1");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendYearOfCentury((int) (byte) 10, (-2020));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfMonth(12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder18.appendTimeZoneId();
        org.joda.time.format.DateTimePrinter dateTimePrinter20 = dateTimeFormatterBuilder18.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder14.append(dateTimePrinter20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimePrinter20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitYear((-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField5.getDurationField();
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField5.getAsShortText((int) 'a', locale11);
        java.lang.String str14 = delegatedDateTimeField5.getAsText((long) 69);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, 365);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsText(readablePartial17, 563, locale19);
        int int22 = offsetDateTimeField16.getLeapAmount((-3630182399900L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97" + "'", str12.equals("97"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "563" + "'", str20.equals("563"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.Partial partial7 = partial3.withFieldAddWrapped(durationFieldType5, 1843);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 1987);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210695083200000L) + "'", long1 == (-210695083200000L));
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test336");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
//        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(0);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = gJChronology7.equals(obj8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology7);
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology7.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate();
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = delegatedDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate13, locale14);
//        int int16 = delegatedDateTimeField12.getMaximumValue();
//        int int17 = dateTime6.get((org.joda.time.DateTimeField) delegatedDateTimeField12);
//        java.lang.String str18 = delegatedDateTimeField12.getName();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "24" + "'", str15.equals("24"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "weekOfWeekyear" + "'", str18.equals("weekOfWeekyear"));
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTime(localTime10, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate9.withEra(1);
        try {
            org.joda.time.LocalDate localDate17 = localDate15.withWeekOfWeekyear(1843);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1843 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDate15);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("DateTimeField[weekOfWeekyear]");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str2.equals("DateTimeField[weekOfWeekyear]"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int7 = delegatedDateTimeField5.getLeapAmount((long) 259200020);
        int int9 = delegatedDateTimeField5.get(18L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = partial3.getChronology();
        int[] intArray5 = partial3.getValues();
        org.joda.time.Chronology chronology6 = partial3.getChronology();
        java.lang.String str7 = partial3.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
        org.joda.time.DateTime.Property property13 = dateTime11.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property18 = dateTime17.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        boolean boolean20 = dateTime11.isSupported(dateTimeFieldType19);
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, "DateTimeField[weekOfWeekyear]");
        try {
            org.joda.time.Partial partial24 = partial3.with(dateTimeFieldType19, 363);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 363 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[]" + "'", str7.equals("[]"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(60720, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendTwoDigitYear((int) (short) -1, false);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.LocalDate localDate16 = dateTime14.toLocalDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder17.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatterBuilder21.toFormatter();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime24.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property27 = dateTime26.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder21.appendShortText(dateTimeFieldType28);
        int int30 = localDate16.indexOf(dateTimeFieldType28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder10.appendFixedSignedDecimal(dateTimeFieldType28, 2);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType28, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
        java.util.Date date6 = localDate5.toDate();
        int int7 = localDate5.getCenturyOfEra();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
        boolean boolean9 = localDate5.isAfter((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval11 = localDate8.toInterval(dateTimeZone10);
        long long15 = dateTimeZone10.convertLocalToUTC(0L, true, (long) (-11));
        org.joda.time.Chronology chronology16 = julianChronology0.withZone(dateTimeZone10);
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = copticChronology17.dayOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField18);
        long long22 = skipDateTimeField19.add((long) 10, 0L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(interval11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.Chronology chronology4 = julianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology0.getZone();
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        int int12 = cachedDateTimeZone10.getOffset((long) (byte) 10);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-28800000) + "'", int12 == (-28800000));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(0, (int) 'a', 84032, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test348");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = localDate8.toDateTimeAtCurrentTime();
//        org.joda.time.LocalDate.Property property10 = localDate8.dayOfYear();
//        org.joda.time.LocalDate localDate11 = property10.roundCeilingCopy();
//        try {
//            org.joda.time.Instant instant12 = new org.joda.time.Instant((java.lang.Object) property10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.LocalDate$Property");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019166" + "'", str4.equals("2019166"));
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(localDate11);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("52");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"52/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("DateTimeField[weekOfWeekyear]");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property5 = localDate4.dayOfYear();
        org.joda.time.LocalDate localDate6 = property5.withMinimumValue();
        org.joda.time.LocalDate localDate7 = property5.roundFloorCopy();
        boolean boolean8 = jodaTimePermission1.equals((java.lang.Object) property5);
        boolean boolean10 = jodaTimePermission1.equals((java.lang.Object) 6);
        java.lang.String str11 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str11.equals("DateTimeField[weekOfWeekyear]"));
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test351");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
//        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(0);
//        int int7 = dateTime3.getSecondOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime3.plusSeconds(1969);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 60754 + "'", int7 == 60754);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(99, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 99");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(2, 2, 69, 24, 784, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-172799900L), (java.lang.Number) 1987, (java.lang.Number) (-3630182399900L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.LocalDate localDate4 = localDate2.withYear((int) (byte) 1);
        try {
            org.joda.time.LocalDate localDate6 = localDate2.withEra(86399);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate2.plus(readablePeriod5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
        java.util.Date date10 = localDate9.toDate();
        int int11 = localDate9.getCenturyOfEra();
        org.joda.time.LocalDate.Property property12 = localDate9.weekyear();
        org.joda.time.LocalDate localDate13 = property12.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology14 = localDate13.getChronology();
        org.joda.time.LocalDate.Property property15 = localDate13.yearOfEra();
        org.joda.time.LocalDate localDate16 = property15.withMaximumValue();
        org.joda.time.Interval interval17 = localDate16.toInterval();
        org.joda.time.LocalDate localDate18 = localDate6.withFields((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.LocalDate.Property property19 = localDate16.era();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(interval17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology1.getZone();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.Chronology chronology6 = gregorianChronology4.withUTC();
        try {
            long long11 = gregorianChronology4.getDateTimeMillis(784, 9, 53, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval8 = localDate5.toInterval(dateTimeZone7);
        int int10 = dateTimeZone7.getOffsetFromLocal((long) 12);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology12 = buddhistChronology11.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = iSOChronology14.weeks();
        boolean boolean17 = iSOChronology14.equals((java.lang.Object) 10.0d);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology19 = iSOChronology14.withZone(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology14.hourOfHalfday();
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology11, dateTimeField20);
        long long24 = skipDateTimeField21.add(0L, (int) (byte) 1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3600000L + "'", long24 == 3600000L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
        java.util.Locale locale19 = null;
        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
        long long22 = offsetDateTimeField18.roundHalfCeiling((long) 4);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField18.getAsText(365L, locale24);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200000L) + "'", long22 == (-259200000L));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "3" + "'", str25.equals("3"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendPattern("DateTimeField[weekOfWeekyear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
        java.util.Locale locale19 = null;
        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
        long long22 = offsetDateTimeField18.roundHalfCeiling((long) 4);
        org.joda.time.DurationField durationField23 = offsetDateTimeField18.getLeapDurationField();
        java.lang.String str25 = offsetDateTimeField18.getAsText(1546300799999L);
        java.lang.String str27 = offsetDateTimeField18.getAsShortText((long) 86399);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200000L) + "'", long22 == (-259200000L));
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "3" + "'", str25.equals("3"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "3" + "'", str27.equals("3"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfDay((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTime dateTime4 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((int) (byte) -1);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test365");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
//        int int5 = dateTime3.getSecondOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime3.yearOfCentury();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = property6.getAsShortText(locale7);
//        org.joda.time.DurationField durationField9 = property6.getDurationField();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 84095 + "'", int5 == 84095);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19" + "'", str8.equals("19"));
//        org.junit.Assert.assertNotNull(durationField9);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.LocalDate localDate5 = dateTime3.toLocalDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatterBuilder10.toFormatter();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime13.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property16 = dateTime15.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property16.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType17);
        int int19 = localDate5.indexOf(dateTimeFieldType17);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray20 = localDate5.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        java.util.Date date24 = localDate23.toDate();
        int int25 = localDate23.getCenturyOfEra();
        org.joda.time.LocalDate localDate27 = localDate23.minusYears(1);
        org.joda.time.LocalDate localDate28 = localDate5.withFields((org.joda.time.ReadablePartial) localDate27);
        org.joda.time.LocalDate.Property property29 = localDate27.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray20);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 20 + "'", int25 == 20);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(property29);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        int int5 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime7 = property4.setCopy("Jun");
        int int8 = dateTime7.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        long long5 = iSOChronology0.add((long) (byte) 0, (long) (-2020), 32);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-64640L) + "'", long5 == (-64640L));
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test369");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate6, locale7);
//        java.lang.String str9 = delegatedDateTimeField5.toString();
//        long long11 = delegatedDateTimeField5.roundHalfFloor((long) 12);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        org.joda.time.LocalDate localDate14 = dateTime13.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str16 = localDate14.toString(dateTimeFormatter15);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.LocalDate localDate19 = localDate14.withPeriodAdded(readablePeriod17, (int) (byte) 100);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = delegatedDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate19, locale20);
//        java.lang.String str22 = delegatedDateTimeField5.getName();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "24" + "'", str8.equals("24"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str9.equals("DateTimeField[weekOfWeekyear]"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019166" + "'", str16.equals("2019166"));
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "24" + "'", str21.equals("24"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "weekOfWeekyear" + "'", str22.equals("weekOfWeekyear"));
//    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test370");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
//        java.util.Locale locale9 = null;
//        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
//        java.util.Locale locale19 = null;
//        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
//        long long22 = offsetDateTimeField18.roundHalfCeiling((long) 4);
//        org.joda.time.DurationField durationField23 = offsetDateTimeField18.getLeapDurationField();
//        boolean boolean25 = offsetDateTimeField18.isLeap((long) 563);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        org.joda.time.LocalDate localDate28 = dateTime27.toLocalDate();
//        java.util.Date date29 = localDate28.toDate();
//        int int30 = localDate28.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property31 = localDate28.weekyear();
//        org.joda.time.LocalDate localDate32 = property31.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology33 = localDate32.getChronology();
//        org.joda.time.LocalDate localDate35 = localDate32.withYear((int) (short) 10);
//        org.joda.time.LocalTime localTime36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone38 = gJChronology37.getZone();
//        org.joda.time.DateTime dateTime39 = localDate35.toDateTime(localTime36, dateTimeZone38);
//        org.joda.time.LocalTime localTime40 = null;
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone42 = gJChronology41.getZone();
//        org.joda.time.DateTime dateTime43 = localDate35.toDateTime(localTime40, dateTimeZone42);
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(dateTimeZone45);
//        org.joda.time.DateTime dateTime48 = dateTime46.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property49 = dateTime48.monthOfYear();
//        org.joda.time.DateTime dateTime51 = dateTime48.minusMonths(0);
//        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj53 = null;
//        boolean boolean54 = gJChronology52.equals(obj53);
//        org.joda.time.DateTime dateTime55 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology52);
//        org.joda.time.DateTimeField dateTimeField56 = gJChronology52.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField56);
//        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate();
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = delegatedDateTimeField57.getAsText((org.joda.time.ReadablePartial) localDate58, locale59);
//        int int61 = delegatedDateTimeField57.getMaximumValue();
//        int int62 = dateTime51.get((org.joda.time.DateTimeField) delegatedDateTimeField57);
//        org.joda.time.DateTimeZone dateTimeZone63 = null;
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime(dateTimeZone63);
//        org.joda.time.LocalDate localDate65 = dateTime64.toLocalDate();
//        org.joda.time.LocalDate localDate67 = localDate65.withYearOfCentury((int) (short) 10);
//        int[] intArray73 = new int[] { 1, (short) 1, ' ', 9, 9 };
//        int int74 = delegatedDateTimeField57.getMaximumValue((org.joda.time.ReadablePartial) localDate67, intArray73);
//        try {
//            int[] intArray76 = offsetDateTimeField18.addWrapField((org.joda.time.ReadablePartial) localTime40, 7, intArray73, 60720);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200000L) + "'", long22 == (-259200000L));
//        org.junit.Assert.assertNull(durationField23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 20 + "'", int30 == 20);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(gJChronology52);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "24" + "'", str60.equals("24"));
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 53 + "'", int61 == 53);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 24 + "'", int62 == 24);
//        org.junit.Assert.assertNotNull(localDate65);
//        org.junit.Assert.assertNotNull(localDate67);
//        org.junit.Assert.assertNotNull(intArray73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 53 + "'", int74 == 53);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendPattern("1");
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
        org.joda.time.DateTime.Property property15 = dateTime13.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property20 = dateTime19.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
        boolean boolean22 = dateTime13.isSupported(dateTimeFieldType21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder9.appendFixedDecimal(dateTimeFieldType21, 563);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendYear(69, 1012);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatterBuilder27.toFormatter();
        try {
            org.joda.time.LocalDate localDate30 = dateTimeFormatter28.parseLocalDate("DateTimeField[weekOfWeekyear]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsShortText(locale5);
        java.lang.String str7 = property4.getAsShortText();
        int int8 = property4.get();
        org.joda.time.DateTime dateTime9 = property4.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property14 = dateTime13.monthOfYear();
        org.joda.time.DateTime dateTime15 = property14.withMaximumValue();
        org.joda.time.DateTime dateTime16 = dateTime15.withEarlierOffsetAtOverlap();
        int int17 = property4.getDifference((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        java.util.GregorianCalendar gregorianCalendar20 = dateTime19.toGregorianCalendar();
        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime();
        int int22 = property4.compareTo((org.joda.time.ReadableInstant) dateTime19);
        java.util.Locale locale23 = null;
        int int24 = property4.getMaximumShortTextLength(locale23);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun" + "'", str6.equals("Jun"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jun" + "'", str7.equals("Jun"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-6) + "'", int17 == (-6));
        org.junit.Assert.assertNotNull(gregorianCalendar20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.LocalDate localDate4 = localDate2.withYearOfCentury((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate2.plus(readablePeriod5);
        int int7 = localDate2.getEra();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate2.plus(readablePeriod8);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("1970-W01-3", 7);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.DateTime dateTime6 = dateTime3.minusYears((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
        org.joda.time.LocalDate localDate11 = localDate9.withYearOfCentury((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateMidnight dateMidnight13 = localDate11.toDateMidnight(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime3.withFields((org.joda.time.ReadablePartial) localDate11);
        java.lang.String str16 = localDate11.toString("1969-12-31");
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969-12-31" + "'", str16.equals("1969-12-31"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField10);
        int int12 = skipUndoDateTimeField11.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 10);
        boolean boolean15 = gregorianChronology3.equals((java.lang.Object) skipUndoDateTimeField11);
        org.joda.time.Chronology chronology16 = gregorianChronology3.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property4.getFieldType();
        boolean boolean6 = property4.isLeap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(69);
        org.joda.time.Chronology chronology4 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(chronology4);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(319920000L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.Chronology chronology6 = gregorianChronology4.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(99, 259200020, 69, 563);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 299 + "'", int4 == 299);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate.Property property8 = localDate6.yearOfEra();
        org.joda.time.LocalDate localDate9 = property8.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property14 = dateTime13.monthOfYear();
        org.joda.time.LocalDate localDate15 = dateTime13.toLocalDate();
        org.joda.time.LocalDate.Property property16 = localDate15.dayOfMonth();
        boolean boolean17 = localDate9.isAfter((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.LocalDate.Property property18 = localDate15.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.LocalDate localDate20 = localDate15.plus(readablePeriod19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str23 = dateTimeFormatter21.print(101L);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
        org.joda.time.LocalDate localDate26 = dateTime25.toLocalDate();
        java.util.Date date27 = localDate26.toDate();
        int int28 = localDate26.getCenturyOfEra();
        org.joda.time.LocalDate.Property property29 = localDate26.weekyear();
        org.joda.time.LocalDate localDate30 = property29.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology31 = localDate30.getChronology();
        org.joda.time.LocalDate localDate33 = localDate30.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime34 = null;
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone36 = gJChronology35.getZone();
        org.joda.time.DateTime dateTime37 = localDate33.toDateTime(localTime34, dateTimeZone36);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter21.withZone(dateTimeZone36);
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeUtils.getZone(dateTimeZone36);
        long long41 = dateTimeZone36.convertUTCToLocal((long) '4');
        org.joda.time.DateMidnight dateMidnight42 = localDate20.toDateMidnight(dateTimeZone36);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(dateTimeZone43);
        org.joda.time.LocalDate localDate45 = dateTime44.toLocalDate();
        java.util.Date date46 = localDate45.toDate();
        int int47 = localDate45.getCenturyOfEra();
        org.joda.time.LocalDate.Property property48 = localDate45.weekyear();
        org.joda.time.LocalDate localDate49 = property48.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology50 = localDate49.getChronology();
        org.joda.time.LocalDate.Property property51 = localDate49.yearOfEra();
        org.joda.time.LocalDate localDate52 = property51.withMaximumValue();
        org.joda.time.Interval interval53 = localDate52.toInterval();
        org.joda.time.LocalDate localDate55 = localDate52.withWeekyear(0);
        org.joda.time.LocalDate localDate56 = localDate20.withFields((org.joda.time.ReadablePartial) localDate55);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1970-W01-3" + "'", str23.equals("1970-W01-3"));
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 19 + "'", int28 == 19);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 52L + "'", long41 == 52L);
        org.junit.Assert.assertNotNull(dateMidnight42);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 19 + "'", int47 == 19);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertNotNull(interval53);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(localDate56);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property6 = localDate5.yearOfCentury();
        boolean boolean7 = julianChronology0.equals((java.lang.Object) property6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.Chronology chronology5 = dateTime3.getChronology();
        org.joda.time.DateTime.Property property6 = dateTime3.secondOfMinute();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.roundCeilingCopy();
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear(18);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant3 = instant0.withDurationAdded((long) 86399, 1970);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
        java.util.Date date6 = localDate5.toDate();
        int int7 = localDate5.getCenturyOfEra();
        boolean boolean8 = iSOChronology1.equals((java.lang.Object) int7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Chronology chronology10 = iSOChronology1.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "Jan", 12, 970);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
        java.util.Date date11 = localDate10.toDate();
        int int12 = localDate10.getCenturyOfEra();
        org.joda.time.LocalDate.Property property13 = localDate10.weekyear();
        org.joda.time.LocalDate localDate14 = property13.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology15 = localDate14.getChronology();
        org.joda.time.LocalDate localDate17 = localDate14.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime18 = null;
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology19.getZone();
        org.joda.time.DateTime dateTime21 = localDate17.toDateTime(localTime18, dateTimeZone20);
        org.joda.time.LocalTime localTime22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone24 = gJChronology23.getZone();
        org.joda.time.DateTime dateTime25 = localDate17.toDateTime(localTime22, dateTimeZone24);
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate(1018L, dateTimeZone24);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField29 = gJChronology28.weekyears();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology28);
        org.joda.time.DateTimeZone dateTimeZone31 = gJChronology28.getZone();
        org.joda.time.DateMidnight dateMidnight32 = localDate26.toDateMidnight(dateTimeZone31);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((java.lang.Object) 0L, dateTimeZone31);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateMidnight32);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime9 = localDate8.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate.Property property10 = localDate8.dayOfYear();
        org.joda.time.LocalDate localDate11 = property10.roundCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.LocalDate localDate14 = dateTime13.toLocalDate();
        java.util.Date date15 = localDate14.toDate();
        int int16 = localDate14.getCenturyOfEra();
        org.joda.time.LocalDate.Property property17 = localDate14.weekyear();
        org.joda.time.LocalDate localDate18 = property17.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology19 = localDate18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime21.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property24 = dateTime23.monthOfYear();
        org.joda.time.LocalDate localDate25 = dateTime23.toLocalDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder26.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatterBuilder30.toFormatter();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
        org.joda.time.DateTime dateTime35 = dateTime33.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property36 = dateTime35.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property36.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder30.appendShortText(dateTimeFieldType37);
        int int39 = localDate25.indexOf(dateTimeFieldType37);
        org.joda.time.LocalDate localDate41 = localDate18.withField(dateTimeFieldType37, 12);
        try {
            org.joda.time.LocalDate localDate43 = localDate11.withField(dateTimeFieldType37, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 19 + "'", int16 == 19);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(localDate41);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = partial3.getChronology();
        int[] intArray5 = partial3.getValues();
        org.joda.time.Chronology chronology6 = partial3.getChronology();
        java.lang.String str7 = partial3.toString();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray8 = partial3.getFieldTypes();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = partial3.getFieldTypes();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[]" + "'", str7.equals("[]"));
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray8);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate11 = localDate6.withPeriodAdded(readablePeriod9, (int) '#');
        org.joda.time.LocalDate.Property property12 = localDate11.weekyear();
        org.joda.time.LocalDate localDate14 = localDate11.withEra((int) (short) 1);
        java.util.Date date15 = localDate14.toDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str18 = dateTimeFormatter16.print(101L);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.LocalDate localDate21 = dateTime20.toLocalDate();
        java.util.Date date22 = localDate21.toDate();
        int int23 = localDate21.getCenturyOfEra();
        org.joda.time.LocalDate.Property property24 = localDate21.weekyear();
        org.joda.time.LocalDate localDate25 = property24.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology26 = localDate25.getChronology();
        org.joda.time.LocalDate localDate28 = localDate25.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime29 = null;
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone31 = gJChronology30.getZone();
        org.joda.time.DateTime dateTime32 = localDate28.toDateTime(localTime29, dateTimeZone31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter16.withZone(dateTimeZone31);
        boolean boolean35 = dateTimeZone31.isStandardOffset((-54L));
        org.joda.time.DateMidnight dateMidnight36 = localDate14.toDateMidnight(dateTimeZone31);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.DurationField durationField38 = iSOChronology37.years();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-W01-3" + "'", str18.equals("1970-W01-3"));
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19 + "'", int23 == 19);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateMidnight36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(durationField38);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 2);
        long long7 = gregorianChronology3.add((long) 18, 100L, 10);
        org.joda.time.DateTimeField dateTimeField8 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology3, dateTimeField8, (-960));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1018L + "'", long7 == 1018L);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime7 = property4.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate.Property property6 = localDate2.yearOfCentury();
        long long7 = property6.remainder();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 259200000L + "'", long7 == 259200000L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
        org.joda.time.Interval interval5 = property4.toInterval();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(interval5);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str2 = dateTimeFormatter0.print(101L);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
        java.util.Date date6 = localDate5.toDate();
        int int7 = localDate5.getCenturyOfEra();
        org.joda.time.LocalDate.Property property8 = localDate5.weekyear();
        org.joda.time.LocalDate localDate9 = property8.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology10 = localDate9.getChronology();
        org.joda.time.LocalDate localDate12 = localDate9.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology14.getZone();
        org.joda.time.DateTime dateTime16 = localDate12.toDateTime(localTime13, dateTimeZone15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        long long20 = dateTimeZone15.convertUTCToLocal((long) '4');
        java.lang.String str21 = dateTimeZone15.getID();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-W01-3" + "'", str2.equals("1970-W01-3"));
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UTC" + "'", str21.equals("UTC"));
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test396");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
//        boolean boolean7 = iSOChronology4.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology9 = iSOChronology4.withZone(dateTimeZone8);
//        java.lang.String str11 = dateTimeZone8.getName((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone8);
//        org.joda.time.Chronology chronology13 = zonedChronology12.withUTC();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) zonedChronology12);
//        try {
//            long long19 = zonedChronology12.getDateTimeMillis(0, 70, 99, 2);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval8 = localDate5.toInterval(dateTimeZone7);
        long long12 = dateTimeZone7.convertLocalToUTC((long) (byte) 1, false, 0L);
        java.lang.String str13 = dateTimeZone7.getID();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
        try {
            org.joda.time.LocalDate localDate11 = localDate9.withDayOfYear(563);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 563 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime1.minusWeeks(24);
        org.joda.time.DateTime dateTime7 = dateTime1.minusYears((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury((int) 'a');
        org.joda.time.DateTime dateTime10 = dateTime7.withTimeAtStartOfDay();
        org.joda.time.TimeOfDay timeOfDay11 = dateTime7.toTimeOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(timeOfDay11);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(0L);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.joda.time.Instant instant5 = instant3.withMillis((-259200000L));
        org.joda.time.Instant instant7 = instant3.withMillis((long) 1969);
        org.joda.time.Instant instant9 = instant7.minus((-63713260799968L));
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.yearOfCentury();
        org.joda.time.LocalDate localDate3 = property2.roundHalfFloorCopy();
        int int4 = property2.getLeapAmount();
        org.joda.time.LocalDate localDate5 = property2.roundFloorCopy();
        org.joda.time.LocalDate localDate6 = property2.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = dateTime2.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str5 = localDate3.toString(dateTimeFormatter4);
        org.joda.time.LocalDate localDate7 = localDate3.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate9 = localDate7.withWeekyear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate12 = localDate7.withPeriodAdded(readablePeriod10, (int) '#');
        int[] intArray14 = buddhistChronology0.get((org.joda.time.ReadablePartial) localDate12, (long) 20);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
        java.util.Date date18 = localDate17.toDate();
        int int19 = localDate17.getCenturyOfEra();
        org.joda.time.LocalDate.Property property20 = localDate17.weekyear();
        boolean boolean21 = buddhistChronology0.equals((java.lang.Object) localDate17);
        org.joda.time.DurationField durationField22 = buddhistChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology0.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone24 = buddhistChronology0.getZone();
        java.lang.String str25 = buddhistChronology0.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970004" + "'", str5.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "BuddhistChronology[UTC]" + "'", str25.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime7 = property4.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay(784);
        org.joda.time.DateTime dateTime11 = dateTime9.withWeekyear(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.secondOfDay();
        org.joda.time.Instant instant6 = gJChronology1.getGregorianCutover();
        org.joda.time.Instant instant8 = instant6.plus((long) (byte) 1);
        org.joda.time.Instant instant10 = instant8.withMillis((long) 'a');
        org.joda.time.Instant instant13 = instant10.withDurationAdded((-172799900L), 52);
        org.joda.time.Instant instant15 = instant13.withMillis((long) 1401);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(instant15);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime6.toMutableDateTime(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.toDateTime(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
        java.util.Date date14 = localDate13.toDate();
        int int15 = localDate13.getCenturyOfEra();
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate();
        boolean boolean17 = localDate13.isAfter((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        org.joda.time.LocalDate localDate20 = dateTime19.toLocalDate();
        java.util.Date date21 = localDate20.toDate();
        int int22 = localDate20.getCenturyOfEra();
        org.joda.time.LocalDate.Property property23 = localDate20.weekyear();
        org.joda.time.LocalDate localDate24 = property23.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology25 = localDate24.getChronology();
        org.joda.time.LocalDate localDate27 = localDate24.withCenturyOfEra(19);
        org.joda.time.LocalDate localDate28 = localDate13.withFields((org.joda.time.ReadablePartial) localDate27);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime30 = localDate13.toDateTimeAtStartOfDay(dateTimeZone29);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime32 = dateTime30.plus(readablePeriod31);
        org.joda.time.Chronology chronology33 = dateTime32.getChronology();
        org.joda.time.DateTime dateTime34 = dateTime6.toDateTime(chronology33);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19 + "'", int15 == 19);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 19 + "'", int22 == 19);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTime34);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test406");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
//        boolean boolean7 = iSOChronology4.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology9 = iSOChronology4.withZone(dateTimeZone8);
//        java.lang.String str11 = dateTimeZone8.getName((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone8);
//        org.joda.time.DurationField durationField13 = zonedChronology12.months();
//        try {
//            long long21 = zonedChronology12.getDateTimeMillis(0, 1012, (int) '4', 10, 60754, 57600, 20);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 60754 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField5.getDurationField();
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField5.getAsShortText((int) 'a', locale11);
        java.lang.String str14 = delegatedDateTimeField5.getAsText((long) 69);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, 365);
        int int18 = offsetDateTimeField16.getLeapAmount((long) (-292275054));
        long long20 = offsetDateTimeField16.roundHalfFloor(115200L);
        org.joda.time.ReadablePartial readablePartial21 = null;
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField16.getAsText(readablePartial21, 2, locale23);
        long long27 = offsetDateTimeField16.getDifferenceAsLong((long) 1843, 0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97" + "'", str12.equals("97"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-259200000L) + "'", long20 == (-259200000L));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2" + "'", str24.equals("2"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfCentury(784, 784);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendLiteral('a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.withYear((int) ' ');
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime1.plusMinutes((int) '#');
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTime1.toString("160000-0800", locale8);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "160000-0800" + "'", str9.equals("160000-0800"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField10);
        int int12 = skipUndoDateTimeField11.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 10);
        boolean boolean15 = gregorianChronology3.equals((java.lang.Object) skipUndoDateTimeField11);
        long long18 = skipUndoDateTimeField11.set(0L, 10);
        java.lang.String str19 = skipUndoDateTimeField11.toString();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property22 = localDate21.dayOfYear();
        org.joda.time.LocalDate localDate23 = property22.withMinimumValue();
        org.joda.time.LocalDate localDate25 = property22.setCopy(10);
        int int26 = localDate25.getDayOfYear();
        int int27 = skipUndoDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) localDate25);
        org.joda.time.LocalDate localDate29 = localDate25.minusYears(24);
        java.util.Locale locale31 = null;
        try {
            java.lang.String str32 = localDate29.toString("", locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10000L + "'", long18 == 10000L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str19.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(localDate29);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
        int int5 = localDate2.getCenturyOfEra();
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtCurrentTime();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "Jan", 12, 970);
        int int6 = fixedDateTimeZone4.getStandardOffset(1998L);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        int int10 = fixedDateTimeZone4.getStandardOffset((long) 84086);
        int int12 = fixedDateTimeZone4.getOffsetFromLocal(1044883541620800000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 970 + "'", int6 == 970);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 970 + "'", int10 == 970);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property17 = dateTime16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType18, 1012);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder0.appendWeekyear(19, (-259200000));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumShortTextLength(locale5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.monthOfYear();
        org.joda.time.DateTime dateTime13 = dateTime10.minusMonths(0);
        org.joda.time.DateTime dateTime15 = dateTime13.withHourOfDay(19);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime18 = dateTime13.withPeriodAdded(readablePeriod16, 2000);
        int int19 = property4.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = dateTime18.withYearOfCentury(12);
        try {
            org.joda.time.DateTime dateTime23 = dateTime21.withDayOfYear((-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for dayOfYear must be in the range [1,366]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 16);
        try {
            org.joda.time.LocalDate localDate3 = localDate1.withDayOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval8 = localDate5.toInterval(dateTimeZone7);
        org.joda.time.LocalDate localDate10 = localDate5.plusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 100);
        org.joda.time.DateMidnight dateMidnight13 = dateTime12.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime12.getZone();
        org.joda.time.DateMidnight dateMidnight15 = localDate5.toDateMidnight(dateTimeZone14);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateMidnight15);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsShortText(locale5);
        java.lang.String str7 = property4.getAsShortText();
        int int8 = property4.get();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property4.getAsText(locale9);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jan" + "'", str6.equals("Jan"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jan" + "'", str7.equals("Jan"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January" + "'", str10.equals("January"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = partial3.getChronology();
        int int5 = partial3.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology6);
        int[] intArray9 = partial3.getValues();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray10 = partial3.getFieldTypes();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray10);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.lang.Appendable appendable2 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj5 = null;
        boolean boolean6 = gJChronology4.equals(obj5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(1L, (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) (byte) 1);
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadableInstant) dateTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate.Property property8 = localDate6.yearOfEra();
        org.joda.time.LocalDate localDate10 = localDate6.minusMonths(16);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate10);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = partial3.getChronology();
        int int5 = partial3.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.Partial partial8 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.yearOfCentury();
        org.joda.time.Partial partial12 = partial8.withChronologyRetainFields((org.joda.time.Chronology) gJChronology9);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(partial12);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTime(localTime10, dateTimeZone12);
        int int14 = localDate9.getMonthOfYear();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.LocalDate localDate17 = localDate9.withPeriodAdded(readablePeriod15, 53);
        int int18 = localDate9.getYearOfEra();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "Jan", 12, 970);
        int int6 = fixedDateTimeZone4.getStandardOffset(1998L);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str9 = fixedDateTimeZone4.getName(0L);
        java.util.TimeZone timeZone10 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 970 + "'", int6 == 970);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.012" + "'", str9.equals("+00:00:00.012"));
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("1969365");
        int int2 = localDate1.getCenturyOfEra();
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19693 + "'", int2 == 19693);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(259200020L, (org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime1.minusWeeks(24);
        org.joda.time.DateTime dateTime7 = dateTime1.minusYears((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury((int) 'a');
        org.joda.time.DateTime dateTime10 = dateTime7.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime12 = dateTime7.withDayOfYear(20);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(24724223999216L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval8 = localDate5.toInterval(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = localDate5.toDateTimeAtCurrentTime();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendEraText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str17 = dateTimeFormatter15.print(101L);
        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatter15.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder13.append(dateTimePrinter18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder8.append(dateTimePrinter18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder8.appendFractionOfMinute(1012, (-259200000));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1970-W01-3" + "'", str17.equals("1970-W01-3"));
        org.junit.Assert.assertNotNull(dateTimePrinter18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField3 = gJChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField6);
        int int8 = skipUndoDateTimeField7.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 10);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
        int int13 = skipUndoDateTimeField10.get((long) 84091);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField5.getAsShortText(2000, locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField5.getAsText(6, locale15);
        long long19 = delegatedDateTimeField5.getDifferenceAsLong(0L, 100L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str25 = localDate23.toString(dateTimeFormatter24);
        org.joda.time.LocalDate localDate27 = localDate23.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate29 = localDate27.withWeekyear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate32 = localDate27.withPeriodAdded(readablePeriod30, (int) '#');
        int[] intArray34 = buddhistChronology20.get((org.joda.time.ReadablePartial) localDate32, (long) 20);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = null;
        java.lang.String str36 = localDate32.toString(dateTimeFormatter35);
        int[] intArray41 = new int[] { 70, (-11), 84032 };
        java.util.Locale locale43 = null;
        try {
            int[] intArray44 = delegatedDateTimeField5.set((org.joda.time.ReadablePartial) localDate32, (int) (byte) 100, intArray41, "2019-W29-4", locale43);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-W29-4\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2000" + "'", str13.equals("2000"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "6" + "'", str16.equals("6"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970004" + "'", str25.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1970-05-10" + "'", str36.equals("1970-05-10"));
        org.junit.Assert.assertNotNull(intArray41);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsShortText(locale5);
        java.lang.String str7 = property4.getAsShortText();
        int int8 = property4.get();
        org.joda.time.DateTime dateTime9 = property4.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property14 = dateTime13.monthOfYear();
        org.joda.time.DateTime dateTime15 = property14.withMaximumValue();
        org.joda.time.DateTime dateTime16 = dateTime15.withEarlierOffsetAtOverlap();
        int int17 = property4.getDifference((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        java.util.GregorianCalendar gregorianCalendar20 = dateTime19.toGregorianCalendar();
        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime();
        int int22 = property4.compareTo((org.joda.time.ReadableInstant) dateTime19);
        int int23 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime24 = property4.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jan" + "'", str6.equals("Jan"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jan" + "'", str7.equals("Jan"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-11) + "'", int17 == (-11));
        org.junit.Assert.assertNotNull(gregorianCalendar20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        int int6 = property4.getMaximumValue();
        java.lang.Class<?> wildcardClass7 = property4.getClass();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withDurationAdded(readableDuration9, 363);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate2.plus(readablePeriod5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
        java.util.Date date10 = localDate9.toDate();
        int int11 = localDate9.getCenturyOfEra();
        org.joda.time.LocalDate.Property property12 = localDate9.weekyear();
        org.joda.time.LocalDate localDate13 = property12.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology14 = localDate13.getChronology();
        org.joda.time.LocalDate.Property property15 = localDate13.yearOfEra();
        org.joda.time.LocalDate localDate16 = property15.withMaximumValue();
        org.joda.time.Interval interval17 = localDate16.toInterval();
        org.joda.time.LocalDate localDate18 = localDate6.withFields((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.LocalDate localDate20 = localDate6.withDayOfYear(2);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(interval17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(localDate20);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendHalfdayOfDayText();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField12 = iSOChronology11.weeks();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str15 = dateTimeFormatter13.print(101L);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.LocalDate localDate18 = dateTime17.toLocalDate();
        java.util.Date date19 = localDate18.toDate();
        int int20 = localDate18.getCenturyOfEra();
        org.joda.time.LocalDate.Property property21 = localDate18.weekyear();
        org.joda.time.LocalDate localDate22 = property21.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology23 = localDate22.getChronology();
        org.joda.time.LocalDate localDate25 = localDate22.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime26 = null;
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone28 = gJChronology27.getZone();
        org.joda.time.DateTime dateTime29 = localDate25.toDateTime(localTime26, dateTimeZone28);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter13.withZone(dateTimeZone28);
        org.joda.time.Chronology chronology31 = iSOChronology11.withZone(dateTimeZone28);
        try {
            org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((java.lang.Object) dateTimeFormatterBuilder7, (org.joda.time.Chronology) iSOChronology11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970-W01-3" + "'", str15.equals("1970-W01-3"));
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 19 + "'", int20 == 19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(chronology31);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(0L, (org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneId();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatterBuilder3.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMinuteOfHour((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj2 = null;
        boolean boolean3 = gJChronology1.equals(obj2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime7 = dateTime5.plusWeeks((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusSeconds(26);
        boolean boolean10 = dateTime5.isAfterNow();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.secondOfDay();
        org.joda.time.Instant instant6 = gJChronology1.getGregorianCutover();
        org.joda.time.Instant instant8 = instant6.plus((long) (byte) 1);
        org.joda.time.Instant instant10 = instant8.withMillis((long) 'a');
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Instant instant12 = instant8.minus(readableDuration11);
        long long13 = instant12.getMillis();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-12219292799999L) + "'", long13 == (-12219292799999L));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(0L);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant1.plus(readableDuration4);
        org.joda.time.Chronology chronology6 = instant1.getChronology();
        org.joda.time.Instant instant8 = instant1.withMillis((long) 563);
        org.joda.time.Instant instant9 = instant8.toInstant();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        int int3 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getMinuteOfDay();
        int int4 = dateTime1.getYearOfEra();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60720 + "'", int2 == 60720);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1012 + "'", int3 == 1012);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj2 = null;
        boolean boolean3 = gJChronology1.equals(obj2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime7 = dateTime5.plusWeeks((int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withSecondOfMinute((-2020));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2020 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(1969, (int) (byte) 10, (-2020));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate7 = localDate2.withPeriodAdded(readablePeriod5, (int) (byte) 100);
        boolean boolean8 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.LocalDate.Property property9 = localDate7.weekyear();
        org.joda.time.LocalDate.Property property10 = localDate7.era();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime dateTime16 = dateTime12.minusWeeks(24);
        org.joda.time.DateTime dateTime18 = dateTime12.minusYears((int) '#');
        org.joda.time.DateTime dateTime20 = dateTime18.withYearOfCentury((int) 'a');
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime20.minus(readableDuration21);
        try {
            int int23 = property10.getDifference((org.joda.time.ReadableInstant) dateTime20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        java.lang.String str5 = partial3.toString();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.yearOfCentury();
        org.joda.time.Partial partial10 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology6);
        int[] intArray11 = partial10.getValues();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.Partial partial13 = partial10.minus(readablePeriod12);
        try {
            int int15 = partial10.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(partial13);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withPivotYear(746);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withDefaultYear(19);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = dateTime2.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str5 = localDate3.toString(dateTimeFormatter4);
        org.joda.time.LocalDate localDate7 = localDate3.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate9 = localDate7.withWeekyear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate12 = localDate7.withPeriodAdded(readablePeriod10, (int) '#');
        int[] intArray14 = buddhistChronology0.get((org.joda.time.ReadablePartial) localDate12, (long) 20);
        long long18 = buddhistChronology0.add((long) 52, (long) 70, 0);
        org.joda.time.Chronology chronology19 = buddhistChronology0.withUTC();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder20.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder24.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder24.appendPattern("1");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder29.appendYearOfCentury((int) (byte) 10, (-2020));
        boolean boolean33 = buddhistChronology0.equals((java.lang.Object) (-2020));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970004" + "'", str5.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 52L + "'", long18 == 52L);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.append(dateTimeFormatter7);
        org.joda.time.Chronology chronology9 = dateTimeFormatter7.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNull(chronology9);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
        java.util.Date date10 = localDate9.toDate();
        int int11 = localDate9.getCenturyOfEra();
        org.joda.time.LocalDate.Property property12 = localDate9.weekyear();
        org.joda.time.LocalDate localDate13 = property12.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology14 = localDate13.getChronology();
        org.joda.time.LocalDate localDate16 = localDate13.withCenturyOfEra(19);
        org.joda.time.LocalDate localDate17 = localDate2.withFields((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime19 = localDate2.toDateTimeAtStartOfDay(dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.plus(readablePeriod20);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField24 = gJChronology23.weekyears();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology23);
        org.joda.time.DateTime dateTime27 = dateTime25.minusMonths(10);
        org.joda.time.DateTime dateTime29 = dateTime25.withSecondOfMinute(4);
        org.joda.time.DateTime dateTime31 = dateTime25.withYearOfEra(70);
        boolean boolean32 = dateTime19.isEqual((org.joda.time.ReadableInstant) dateTime25);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 418);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField11);
        int int13 = skipUndoDateTimeField12.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, (org.joda.time.DateTimeField) skipUndoDateTimeField12, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = skipUndoDateTimeField12.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField5.getDurationField();
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField5.getAsShortText((int) 'a', locale11);
        java.lang.String str14 = delegatedDateTimeField5.getAsText((long) 69);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, 365);
        long long19 = offsetDateTimeField16.add((-172799900L), 5);
        java.util.Locale locale20 = null;
        int int21 = offsetDateTimeField16.getMaximumTextLength(locale20);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97" + "'", str12.equals("97"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2851200100L + "'", long19 == 2851200100L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMonthOfYear(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTwoDigitYear(19, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 3);
        int int5 = dateTimeZone1.getOffsetFromLocal(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test462");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        java.util.Date date3 = localDate2.toDate();
//        int int4 = localDate2.getCenturyOfEra();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        java.util.Date date10 = localDate9.toDate();
//        int int11 = localDate9.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property12 = localDate9.weekyear();
//        org.joda.time.LocalDate localDate13 = property12.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology14 = localDate13.getChronology();
//        org.joda.time.LocalDate localDate16 = localDate13.withCenturyOfEra(19);
//        org.joda.time.LocalDate localDate17 = localDate2.withFields((org.joda.time.ReadablePartial) localDate16);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField20 = iSOChronology19.weeks();
//        boolean boolean22 = iSOChronology19.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology24 = iSOChronology19.withZone(dateTimeZone23);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str27 = dateTimeZone25.getShortName(31535999999L);
//        org.joda.time.Chronology chronology28 = iSOChronology19.withZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime29 = localDate17.toDateTimeAtMidnight(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        org.joda.time.LocalDate localDate32 = dateTime31.toLocalDate();
//        java.util.Date date33 = localDate32.toDate();
//        int int34 = localDate32.getCenturyOfEra();
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.LocalDate localDate36 = localDate32.plus(readablePeriod35);
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(dateTimeZone37);
//        org.joda.time.LocalDate localDate39 = dateTime38.toLocalDate();
//        java.util.Date date40 = localDate39.toDate();
//        int int41 = localDate39.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property42 = localDate39.weekyear();
//        org.joda.time.LocalDate localDate43 = property42.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology44 = localDate43.getChronology();
//        org.joda.time.LocalDate.Property property45 = localDate43.yearOfEra();
//        org.joda.time.LocalDate localDate46 = property45.withMaximumValue();
//        org.joda.time.Interval interval47 = localDate46.toInterval();
//        org.joda.time.LocalDate localDate48 = localDate36.withFields((org.joda.time.ReadablePartial) localDate46);
//        boolean boolean49 = localDate17.isAfter((org.joda.time.ReadablePartial) localDate36);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "UTC" + "'", str27.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 19 + "'", int34 == 19);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 19 + "'", int41 == 19);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(chronology44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertNotNull(interval47);
//        org.junit.Assert.assertNotNull(localDate48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        java.lang.Object obj0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate7 = localDate2.withPeriodAdded(readablePeriod5, (int) (byte) 100);
        org.joda.time.DateTime dateTime8 = localDate2.toDateTimeAtMidnight();
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfSecond();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 2019, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-259200000));
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withYear((int) ' ');
        java.lang.String str7 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime4);
        java.lang.String str9 = dateTimeFormatter2.print((long) 746);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970W017" + "'", str7.equals("1970W017"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970W013" + "'", str9.equals("1970W013"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 100);
        org.joda.time.DateMidnight dateMidnight2 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime1.getZone();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        long long7 = cachedDateTimeZone5.previousTransition((long) 960);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-5756400001L) + "'", long7 == (-5756400001L));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField5.getDurationField();
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField5.getAsShortText((int) 'a', locale11);
        java.lang.String str14 = delegatedDateTimeField5.getAsText((long) 69);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, 365);
        int int18 = offsetDateTimeField16.getLeapAmount((long) (-292275054));
        int int19 = offsetDateTimeField16.getOffset();
        boolean boolean21 = offsetDateTimeField16.isLeap(115200L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97" + "'", str12.equals("97"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 365 + "'", int19 == 365);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.months();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property9 = dateTime8.monthOfYear();
        org.joda.time.LocalDate localDate10 = dateTime8.toLocalDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatterBuilder15.toFormatter();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property21 = dateTime20.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder15.appendShortText(dateTimeFieldType22);
        int int24 = localDate10.indexOf(dateTimeFieldType22);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray25 = localDate10.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.LocalDate localDate28 = dateTime27.toLocalDate();
        java.util.Date date29 = localDate28.toDate();
        int int30 = localDate28.getCenturyOfEra();
        org.joda.time.LocalDate localDate32 = localDate28.minusYears(1);
        org.joda.time.LocalDate localDate33 = localDate10.withFields((org.joda.time.ReadablePartial) localDate32);
        long long35 = julianChronology0.set((org.joda.time.ReadablePartial) localDate33, 10L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray25);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 19 + "'", int30 == 19);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-30067199990L) + "'", long35 == (-30067199990L));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        int int3 = dateTime1.getSecondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.minusHours((int) '#');
        org.joda.time.DateTime dateTime7 = dateTime5.withSecondOfMinute((int) (short) 0);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31920 + "'", int3 == 31920);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
        java.util.Locale locale19 = null;
        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
        java.lang.Class<?> wildcardClass21 = offsetDateTimeField18.getClass();
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField18.getMaximumTextLength(locale22);
        try {
            long long26 = offsetDateTimeField18.set((long) 32, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [3,55]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateMidnight dateMidnight4 = dateTime1.toDateMidnight();
        java.util.Locale locale5 = null;
        java.util.Calendar calendar6 = dateMidnight4.toCalendar(locale5);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(calendar6);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate6, locale7);
        java.lang.String str9 = delegatedDateTimeField5.toString();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone11);
        int[] intArray17 = new int[] { 2019, 100, 69, 365 };
        int int18 = delegatedDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate12, intArray17);
        long long20 = delegatedDateTimeField5.roundCeiling((long) 'a');
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str9.equals("DateTimeField[weekOfWeekyear]"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 345600000L + "'", long20 == 345600000L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumShortTextLength(locale5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.monthOfYear();
        org.joda.time.DateTime dateTime13 = dateTime10.minusMonths(0);
        org.joda.time.DateTime dateTime15 = dateTime13.withHourOfDay(19);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime18 = dateTime13.withPeriodAdded(readablePeriod16, 2000);
        int int19 = property4.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = dateTime18.plusHours((-11));
        int int22 = dateTime18.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime9 = localDate8.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate.Property property10 = localDate8.dayOfYear();
        org.joda.time.LocalDate localDate11 = property10.roundCeilingCopy();
        org.joda.time.DateTimeField dateTimeField12 = property10.getField();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.weeks();
        org.joda.time.DurationField durationField2 = gJChronology0.hours();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj4 = null;
        boolean boolean5 = gJChronology3.equals(obj4);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField8);
        boolean boolean10 = skipUndoDateTimeField9.isSupported();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) '#');
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean6 = julianChronology4.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology4.year();
        org.joda.time.Chronology chronology8 = julianChronology4.withUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology4.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone10.getUncachedZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter3.withZone(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property17 = dateTime16.monthOfYear();
        org.joda.time.DateTime dateTime18 = property17.roundHalfCeilingCopy();
        int int19 = property17.getMaximumValue();
        int int20 = property17.getMaximumValueOverall();
        org.joda.time.DateTime dateTime22 = property17.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime24 = dateTime22.plusWeeks(60720);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("", "Jan", 12, 970);
        int int31 = fixedDateTimeZone29.getStandardOffset(1998L);
        java.util.TimeZone timeZone32 = fixedDateTimeZone29.toTimeZone();
        java.util.TimeZone timeZone33 = fixedDateTimeZone29.toTimeZone();
        org.joda.time.DateTime dateTime34 = dateTime24.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone29);
        try {
            org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime24, 19693);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 19693");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 970 + "'", int31 == 970);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        java.lang.String str5 = partial3.toString();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.yearOfCentury();
        org.joda.time.Partial partial10 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology6);
        java.lang.String str11 = partial10.toString();
        try {
            org.joda.time.DateTimeField dateTimeField13 = partial10.getField(0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "[]" + "'", str11.equals("[]"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField5.getAsShortText(2000, locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField5.getAsText(6, locale15);
        long long19 = delegatedDateTimeField5.add((long) 100, (int) '#');
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField5.getAsShortText((int) (byte) 1, locale21);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2000" + "'", str13.equals("2000"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "6" + "'", str16.equals("6"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 21168000100L + "'", long19 == 21168000100L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1" + "'", str22.equals("1"));
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test481");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
//        boolean boolean7 = iSOChronology4.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology9 = iSOChronology4.withZone(dateTimeZone8);
//        java.lang.String str11 = dateTimeZone8.getName((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone8);
//        org.joda.time.DurationField durationField13 = zonedChronology12.months();
//        org.joda.time.DateTimeField dateTimeField14 = zonedChronology12.era();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.DateTime dateTime6 = dateTime3.minusYears((int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime3.isSupported(dateTimeFieldType7);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField11 = gJChronology10.weekyears();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths(10);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, (org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime17 = dateTime3.minus(readableDuration16);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears(0);
        org.joda.time.DateTime dateTime4 = dateTime0.minusDays((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
        org.joda.time.LocalDate localDate3 = property2.withMinimumValue();
        org.joda.time.LocalDate localDate4 = property2.roundFloorCopy();
        org.joda.time.DateTimeField dateTimeField5 = property2.getField();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(0, '4', 0, (int) (byte) 0, 1969, false, 784);
        java.io.OutputStream outputStream10 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", outputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.Partial partial2 = new org.joda.time.Partial((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMonthOfYear(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay(70, (-960));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendWeekOfWeekyear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime1.minusWeeks(24);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(784);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str9 = dateTime7.toString(dateTimeFormatter8);
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-W06-5" + "'", str9.equals("1970-W06-5"));
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.year();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfWeek();
        org.joda.time.Instant instant7 = new org.joda.time.Instant(0L);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Instant instant9 = instant7.plus(readableDuration8);
        org.joda.time.Instant instant11 = instant9.withMillis((-259200000L));
        int int12 = property5.compareTo((org.joda.time.ReadableInstant) instant9);
        boolean boolean13 = property5.isLeap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(0, '4', 0, (int) (byte) 0, 1969, false, 784);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder8.setStandardOffset(365);
        java.io.DataOutput dataOutput12 = null;
        try {
            dateTimeZoneBuilder8.writeTo("January", dataOutput12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(18);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-18) + "'", int1 == (-18));
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test494");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
//        boolean boolean7 = iSOChronology4.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology9 = iSOChronology4.withZone(dateTimeZone8);
//        java.lang.String str11 = dateTimeZone8.getName((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone13 = zonedChronology12.getZone();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        java.util.Date date5 = localDate4.toDate();
        int int6 = localDate4.getCenturyOfEra();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
        boolean boolean8 = localDate4.isAfter((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval10 = localDate7.toInterval(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology1, dateTimeZone9);
        org.joda.time.Chronology chronology12 = gJChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology1.weekyear();
        int int14 = gJChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(interval10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.Chronology chronology4 = julianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology0.getZone();
        org.joda.time.Chronology chronology6 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "hi!", "");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "secondOfMinute", "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        long long9 = skipUndoDateTimeField6.set(100L, (int) (short) 1);
        try {
            long long12 = skipUndoDateTimeField6.set(84032L, (-960));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -960 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1100L + "'", long9 == 1100L);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test500");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
//        boolean boolean7 = iSOChronology4.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology9 = iSOChronology4.withZone(dateTimeZone8);
//        java.lang.String str11 = dateTimeZone8.getName((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone8);
//        org.joda.time.DurationField durationField13 = zonedChronology12.months();
//        org.joda.time.DurationField durationField14 = zonedChronology12.weeks();
//        try {
//            long long22 = zonedChronology12.getDateTimeMillis(119, 563, 84032, 70, 6, 0, 19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(durationField14);
//    }
//}

