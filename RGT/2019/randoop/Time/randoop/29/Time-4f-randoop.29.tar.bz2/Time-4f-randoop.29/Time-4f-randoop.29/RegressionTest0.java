import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        try {
            org.joda.time.DateTime dateTime5 = dateTime1.withDate((int) (short) 100, (int) (short) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray4 = gJChronology0.get(readablePeriod1, (long) ' ', 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField1, dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) (byte) -1, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            java.lang.String str2 = dateTimeFormatter0.print(readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (short) 0, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        try {
            org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) "", (org.joda.time.Chronology) gJChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        int[] intArray1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        try {
            org.joda.time.Partial partial4 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray1, (org.joda.time.Chronology) iSOChronology3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertNotNull(iSOChronology3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 10);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.util.Date date0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.weeks();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField6 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, durationField3, dateTimeFieldType4, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = gJChronology0.get(readablePeriod3, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        try {
            long long7 = gJChronology0.getDateTimeMillis((long) 'a', (int) (short) 10, (int) (short) -1, (int) '#', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            boolean boolean6 = localDateTime4.isBefore(readablePartial5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        try {
            long long10 = iSOChronology1.getDateTimeMillis((int) ' ', (int) ' ', 10, (int) ' ', 0, (-1), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, durationField2, dateTimeFieldType3, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 10L + "'", long0 == 10L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(1L, "hi!");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj2 = null;
        boolean boolean3 = gJChronology1.equals(obj2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        try {
            org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((java.lang.Object) 0.0f, chronology5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Float");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        try {
            org.joda.time.LocalDate localDate3 = localDate1.withDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (short) 1);
        try {
            org.joda.time.DateTime dateTime4 = dateTime0.withMinuteOfHour((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType3, (int) (byte) 100, (int) (short) 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.yearOfCentury();
        try {
            org.joda.time.LocalDate localDate4 = property2.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) 1, number2, (java.lang.Number) (byte) 10);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) ' ', (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 31L + "'", long2 == 31L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.Chronology chronology5 = dateTime3.getChronology();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        java.util.GregorianCalendar gregorianCalendar11 = dateTime10.toGregorianCalendar();
        try {
            org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance(chronology5, (org.joda.time.ReadableDateTime) dateTime6, (org.joda.time.ReadableDateTime) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianCalendar11);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) '4', 0, (int) ' ', 19, (int) (short) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 19, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        try {
            long long9 = gJChronology0.getDateTimeMillis((int) (byte) 1, (int) (short) -1, 1, 100, (int) (short) -1, (int) (byte) -1, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField3 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.Chronology chronology5 = dateTime3.getChronology();
        org.joda.time.DateTime.Property property6 = dateTime3.secondOfMinute();
        int int7 = dateTime3.getYear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("GJChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        org.joda.time.LocalDateTime localDateTime7 = dateTime5.toLocalDateTime();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDateTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(localDateTime7);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        try {
            long long2 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(100L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 101L + "'", long2 == 101L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("1969365");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969365\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.yearOfCentury();
        try {
            org.joda.time.LocalDate localDate4 = property2.setCopy("2019166");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019166 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.Partial partial2 = new org.joda.time.Partial(dateTimeFieldType0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.Chronology chronology5 = dateTime3.getChronology();
        org.joda.time.DateTime.Property property6 = dateTime3.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.DateTime.Property property8 = dateTime3.property(dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.secondOfDay();
        try {
            org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((int) (byte) -1, 100, 100, (org.joda.time.Chronology) gJChronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology2 = dateTime1.getChronology();
        try {
            org.joda.time.DateTime dateTime6 = dateTime1.withDate((int) 'a', (int) (short) 0, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsShortText(locale5);
        java.lang.String str7 = property4.getAsShortText();
        int int8 = property4.getMaximumValueOverall();
        java.util.Locale locale9 = null;
        int int10 = property4.getMaximumTextLength(locale9);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun" + "'", str6.equals("Jun"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jun" + "'", str7.equals("Jun"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
//        try {
//            org.joda.time.LocalDate localDate10 = localDate6.withCenturyOfEra((-1));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for centuryOfEra must be in the range [0,2922789]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019166" + "'", str4.equals("2019166"));
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfCentury();
        long long5 = property4.remainder();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31535999999L + "'", long5 == 31535999999L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateMidnight dateMidnight4 = dateTime1.toDateMidnight();
        try {
            org.joda.time.DateTime dateTime6 = dateTime1.withDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateMidnight4);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = partial3.getChronology();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.Partial.Property property6 = partial3.property(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.LocalDate localDate8 = localDate2.withField(dateTimeFieldType6, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        int int5 = property4.getMaximumValue();
        int int6 = property4.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("1969-365T��:��:��");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-365T��:��:��\" is malformed at \"-365T��:��:��\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsShortText(locale5);
        java.lang.String str7 = property4.getAsShortText();
        java.util.Locale locale9 = null;
        try {
            org.joda.time.DateTime dateTime10 = property4.setCopy("1969-365T��:��:��", locale9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-365T��:��:��\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jun" + "'", str6.equals("Jun"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jun" + "'", str7.equals("Jun"));
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate6, locale7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        try {
//            org.joda.time.LocalDate.Property property10 = localDate6.property(dateTimeFieldType9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "24" + "'", str8.equals("24"));
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial3.minus(readablePeriod4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = iSOChronology7.days();
        try {
            org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((java.lang.Object) partial5, (org.joda.time.Chronology) iSOChronology7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(partial5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) (-1.0f), dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Float");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        java.util.Locale locale8 = null;
        try {
            org.joda.time.LocalDate localDate9 = property5.setCopy("Jun", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Jun\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(101L);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.Chronology chronology2 = dateTime1.getChronology();
//        int int3 = dateTime1.getDayOfWeek();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj3 = null;
        boolean boolean4 = gJChronology2.equals(obj3);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.Instant instant6 = gJChronology2.getGregorianCutover();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) instant6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (short) 1, 10, 12, 0, (int) '#', 2000, 9, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.weeks();
        org.joda.time.DurationField durationField3 = gJChronology0.centuries();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj4 = null;
        boolean boolean5 = gJChronology3.equals(obj4);
        try {
            org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((java.lang.Object) dateTimeField2, (org.joda.time.Chronology) gJChronology3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.GJChronology$ImpreciseCutoverField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) -1, 20, (int) (byte) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial3.minus(readablePeriod4);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType7 = partial5.getFieldType(1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(partial5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        try {
            long long8 = iSOChronology1.getDateTimeMillis((long) 19, 0, (-1), (int) (byte) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        long long1 = instant0.getMillis();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560640824629L + "'", long1 == 1560640824629L);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 100);
        org.joda.time.ReadableInstant readableInstant2 = null;
        boolean boolean3 = dateTime1.isEqual(readableInstant2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        long long2 = org.joda.time.field.FieldUtils.safeDivide((long) 2019, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = gJChronology0.get(readablePeriod3, (long) (short) -1, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DurationField durationField3 = property2.getDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        try {
            int[] intArray9 = gJChronology1.get(readablePeriod6, 0L, 1560640820478L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale11 = null;
        try {
            long long12 = delegatedDateTimeField5.set(1L, "", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        try {
            org.joda.time.DateTime dateTime8 = dateTime3.withEra(6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 6 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str3 = illegalFieldValueException2.toString();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Number number5 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Instant instant4 = gJChronology0.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology0.millis();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.Chronology chronology8 = dateTime7.getChronology();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = iSOChronology10.weeks();
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime7.toMutableDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj15 = null;
        boolean boolean16 = gJChronology14.equals(obj15);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(1L, (org.joda.time.Chronology) gJChronology14);
        try {
            org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) dateTime7, (org.joda.time.ReadableDateTime) dateTime18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime17);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property5 = dateTime4.monthOfYear();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusMonths(0);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj9 = null;
//        boolean boolean10 = gJChronology8.equals(obj9);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology8);
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology8.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = delegatedDateTimeField13.getAsText((org.joda.time.ReadablePartial) localDate14, locale15);
//        int int17 = delegatedDateTimeField13.getMaximumValue();
//        int int18 = dateTime7.get((org.joda.time.DateTimeField) delegatedDateTimeField13);
//        org.joda.time.DurationField durationField19 = delegatedDateTimeField13.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField19, dateTimeFieldType20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "24" + "'", str16.equals("24"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(durationField19);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval8 = localDate5.toInterval(dateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField11 = gJChronology10.weekyears();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths(10);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime12.minus(readablePeriod15);
        try {
            org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime16, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property5 = dateTime4.monthOfYear();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusMonths(0);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj9 = null;
//        boolean boolean10 = gJChronology8.equals(obj9);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology8);
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology8.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = delegatedDateTimeField13.getAsText((org.joda.time.ReadablePartial) localDate14, locale15);
//        int int17 = delegatedDateTimeField13.getMaximumValue();
//        int int18 = dateTime7.get((org.joda.time.DateTimeField) delegatedDateTimeField13);
//        org.joda.time.DurationField durationField19 = delegatedDateTimeField13.getRangeDurationField();
//        org.joda.time.DurationField durationField20 = org.joda.time.field.MillisDurationField.INSTANCE;
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField21 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField19, durationField20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "24" + "'", str16.equals("24"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(durationField20);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "GJChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 784, 31535999999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24724223999216L + "'", long2 == 24724223999216L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.minutes();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("GJChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'GJChronology[UTC]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("[]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) 'a', 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 970 + "'", int2 == 970);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.weeks();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.minus(readableDuration5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(readableDuration7, (int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.LocalDate localDate4 = localDate2.withYearOfCentury((int) (short) 10);
        java.util.Locale locale6 = null;
        try {
            java.lang.String str7 = localDate2.toString("DateTimeField[weekOfWeekyear]", locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology10);
        org.joda.time.DurationField durationField12 = gJChronology10.minutes();
        org.joda.time.Partial partial13 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = partial13.getFormatter();
        java.lang.String str15 = partial13.toString();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology16);
        org.joda.time.DurationField durationField18 = gJChronology16.minutes();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology16.yearOfCentury();
        org.joda.time.Partial partial20 = partial13.withChronologyRetainFields((org.joda.time.Chronology) gJChronology16);
        try {
            boolean boolean21 = localDate9.isEqual((org.joda.time.ReadablePartial) partial13);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[]" + "'", str15.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(partial20);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTime(localTime10, dateTimeZone12);
        try {
            org.joda.time.LocalDate localDate15 = localDate9.withYearOfCentury((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "DateTimeField[weekOfWeekyear]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("GJChronology[UTC]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(0);
        org.joda.time.DateTime dateTime8 = dateTime6.withHourOfDay(19);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime6.withPeriodAdded(readablePeriod9, 2000);
        int int12 = dateTime11.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000000233d + "'", double1 == 2440587.5000000233d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial3.minus(readablePeriod4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.Partial partial8 = partial5.with(dateTimeFieldType6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(partial5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        try {
            long long7 = gJChronology0.getDateTimeMillis(0, (int) (short) 1, 2000, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfCentury();
        int int5 = dateTime3.getYearOfCentury();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.LocalDate localDate5 = dateTime3.toLocalDate();
        java.util.Locale locale7 = null;
        try {
            java.lang.String str8 = dateTime3.toString("Coordinated Universal Time", locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: oo");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.field.FieldUtils.verifyValueBounds("", (int) '#', 9, (int) 'a');
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        try {
            org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((-1));
        try {
            org.joda.time.LocalDate localDate6 = localDate4.withDayOfMonth(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 101L, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial3.minus(readablePeriod4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property10 = dateTime9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        try {
            int int12 = partial3.get(dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'monthOfYear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(partial5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
        java.util.Locale locale19 = null;
        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
        long long22 = offsetDateTimeField18.roundHalfCeiling((long) 4);
        try {
            long long25 = offsetDateTimeField18.set(0L, "hi!");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200000L) + "'", long22 == (-259200000L));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((-259200000L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-259200000) + "'", int1 == (-259200000));
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str7 = localDate5.toString(dateTimeFormatter6);
//        org.joda.time.LocalDate localDate9 = localDate5.withWeekOfWeekyear(19);
//        org.joda.time.LocalDate localDate11 = localDate9.withWeekyear((int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.LocalDate localDate14 = localDate9.withPeriodAdded(readablePeriod12, (int) '#');
//        int[] intArray16 = buddhistChronology2.get((org.joda.time.ReadablePartial) localDate14, (long) 20);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019166" + "'", str7.equals("2019166"));
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(intArray16);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
        java.util.Date date14 = localDate13.toDate();
        int int15 = localDate13.getCenturyOfEra();
        org.joda.time.LocalDate.Property property16 = localDate13.weekyear();
        int[] intArray21 = new int[] { 'a', 2000, (byte) 0 };
        try {
            int[] intArray23 = delegatedDateTimeField5.set((org.joda.time.ReadablePartial) localDate13, 20, intArray21, 24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 20 + "'", int15 == 20);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forID("UTC");
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) gJChronology1, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GJChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime10 = null;
        try {
            org.joda.time.LocalDateTime localDateTime11 = localDate9.toLocalDateTime(localTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.yearOfCentury();
        org.joda.time.LocalDate localDate3 = property2.roundHalfFloorCopy();
        java.util.Locale locale4 = null;
        int int5 = property2.getMaximumShortTextLength(locale4);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
//        java.util.Locale locale9 = null;
//        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
//        java.util.Locale locale19 = null;
//        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
//        long long22 = offsetDateTimeField18.roundHalfCeiling((long) 4);
//        org.joda.time.DurationField durationField23 = offsetDateTimeField18.getLeapDurationField();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.LocalDate localDate26 = dateTime25.toLocalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str28 = localDate26.toString(dateTimeFormatter27);
//        int[] intArray33 = new int[] { 970, 53, (short) 1 };
//        try {
//            int[] intArray35 = offsetDateTimeField18.set((org.joda.time.ReadablePartial) localDate26, (int) (byte) -1, intArray33, (int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200000L) + "'", long22 == (-259200000L));
//        org.junit.Assert.assertNull(durationField23);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019166" + "'", str28.equals("2019166"));
//        org.junit.Assert.assertNotNull(intArray33);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
//        java.util.Locale locale9 = null;
//        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
//        java.util.Date date14 = localDate13.toDate();
//        int int15 = localDate13.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property16 = localDate13.weekyear();
//        org.joda.time.LocalDate localDate17 = property16.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology18 = localDate17.getChronology();
//        org.joda.time.LocalDate localDate20 = localDate17.withYear((int) (short) 10);
//        org.joda.time.LocalTime localTime21 = null;
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology22.getZone();
//        org.joda.time.DateTime dateTime24 = localDate20.toDateTime(localTime21, dateTimeZone23);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        org.joda.time.DateTime dateTime29 = dateTime27.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property30 = dateTime29.monthOfYear();
//        org.joda.time.DateTime dateTime32 = dateTime29.minusMonths(0);
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj34 = null;
//        boolean boolean35 = gJChronology33.equals(obj34);
//        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology33);
//        org.joda.time.DateTimeField dateTimeField37 = gJChronology33.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37);
//        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate();
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = delegatedDateTimeField38.getAsText((org.joda.time.ReadablePartial) localDate39, locale40);
//        int int42 = delegatedDateTimeField38.getMaximumValue();
//        int int43 = dateTime32.get((org.joda.time.DateTimeField) delegatedDateTimeField38);
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone44);
//        org.joda.time.LocalDate localDate46 = dateTime45.toLocalDate();
//        org.joda.time.LocalDate localDate48 = localDate46.withYearOfCentury((int) (short) 10);
//        int[] intArray54 = new int[] { 1, (short) 1, ' ', 9, 9 };
//        int int55 = delegatedDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate48, intArray54);
//        java.util.Locale locale57 = null;
//        try {
//            int[] intArray58 = delegatedDateTimeField5.set((org.joda.time.ReadablePartial) localDate20, (int) (short) 100, intArray54, "June", locale57);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"June\" for weekOfWeekyear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 20 + "'", int15 == 20);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "24" + "'", str41.equals("24"));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 53 + "'", int42 == 53);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 24 + "'", int43 == 24);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertNotNull(localDate48);
//        org.junit.Assert.assertNotNull(intArray54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 53 + "'", int55 == 53);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        java.lang.Appendable appendable3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DurationField durationField6 = gJChronology4.minutes();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime15 = dateTime14.toLocalDateTime();
        org.joda.time.LocalDateTime localDateTime16 = dateTime14.toLocalDateTime();
        int int17 = skipUndoDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDateTime16);
        try {
            dateTimeFormatter2.printTo(appendable3, (org.joda.time.ReadablePartial) localDateTime16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertNotNull(localDateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfSecond();
//        try {
//            org.joda.time.DateTime dateTime7 = dateTime1.withTime(12, 10, 100, 12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 381 + "'", int2 == 381);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.append(dateTimeParser3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (-259200000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate6, locale7);
//        java.lang.String str9 = delegatedDateTimeField5.toString();
//        long long11 = delegatedDateTimeField5.roundHalfFloor((long) 12);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        org.joda.time.LocalDate localDate14 = dateTime13.toLocalDate();
//        java.util.Date date15 = localDate14.toDate();
//        int int16 = localDate14.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property17 = localDate14.weekyear();
//        org.joda.time.LocalDate localDate18 = property17.roundHalfCeilingCopy();
//        org.joda.time.LocalDate localDate19 = property17.roundCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
//        org.joda.time.DateTime dateTime24 = dateTime22.withMinuteOfHour((int) '4');
//        org.joda.time.DateTime.Property property25 = dateTime24.monthOfYear();
//        org.joda.time.DateTime dateTime27 = dateTime24.minusMonths(0);
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj29 = null;
//        boolean boolean30 = gJChronology28.equals(obj29);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology28);
//        org.joda.time.DateTimeField dateTimeField32 = gJChronology28.weekOfWeekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32);
//        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate();
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = delegatedDateTimeField33.getAsText((org.joda.time.ReadablePartial) localDate34, locale35);
//        int int37 = delegatedDateTimeField33.getMaximumValue();
//        int int38 = dateTime27.get((org.joda.time.DateTimeField) delegatedDateTimeField33);
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(dateTimeZone39);
//        org.joda.time.LocalDate localDate41 = dateTime40.toLocalDate();
//        org.joda.time.LocalDate localDate43 = localDate41.withYearOfCentury((int) (short) 10);
//        int[] intArray49 = new int[] { 1, (short) 1, ' ', 9, 9 };
//        int int50 = delegatedDateTimeField33.getMaximumValue((org.joda.time.ReadablePartial) localDate43, intArray49);
//        try {
//            int[] intArray52 = delegatedDateTimeField5.add((org.joda.time.ReadablePartial) localDate19, 3, intArray49, 19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "24" + "'", str8.equals("24"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str9.equals("DateTimeField[weekOfWeekyear]"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 20 + "'", int16 == 20);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "24" + "'", str36.equals("24"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 53 + "'", int37 == 53);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 24 + "'", int38 == 24);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(intArray49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 53 + "'", int50 == 53);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        boolean boolean2 = dateTimeFormatter0.isParser();
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DurationField durationField6 = gJChronology4.minutes();
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = partial7.getFormatter();
        java.lang.String str9 = partial7.toString();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology10);
        org.joda.time.DurationField durationField12 = gJChronology10.minutes();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.yearOfCentury();
        org.joda.time.Partial partial14 = partial7.withChronologyRetainFields((org.joda.time.Chronology) gJChronology10);
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadablePartial) partial14);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimePrinter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[]" + "'", str9.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(partial14);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(345600000L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DurationField durationField5 = gJChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
        int int16 = skipUndoDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) localDateTime15);
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadablePartial) localDateTime15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDateTime14);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
        int int10 = localDate9.getCenturyOfEra();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        java.util.Date date5 = localDate4.toDate();
        int int6 = localDate4.getCenturyOfEra();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
        boolean boolean8 = localDate4.isAfter((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval10 = localDate7.toInterval(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology1, dateTimeZone9);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj13 = null;
        boolean boolean14 = gJChronology12.equals(obj13);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology12);
        org.joda.time.Chronology chronology16 = dateTime15.getChronology();
        org.joda.time.Chronology chronology17 = dateTime15.getChronology();
        org.joda.time.DateTime.Property property18 = dateTime15.secondOfMinute();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime15.minus(readablePeriod19);
        try {
            org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) dateTime20, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(interval10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate6, locale7);
        java.lang.String str9 = delegatedDateTimeField5.toString();
        long long11 = delegatedDateTimeField5.roundHalfFloor((long) 12);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.LocalDate localDate14 = dateTime13.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str16 = localDate14.toString(dateTimeFormatter15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate19 = localDate14.withPeriodAdded(readablePeriod17, (int) (byte) 100);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate19, locale20);
        try {
            org.joda.time.LocalDate localDate23 = localDate19.withDayOfYear((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str9.equals("DateTimeField[weekOfWeekyear]"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970004" + "'", str16.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        boolean boolean4 = dateTime1.isAfter(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(563, (int) 'a', 0, 9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.withYear((int) ' ');
        org.joda.time.DateTime.Property property4 = dateTime1.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = partial3.getChronology();
        int[] intArray5 = partial3.getValues();
        java.util.Locale locale7 = null;
        try {
            java.lang.String str8 = partial3.toString("hi!", locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        try {
            org.joda.time.DateTime dateTime3 = dateTime1.withDayOfYear(784);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 784 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (short) 1);
        try {
            org.joda.time.DateTime dateTime4 = dateTime0.withDayOfWeek(84032);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 84032 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
        java.util.Locale locale19 = null;
        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str25 = localDate23.toString(dateTimeFormatter24);
        org.joda.time.LocalDate localDate27 = localDate23.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate29 = localDate27.withWeekyear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate32 = localDate27.withPeriodAdded(readablePeriod30, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property38 = dateTime37.monthOfYear();
        org.joda.time.DateTime dateTime40 = dateTime37.minusMonths(0);
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj42 = null;
        boolean boolean43 = gJChronology41.equals(obj42);
        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology41);
        org.joda.time.DateTimeField dateTimeField45 = gJChronology41.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField45);
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate();
        java.util.Locale locale48 = null;
        java.lang.String str49 = delegatedDateTimeField46.getAsText((org.joda.time.ReadablePartial) localDate47, locale48);
        int int50 = delegatedDateTimeField46.getMaximumValue();
        int int51 = dateTime40.get((org.joda.time.DateTimeField) delegatedDateTimeField46);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.LocalDate localDate54 = dateTime53.toLocalDate();
        org.joda.time.LocalDate localDate56 = localDate54.withYearOfCentury((int) (short) 10);
        int[] intArray62 = new int[] { 1, (short) 1, ' ', 9, 9 };
        int int63 = delegatedDateTimeField46.getMaximumValue((org.joda.time.ReadablePartial) localDate56, intArray62);
        try {
            int[] intArray65 = offsetDateTimeField18.add((org.joda.time.ReadablePartial) localDate27, 100, intArray62, (-11));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970004" + "'", str25.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1" + "'", str49.equals("1"));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 53 + "'", int50 == 53);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 53 + "'", int63 == 53);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial3.minus(readablePeriod4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        int int8 = dateTime7.getMillisOfSecond();
        org.joda.time.DateTime dateTime9 = partial3.toDateTime((org.joda.time.ReadableInstant) dateTime7);
        try {
            org.joda.time.DateTimeField dateTimeField11 = partial3.getField(4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(partial5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = partial3.getChronology();
        int[] intArray5 = partial3.getValues();
        java.lang.String str6 = partial3.toStringList();
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType8 = partial3.getFieldType(0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj6 = null;
        boolean boolean7 = gJChronology5.equals(obj6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology5.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        int int13 = delegatedDateTimeField10.getDifference((long) 19, (long) 19);
        java.util.Locale locale14 = null;
        int int15 = delegatedDateTimeField10.getMaximumShortTextLength(locale14);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property20 = dateTime19.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField10, dateTimeFieldType21, 2);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType21, (int) (byte) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.secondOfMinute();
        try {
            long long11 = julianChronology0.getDateTimeMillis(0, (int) (short) 0, 20, (-259200000), 84032, 12, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -259200000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) '#');
        boolean boolean4 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        java.lang.String str5 = partial3.toString();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.yearOfCentury();
        org.joda.time.Partial partial10 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology6);
        int[] intArray11 = partial10.getValues();
        java.util.Locale locale13 = null;
        try {
            java.lang.String str14 = partial10.toString("1970-W01-3", locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: W");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) -1, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime7 = property4.setCopy(6);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(0);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj8 = null;
        boolean boolean9 = gJChronology7.equals(obj8);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology7);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology7.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate();
        java.util.Locale locale14 = null;
        java.lang.String str15 = delegatedDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate13, locale14);
        int int16 = delegatedDateTimeField12.getMaximumValue();
        int int17 = dateTime6.get((org.joda.time.DateTimeField) delegatedDateTimeField12);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property20 = localDate19.yearOfCentury();
        org.joda.time.LocalDate localDate21 = property20.roundHalfFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology22);
        org.joda.time.DurationField durationField24 = gJChronology22.minutes();
        org.joda.time.Partial partial25 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology22);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = partial25.getFormatter();
        java.lang.String str27 = partial25.toString();
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology28);
        org.joda.time.DurationField durationField30 = gJChronology28.minutes();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology28.yearOfCentury();
        org.joda.time.Partial partial32 = partial25.withChronologyRetainFields((org.joda.time.Chronology) gJChronology28);
        int[] intArray33 = partial32.getValues();
        try {
            int int34 = delegatedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDate21, intArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNull(dateTimeFormatter26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "[]" + "'", str27.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(partial32);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(2019, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "1");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 1, 18);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 18L + "'", long2 == 18L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (short) 1);
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = dateTime2.toCalendar(locale3);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.withDurationAdded(readableDuration5, 100);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(calendar4);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 2000, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1998L + "'", long2 == 1998L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, 69);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.lang.String str9 = delegatedDateTimeField5.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str9.equals("DateTimeField[weekOfWeekyear]"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        int int6 = property4.getMaximumValue();
        java.lang.Class<?> wildcardClass7 = property4.getClass();
        org.joda.time.DateTime dateTime8 = property4.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("2019-W29-4");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-W29-4\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 4);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.yearOfCentury();
        org.joda.time.LocalDate localDate3 = property2.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate4 = property2.roundCeilingCopy();
        try {
            org.joda.time.LocalDate localDate6 = localDate4.withWeekOfWeekyear(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter3.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.Instant instant2 = new org.joda.time.Instant(0L);
        org.joda.time.MutableDateTime mutableDateTime3 = instant2.toMutableDateTimeISO();
        int int6 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "52", 2019);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2020) + "'", int6 == (-2020));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
        org.joda.time.LocalTime localTime9 = null;
        try {
            org.joda.time.LocalDateTime localDateTime10 = localDate8.toLocalDateTime(localTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.Chronology chronology5 = dateTime3.getChronology();
        org.joda.time.DateTime.Property property6 = dateTime3.secondOfMinute();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        int int8 = dateTime7.getMinuteOfHour();
        int int9 = dateTime7.getSecondOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.DateTime dateTime6 = dateTime3.minusYears((int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfEra(69);
        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        boolean boolean4 = iSOChronology1.equals((java.lang.Object) 10.0d);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology6 = iSOChronology1.withZone(dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        try {
            int[] intArray9 = iSOChronology1.get(readablePeriod7, (long) 26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField3 = gJChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property14 = dateTime13.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
        boolean boolean16 = dateTime7.isSupported(dateTimeFieldType15);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField3, dateTimeFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(20, 19, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime6.minusWeeks((int) (byte) 10);
        int int9 = dateTime6.getYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.weeks();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            long long8 = gJChronology0.getDateTimeMillis((int) (short) 0, (-2020), 4, 57600, 0, (-1), (-259200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = partial3.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = partial3.getFormatter();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNull(dateTimeFormatter5);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) -1, (long) 53);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-54L) + "'", long2 == (-54L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.DateTime dateTime6 = dateTime3.plusHours(57600);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) 57600, (org.joda.time.Chronology) julianChronology7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(julianChronology7);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 100);
        org.joda.time.DateMidnight dateMidnight2 = dateTime1.toDateMidnight();
        java.util.Date date3 = dateMidnight2.toDate();
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property5 = localDate4.yearOfCentury();
        org.joda.time.LocalDate localDate6 = property5.roundHalfFloorCopy();
        int int7 = property5.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField8 = property5.getField();
        org.joda.time.LocalDate localDate9 = property5.roundFloorCopy();
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadablePartial) localDate9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.io.Writer writer2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMinuteOfHour((int) '4');
        org.joda.time.DateMidnight dateMidnight7 = dateTime4.toDateMidnight();
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) dateMidnight7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateMidnight7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTime(localTime10, dateTimeZone12);
        org.joda.time.LocalTime localTime14 = null;
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology15.getZone();
        org.joda.time.DateTime dateTime17 = localDate9.toDateTime(localTime14, dateTimeZone16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(iSOChronology18);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.LocalDate localDate8 = localDate6.plusMonths(26);
        try {
            org.joda.time.DateTimeField dateTimeField10 = localDate8.getField((-259200000));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: -259200000");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.ReadableInstant readableInstant0 = null;
        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 345600000L + "'", long1 == 345600000L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 365, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 365L + "'", long2 == 365L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology2 = dateTime1.getChronology();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime1.toMutableDateTime((org.joda.time.Chronology) iSOChronology4);
        long long7 = mutableDateTime6.getMillis();
        int int8 = mutableDateTime6.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 345600000L + "'", long7 == 345600000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        int int6 = property4.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 1970, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.LocalDate localDate21 = dateTime20.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str23 = localDate21.toString(dateTimeFormatter22);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.LocalDate localDate26 = localDate21.withPeriodAdded(readablePeriod24, (int) (byte) 100);
        org.joda.time.LocalDate localDate28 = localDate26.plusDays((int) (short) 10);
        int int29 = localDate28.getDayOfWeek();
        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
        org.joda.time.LocalDate localDate34 = dateTime33.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str36 = localDate34.toString(dateTimeFormatter35);
        org.joda.time.LocalDate localDate38 = localDate34.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate40 = localDate38.withWeekyear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.LocalDate localDate43 = localDate38.withPeriodAdded(readablePeriod41, (int) '#');
        int[] intArray45 = buddhistChronology31.get((org.joda.time.ReadablePartial) localDate43, (long) 20);
        java.util.Locale locale47 = null;
        try {
            int[] intArray48 = offsetDateTimeField18.set((org.joda.time.ReadablePartial) localDate28, 970, intArray45, "1970-W01-3", locale47);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970-W01-3\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1970004" + "'", str23.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertNotNull(buddhistChronology31);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1970004" + "'", str36.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(intArray45);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.DateTime dateTime6 = dateTime3.minusYears((int) (byte) 100);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.Chronology chronology5 = dateTime3.getChronology();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "1969365", "");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "3", "1969365");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str3 = illegalFieldValueException2.toString();
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.Number number5 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported"));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsShortText(locale5);
        long long7 = property4.remainder();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jan" + "'", str6.equals("Jan"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 319920000L + "'", long7 == 319920000L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DurationField durationField5 = property4.getRangeDurationField();
        try {
            long long8 = durationField5.subtract(0L, 31535999999L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -31535999999");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.Chronology chronology4 = julianChronology0.withUTC();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj6 = null;
        boolean boolean7 = gJChronology5.equals(obj6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology5.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate();
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField10.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField10.getDurationField();
        boolean boolean15 = julianChronology0.equals((java.lang.Object) delegatedDateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(3, 0, 69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter1.parseMutableDateTime("Dec");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Dec\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(0);
        org.joda.time.DateTime dateTime8 = dateTime6.withHourOfDay(19);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime6.withPeriodAdded(readablePeriod9, 2000);
        org.joda.time.DateTime dateTime13 = dateTime6.plusSeconds(9);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(784, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 794 + "'", int2 == 794);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime1.minusWeeks(24);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(784);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str9 = dateTime7.toString(dateTimeFormatter8);
        java.lang.StringBuffer stringBuffer10 = null;
        try {
            dateTimeFormatter8.printTo(stringBuffer10, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-W06-5" + "'", str9.equals("1970-W06-5"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsShortText(locale5);
        java.lang.String str7 = property4.getAsShortText();
        int int8 = property4.get();
        org.joda.time.DateTime dateTime9 = property4.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property14 = dateTime13.monthOfYear();
        org.joda.time.DateTime dateTime15 = property14.withMaximumValue();
        org.joda.time.DateTime dateTime16 = dateTime15.withEarlierOffsetAtOverlap();
        int int17 = property4.getDifference((org.joda.time.ReadableInstant) dateTime16);
        boolean boolean18 = dateTime16.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jan" + "'", str6.equals("Jan"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jan" + "'", str7.equals("Jan"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-11) + "'", int17 == (-11));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.LocalDate localDate4 = localDate2.withYearOfCentury((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str9 = localDate7.toString(dateTimeFormatter8);
        org.joda.time.LocalDate localDate11 = localDate7.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate13 = localDate11.withWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime14 = localDate13.toDateTimeAtCurrentTime();
        boolean boolean15 = localDate4.isEqual((org.joda.time.ReadablePartial) localDate13);
        try {
            org.joda.time.LocalDate localDate17 = localDate13.withYearOfCentury((-2020));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2020 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970004" + "'", str9.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
        java.util.Locale locale19 = null;
        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
        long long22 = offsetDateTimeField18.roundHalfCeiling((long) 4);
        org.joda.time.DurationField durationField23 = offsetDateTimeField18.getLeapDurationField();
        java.lang.String str25 = offsetDateTimeField18.getAsText(1546300799999L);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology26);
        org.joda.time.DurationField durationField28 = gJChronology26.minutes();
        org.joda.time.Partial partial29 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology26);
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology31);
        org.joda.time.DurationField durationField33 = gJChronology31.minutes();
        org.joda.time.Partial partial34 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = partial34.getFormatter();
        java.lang.String str36 = partial34.toString();
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology37);
        org.joda.time.DurationField durationField39 = gJChronology37.minutes();
        org.joda.time.DateTimeField dateTimeField40 = gJChronology37.yearOfCentury();
        org.joda.time.Partial partial41 = partial34.withChronologyRetainFields((org.joda.time.Chronology) gJChronology37);
        int[] intArray42 = partial41.getValues();
        try {
            int[] intArray44 = offsetDateTimeField18.set((org.joda.time.ReadablePartial) partial29, 0, intArray42, 57600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for monthOfYear must be in the range [3,55]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200000L) + "'", long22 == (-259200000L));
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "3" + "'", str25.equals("3"));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNull(dateTimeFormatter35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "[]" + "'", str36.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(partial41);
        org.junit.Assert.assertNotNull(intArray42);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        java.lang.String str5 = partial3.toString();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.yearOfCentury();
        org.joda.time.Partial partial10 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology6);
        try {
            int int12 = partial3.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(partial10);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(365, 18, (int) (short) 0, (int) (short) 100, (int) (byte) 10, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str8 = localDate6.toString(dateTimeFormatter7);
        org.joda.time.LocalDate localDate10 = localDate6.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate12 = localDate10.withWeekyear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.LocalDate localDate15 = localDate10.withPeriodAdded(readablePeriod13, (int) '#');
        int[] intArray17 = buddhistChronology3.get((org.joda.time.ReadablePartial) localDate15, (long) 20);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.Chronology chronology19 = buddhistChronology3.withZone(dateTimeZone18);
        try {
            org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(970, 0, (int) (byte) 1, (org.joda.time.Chronology) buddhistChronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970004" + "'", str8.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((-1));
        int int5 = localDate4.getMonthOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate6, locale7);
        int int9 = delegatedDateTimeField5.getMaximumValue();
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField5.getAsText((int) '4', locale11);
        long long14 = delegatedDateTimeField5.roundFloor((long) 1970);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200000L) + "'", long14 == (-259200000L));
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
//        boolean boolean7 = iSOChronology4.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology9 = iSOChronology4.withZone(dateTimeZone8);
//        java.lang.String str11 = dateTimeZone8.getName((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone8);
//        try {
//            long long18 = zonedChronology12.getDateTimeMillis(1560640820478L, 10, 0, 1969, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        try {
            long long8 = copticChronology0.getDateTimeMillis((int) '4', 970, 84032, (int) (short) 10, (-11), 2019, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -11 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(53);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime9 = dateTime8.toLocalDateTime();
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        boolean boolean17 = dateTime8.isSupported(dateTimeFieldType16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType16, 365);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology20);
        org.joda.time.DurationField durationField22 = gJChronology20.minutes();
        org.joda.time.DurationField durationField23 = gJChronology20.halfdays();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.DurationField durationField26 = iSOChronology25.weeks();
        long long29 = durationField26.subtract((long) (short) 100, 100L);
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField30 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType16, durationField23, durationField26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-60479999900L) + "'", long29 == (-60479999900L));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(0L);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.joda.time.Instant instant4 = instant1.toInstant();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj6 = null;
        boolean boolean7 = gJChronology5.equals(obj6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology5.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate();
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField10.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
        java.lang.String str14 = delegatedDateTimeField10.toString();
        long long16 = delegatedDateTimeField10.roundHalfFloor((long) 12);
        int int17 = instant4.get((org.joda.time.DateTimeField) delegatedDateTimeField10);
        long long19 = delegatedDateTimeField10.roundHalfEven((long) 794);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str14.equals("DateTimeField[weekOfWeekyear]"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200000L) + "'", long16 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200000L) + "'", long19 == (-259200000L));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "1970-W01-7");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("DateTimeField[secondOfMinute]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[secondOfMinute]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.minusMonths(10);
        try {
            org.joda.time.DateTime dateTime7 = dateTime3.withYearOfCentury(970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 970 for yearOfCentury must be in the range [1,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.DateTime dateTime6 = dateTime3.minusYears((int) (byte) 100);
        int int7 = dateTime6.getDayOfYear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
        java.util.Locale locale19 = null;
        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str25 = localDate23.toString(dateTimeFormatter24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate28 = localDate23.withPeriodAdded(readablePeriod26, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology30);
        org.joda.time.DurationField durationField32 = gJChronology30.minutes();
        org.joda.time.Partial partial33 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology30);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = partial33.getFormatter();
        java.lang.String str35 = partial33.toString();
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology36);
        org.joda.time.DurationField durationField38 = gJChronology36.minutes();
        org.joda.time.DateTimeField dateTimeField39 = gJChronology36.yearOfCentury();
        org.joda.time.Partial partial40 = partial33.withChronologyRetainFields((org.joda.time.Chronology) gJChronology36);
        int[] intArray41 = partial40.getValues();
        try {
            int[] intArray43 = offsetDateTimeField18.addWrapPartial((org.joda.time.ReadablePartial) localDate28, 0, intArray41, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970004" + "'", str25.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "[]" + "'", str35.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(partial40);
        org.junit.Assert.assertNotNull(intArray41);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
//        boolean boolean7 = iSOChronology4.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology9 = iSOChronology4.withZone(dateTimeZone8);
//        java.lang.String str11 = dateTimeZone8.getName((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone8);
//        try {
//            long long20 = zonedChronology12.getDateTimeMillis((int) (short) -1, (int) (byte) 100, 970, 3, 19, (int) (short) 100, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(0);
        org.joda.time.DateTime dateTime8 = dateTime6.withHourOfDay(19);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime6.withPeriodAdded(readablePeriod9, 2000);
        org.joda.time.DateTime dateTime13 = dateTime6.minusWeeks((int) (short) 0);
        org.joda.time.DateTime dateTime14 = dateTime6.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = partial3.getChronology();
        int[] intArray5 = partial3.getValues();
        java.lang.String str6 = partial3.toString();
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = partial3.toString("DateTimeField[weekOfWeekyear]", locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(0);
        org.joda.time.DateTime dateTime8 = dateTime3.withMillis((long) (short) -1);
        java.util.GregorianCalendar gregorianCalendar9 = dateTime8.toGregorianCalendar();
        org.joda.time.Instant instant10 = dateTime8.toInstant();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology2 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.LocalDate localDate7 = property5.roundCeilingCopy();
        org.joda.time.LocalDate localDate8 = property5.roundFloorCopy();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime5 = property4.getDateTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumShortTextLength(locale5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.monthOfYear();
        org.joda.time.DateTime dateTime13 = dateTime10.minusMonths(0);
        org.joda.time.DateTime dateTime15 = dateTime13.withHourOfDay(19);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime18 = dateTime13.withPeriodAdded(readablePeriod16, 2000);
        int int19 = property4.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = dateTime18.plusYears((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) 100, (int) (byte) -1, 1970, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((-259200000), (-11), (int) (byte) 1, 6, 24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -11 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology3.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        java.util.Date date8 = localDate7.toDate();
        int int9 = localDate7.getCenturyOfEra();
        long long11 = gJChronology3.set((org.joda.time.ReadablePartial) localDate7, (long) 20);
        try {
            org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(2, 84032, (int) (short) 1, (org.joda.time.Chronology) gJChronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 84032 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 259200020L + "'", long11 == 259200020L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendPattern("1");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendYearOfCentury((int) (byte) 10, (-2020));
        org.joda.time.format.DateTimeParser dateTimeParser13 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendOptional(dateTimeParser13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
        java.util.Date date12 = localDate11.toDate();
        int int13 = localDate11.getCenturyOfEra();
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        boolean boolean15 = localDate11.isAfter((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval17 = localDate14.toInterval(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology8, dateTimeZone16);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(19, (int) (short) 10, 53, 9, (int) (byte) -1, 53, 53, dateTimeZone16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 19 + "'", int13 == 19);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(interval17);
        org.junit.Assert.assertNotNull(zonedChronology18);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology2 = gJChronology0.withUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property6 = localDate5.yearOfCentury();
        boolean boolean7 = julianChronology0.equals((java.lang.Object) property6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology0);
        try {
            long long13 = julianChronology0.getDateTimeMillis(10, 69, 18, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        boolean boolean3 = dateTime0.isBefore((long) 53);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property14 = dateTime13.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
        boolean boolean16 = dateTime7.isSupported(dateTimeFieldType15);
        try {
            org.joda.time.DateTime dateTime18 = dateTime0.withField(dateTimeFieldType15, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        int int3 = dateTime1.getYearOfCentury();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 70 + "'", int3 == 70);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime1.withYearOfEra((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter6.withOffsetParsed();
        java.lang.String str8 = dateTime1.toString(dateTimeFormatter6);
        org.joda.time.DateTime dateTime10 = dateTime1.minusHours((int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-W01-7" + "'", str8.equals("1970-W01-7"));
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
        org.joda.time.LocalDate.Property property10 = localDate6.weekOfWeekyear();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsShortText(locale11);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property6 = localDate5.yearOfCentury();
        boolean boolean7 = julianChronology0.equals((java.lang.Object) property6);
        org.joda.time.LocalDate localDate9 = property6.addToCopy((int) '4');
        org.joda.time.LocalDate localDate10 = property6.roundFloorCopy();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate10);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "Jan", 12, 970);
        int int6 = fixedDateTimeZone4.getStandardOffset(1998L);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 970 + "'", int6 == 970);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.DurationField durationField9 = iSOChronology8.weeks();
//        boolean boolean11 = iSOChronology8.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology13 = iSOChronology8.withZone(dateTimeZone12);
//        java.lang.String str15 = dateTimeZone12.getName((long) (short) 10);
//        try {
//            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((-11), 5, 5, (int) (byte) 10, 5, 52, (int) (short) -1, dateTimeZone12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate2.plus(readablePeriod5);
        try {
            org.joda.time.LocalDate localDate8 = localDate2.withDayOfWeek(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withMonthOfYear(26);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 26 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTime(localTime10, dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime13.withMillis(0L);
        org.joda.time.DateTime dateTime17 = dateTime13.withMillis(1998L);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property6 = localDate5.yearOfCentury();
        boolean boolean7 = julianChronology0.equals((java.lang.Object) property6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = julianChronology0.add(readablePeriod8, 18L, 3);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 18L + "'", long11 == 18L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsShortText(locale5);
        java.lang.String str7 = property4.getAsShortText();
        int int8 = property4.get();
        org.joda.time.DateTime dateTime9 = property4.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property14 = dateTime13.monthOfYear();
        org.joda.time.DateTime dateTime15 = property14.withMaximumValue();
        org.joda.time.DateTime dateTime16 = dateTime15.withEarlierOffsetAtOverlap();
        int int17 = property4.getDifference((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime18 = dateTime16.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jan" + "'", str6.equals("Jan"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jan" + "'", str7.equals("Jan"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-11) + "'", int17 == (-11));
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        java.util.Date date5 = localDate4.toDate();
        int int6 = localDate4.getCenturyOfEra();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
        boolean boolean8 = localDate4.isAfter((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval10 = localDate7.toInterval(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology1, dateTimeZone9);
        try {
            long long16 = zonedChronology11.getDateTimeMillis(12, 60720, 2, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 60720 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(interval10);
        org.junit.Assert.assertNotNull(zonedChronology11);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(53);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime9 = dateTime8.toLocalDateTime();
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        boolean boolean17 = dateTime8.isSupported(dateTimeFieldType16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType16, 365);
        try {
            org.joda.time.Partial partial21 = new org.joda.time.Partial(dateTimeFieldType16, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsShortText(locale5);
        java.lang.String str7 = property4.getAsShortText();
        int int8 = property4.get();
        org.joda.time.DateTime dateTime9 = property4.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property14 = dateTime13.monthOfYear();
        org.joda.time.DateTime dateTime15 = property14.withMaximumValue();
        org.joda.time.DateTime dateTime16 = dateTime15.withEarlierOffsetAtOverlap();
        int int17 = property4.getDifference((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        java.util.GregorianCalendar gregorianCalendar20 = dateTime19.toGregorianCalendar();
        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime();
        int int22 = property4.compareTo((org.joda.time.ReadableInstant) dateTime19);
        try {
            org.joda.time.DateTime dateTime24 = dateTime19.withMonthOfYear(52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jan" + "'", str6.equals("Jan"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jan" + "'", str7.equals("Jan"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-11) + "'", int17 == (-11));
        org.junit.Assert.assertNotNull(gregorianCalendar20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(53);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime9 = dateTime8.toLocalDateTime();
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        boolean boolean17 = dateTime8.isSupported(dateTimeFieldType16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType16, 365);
        org.joda.time.format.DateTimePrinter dateTimePrinter20 = null;
        org.joda.time.format.DateTimeParser dateTimeParser21 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.append(dateTimePrinter20, dateTimeParser21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((-1));
        try {
            org.joda.time.LocalDate localDate6 = localDate4.withDayOfMonth((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Instant instant4 = gJChronology0.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology0.millis();
        org.joda.time.DurationField durationField6 = gJChronology0.halfdays();
        java.lang.Class<?> wildcardClass7 = gJChronology0.getClass();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property10 = dateTime9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        boolean boolean12 = dateTime3.isSupported(dateTimeFieldType11);
        org.joda.time.DateTime.Property property13 = dateTime3.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime18 = dateTime17.toLocalDateTime();
        org.joda.time.DateTime.Property property19 = dateTime17.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime21.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property24 = dateTime23.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        boolean boolean26 = dateTime17.isSupported(dateTimeFieldType25);
        org.joda.time.DateTime.Property property27 = dateTime17.millisOfDay();
        long long28 = property13.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime17);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localDateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        java.lang.String str2 = dateTimeZone1.getID();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 84032, "1969-365T��:��:��");
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime1.minusWeeks(24);
        java.util.GregorianCalendar gregorianCalendar6 = dateTime1.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Locale locale4 = null;
        try {
            java.lang.String str5 = localDate2.toString("GregorianChronology[UTC]", locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        long long7 = delegatedDateTimeField5.roundFloor((long) 100);
        try {
            long long10 = delegatedDateTimeField5.set((long) 1970, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-259200000L) + "'", long7 == (-259200000L));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(53);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime9 = dateTime8.toLocalDateTime();
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        boolean boolean17 = dateTime8.isSupported(dateTimeFieldType16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType16, 365);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, (java.lang.Number) 26, (java.lang.Number) 5, (java.lang.Number) 2440587.5000000233d);
        try {
            org.joda.time.Partial partial25 = new org.joda.time.Partial(dateTimeFieldType16, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(0L);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = instant1.toMutableDateTime();
        org.joda.time.DateTime dateTime5 = instant1.toDateTimeISO();
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        java.util.Locale locale6 = null;
        java.lang.String str7 = partial3.toString("3", locale6);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) '#');
        try {
            boolean boolean10 = partial3.isAfter((org.joda.time.ReadablePartial) localDate9);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3" + "'", str7.equals("3"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "24");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = dateTime2.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str5 = localDate3.toString(dateTimeFormatter4);
        org.joda.time.LocalDate localDate7 = localDate3.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate9 = localDate7.withWeekyear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate12 = localDate7.withPeriodAdded(readablePeriod10, (int) '#');
        int[] intArray14 = buddhistChronology0.get((org.joda.time.ReadablePartial) localDate12, (long) 20);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
        java.util.Date date18 = localDate17.toDate();
        int int19 = localDate17.getCenturyOfEra();
        org.joda.time.LocalDate.Property property20 = localDate17.weekyear();
        boolean boolean21 = buddhistChronology0.equals((java.lang.Object) localDate17);
        try {
            org.joda.time.LocalDate localDate23 = localDate17.withDayOfWeek(20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970004" + "'", str5.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(0);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj8 = null;
        boolean boolean9 = gJChronology7.equals(obj8);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology7);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology7.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate();
        java.util.Locale locale14 = null;
        java.lang.String str15 = delegatedDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate13, locale14);
        int int16 = delegatedDateTimeField12.getMaximumValue();
        int int17 = dateTime6.get((org.joda.time.DateTimeField) delegatedDateTimeField12);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        org.joda.time.LocalDate localDate20 = dateTime19.toLocalDate();
        org.joda.time.LocalDate localDate22 = localDate20.withYearOfCentury((int) (short) 10);
        int[] intArray28 = new int[] { 1, (short) 1, ' ', 9, 9 };
        int int29 = delegatedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDate22, intArray28);
        org.joda.time.ReadablePartial readablePartial30 = null;
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology32);
        org.joda.time.DurationField durationField34 = gJChronology32.minutes();
        org.joda.time.Partial partial35 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = partial35.getFormatter();
        java.lang.String str37 = partial35.toString();
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology38);
        org.joda.time.DurationField durationField40 = gJChronology38.minutes();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology38.yearOfCentury();
        org.joda.time.Partial partial42 = partial35.withChronologyRetainFields((org.joda.time.Chronology) gJChronology38);
        int[] intArray43 = partial42.getValues();
        try {
            int[] intArray45 = delegatedDateTimeField12.add(readablePartial30, (int) (byte) 0, intArray43, 794);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 53 + "'", int29 == 53);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNull(dateTimeFormatter36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "[]" + "'", str37.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(partial42);
        org.junit.Assert.assertNotNull(intArray43);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        try {
            org.joda.time.DateTime dateTime7 = dateTime3.withDate(9, 2000, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(259200020L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate11 = localDate6.withPeriodAdded(readablePeriod9, (int) '#');
        org.joda.time.LocalDate.Property property12 = localDate11.weekyear();
        org.joda.time.LocalDate localDate14 = localDate11.withEra((int) (short) 1);
        java.util.Date date15 = localDate14.toDate();
        org.joda.time.LocalDate.Property property16 = localDate14.dayOfWeek();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendPattern("1");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendYearOfCentury((int) (byte) 10, (-2020));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendFractionOfSecond(100, (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        boolean boolean4 = iSOChronology1.equals((java.lang.Object) 10.0d);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology6 = iSOChronology1.withZone(dateTimeZone5);
        long long9 = dateTimeZone5.convertLocalToUTC(0L, false);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj11 = null;
        boolean boolean12 = gJChronology10.equals(obj11);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTime dateTime14 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property15 = dateTime13.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DurationField durationField18 = iSOChronology17.days();
        org.joda.time.DurationField durationField19 = iSOChronology17.centuries();
        org.joda.time.DateTime dateTime20 = dateTime13.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.Chronology chronology21 = dateTime20.getChronology();
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.yearOfCentury();
        int int26 = gJChronology23.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology23.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) gJChronology22, (org.joda.time.Chronology) gJChronology23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GJChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime1.withYearOfEra((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter6.withOffsetParsed();
        java.lang.String str8 = dateTime1.toString(dateTimeFormatter6);
        org.joda.time.DateTime dateTime10 = dateTime1.minusSeconds((-1));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-W01-7" + "'", str8.equals("1970-W01-7"));
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 57600, 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 115200L + "'", long2 == 115200L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.yearOfCentury();
        org.joda.time.DurationField durationField4 = gJChronology0.centuries();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate.Property property8 = localDate6.yearOfEra();
        org.joda.time.LocalDate localDate9 = property8.withMaximumValue();
        try {
            org.joda.time.LocalDate localDate11 = localDate9.withDayOfWeek(24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property3 = localDate2.yearOfCentury();
        org.joda.time.LocalDate localDate4 = property3.roundHalfFloorCopy();
        int int5 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField6 = property3.getField();
        org.joda.time.LocalDate localDate7 = property3.roundFloorCopy();
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 100.0f, (java.lang.Object) property3);
        org.joda.time.DurationField durationField9 = property3.getRangeDurationField();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        long long4 = durationField1.subtract((long) ' ', (long) 2019);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-63713260799968L) + "'", long4 == (-63713260799968L));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate.Property property8 = localDate6.yearOfEra();
        org.joda.time.LocalDate.Property property9 = localDate6.year();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval8 = localDate5.toInterval(dateTimeZone7);
        int int10 = dateTimeZone7.getOffsetFromLocal((long) 12);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.year();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField3 = gJChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField6);
        int int8 = skipUndoDateTimeField7.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 10);
        java.lang.String str11 = skipUndoDateTimeField7.getName();
        java.util.Locale locale14 = null;
        try {
            long long15 = skipUndoDateTimeField7.set((-60479999900L), "Dec", locale14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Dec\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "secondOfMinute" + "'", str11.equals("secondOfMinute"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField10);
        int int12 = skipUndoDateTimeField11.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 10);
        boolean boolean15 = gregorianChronology3.equals((java.lang.Object) skipUndoDateTimeField11);
        long long18 = skipUndoDateTimeField11.set(0L, 10);
        try {
            long long21 = skipUndoDateTimeField11.set((long) 69, "hi!");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10000L + "'", long18 == 10000L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(0);
        org.joda.time.DateTime dateTime8 = dateTime6.withHourOfDay(19);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime6.withPeriodAdded(readablePeriod9, 2000);
        org.joda.time.LocalTime localTime12 = dateTime6.toLocalTime();
        org.joda.time.DateTime.Property property13 = dateTime6.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str2 = dateTimeFormatter0.print(101L);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
        java.util.Date date6 = localDate5.toDate();
        int int7 = localDate5.getCenturyOfEra();
        org.joda.time.LocalDate.Property property8 = localDate5.weekyear();
        org.joda.time.LocalDate localDate9 = property8.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology10 = localDate9.getChronology();
        org.joda.time.LocalDate localDate12 = localDate9.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology14.getZone();
        org.joda.time.DateTime dateTime16 = localDate12.toDateTime(localTime13, dateTimeZone15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withZone(dateTimeZone15);
        try {
            org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15, 84032);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 84032");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-W01-3" + "'", str2.equals("1970-W01-3"));
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (short) 1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusYears(2);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 4, 10, (-2020));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(53);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime9 = dateTime8.toLocalDateTime();
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        boolean boolean17 = dateTime8.isSupported(dateTimeFieldType16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType16, 365);
        boolean boolean20 = dateTimeFormatterBuilder19.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(0L);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.joda.time.Instant instant4 = instant1.toInstant();
        org.joda.time.DateTime dateTime5 = instant1.toDateTime();
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property8 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate9 = property8.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate10 = property8.roundCeilingCopy();
        org.joda.time.DateMidnight dateMidnight11 = localDate10.toDateMidnight();
        int[] intArray13 = new int[] {};
        try {
            int[] intArray15 = delegatedDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) localDate10, 5, intArray13, 970);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitYear((int) '4', false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str2 = dateTimeFormatter0.print(101L);
        org.joda.time.DateTime dateTime4 = dateTimeFormatter0.parseDateTime("1970-W01-7");
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-W01-3" + "'", str2.equals("1970-W01-3"));
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial3.minus(readablePeriod4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.Partial partial8 = partial3.withFieldAddWrapped(durationFieldType6, 60720);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(partial5);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute(100);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str9 = localDate7.toString(dateTimeFormatter8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970004" + "'", str9.equals("1970004"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        boolean boolean6 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        try {
            org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.parse("1969365", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969365\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumShortTextLength(locale5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.monthOfYear();
        org.joda.time.DateTime dateTime13 = dateTime10.minusMonths(0);
        org.joda.time.DateTime dateTime15 = dateTime13.withHourOfDay(19);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime18 = dateTime13.withPeriodAdded(readablePeriod16, 2000);
        int int19 = property4.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.ReadablePartial readablePartial20 = null;
        try {
            int int21 = property4.compareTo(readablePartial20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        java.lang.String str5 = partial3.toString();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.Partial partial8 = partial3.withFieldAddWrapped(durationFieldType6, (-11));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Jun", "1969-365T��:��:��", false, 784, 784);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfDay((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.days();
        org.joda.time.DurationField durationField3 = iSOChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.era();
        org.joda.time.Partial partial5 = new org.joda.time.Partial((org.joda.time.Chronology) iSOChronology1);
        try {
            long long11 = iSOChronology1.getDateTimeMillis((long) (-259200000), 3, 10, 794, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 794 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(373L, (long) 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 746 + "'", int2 == 746);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        int int3 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gJChronology0.hours();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField10);
        int int12 = skipUndoDateTimeField11.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 10);
        boolean boolean15 = gregorianChronology3.equals((java.lang.Object) skipUndoDateTimeField11);
        try {
            long long20 = gregorianChronology3.getDateTimeMillis((int) (byte) 100, 563, 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 563 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder9.toFormatter();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder9.appendShortText(dateTimeFieldType16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType16, 12, 24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj3 = null;
        boolean boolean4 = gJChronology2.equals(obj3);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.Instant instant7 = new org.joda.time.Instant(0L);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = instant7.toMutableDateTime(dateTimeZone8);
        boolean boolean10 = dateTime5.isAfter((org.joda.time.ReadableInstant) instant7);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) instant7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (short) 1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfWeek((int) (short) 1);
        org.joda.time.DateTime.Property property5 = dateTime2.centuryOfEra();
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            int int7 = property5.compareTo(readablePartial6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval8 = localDate5.toInterval(dateTimeZone7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval8);
        org.joda.time.ReadableInterval readableInterval10 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval8);
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval8);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(readableInterval10);
        org.junit.Assert.assertNotNull(readableInterval11);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField3 = gJChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField6);
        int int8 = skipUndoDateTimeField7.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 10);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipUndoDateTimeField10.getAsShortText((int) (short) 0, locale12);
        try {
            long long16 = skipUndoDateTimeField10.set((long) (short) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        int int6 = property4.getMaximumValue();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property4.getAsText(locale7);
        java.lang.String str9 = property4.getAsString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "January" + "'", str8.equals("January"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property5 = dateTime4.monthOfYear();
        org.joda.time.LocalDate localDate6 = dateTime4.toLocalDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property17 = dateTime16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType18);
        int int20 = localDate6.indexOf(dateTimeFieldType18);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType18, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime1.minusWeeks(24);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(784);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str9 = dateTime7.toString(dateTimeFormatter8);
        boolean boolean10 = dateTimeFormatter8.isParser();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-W06-5" + "'", str9.equals("1970-W06-5"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval8 = localDate5.toInterval(dateTimeZone7);
        int int10 = dateTimeZone7.getOffsetFromLocal((long) 12);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology12 = buddhistChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology11.era();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        java.lang.String str7 = delegatedDateTimeField5.getAsText((long) 784);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 31L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210864081600000L) + "'", long1 == (-210864081600000L));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime3 = property2.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(18, (-11), 4, 2000, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.fromCalendarFields((java.util.Calendar) gregorianCalendar2);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone1);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 563);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 563");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate2);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str6 = localDate4.toString(dateTimeFormatter5);
        org.joda.time.LocalDate localDate8 = localDate4.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate10 = localDate8.withWeekyear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.LocalDate localDate12 = localDate8.minus(readablePeriod11);
        int int13 = localDate12.getDayOfMonth();
        java.lang.String str14 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate12);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970004" + "'", str6.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970-05-10T��:��" + "'", str14.equals("1970-05-10T��:��"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(69);
        try {
            org.joda.time.LocalTime localTime4 = dateTimeFormatter2.parseLocalTime("1970-05-10T��:��");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970-05-10T��:��\" is malformed at \"70-05-10T��:��\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        java.lang.String str5 = partial3.toString();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.yearOfCentury();
        org.joda.time.Partial partial10 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology6);
        java.lang.String str11 = partial10.toString();
        java.lang.String str12 = partial10.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "[]" + "'", str11.equals("[]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "[]" + "'", str12.equals("[]"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        try {
            org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTime dateTime4 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime3.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = iSOChronology7.days();
        org.joda.time.DurationField durationField9 = iSOChronology7.centuries();
        org.joda.time.DateTime dateTime10 = dateTime3.withChronology((org.joda.time.Chronology) iSOChronology7);
        boolean boolean12 = dateTime10.isBefore((long) (-259200000));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField10);
        int int12 = skipUndoDateTimeField11.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 10);
        boolean boolean15 = gregorianChronology3.equals((java.lang.Object) skipUndoDateTimeField11);
        long long18 = skipUndoDateTimeField11.set(0L, 10);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property21 = localDate20.dayOfYear();
        org.joda.time.LocalDate localDate22 = property21.withMinimumValue();
        org.joda.time.DateTimeField[] dateTimeFieldArray23 = localDate22.getFields();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology25);
        org.joda.time.DurationField durationField27 = gJChronology25.minutes();
        org.joda.time.Partial partial28 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology25);
        org.joda.time.Chronology chronology29 = partial28.getChronology();
        int[] intArray30 = partial28.getValues();
        try {
            int[] intArray32 = skipUndoDateTimeField11.add((org.joda.time.ReadablePartial) localDate22, (int) (short) 1, intArray30, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10000L + "'", long18 == 10000L);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeFieldArray23);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        try {
            org.joda.time.LocalDate localDate8 = property5.setCopy("GJChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GJChronology[UTC]\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 100);
        org.joda.time.DateMidnight dateMidnight2 = dateTime1.toDateMidnight();
        int int3 = dateMidnight2.getDayOfYear();
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 365 + "'", int3 == 365);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsShortText(locale5);
        java.lang.String str7 = property4.getAsShortText();
        int int8 = property4.get();
        org.joda.time.DateTime dateTime9 = property4.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property14 = dateTime13.monthOfYear();
        org.joda.time.DateTime dateTime15 = property14.withMaximumValue();
        org.joda.time.DateTime dateTime16 = dateTime15.withEarlierOffsetAtOverlap();
        int int17 = property4.getDifference((org.joda.time.ReadableInstant) dateTime16);
        java.lang.Object obj18 = null;
        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property4, obj18);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jan" + "'", str6.equals("Jan"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jan" + "'", str7.equals("Jan"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-11) + "'", int17 == (-11));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsShortText(locale5);
        java.lang.String str7 = property4.getAsShortText();
        int int8 = property4.get();
        org.joda.time.DateTime dateTime9 = property4.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property14 = dateTime13.monthOfYear();
        org.joda.time.DateTime dateTime15 = property14.withMaximumValue();
        org.joda.time.DateTime dateTime16 = dateTime15.withEarlierOffsetAtOverlap();
        int int17 = property4.getDifference((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime19 = dateTime16.withYearOfEra(1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jan" + "'", str6.equals("Jan"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jan" + "'", str7.equals("Jan"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-11) + "'", int17 == (-11));
        org.junit.Assert.assertNotNull(dateTime19);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        java.lang.String str2 = dateTimeFormatter0.print(101L);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
//        java.util.Date date6 = localDate5.toDate();
//        int int7 = localDate5.getCenturyOfEra();
//        org.joda.time.LocalDate.Property property8 = localDate5.weekyear();
//        org.joda.time.LocalDate localDate9 = property8.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology10 = localDate9.getChronology();
//        org.joda.time.LocalDate localDate12 = localDate9.withYear((int) (short) 10);
//        org.joda.time.LocalTime localTime13 = null;
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology14.getZone();
//        org.joda.time.DateTime dateTime16 = localDate12.toDateTime(localTime13, dateTimeZone15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withZone(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        long long20 = dateTimeZone15.convertUTCToLocal((long) '4');
//        java.lang.String str22 = dateTimeZone15.getName((long) 2019);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-W01-3" + "'", str2.equals("1970-W01-3"));
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Coordinated Universal Time" + "'", str22.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsShortText(locale5);
        java.lang.String str7 = property4.getAsShortText();
        int int8 = property4.get();
        try {
            org.joda.time.DateTime dateTime10 = property4.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Jan" + "'", str6.equals("Jan"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jan" + "'", str7.equals("Jan"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        java.lang.String str5 = partial3.toString();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.yearOfCentury();
        org.joda.time.Partial partial10 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology6.millisOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateMidnight dateMidnight4 = dateTime1.toDateMidnight();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime7 = dateTime1.minusDays(794);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        java.lang.String str5 = partial3.toString();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.yearOfCentury();
        org.joda.time.Partial partial10 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology6);
        try {
            java.lang.String str12 = partial3.toString("1970-W06-5");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: W");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(partial10);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate11 = localDate6.withPeriodAdded(readablePeriod9, (int) '#');
        org.joda.time.LocalDate.Property property12 = localDate11.weekyear();
        org.joda.time.LocalDate localDate14 = localDate11.withEra((int) (short) 1);
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = localDate14.toString("DateTimeField[weekOfWeekyear]", locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property10 = dateTime9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder4.appendDayOfWeek(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        org.joda.time.DurationField durationField7 = gJChronology0.weeks();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        try {
            int[] intArray11 = gJChronology0.get(readablePeriod8, (long) 53, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.secondOfMinute();
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) julianChronology0);
        try {
            long long9 = julianChronology0.getDateTimeMillis(18, 69, (int) (byte) 0, (-259200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -259200000 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(259200020L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 259200020 + "'", int1 == 259200020);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendDayOfMonth(84032);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
        try {
            long long21 = offsetDateTimeField18.set(0L, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for monthOfYear must be in the range [3,55]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField5.getAsShortText(2000, locale12);
        java.util.Locale locale14 = null;
        int int15 = delegatedDateTimeField5.getMaximumTextLength(locale14);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2000" + "'", str13.equals("2000"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
        java.util.Date date6 = localDate5.toDate();
        int int7 = localDate5.getCenturyOfEra();
        boolean boolean8 = iSOChronology1.equals((java.lang.Object) int7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        try {
            int[] intArray12 = iSOChronology1.get(readablePeriod10, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Jun", "1969-365T��:��:��", false, 784, 784);
        org.joda.time.format.DateTimeParser dateTimeParser12 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime3.plusMillis(794);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
//        boolean boolean7 = iSOChronology4.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology9 = iSOChronology4.withZone(dateTimeZone8);
//        java.lang.String str11 = dateTimeZone8.getName((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone8);
//        org.joda.time.Chronology chronology13 = zonedChronology12.withUTC();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) zonedChronology12);
//        org.joda.time.Chronology chronology15 = zonedChronology12.withUTC();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(chronology15);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "[]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate11 = localDate6.withPeriodAdded(readablePeriod9, (int) '#');
        org.joda.time.LocalDate.Property property12 = localDate11.weekyear();
        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
        org.joda.time.LocalDate localDate14 = property12.withMaximumValue();
        try {
            org.joda.time.LocalDate localDate16 = localDate14.plusYears(4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278997 for year must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate14);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField5.getDurationField();
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField5.getAsShortText((int) 'a', locale11);
        try {
            long long15 = delegatedDateTimeField5.set((long) 259200020, "UTC");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97" + "'", str12.equals("97"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = partial3.getFormatter();
        java.lang.String str5 = partial3.toString();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.yearOfCentury();
        org.joda.time.Partial partial10 = partial3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology6);
        java.lang.String str11 = partial10.toString();
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType13 = partial10.getFieldType(4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "[]" + "'", str11.equals("[]"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        int int5 = dateTime3.getSecondOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.yearOfCentury();
        org.joda.time.DateTime dateTime8 = property6.addWrapFieldToCopy(1969);
        org.joda.time.DateTime dateTime10 = property6.addWrapFieldToCopy(0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 259200020L, 259200020);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
        java.util.Date date10 = localDate9.toDate();
        int int11 = localDate9.getCenturyOfEra();
        org.joda.time.LocalDate.Property property12 = localDate9.weekyear();
        org.joda.time.LocalDate localDate13 = property12.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology14 = localDate13.getChronology();
        org.joda.time.LocalDate localDate16 = localDate13.withCenturyOfEra(19);
        org.joda.time.LocalDate localDate17 = localDate2.withFields((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime19 = localDate2.toDateTimeAtStartOfDay(dateTimeZone18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        int int21 = localDate2.indexOf(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        int int7 = skipUndoDateTimeField6.getMinimumValue();
        int int8 = skipUndoDateTimeField6.getMinimumValue();
        long long10 = skipUndoDateTimeField6.roundHalfEven((long) 10);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime6.minusWeeks((int) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar9 = dateTime8.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "Jan", 12, 970);
        int int6 = fixedDateTimeZone4.getStandardOffset(1998L);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 970 + "'", int6 == 970);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.minus(readableDuration3);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.halfdayOfDay();
        org.joda.time.Chronology chronology4 = gJChronology0.withUTC();
        org.joda.time.DurationField durationField5 = gJChronology0.halfdays();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField3 = gJChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField6);
        int int8 = skipUndoDateTimeField7.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 10);
        java.lang.String str11 = skipUndoDateTimeField10.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.LocalDate localDate14 = dateTime13.toLocalDate();
        java.util.Date date15 = localDate14.toDate();
        int int16 = localDate14.getCenturyOfEra();
        org.joda.time.LocalDate.Property property17 = localDate14.weekyear();
        org.joda.time.LocalDate localDate18 = property17.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology19 = localDate18.getChronology();
        org.joda.time.LocalDate localDate21 = localDate18.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone24 = gJChronology23.getZone();
        org.joda.time.DateTime dateTime25 = localDate21.toDateTime(localTime22, dateTimeZone24);
        org.joda.time.LocalTime localTime26 = null;
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone28 = gJChronology27.getZone();
        org.joda.time.DateTime dateTime29 = localDate21.toDateTime(localTime26, dateTimeZone28);
        int[] intArray33 = new int[] { 18, 1 };
        java.util.Locale locale35 = null;
        try {
            int[] intArray36 = skipUndoDateTimeField10.set((org.joda.time.ReadablePartial) localDate21, 0, intArray33, "UTC", locale35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str11.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 19 + "'", int16 == 19);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        int int6 = dateTime5.getMinuteOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.minusWeeks((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
        java.util.Date date12 = localDate11.toDate();
        int int13 = localDate11.getCenturyOfEra();
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        boolean boolean15 = localDate11.isAfter((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval17 = localDate14.toInterval(dateTimeZone16);
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime8.toMutableDateTime(dateTimeZone16);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        try {
            int int20 = dateTime8.get(dateTimeFieldType19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 19 + "'", int13 == 19);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(interval17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.DateTime dateTime6 = dateTime3.minusYears((int) (byte) 100);
        org.joda.time.LocalDateTime localDateTime7 = dateTime3.toLocalDateTime();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDateTime7);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("2000", "January");
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate6, locale7);
        java.lang.String str9 = delegatedDateTimeField5.toString();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone11);
        int[] intArray17 = new int[] { 2019, 100, 69, 365 };
        int int18 = delegatedDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate12, intArray17);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology19);
        org.joda.time.DurationField durationField21 = gJChronology19.minutes();
        org.joda.time.Partial partial22 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology19);
        org.joda.time.Chronology chronology23 = partial22.getChronology();
        int[] intArray24 = partial22.getValues();
        java.lang.String str25 = partial22.toStringList();
        java.util.Locale locale26 = null;
        try {
            java.lang.String str27 = delegatedDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) partial22, locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekOfWeekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str9.equals("DateTimeField[weekOfWeekyear]"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "[]" + "'", str25.equals("[]"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.Chronology chronology5 = dateTime3.getChronology();
        org.joda.time.DateTime.Property property6 = dateTime3.secondOfMinute();
        org.joda.time.DateTime dateTime8 = property6.addWrapFieldToCopy(563);
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.yearOfCentury();
        org.joda.time.LocalDate localDate3 = property2.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate5 = property2.addToCopy((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property10 = dateTime9.monthOfYear();
        org.joda.time.DateTime dateTime12 = dateTime9.minusMonths(0);
        org.joda.time.DateTime dateTime14 = dateTime9.withMillis((long) (short) -1);
        java.util.GregorianCalendar gregorianCalendar15 = dateTime14.toGregorianCalendar();
        org.joda.time.DateTime.Property property16 = dateTime14.era();
        int int17 = property2.getDifference((org.joda.time.ReadableInstant) dateTime14);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gregorianCalendar15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        java.lang.Appendable appendable2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
        java.util.Date date6 = localDate5.toDate();
        int int7 = localDate5.getCenturyOfEra();
        org.joda.time.LocalDate.Property property8 = localDate5.weekyear();
        org.joda.time.LocalDate localDate9 = property8.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology10 = localDate9.getChronology();
        org.joda.time.LocalDate localDate12 = localDate9.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology14.getZone();
        org.joda.time.DateTime dateTime16 = localDate12.toDateTime(localTime13, dateTimeZone15);
        int int17 = localDate12.getMonthOfYear();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.LocalDate localDate20 = localDate12.withPeriodAdded(readablePeriod18, 53);
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadablePartial) localDate20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(localDate20);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        boolean boolean11 = delegatedDateTimeField5.isLenient();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 52, (java.lang.Number) 60720, (java.lang.Number) 24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime7 = dateTime5.withHourOfDay(0);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.DateTime dateTime10 = dateTime7.withZoneRetainFields(dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime7.withCenturyOfEra(57600);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = partial3.getChronology();
        java.util.Locale locale6 = null;
        try {
            java.lang.String str7 = partial3.toString("Coordinated Universal Time", locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: oo");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(0L);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.joda.time.Instant instant4 = instant1.toInstant();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj6 = null;
        boolean boolean7 = gJChronology5.equals(obj6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology5.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate();
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField10.getAsText((org.joda.time.ReadablePartial) localDate11, locale12);
        java.lang.String str14 = delegatedDateTimeField10.toString();
        long long16 = delegatedDateTimeField10.roundHalfFloor((long) 12);
        int int17 = instant4.get((org.joda.time.DateTimeField) delegatedDateTimeField10);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj19 = null;
        boolean boolean20 = gJChronology18.equals(obj19);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology18);
        org.joda.time.Instant instant22 = gJChronology18.getGregorianCutover();
        org.joda.time.DurationField durationField23 = gJChronology18.millis();
        org.joda.time.DurationField durationField24 = gJChronology18.halfdays();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField27 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField10, durationField24, dateTimeFieldType25, 84032);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str14.equals("DateTimeField[weekOfWeekyear]"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200000L) + "'", long16 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = dateTime2.toLocalDate();
        java.util.Date date4 = localDate3.toDate();
        int int5 = localDate3.getCenturyOfEra();
        org.joda.time.LocalDate.Property property6 = localDate3.weekyear();
        org.joda.time.LocalDate localDate7 = property6.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology8 = localDate7.getChronology();
        org.joda.time.LocalDate localDate10 = localDate7.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime11 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology12.getZone();
        org.joda.time.DateTime dateTime14 = localDate10.toDateTime(localTime11, dateTimeZone13);
        org.joda.time.LocalTime localTime15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTime dateTime18 = localDate10.toDateTime(localTime15, dateTimeZone17);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(1018L, dateTimeZone17);
        int int21 = dateTimeZone17.getOffsetFromLocal((long) 24);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate7 = localDate2.withPeriodAdded(readablePeriod5, (int) (byte) 100);
        org.joda.time.LocalDate.Property property8 = localDate7.weekyear();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj10 = null;
        boolean boolean11 = gJChronology9.equals(obj10);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
        org.joda.time.Chronology chronology13 = dateTime12.getChronology();
        org.joda.time.Chronology chronology14 = dateTime12.getChronology();
        org.joda.time.DateTime.Property property15 = dateTime12.secondOfMinute();
        org.joda.time.DateTime dateTime16 = property15.roundHalfCeilingCopy();
        long long17 = property15.remainder();
        org.joda.time.DateTimeField dateTimeField18 = property15.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property15.getFieldType();
        try {
            org.joda.time.LocalDate localDate21 = localDate7.withField(dateTimeFieldType19, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfMinute' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) 'a', 19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1843 + "'", int2 == 1843);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = dateTime2.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str5 = localDate3.toString(dateTimeFormatter4);
        org.joda.time.LocalDate localDate7 = localDate3.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate9 = localDate7.withWeekyear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate12 = localDate7.withPeriodAdded(readablePeriod10, (int) '#');
        int[] intArray14 = buddhistChronology0.get((org.joda.time.ReadablePartial) localDate12, (long) 20);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
        java.util.Date date18 = localDate17.toDate();
        int int19 = localDate17.getCenturyOfEra();
        org.joda.time.LocalDate.Property property20 = localDate17.weekyear();
        boolean boolean21 = buddhistChronology0.equals((java.lang.Object) localDate17);
        java.lang.String str22 = buddhistChronology0.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970004" + "'", str5.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "BuddhistChronology[UTC]" + "'", str22.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        int int6 = property4.getMaximumValue();
        int int7 = property4.getMaximumValueOverall();
        org.joda.time.DateTime dateTime9 = property4.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMinutes((int) '#');
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "1969365", "");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getShortName(locale6, "3", "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj2 = null;
        boolean boolean3 = gJChronology1.equals(obj2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField6.getAsText((org.joda.time.ReadablePartial) localDate7, locale8);
        org.joda.time.DurationField durationField10 = delegatedDateTimeField6.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime15 = dateTime14.toLocalDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property21 = dateTime20.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        boolean boolean23 = dateTime14.isSupported(dateTimeFieldType22);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, durationField10, dateTimeFieldType22, 1843);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate11 = localDate6.withPeriodAdded(readablePeriod9, (int) '#');
        org.joda.time.LocalDate.Property property12 = localDate11.weekyear();
        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
        java.util.Locale locale15 = null;
        try {
            org.joda.time.LocalDate localDate16 = property12.setCopy("BuddhistChronology[UTC]", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"BuddhistChronology[UTC]\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str3 = illegalFieldValueException2.toString();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str8 = illegalFieldValueException7.toString();
        java.lang.String str9 = illegalFieldValueException7.toString();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str14 = illegalFieldValueException13.toString();
        java.lang.String str15 = illegalFieldValueException13.toString();
        illegalFieldValueException7.addSuppressed((java.lang.Throwable) illegalFieldValueException13);
        java.lang.String str17 = illegalFieldValueException7.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported"));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported" + "'", str8.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported" + "'", str9.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported" + "'", str14.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported" + "'", str15.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported" + "'", str17.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(0L);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.joda.time.Instant instant4 = instant1.toInstant();
        org.joda.time.DateTime dateTime5 = instant1.toDateTime();
        int int6 = dateTime5.getHourOfDay();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate6, locale7);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumTextLength(locale9);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendCenturyOfEra(563, 365);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
        org.joda.time.LocalDate localDate3 = property2.withMinimumValue();
        org.joda.time.LocalDate localDate5 = property2.setCopy(10);
        java.lang.String str6 = localDate5.toString();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-01-10" + "'", str6.equals("1969-01-10"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTime(localTime10, dateTimeZone12);
        java.util.GregorianCalendar gregorianCalendar14 = dateTime13.toGregorianCalendar();
        int int15 = dateTime13.getCenturyOfEra();
        org.joda.time.DateTime.Property property16 = dateTime13.dayOfWeek();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        int int8 = delegatedDateTimeField5.getDifference((long) 19, (long) 19);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField5.getMaximumShortTextLength(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType16, 2);
        java.util.Locale locale19 = null;
        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
        long long22 = offsetDateTimeField18.roundHalfCeiling((long) 4);
        org.joda.time.DurationField durationField23 = offsetDateTimeField18.getLeapDurationField();
        try {
            long long26 = offsetDateTimeField18.set(1546300799999L, "Jan");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Jan\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200000L) + "'", long22 == (-259200000L));
        org.junit.Assert.assertNull(durationField23);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTime.Property property8 = dateTime6.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.withYear((int) ' ');
        org.joda.time.DateTime.Property property4 = dateTime1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property4.getFieldType();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property4.getAsShortText(locale6);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jan" + "'", str7.equals("Jan"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.yearOfCentury();
        org.joda.time.LocalDate localDate3 = property2.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate5 = localDate3.plusYears(0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        try {
            long long11 = gJChronology0.getDateTimeMillis((int) (short) 10, 19, 32, 26);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.lang.Integer int2 = dateTimeFormatter1.getPivotYear();
        java.lang.Integer int3 = dateTimeFormatter1.getPivotYear();
        try {
            org.joda.time.Instant instant4 = org.joda.time.Instant.parse("1969365", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969365\" is malformed at \"69365\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(int2);
        org.junit.Assert.assertNull(int3);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969365", "UTC");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(12, (int) (short) -1, 1, 0, 24, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(69);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        boolean boolean4 = dateTimeFormatter3.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        org.joda.time.Interval interval4 = localDate2.toInterval();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(interval4);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime7 = property4.roundCeilingCopy();
        int int8 = dateTime7.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(0);
        org.joda.time.DateTime dateTime8 = dateTime6.withHourOfDay(19);
        int int9 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property10 = dateTime6.era();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 60720 + "'", int9 == 60720);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime1.minusWeeks(24);
        org.joda.time.DateTime dateTime7 = dateTime1.minusMinutes(784);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime9 = localDate8.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate.Property property10 = localDate8.dayOfYear();
        org.joda.time.LocalDate localDate11 = property10.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMinuteOfHour((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.lang.String str6 = dateTime2.toString(dateTimeFormatter5);
        try {
            org.joda.time.Instant instant7 = org.joda.time.Instant.parse("1970004", dateTimeFormatter5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970004\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19700104" + "'", str6.equals("19700104"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
        org.joda.time.LocalDate localDate3 = property2.withMinimumValue();
        java.lang.String str4 = property2.getName();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "dayOfYear" + "'", str4.equals("dayOfYear"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.Instant instant4 = new org.joda.time.Instant(0L);
        org.joda.time.MutableDateTime mutableDateTime5 = instant4.toMutableDateTimeISO();
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadableInstant) mutableDateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 31L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfCentury();
        org.joda.time.DateTime dateTime6 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfEra(3);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime6.getZone();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate2);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getYearOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.minusDays(0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 12096000097L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1044883541620800000L + "'", long1 == 1044883541620800000L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(53);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime9 = dateTime8.toLocalDateTime();
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        boolean boolean17 = dateTime8.isSupported(dateTimeFieldType16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType16, 365);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) '#');
        org.joda.time.LocalDate.Property property6 = localDate5.yearOfCentury();
        boolean boolean7 = julianChronology0.equals((java.lang.Object) property6);
        org.joda.time.LocalDate localDate9 = property6.addToCopy((int) '4');
        int int10 = localDate9.size();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
        boolean boolean6 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval8 = localDate5.toInterval(dateTimeZone7);
        long long12 = dateTimeZone7.convertLocalToUTC((long) (byte) 1, false, 0L);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = gJChronology14.weekyears();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) gJChronology14);
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.minus(readableDuration17);
        int int19 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime16);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        java.util.Date date3 = localDate2.toDate();
        int int4 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology7 = localDate6.getChronology();
        org.joda.time.LocalDate localDate9 = localDate6.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTime(localTime10, dateTimeZone12);
        java.util.GregorianCalendar gregorianCalendar14 = dateTime13.toGregorianCalendar();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.minus(readableDuration15);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "Jan", 12, 970);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((-43199995L));
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(259200020L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        int int5 = property4.getMaximumValue();
        int int6 = property4.get();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
        java.util.Date date9 = localDate8.toDate();
        int int10 = localDate8.getCenturyOfEra();
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate();
        boolean boolean12 = localDate8.isAfter((org.joda.time.ReadablePartial) localDate11);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval14 = localDate11.toInterval(dateTimeZone13);
        int int16 = dateTimeZone13.getOffsetFromLocal((long) 12);
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
        org.joda.time.LocalDate localDate18 = org.joda.time.LocalDate.now(dateTimeZone13);
        int int20 = dateTimeZone13.getOffsetFromLocal(1998L);
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((int) (byte) 1, (-11), 6, 2019, 6, (int) (byte) 100, dateTimeZone13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(interval14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        java.util.Date date5 = localDate4.toDate();
        int int6 = localDate4.getCenturyOfEra();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
        boolean boolean8 = localDate4.isAfter((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval10 = localDate7.toInterval(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology1, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone9);
        try {
            org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 18");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(interval10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str5 = dateTimeFormatter3.print(101L);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
        java.util.Date date9 = localDate8.toDate();
        int int10 = localDate8.getCenturyOfEra();
        org.joda.time.LocalDate.Property property11 = localDate8.weekyear();
        org.joda.time.LocalDate localDate12 = property11.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology13 = localDate12.getChronology();
        org.joda.time.LocalDate localDate15 = localDate12.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone18 = gJChronology17.getZone();
        org.joda.time.DateTime dateTime19 = localDate15.toDateTime(localTime16, dateTimeZone18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter3.withZone(dateTimeZone18);
        org.joda.time.Chronology chronology21 = iSOChronology1.withZone(dateTimeZone18);
        org.joda.time.DurationField durationField22 = iSOChronology1.weeks();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970-W01-3" + "'", str5.equals("1970-W01-3"));
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
        org.joda.time.LocalDate localDate6 = localDate2.withWeekOfWeekyear(19);
        org.joda.time.LocalDate localDate8 = localDate6.withWeekyear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate11 = localDate6.withPeriodAdded(readablePeriod9, (int) '#');
        org.joda.time.LocalDate.Property property12 = localDate11.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
        java.util.Date date16 = localDate15.toDate();
        int int17 = localDate15.getCenturyOfEra();
        org.joda.time.LocalDate.Property property18 = localDate15.weekyear();
        org.joda.time.LocalDate localDate19 = property18.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology20 = localDate19.getChronology();
        org.joda.time.LocalDate localDate22 = localDate19.withYear((int) (short) 10);
        org.joda.time.LocalTime localTime23 = null;
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone25 = gJChronology24.getZone();
        org.joda.time.DateTime dateTime26 = localDate22.toDateTime(localTime23, dateTimeZone25);
        int int27 = property12.compareTo((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTime.Property property28 = dateTime26.minuteOfDay();
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970004" + "'", str4.equals("1970004"));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(property28);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "BuddhistChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate6, locale7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField5.getDurationField();
        long long11 = delegatedDateTimeField5.roundHalfEven((long) 20);
        int int13 = delegatedDateTimeField5.get(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateMidnight dateMidnight4 = dateTime1.toDateMidnight();
        org.joda.time.DateTime.Property property5 = dateTime1.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime1.toMutableDateTime();
        int int7 = dateTime1.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = iSOChronology4.weeks();
//        boolean boolean7 = iSOChronology4.equals((java.lang.Object) 10.0d);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology9 = iSOChronology4.withZone(dateTimeZone8);
//        java.lang.String str11 = dateTimeZone8.getName((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone8);
//        java.lang.String str13 = zonedChronology12.toString();
//        org.joda.time.DurationField durationField14 = zonedChronology12.months();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ZonedChronology[GJChronology[UTC], UTC]" + "'", str13.equals("ZonedChronology[GJChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(durationField14);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        java.lang.Appendable appendable2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
        org.joda.time.LocalDate localDate7 = localDate5.withYearOfCentury((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate5.plus(readablePeriod8);
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadablePartial) localDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("1970-W01-7");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970-W01-7\" is malformed at \"-W01-7\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.days();
        org.joda.time.DurationField durationField6 = iSOChronology4.centuries();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.era();
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) iSOChronology4);
        try {
            org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(9, 19, 2000, (org.joda.time.Chronology) iSOChronology4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.days();
        org.joda.time.DurationField durationField4 = iSOChronology2.centuries();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 84032, (org.joda.time.Chronology) iSOChronology2);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        boolean boolean10 = dateTimeFormatterBuilder8.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(0);
        org.joda.time.DateTime dateTime8 = dateTime3.withMillis((long) (short) -1);
        java.util.GregorianCalendar gregorianCalendar9 = dateTime8.toGregorianCalendar();
        org.joda.time.DateTime.Property property10 = dateTime8.era();
        org.joda.time.DateTime.Property property11 = dateTime8.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekOfWeekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate6, locale7);
        java.lang.String str9 = delegatedDateTimeField5.toString();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone11);
        int[] intArray17 = new int[] { 2019, 100, 69, 365 };
        int int18 = delegatedDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate12, intArray17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType19, 365, (int) (byte) 10, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str9.equals("DateTimeField[weekOfWeekyear]"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime();
        int int4 = dateTime1.getMinuteOfHour();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.LocalDate localDate4 = localDate2.withYearOfCentury((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate2.plus(readablePeriod5);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType8 = localDate6.getFieldType(32);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 32");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime1.minusWeeks(24);
        org.joda.time.DateTime dateTime7 = dateTime1.minusYears((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime1.plusMonths(52);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfEra((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withOffsetParsed();
        java.lang.String str18 = dateTime11.toString(dateTimeFormatter16);
        boolean boolean19 = dateTime9.equals((java.lang.Object) dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-W01-7" + "'", str18.equals("1970-W01-7"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("DateTimeField[weekOfWeekyear]");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        java.lang.Object obj4 = null;
        boolean boolean5 = jodaTimePermission1.equals(obj4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendPattern("1");
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
        org.joda.time.DateTime.Property property15 = dateTime13.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property20 = dateTime19.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
        boolean boolean22 = dateTime13.isSupported(dateTimeFieldType21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder9.appendFixedDecimal(dateTimeFieldType21, 563);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder28.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder29.appendEraText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str33 = dateTimeFormatter31.print(101L);
        org.joda.time.format.DateTimePrinter dateTimePrinter34 = dateTimeFormatter31.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder29.append(dateTimePrinter34);
        org.joda.time.format.DateTimeParser dateTimeParser36 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder24.append(dateTimePrinter34, dateTimeParser36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1970-W01-3" + "'", str33.equals("1970-W01-3"));
        org.junit.Assert.assertNotNull(dateTimePrinter34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendPattern("1");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendYearOfCentury((int) (byte) 10, (-2020));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMillisOfDay(16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField10);
        int int12 = skipUndoDateTimeField11.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField11, 10);
        boolean boolean15 = gregorianChronology3.equals((java.lang.Object) skipUndoDateTimeField11);
        boolean boolean17 = skipUndoDateTimeField11.isLeap((long) 6);
        try {
            long long20 = skipUndoDateTimeField11.set((long) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField3 = gJChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField6);
        int int8 = skipUndoDateTimeField7.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 10);
        java.lang.String str11 = skipUndoDateTimeField7.getName();
        java.util.Locale locale14 = null;
        try {
            long long15 = skipUndoDateTimeField7.set((long) 69, "", locale14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "secondOfMinute" + "'", str11.equals("secondOfMinute"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendPattern("1");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendYearOfCentury((int) (byte) 10, (-2020));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendLiteral("2019-W29-4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder17.appendPattern("1");
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime24.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime27 = dateTime26.toLocalDateTime();
        org.joda.time.DateTime.Property property28 = dateTime26.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        boolean boolean35 = dateTime26.isSupported(dateTimeFieldType34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType34, 563);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder9.appendShortText(dateTimeFieldType34);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder9.appendYearOfCentury(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localDateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((int) '4');
        org.joda.time.DateTime.Property property10 = dateTime9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        boolean boolean12 = dateTime3.isSupported(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, "DateTimeField[weekOfWeekyear]");
        org.joda.time.DurationFieldType durationFieldType15 = illegalFieldValueException14.getDurationFieldType();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(durationFieldType15);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) '4');
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.minus(readableDuration5);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekyear((int) (byte) 100);
        int int9 = dateTime8.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1012 + "'", int9 == 1012);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("2019-W29-4");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTimeZoneShortName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendClockhourOfDay((int) (byte) 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder7.appendFractionOfDay((int) (short) -1, 784);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        boolean boolean9 = julianChronology7.equals((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeField dateTimeField10 = julianChronology7.year();
        org.joda.time.Chronology chronology11 = julianChronology7.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology7.getZone();
        boolean boolean14 = dateTimeZone12.isStandardOffset((long) (byte) 1);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(52, 3, 2000, 24, (int) (short) 100, 563, 0, dateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }
}

