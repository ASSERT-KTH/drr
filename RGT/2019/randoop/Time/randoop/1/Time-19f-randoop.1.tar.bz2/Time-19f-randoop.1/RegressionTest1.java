import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.Chronology chronology10 = dateTimeFormatter9.getChronology();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.append(dateTimeFormatter9);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        org.joda.time.DateTime dateTime18 = property17.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime20 = property17.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.minuteOfHour();
        org.joda.time.DateTime dateTime22 = property21.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property21.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, dateTimeFieldType23, 9700, 77045, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder6.appendFixedDecimal(dateTimeFieldType23, 134);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder2.appendShortText(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfEra((int) '4', 23);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime3 = dateTime2.toLocalDateTime();
        int[] intArray5 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime3, 0L);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        try {
            int[] intArray9 = gregorianChronology0.get(readablePeriod7, (long) 236);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDateTime3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
//        int int8 = property7.getLeapAmount();
//        org.joda.time.DateTime dateTime10 = property7.addToCopy((-1));
//        org.joda.time.DateTime dateTime12 = property7.addToCopy((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        java.lang.String str14 = dateTime12.toString(dateTimeFormatter13);
//        java.util.Locale locale15 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter13.withLocale(locale15);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
//        java.lang.String str23 = fixedDateTimeZone21.getNameKey((long) 2360);
//        java.lang.String str24 = fixedDateTimeZone21.getID();
//        int int26 = fixedDateTimeZone21.getOffset(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter16.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone21);
//        org.joda.time.Chronology chronology28 = dateTimeFormatter16.getChronolgy();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "00:10:00.135" + "'", str14.equals("00:10:00.135"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.010" + "'", str23.equals("+00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.010" + "'", str24.equals("+00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNull(chronology28);
//    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        int int4 = property3.getMinimumValueOverall();
//        long long5 = property3.remainder();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275054) + "'", int4 == (-292275054));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 135L + "'", long5 == 135L);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateMidnight dateMidnight3 = dateTime2.toDateMidnight();
        boolean boolean5 = dateTime2.isBefore((long) 59);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        java.lang.String str3 = dateTimeZone1.toString();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
//        int int8 = dateTime7.getWeekOfWeekyear();
//        int int9 = dateTime7.getMinuteOfHour();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime11 = dateTime10.toLocalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
//        int int15 = dateTime14.getWeekOfWeekyear();
//        int int16 = dateTime14.getMinuteOfHour();
//        int int17 = dateTime14.getYear();
//        boolean boolean18 = dateTime10.isAfter((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime.Property property19 = dateTime14.year();
//        int int20 = dateTime7.compareTo((org.joda.time.ReadableInstant) dateTime14);
//        int int21 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime.Property property23 = dateTime22.year();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.010" + "'", str3.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(localDateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1970 + "'", int17 == 1970);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(property23);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime5 = dateTime4.toLocalDateTime();
        int[] intArray7 = gregorianChronology2.get((org.joda.time.ReadablePartial) localDateTime5, 0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDateTime5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
//        int int4 = dateTime3.getWeekOfWeekyear();
//        int int5 = dateTime3.getMinuteOfHour();
//        org.joda.time.DateTime dateTime7 = dateTime3.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime9 = dateTime3.minusSeconds(0);
//        org.joda.time.DateTime dateTime11 = dateTime3.withHourOfDay(22);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
//        long long17 = dateTimeZone13.convertUTCToLocal((long) 24);
//        org.joda.time.DateTime dateTime18 = dateTime11.withZone(dateTimeZone13);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(obj0, dateTimeZone13);
//        int int20 = dateTime19.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 34L + "'", long17 == 34L);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        long long23 = unsupportedDateTimeField20.add((-9350942L), (int) (byte) 1);
        try {
            int int25 = unsupportedDateTimeField20.getMinimumValue((-9350942L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 595449058L + "'", long23 == 595449058L);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getShortName((long) 1439, locale8);
//        try {
//            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(9, 67552, 77045, (int) 'a', 459, dateTimeZone6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.010" + "'", str9.equals("+00:00:00.010"));
//    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        java.lang.String str3 = dateTimeZone1.toString();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
//        int int8 = dateTime7.getWeekOfWeekyear();
//        int int9 = dateTime7.getMinuteOfHour();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime11 = dateTime10.toLocalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
//        int int15 = dateTime14.getWeekOfWeekyear();
//        int int16 = dateTime14.getMinuteOfHour();
//        int int17 = dateTime14.getYear();
//        boolean boolean18 = dateTime10.isAfter((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime.Property property19 = dateTime14.year();
//        int int20 = dateTime7.compareTo((org.joda.time.ReadableInstant) dateTime14);
//        int int21 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime23 = dateTime7.withWeekyear((int) '#');
//        org.joda.time.ReadableDuration readableDuration24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.minus(readableDuration24);
//        org.joda.time.DateTime.Property property26 = dateTime23.yearOfEra();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.010" + "'", str3.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(localDateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1970 + "'", int17 == 1970);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        java.lang.Class<?> wildcardClass2 = dateTimeFormatter0.getClass();
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minus((long) (byte) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.secondOfDay();
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTime((org.joda.time.Chronology) gregorianChronology7);
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadableInstant) dateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName((long) 1439, locale3);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
//        java.lang.String str8 = dateTimeZone6.toString();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
//        int int13 = dateTime12.getWeekOfWeekyear();
//        int int14 = dateTime12.getMinuteOfHour();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime16 = dateTime15.toLocalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        int int20 = dateTime19.getWeekOfWeekyear();
//        int int21 = dateTime19.getMinuteOfHour();
//        int int22 = dateTime19.getYear();
//        boolean boolean23 = dateTime15.isAfter((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime.Property property24 = dateTime19.year();
//        int int25 = dateTime12.compareTo((org.joda.time.ReadableInstant) dateTime19);
//        int int26 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime12);
//        long long28 = dateTimeZone1.getMillisKeepLocal(dateTimeZone6, (long) (short) 1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.010" + "'", str4.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.010" + "'", str8.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(localDateTime16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1970 + "'", int22 == 1970);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("0", 559);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder3.setStandardOffset(2019);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-9350942L), "448");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 36, (java.lang.Number) 189, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.hourOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.minuteOfDay();
        org.joda.time.DurationField durationField24 = gregorianChronology21.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now(dateTimeZone27);
        org.joda.time.TimeOfDay timeOfDay29 = dateTime28.toTimeOfDay();
        java.lang.Class<?> wildcardClass30 = timeOfDay29.getClass();
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone34);
        org.joda.time.DateTime.Property property36 = dateTime35.year();
        org.joda.time.DateTime dateTime37 = property36.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime39 = property36.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfHour();
        org.joda.time.DateTime dateTime41 = property40.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property40.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, dateTimeFieldType42, 9700, 77045, 0);
        int int47 = offsetDateTimeField46.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField48 = offsetDateTimeField46.getWrappedField();
        long long50 = offsetDateTimeField46.roundHalfCeiling((long) '4');
        org.joda.time.ReadablePartial readablePartial51 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology52.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone54 = gregorianChronology52.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology55.secondOfDay();
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime58 = dateTime57.toLocalDateTime();
        int[] intArray60 = gregorianChronology55.get((org.joda.time.ReadablePartial) localDateTime58, 0L);
        int[] intArray62 = gregorianChronology52.get((org.joda.time.ReadablePartial) localDateTime58, 14332974220L);
        int int63 = offsetDateTimeField46.getMinimumValue(readablePartial51, intArray62);
        try {
            int int64 = unsupportedDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay29, intArray62);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(timeOfDay29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 77045 + "'", int47 == 77045);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(localDateTime58);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 77045 + "'", int63 == 77045);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long11 = fixedDateTimeZone4.convertLocalToUTC(0L, false, (long) (-1));
        int int13 = fixedDateTimeZone4.getStandardOffset((long) 77046332);
        int int15 = fixedDateTimeZone4.getOffsetFromLocal(565L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 2360);
        long long8 = fixedDateTimeZone4.nextTransition(0L);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        int int11 = fixedDateTimeZone4.getOffset(0L);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 382);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 382");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property5 = dateTime4.monthOfYear();
        int int6 = dateTime4.getEra();
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(localDateTime7);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime6 = dateTime4.plusMillis(22);
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime4.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.010" + "'", str3.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(yearMonthDay7);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getShortName((-328761356905L));
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.year();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
//        int int10 = dateTime9.getWeekOfWeekyear();
//        int int11 = dateTime9.getMinuteOfHour();
//        int int12 = property6.getDifference((org.joda.time.ReadableInstant) dateTime9);
//        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) int12);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology0.centuryOfEra();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.Chronology chronology18 = gregorianChronology0.withZone(dateTimeZone17);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(chronology18);
//    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        int int3 = dateTime2.getWeekOfWeekyear();
//        int int4 = dateTime2.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.hourOfDay();
//        int int11 = dateTime8.get(dateTimeField10);
//        org.joda.time.DateTime dateTime13 = dateTime8.withMillis((long) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology14.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.secondOfDay();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime20 = dateTime19.toLocalDateTime();
//        int[] intArray22 = gregorianChronology17.get((org.joda.time.ReadablePartial) localDateTime20, 0L);
//        int[] intArray24 = gregorianChronology14.get((org.joda.time.ReadablePartial) localDateTime20, 14332974220L);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology14.year();
//        org.joda.time.DateTime dateTime26 = dateTime8.toDateTime((org.joda.time.Chronology) gregorianChronology14);
//        boolean boolean27 = dateTime26.isBeforeNow();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(localDateTime20);
//        org.junit.Assert.assertNotNull(intArray22);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField3 = gregorianChronology0.eras();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfCentury(0);
        org.joda.time.DateTime dateTime5 = dateTime3.withYearOfEra((int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.plusDays(166);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.Locale locale5 = null;
        java.lang.String str6 = cachedDateTimeZone3.getName((long) '#', locale5);
        java.lang.String str8 = cachedDateTimeZone3.getNameKey((long) 77046332);
        int int10 = cachedDateTimeZone3.getOffset((long) '4');
        long long13 = cachedDateTimeZone3.convertLocalToUTC((long) 77046338, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 77046328L + "'", long13 == 77046328L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        int int16 = offsetDateTimeField15.getMinimumValue();
        long long18 = offsetDateTimeField15.roundHalfCeiling(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone22);
        org.joda.time.DateTime.Property property24 = dateTime23.year();
        org.joda.time.DateTime dateTime25 = property24.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime27 = property24.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property28 = dateTime27.minuteOfHour();
        org.joda.time.DateTime dateTime29 = property28.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property28.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, dateTimeFieldType30, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.hourOfDay();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology35.minuteOfDay();
        org.joda.time.DurationField durationField38 = gregorianChronology35.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType30, durationField38);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.hourOfDay();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.minuteOfDay();
        org.joda.time.DurationField durationField43 = gregorianChronology40.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType30, durationField43);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField45 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, dateTimeFieldType30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        int int3 = dateTime2.getWeekOfWeekyear();
//        int int4 = dateTime2.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
//        org.joda.time.DateTime dateTime10 = dateTime2.withHourOfDay(22);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
//        long long16 = dateTimeZone12.convertUTCToLocal((long) 24);
//        org.joda.time.DateTime dateTime17 = dateTime10.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property18 = dateTime10.dayOfYear();
//        org.joda.time.DateTime.Property property19 = dateTime10.weekOfWeekyear();
//        org.joda.time.DateTime.Property property20 = dateTime10.yearOfEra();
//        org.joda.time.DateTime dateTime22 = property20.setCopy(1283);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone24);
//        org.joda.time.TimeOfDay timeOfDay26 = dateTime25.toTimeOfDay();
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.DateTime dateTime29 = dateTime25.withDurationAdded(readableDuration27, (int) (short) 1);
//        org.joda.time.DateTime dateTime31 = dateTime25.minusYears(9);
//        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime22, (org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime34 = dateTime22.plusSeconds(649);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 34L + "'", long16 == 34L);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(timeOfDay26);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(dateTime34);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfDay();
        org.joda.time.DateTime dateTime9 = property8.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime10 = property8.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        java.util.Locale locale16 = null;
        java.lang.String str17 = cachedDateTimeZone14.getName((long) '#', locale16);
        long long19 = cachedDateTimeZone14.previousTransition(331L);
        org.joda.time.DateTimeZone dateTimeZone20 = cachedDateTimeZone14.getUncachedZone();
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) property8, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.010" + "'", str17.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 331L + "'", long19 == 331L);
        org.junit.Assert.assertNotNull(dateTimeZone20);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.hourOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.minuteOfDay();
        org.joda.time.DurationField durationField24 = gregorianChronology21.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
        try {
            long long28 = unsupportedDateTimeField25.set((long) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("GregorianChronology[+00:00:00.010]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"GregorianChronology[+00:00:00.010]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str5 = iSOChronology4.toString();
        org.joda.time.DurationField durationField6 = iSOChronology4.millis();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[+00:00:00.010]" + "'", str5.equals("ISOChronology[+00:00:00.010]"));
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.hourOfHalfday();
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 77047148);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 77047148");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
//        int int8 = property7.getLeapAmount();
//        org.joda.time.DateTime dateTime10 = property7.addToCopy((-1));
//        org.joda.time.DateTime dateTime12 = property7.addToCopy((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        java.lang.String str14 = dateTime12.toString(dateTimeFormatter13);
//        java.lang.StringBuffer stringBuffer15 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        int int19 = dateTime18.getWeekOfWeekyear();
//        int int20 = dateTime18.getMinuteOfHour();
//        org.joda.time.DateTime dateTime22 = dateTime18.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime24 = dateTime18.minusSeconds(0);
//        org.joda.time.DateTime dateTime26 = dateTime18.withHourOfDay(22);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone30 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone28);
//        long long32 = dateTimeZone28.convertUTCToLocal((long) 24);
//        org.joda.time.DateTime dateTime33 = dateTime26.withZone(dateTimeZone28);
//        org.joda.time.DateTime.Property property34 = dateTime26.dayOfYear();
//        org.joda.time.DateTime.Property property35 = dateTime26.millisOfSecond();
//        org.joda.time.DateTime.Property property36 = dateTime26.yearOfCentury();
//        try {
//            dateTimeFormatter13.printTo(stringBuffer15, (org.joda.time.ReadableInstant) dateTime26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "00:10:00.135" + "'", str14.equals("00:10:00.135"));
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 34L + "'", long32 == 34L);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(property36);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("GregorianChronology[+00:00:00.010]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[+00:00:00.010]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        int int16 = offsetDateTimeField15.getMinimumValue();
        long long18 = offsetDateTimeField15.roundHalfCeiling(0L);
        java.lang.String str19 = offsetDateTimeField15.toString();
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField15.getAsShortText((-128044800000L), locale21);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str19.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9700" + "'", str22.equals("9700"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(459, 1284, 77045, 1283);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.Locale locale5 = null;
        java.lang.String str6 = cachedDateTimeZone3.getName((long) '#', locale5);
        int int8 = cachedDateTimeZone3.getStandardOffset((long) 2019);
        int int10 = cachedDateTimeZone3.getOffset((long) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getLeapDurationField();
        java.util.Locale locale23 = null;
        try {
            java.lang.String str24 = unsupportedDateTimeField20.getAsShortText(24L, locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNull(durationField21);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.year();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getWeekOfWeekyear();
//        int int17 = dateTime15.getMinuteOfHour();
//        int int18 = property12.getDifference((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
//        org.joda.time.DateTime.Property property22 = dateTime21.year();
//        org.joda.time.DateTime dateTime23 = property22.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime25 = property22.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property26 = dateTime25.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateMidnight dateMidnight30 = dateTime29.toDateMidnight();
//        boolean boolean31 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime29);
//        long long32 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime25);
//        boolean boolean33 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.ReadableDuration readableDuration34 = null;
//        org.joda.time.DateTime dateTime36 = dateTime25.withDurationAdded(readableDuration34, (int) (short) 100);
//        org.joda.time.DateTime.Property property37 = dateTime36.weekyear();
//        java.lang.Object obj38 = null;
//        boolean boolean39 = property37.equals(obj38);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateMidnight30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
//        int int4 = dateTime2.getMillisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusYears(0);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime2.plus(readablePeriod7);
//        org.joda.time.DateTime dateTime10 = dateTime2.plusMonths(4);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 135 + "'", int4 == 135);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        int int3 = dateTime2.getWeekOfWeekyear();
//        int int4 = dateTime2.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
//        org.joda.time.DateTime dateTime10 = dateTime2.withDayOfMonth((int) (short) 1);
//        org.joda.time.DateTime.Property property11 = dateTime2.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology(chronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfEra(10, 236);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral("18:55:52.592");
        boolean boolean12 = dateTimeFormatterBuilder11.canBuildParser();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.clockhourOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendLiteral('a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.Chronology chronology22 = dateTimeFormatter21.getChronology();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder18.append(dateTimeFormatter21);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now(dateTimeZone27);
        org.joda.time.DateTime.Property property29 = dateTime28.year();
        org.joda.time.DateTime dateTime30 = property29.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime32 = property29.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property33 = dateTime32.minuteOfHour();
        org.joda.time.DateTime dateTime34 = property33.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, dateTimeFieldType35, 9700, 77045, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder18.appendFixedDecimal(dateTimeFieldType35, 134);
        org.joda.time.IllegalFieldValueException illegalFieldValueException45 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, (java.lang.Number) 1969, (java.lang.Number) (short) 100, (java.lang.Number) 236);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, dateTimeFieldType35, (int) (byte) 100, 292278993, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder11.appendFixedDecimal(dateTimeFieldType35, 77044);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gregorianChronology0.add(readablePeriod5, (long) 565, 135);
        org.joda.time.DurationField durationField9 = gregorianChronology0.halfdays();
        try {
            long long14 = gregorianChronology0.getDateTimeMillis(341, 125, (int) (short) 10, 135);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 125 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 565L + "'", long8 == 565L);
        org.junit.Assert.assertNotNull(durationField9);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        int int3 = dateTime2.getWeekOfWeekyear();
//        int int4 = dateTime2.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        int int12 = dateTime11.getWeekOfWeekyear();
//        int int13 = dateTime11.getMinuteOfHour();
//        int int14 = dateTime11.getYear();
//        boolean boolean15 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime11);
//        boolean boolean16 = dateTime6.equals((java.lang.Object) dateTime7);
//        boolean boolean18 = dateTime7.isEqual((long) 1);
//        org.joda.time.DateTime dateTime20 = dateTime7.withHourOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property21 = dateTime7.dayOfMonth();
//        org.joda.time.Interval interval22 = property21.toInterval();
//        long long23 = property21.remainder();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1970 + "'", int14 == 1970);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(interval22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 135L + "'", long23 == 135L);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 2360);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        int int9 = fixedDateTimeZone4.getOffset(0L);
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 559, 1125);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) ' ');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("+00:00:00.010");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("+00:00:00.010");
        jodaTimePermission1.checkGuard((java.lang.Object) jodaTimePermission3);
        java.lang.String str5 = jodaTimePermission1.getActions();
        java.lang.String str6 = jodaTimePermission1.getActions();
        java.lang.Object obj7 = null;
        jodaTimePermission1.checkGuard(obj7);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.year();
        org.joda.time.DateTime dateTime13 = property12.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime15 = property12.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property16 = dateTime15.minuteOfHour();
        org.joda.time.DateTime.Property property17 = dateTime15.minuteOfDay();
        org.joda.time.DateTime dateTime18 = property17.roundHalfFloorCopy();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime18);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
//        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
//        long long23 = unsupportedDateTimeField20.add((-9350942L), (int) (byte) 1);
//        long long26 = unsupportedDateTimeField20.getDifferenceAsLong((long) (short) 1, 31742L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(dateTimeZone31);
//        org.joda.time.DateTime.Property property33 = dateTime32.year();
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now(dateTimeZone35);
//        int int37 = dateTime36.getWeekOfWeekyear();
//        int int38 = dateTime36.getMinuteOfHour();
//        int int39 = property33.getDifference((org.joda.time.ReadableInstant) dateTime36);
//        boolean boolean40 = gregorianChronology27.equals((java.lang.Object) int39);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
//        org.joda.time.TimeOfDay timeOfDay44 = dateTime43.toTimeOfDay();
//        long long46 = gregorianChronology27.set((org.joda.time.ReadablePartial) timeOfDay44, (-11L));
//        boolean boolean47 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay44);
//        java.util.Locale locale48 = null;
//        try {
//            java.lang.String str49 = unsupportedDateTimeField20.getAsText((org.joda.time.ReadablePartial) timeOfDay44, locale48);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 595449058L + "'", long23 == 595449058L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(timeOfDay44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-86399865L) + "'", long46 == (-86399865L));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        int int3 = dateTime2.getWeekOfWeekyear();
//        int int4 = dateTime2.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
//        org.joda.time.DateTime dateTime10 = dateTime2.withHourOfDay(22);
//        int int11 = dateTime10.getYearOfEra();
//        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
//        int int13 = property12.getLeapAmount();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        try {
            boolean boolean22 = unsupportedDateTimeField20.isLeap(1560633850118L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getLeapDurationField();
        boolean boolean22 = unsupportedDateTimeField20.isSupported();
        long long25 = unsupportedDateTimeField20.add((-328838400000L), 332);
        try {
            long long28 = unsupportedDateTimeField20.set((long) 2019, "0");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-128044800000L) + "'", long25 == (-128044800000L));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        int int2 = property1.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        java.util.Locale locale8 = null;
        java.lang.String str9 = cachedDateTimeZone6.getName((long) '#', locale8);
        long long12 = cachedDateTimeZone6.convertLocalToUTC((long) 341, false);
        int int14 = cachedDateTimeZone6.getStandardOffset((long) (byte) 1);
        boolean boolean16 = cachedDateTimeZone6.equals((java.lang.Object) (byte) 0);
        boolean boolean17 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property1, (java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59 + "'", int2 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.010" + "'", str9.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 331L + "'", long12 == 331L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        int int5 = dateTime4.getWeekOfWeekyear();
//        int int6 = dateTime4.getMinuteOfHour();
//        int int7 = dateTime4.getYear();
//        boolean boolean8 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property9 = dateTime4.year();
//        int int10 = property9.getMaximumValue();
//        org.joda.time.DateTime dateTime11 = property9.roundHalfCeilingCopy();
//        java.lang.String str12 = property9.getAsShortText();
//        org.junit.Assert.assertNotNull(localDateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292278993 + "'", int10 == 292278993);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970" + "'", str12.equals("1970"));
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        java.lang.String str5 = dateTimeZone1.getID();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField7 = iSOChronology6.weekyears();
        long long10 = durationField7.subtract((long) 45, 2360);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.010" + "'", str3.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.010" + "'", str5.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-74473862399955L) + "'", long10 == (-74473862399955L));
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
//        int int4 = dateTime2.getMillisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusHours(1282);
//        org.joda.time.DateTime.Property property7 = dateTime6.monthOfYear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 135 + "'", int4 == 135);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.hourOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.minuteOfDay();
        org.joda.time.DurationField durationField24 = gregorianChronology21.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
        java.util.Locale locale28 = null;
        try {
            long long29 = unsupportedDateTimeField25.set((-328761356905L), "", locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
//        int int4 = dateTime2.getMillisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusYears(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMillisOfSecond(24);
//        boolean boolean11 = dateTimeFormatterBuilder10.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendMinuteOfHour(77045);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
//        int int17 = dateTime16.getWeekOfWeekyear();
//        int int18 = dateTime16.getMinuteOfHour();
//        org.joda.time.DateTime dateTime20 = dateTime16.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime22 = dateTime16.minusSeconds(0);
//        org.joda.time.DateTime dateTime24 = dateTime16.withHourOfDay(22);
//        org.joda.time.DateTime.Property property25 = dateTime16.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property25.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType26);
//        org.joda.time.DateTime.Property property28 = dateTime6.property(dateTimeFieldType26);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) 35L, "9723");
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 135 + "'", int4 == 135);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(property28);
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
//        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getLeapDurationField();
//        boolean boolean22 = unsupportedDateTimeField20.isSupported();
//        long long25 = unsupportedDateTimeField20.add((-328838400000L), 332);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
//        org.joda.time.DateTime.Property property32 = dateTime31.year();
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone34);
//        int int36 = dateTime35.getWeekOfWeekyear();
//        int int37 = dateTime35.getMinuteOfHour();
//        int int38 = property32.getDifference((org.joda.time.ReadableInstant) dateTime35);
//        boolean boolean39 = gregorianChronology26.equals((java.lang.Object) int38);
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now(dateTimeZone41);
//        org.joda.time.TimeOfDay timeOfDay43 = dateTime42.toTimeOfDay();
//        long long45 = gregorianChronology26.set((org.joda.time.ReadablePartial) timeOfDay43, (-11L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now(dateTimeZone50);
//        org.joda.time.DateTime.Property property52 = dateTime51.year();
//        org.joda.time.DateTime dateTime53 = property52.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime55 = property52.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property56 = dateTime55.minuteOfHour();
//        org.joda.time.DateTime dateTime57 = property56.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = property56.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, dateTimeFieldType58, 9700, 77045, 0);
//        int int63 = offsetDateTimeField62.getMinimumValue();
//        org.joda.time.DateTimeField dateTimeField64 = offsetDateTimeField62.getWrappedField();
//        long long66 = offsetDateTimeField62.roundHalfCeiling((long) '4');
//        org.joda.time.ReadablePartial readablePartial67 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology68 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField69 = gregorianChronology68.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone70 = gregorianChronology68.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology71 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology71.secondOfDay();
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime74 = dateTime73.toLocalDateTime();
//        int[] intArray76 = gregorianChronology71.get((org.joda.time.ReadablePartial) localDateTime74, 0L);
//        int[] intArray78 = gregorianChronology68.get((org.joda.time.ReadablePartial) localDateTime74, 14332974220L);
//        int int79 = offsetDateTimeField62.getMinimumValue(readablePartial67, intArray78);
//        try {
//            int[] intArray81 = unsupportedDateTimeField20.add((org.joda.time.ReadablePartial) timeOfDay43, 22, intArray78, 62);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNull(durationField21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-128044800000L) + "'", long25 == (-128044800000L));
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(timeOfDay43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-86399865L) + "'", long45 == (-86399865L));
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 77045 + "'", int63 == 77045);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 0L + "'", long66 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology68);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertNotNull(dateTimeZone70);
//        org.junit.Assert.assertNotNull(gregorianChronology71);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertNotNull(localDateTime74);
//        org.junit.Assert.assertNotNull(intArray76);
//        org.junit.Assert.assertNotNull(intArray78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 77045 + "'", int79 == 77045);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property5 = dateTime4.monthOfYear();
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((-292275054));
        org.joda.time.DateTime dateTime9 = dateTime7.plus(0L);
        int int10 = dateTime7.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
//        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
//        long long23 = unsupportedDateTimeField20.add((-9350942L), (int) (byte) 1);
//        boolean boolean24 = unsupportedDateTimeField20.isLenient();
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology27.getZone();
//        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology27.getZone();
//        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology27.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone34);
//        org.joda.time.DateTime.Property property36 = dateTime35.year();
//        org.joda.time.DateTime dateTime37 = property36.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime39 = property36.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property40 = dateTime39.minuteOfHour();
//        org.joda.time.DateTime dateTime41 = property40.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property40.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, dateTimeFieldType42, 9700, 77045, 0);
//        int int47 = offsetDateTimeField46.getMinimumValue();
//        org.joda.time.DateTimeField dateTimeField48 = offsetDateTimeField46.getWrappedField();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone53 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology54.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone56 = gregorianChronology54.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology57.secondOfDay();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime60 = dateTime59.toLocalDateTime();
//        int[] intArray62 = gregorianChronology57.get((org.joda.time.ReadablePartial) localDateTime60, 0L);
//        int[] intArray64 = gregorianChronology54.get((org.joda.time.ReadablePartial) localDateTime60, 14332974220L);
//        boolean boolean65 = fixedDateTimeZone53.isLocalDateTimeGap(localDateTime60);
//        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology66.secondOfDay();
//        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime69 = dateTime68.toLocalDateTime();
//        int[] intArray71 = gregorianChronology66.get((org.joda.time.ReadablePartial) localDateTime69, 0L);
//        int int72 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) localDateTime60, intArray71);
//        long long74 = gregorianChronology27.set((org.joda.time.ReadablePartial) localDateTime60, 0L);
//        try {
//            int int75 = unsupportedDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) localDateTime60);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 595449058L + "'", long23 == 595449058L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 77045 + "'", int47 == 77045);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(gregorianChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertNotNull(gregorianChronology57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(localDateTime60);
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology66);
//        org.junit.Assert.assertNotNull(dateTimeField67);
//        org.junit.Assert.assertNotNull(localDateTime69);
//        org.junit.Assert.assertNotNull(intArray71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 77045 + "'", int72 == 77045);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 83L + "'", long74 == 83L);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
//        org.joda.time.Interval interval5 = property3.toInterval();
//        boolean boolean6 = property3.isLeap();
//        int int7 = property3.getMinimumValue();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property3.getAsText(locale8);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(interval5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292275054) + "'", int7 == (-292275054));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970" + "'", str9.equals("1970"));
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        int int3 = dateTime2.getWeekOfWeekyear();
//        int int4 = dateTime2.getMinuteOfHour();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
//        int int10 = dateTime9.getWeekOfWeekyear();
//        int int11 = dateTime9.getMinuteOfHour();
//        int int12 = dateTime9.getYear();
//        boolean boolean13 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime.Property property14 = dateTime9.year();
//        int int15 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime17 = dateTime9.plusMonths((int) (short) 0);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime9.minus(readablePeriod18);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        org.joda.time.DateTime dateTime23 = dateTime9.withZoneRetainFields(dateTimeZone21);
//        org.joda.time.DateTime dateTime25 = dateTime23.withMillisOfSecond(366);
//        org.joda.time.ReadableDuration readableDuration26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime23.minus(readableDuration26);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.year();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
//        int int10 = dateTime9.getWeekOfWeekyear();
//        int int11 = dateTime9.getMinuteOfHour();
//        int int12 = property6.getDifference((org.joda.time.ReadableInstant) dateTime9);
//        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) int12);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology0.centuryOfEra();
//        try {
//            long long24 = gregorianChronology0.getDateTimeMillis(69, (int) 'a', (int) ' ', 9701, (int) '#', 292278993, 1969);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9701 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
//        int int8 = property7.getLeapAmount();
//        org.joda.time.DateTime dateTime10 = property7.addToCopy((-1));
//        org.joda.time.DateTime dateTime12 = property7.addToCopy((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        java.lang.String str14 = dateTime12.toString(dateTimeFormatter13);
//        java.util.Locale locale15 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter13.withLocale(locale15);
//        try {
//            org.joda.time.LocalDateTime localDateTime18 = dateTimeFormatter13.parseLocalDateTime("ISOChronology[+00:00:00.010]");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[+00:00:00.010]\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "00:10:00.135" + "'", str14.equals("00:10:00.135"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology(chronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfEra(10, 236);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral("18:55:52.592");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear(565);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.TimeOfDay timeOfDay5 = dateTime4.toTimeOfDay();
        int int6 = property1.compareTo((org.joda.time.ReadablePartial) timeOfDay5);
        org.joda.time.DurationField durationField7 = property1.getRangeDurationField();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(timeOfDay5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(135, 25, 341, 332);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
//        int int4 = dateTime2.getMillisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusYears(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = property7.roundHalfFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.year();
//        org.joda.time.DateTime dateTime13 = property12.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime15 = property12.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property16 = dateTime15.minuteOfHour();
//        int int17 = property16.getLeapAmount();
//        org.joda.time.DateTime dateTime19 = property16.addToCopy((-1));
//        int int20 = property7.getDifference((org.joda.time.ReadableInstant) dateTime19);
//        int int21 = dateTime19.getWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 135 + "'", int4 == 135);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        int int3 = dateTime2.getWeekOfWeekyear();
//        int int4 = dateTime2.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        int int12 = dateTime11.getWeekOfWeekyear();
//        int int13 = dateTime11.getMinuteOfHour();
//        int int14 = dateTime11.getYear();
//        boolean boolean15 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime11);
//        boolean boolean16 = dateTime6.equals((java.lang.Object) dateTime7);
//        org.joda.time.ReadableDuration readableDuration17 = null;
//        org.joda.time.DateTime dateTime19 = dateTime6.withDurationAdded(readableDuration17, 62);
//        org.joda.time.DateTime dateTime21 = dateTime6.plusYears(0);
//        org.joda.time.DateTime.Property property22 = dateTime6.year();
//        try {
//            org.joda.time.DateTime dateTime24 = dateTime6.withYearOfEra(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1970 + "'", int14 == 1970);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.hourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.weekyear();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology7.hourOfHalfday();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(0, 36, (int) (short) -1, 10, 77046338, 559, (int) ' ', (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 77046338 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
//        java.lang.String str4 = dateTimeZone2.toString();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getWeekOfWeekyear();
//        int int10 = dateTime8.getMinuteOfHour();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getWeekOfWeekyear();
//        int int17 = dateTime15.getMinuteOfHour();
//        int int18 = dateTime15.getYear();
//        boolean boolean19 = dateTime11.isAfter((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime.Property property20 = dateTime15.year();
//        int int21 = dateTime8.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime24 = dateTime8.withWeekyear((int) '#');
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.minuteOfDay();
//        org.joda.time.MutableDateTime mutableDateTime28 = dateTime8.toMutableDateTime((org.joda.time.Chronology) gregorianChronology25);
//        int int31 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime28, "62", (int) (byte) 100);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.010" + "'", str4.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1970 + "'", int18 == 1970);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-101) + "'", int31 == (-101));
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.withDurationAdded(readableDuration4, (int) (short) 1);
//        int int7 = dateTime2.getMinuteOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime2.plusSeconds((int) (short) -1);
//        int int10 = dateTime9.getYearOfEra();
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime9.withDayOfWeek(189);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 189 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((-86399865L), chronology1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendFractionOfMinute(24, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear((int) (short) 10, false);
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatterBuilder13.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder0.append(dateTimePrinter14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "18:55:52.592", "00:10:00.135");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.append(dateTimeFormatter5);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.year();
        org.joda.time.DateTime dateTime14 = property13.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime16 = property13.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.minuteOfHour();
        org.joda.time.DateTime dateTime18 = property17.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property17.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType19, 9700, 77045, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder2.appendFixedDecimal(dateTimeFieldType19, 134);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 1969, (java.lang.Number) (short) 100, (java.lang.Number) 236);
        java.lang.Number number30 = illegalFieldValueException29.getUpperBound();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 236 + "'", number30.equals(236));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        long long23 = durationField19.subtract((long) 125, (int) (byte) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 125L + "'", long23 == 125L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        long long17 = offsetDateTimeField15.remainder((long) 341);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.hourOfDay();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology18.weekyear();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.YearMonthDay yearMonthDay23 = dateTime22.toYearMonthDay();
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay23, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 341L + "'", long17 == 341L);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(yearMonthDay23);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 62, (java.lang.Number) 24, (java.lang.Number) (byte) 100);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        illegalFieldValueException4.prependMessage("166");
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = illegalFieldValueException4.getDateTimeFieldType();
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(dateTimeFieldType8);
        org.junit.Assert.assertNull(durationFieldType9);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
//        int int4 = dateTime2.getMillisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusYears(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMillisOfSecond(24);
//        boolean boolean11 = dateTimeFormatterBuilder10.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendMinuteOfHour(77045);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
//        int int17 = dateTime16.getWeekOfWeekyear();
//        int int18 = dateTime16.getMinuteOfHour();
//        org.joda.time.DateTime dateTime20 = dateTime16.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime22 = dateTime16.minusSeconds(0);
//        org.joda.time.DateTime dateTime24 = dateTime16.withHourOfDay(22);
//        org.joda.time.DateTime.Property property25 = dateTime16.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property25.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType26);
//        org.joda.time.DateTime.Property property28 = dateTime6.property(dateTimeFieldType26);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, "134");
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 135 + "'", int4 == 135);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(property28);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
//        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getLeapDurationField();
//        boolean boolean22 = unsupportedDateTimeField20.isSupported();
//        long long25 = unsupportedDateTimeField20.add((-328838400000L), 332);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now(dateTimeZone27);
//        org.joda.time.TimeOfDay timeOfDay29 = dateTime28.toTimeOfDay();
//        int int30 = dateTime28.getMillisOfSecond();
//        org.joda.time.DateTime dateTime32 = dateTime28.minusYears(0);
//        org.joda.time.DateTime dateTime34 = dateTime32.plusHours((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now(dateTimeZone36);
//        org.joda.time.DateTime.Property property38 = dateTime37.year();
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now(dateTimeZone40);
//        int int42 = dateTime41.getWeekOfWeekyear();
//        int int43 = dateTime41.getMinuteOfHour();
//        int int44 = property38.getDifference((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.LocalTime localTime45 = dateTime41.toLocalTime();
//        org.joda.time.DateTime dateTime46 = dateTime32.withFields((org.joda.time.ReadablePartial) localTime45);
//        java.util.Locale locale47 = null;
//        try {
//            java.lang.String str48 = unsupportedDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localTime45, locale47);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNull(durationField21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-128044800000L) + "'", long25 == (-128044800000L));
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(timeOfDay29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 135 + "'", int30 == 135);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertNotNull(localTime45);
//        org.junit.Assert.assertNotNull(dateTime46);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
//        int int4 = dateTime2.getMillisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusYears(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
//        org.joda.time.DateTime.Property property11 = dateTime10.year();
//        org.joda.time.DateTime dateTime12 = property11.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime14 = property11.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property15 = dateTime14.minuteOfHour();
//        org.joda.time.DateTime dateTime16 = property15.withMinimumValue();
//        boolean boolean17 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime19 = dateTime16.withYearOfEra(24);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 135 + "'", int4 == 135);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
//        int int16 = offsetDateTimeField15.getMinimumValue();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) (short) 1);
//        int int24 = dateTime19.getMinuteOfDay();
//        org.joda.time.DateTime dateTime26 = dateTime19.plusSeconds((int) (short) -1);
//        long long27 = dateTime19.getMillis();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
//        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
//        java.lang.Class<?> wildcardClass32 = timeOfDay31.getClass();
//        org.joda.time.DateTime dateTime33 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay31);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay31, locale34);
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = offsetDateTimeField15.getAsShortText(14332978624L, locale37);
//        try {
//            long long41 = offsetDateTimeField15.set((long) 292278993, "0");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for minuteOfHour must be in the range [77045,0]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(timeOfDay20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 125L + "'", long27 == 125L);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(timeOfDay31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9721" + "'", str38.equals("9721"));
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getLeapDurationField();
        boolean boolean22 = unsupportedDateTimeField20.isSupported();
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = unsupportedDateTimeField20.getAsText(1284, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.withDurationAdded(readableDuration4, (int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime2.minusYears(9);
        org.joda.time.DateTime dateTime10 = dateTime8.minusYears(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear((int) '4', 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendDayOfWeek(292278993);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendTimeZoneShortName(strMap10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        long long23 = unsupportedDateTimeField20.add((-9350942L), (int) (byte) 1);
        long long26 = unsupportedDateTimeField20.getDifferenceAsLong((long) (short) 1, 31742L);
        java.util.Locale locale27 = null;
        try {
            int int28 = unsupportedDateTimeField20.getMaximumTextLength(locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 595449058L + "'", long23 == 595449058L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        boolean boolean5 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMinuteOfDay(23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.DurationField durationField16 = offsetDateTimeField15.getLeapDurationField();
        boolean boolean17 = offsetDateTimeField15.isSupported();
        int int18 = offsetDateTimeField15.getMinimumValue();
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField15.getAsText(45, locale20);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 77045 + "'", int18 == 77045);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "45" + "'", str21.equals("45"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 18, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
//        int int4 = dateTime3.getWeekOfWeekyear();
//        int int5 = dateTime3.getMinuteOfHour();
//        org.joda.time.DateTime dateTime7 = dateTime3.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime9 = dateTime3.minusSeconds(0);
//        org.joda.time.DateTime dateTime11 = dateTime3.withHourOfDay(22);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
//        long long17 = dateTimeZone13.convertUTCToLocal((long) 24);
//        org.joda.time.DateTime dateTime18 = dateTime11.withZone(dateTimeZone13);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(obj0, dateTimeZone13);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone13.getShortName((-9424284L), locale21);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 34L + "'", long17 == 34L);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00:00.010" + "'", str22.equals("+00:00:00.010"));
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfCentury(0);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, 2019);
        try {
            org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear(67552);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 67552 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        int int3 = dateTime2.getWeekOfWeekyear();
//        int int4 = dateTime2.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
//        org.joda.time.DateTime dateTime10 = dateTime2.withHourOfDay(22);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
//        long long16 = dateTimeZone12.convertUTCToLocal((long) 24);
//        org.joda.time.DateTime dateTime17 = dateTime10.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property18 = dateTime10.dayOfYear();
//        org.joda.time.DateTime.Property property19 = dateTime10.weekOfWeekyear();
//        org.joda.time.DateTime dateTime21 = dateTime10.plusWeeks(1970);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 34L + "'", long16 == 34L);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 1284);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.hourOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.minuteOfDay();
        org.joda.time.DurationField durationField24 = gregorianChronology21.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = unsupportedDateTimeField25.getType();
        try {
            long long29 = unsupportedDateTimeField25.set(0L, "");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
        int int4 = dateTime2.getMillisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.minusYears(0);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime9 = dateTime6.minusMillis(59);
        int int10 = dateTime6.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 294 + "'", int4 == 294);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        int int3 = dateTime2.getWeekOfWeekyear();
        int int4 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
        org.joda.time.DateTime dateTime10 = dateTime2.withHourOfDay(22);
        int int11 = dateTime10.getYearOfEra();
        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
        org.joda.time.DateTime dateTime14 = dateTime10.plusMinutes(9700);
        org.joda.time.DateTime dateTime15 = dateTime10.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 559, (long) 59);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 500L + "'", long2 == 500L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.clockhourOfHalfday();
        try {
            long long12 = gregorianChronology2.getDateTimeMillis(565, 22, 23, (int) ' ', (int) '4', 77044, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        int int3 = dateTime2.getWeekOfWeekyear();
        int int4 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
        org.joda.time.DateTime dateTime10 = dateTime2.withHourOfDay(22);
        int int11 = dateTime10.getYearOfEra();
        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime10.minus(readableDuration13);
        org.joda.time.DateTime dateTime16 = dateTime14.withWeekyear(69);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
        int int4 = dateTime2.getMillisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.minusYears(0);
        org.joda.time.DateTime dateTime8 = dateTime2.withWeekyear((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.hourOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfWeek();
        int int12 = dateTime8.get(dateTimeField11);
        org.joda.time.DateTime dateTime14 = dateTime8.minusHours(559);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 18, dateTimeZone17);
        org.joda.time.DateTime dateTime21 = dateTime19.withYearOfEra((int) ' ');
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime8, (org.joda.time.ReadableInstant) dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 294 + "'", int4 == 294);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        java.util.TimeZone timeZone5 = dateTimeZone1.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        java.lang.String str7 = dateTimeZone1.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.010" + "'", str3.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.Locale locale5 = null;
        java.lang.String str6 = cachedDateTimeZone3.getName((long) '#', locale5);
        long long9 = cachedDateTimeZone3.convertLocalToUTC((long) 341, false);
        int int11 = cachedDateTimeZone3.getStandardOffset((long) (byte) 1);
        boolean boolean13 = cachedDateTimeZone3.equals((java.lang.Object) (byte) 0);
        org.joda.time.ReadableInstant readableInstant14 = null;
        int int15 = cachedDateTimeZone3.getOffset(readableInstant14);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 331L + "'", long9 == 331L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        org.joda.time.DurationField durationField3 = iSOChronology0.millis();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.dayOfWeek();
        org.joda.time.DurationField durationField5 = iSOChronology0.years();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        int int3 = dateTime2.getWeekOfWeekyear();
        int int4 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
        org.joda.time.DateTime dateTime10 = dateTime2.withHourOfDay(22);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = dateTimeZone12.convertUTCToLocal((long) 24);
        org.joda.time.DateTime dateTime17 = dateTime10.withZone(dateTimeZone12);
        org.joda.time.DateTime.Property property18 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property19 = dateTime10.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime20 = dateTime10.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 34L + "'", long16 == 34L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property8 = dateTime7.minuteOfHour();
        int int9 = property8.getLeapAmount();
        org.joda.time.DateTime dateTime11 = property8.addToCopy((-1));
        org.joda.time.DateTime dateTime13 = property8.addToCopy((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.lang.String str15 = dateTime13.toString(dateTimeFormatter14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter14.withLocale(locale16);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
        java.lang.String str24 = fixedDateTimeZone22.getNameKey((long) 2360);
        java.lang.String str25 = fixedDateTimeZone22.getID();
        int int27 = fixedDateTimeZone22.getOffset(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter17.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        try {
            org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.parse("Property[year]", dateTimeFormatter28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[year]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "00:10:01.294" + "'", str15.equals("00:10:01.294"));
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.010" + "'", str24.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.010" + "'", str25.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        int int10 = dateTime9.getWeekOfWeekyear();
        int int11 = dateTime9.getMinuteOfHour();
        int int12 = property6.getDifference((org.joda.time.ReadableInstant) dateTime9);
        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) int12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology0.getZone();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime16.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.hourOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.minuteOfDay();
        org.joda.time.DurationField durationField24 = gregorianChronology21.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = unsupportedDateTimeField25.getType();
        try {
            long long28 = unsupportedDateTimeField25.roundHalfEven((long) 1284);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.halfdays();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField4 = new org.joda.time.field.ScaledDurationField(durationField1, durationFieldType2, 341);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMonths(24);
        org.joda.time.DateTime.Property property6 = dateTime5.minuteOfDay();
        org.joda.time.DateTime.Property property7 = dateTime5.yearOfCentury();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.withChronology(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        long long17 = offsetDateTimeField15.remainder((long) 341);
        int int19 = offsetDateTimeField15.getMinimumValue((long) 455);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 341L + "'", long17 == 341L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 77045 + "'", int19 == 77045);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMonths(24);
        java.lang.Object obj6 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        int int10 = dateTime9.getWeekOfWeekyear();
        int int11 = dateTime9.getMinuteOfHour();
        org.joda.time.DateTime dateTime13 = dateTime9.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime15 = dateTime9.minusSeconds(0);
        org.joda.time.DateTime dateTime17 = dateTime9.withHourOfDay(22);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone19);
        long long23 = dateTimeZone19.convertUTCToLocal((long) 24);
        org.joda.time.DateTime dateTime24 = dateTime17.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(obj6, dateTimeZone19);
        java.util.Locale locale27 = null;
        java.lang.String str28 = dateTimeZone19.getShortName((-9424284L), locale27);
        org.joda.time.DateTime dateTime29 = dateTime2.toDateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime31 = dateTime29.minusMinutes(9);
        org.joda.time.DateTime dateTime33 = dateTime31.minus((long) 59);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 34L + "'", long23 == 34L);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00:00.010" + "'", str28.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneName(strMap6);
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.withDurationAdded(readableDuration4, (int) (short) 1);
        int int7 = dateTime2.getMinuteOfDay();
        org.joda.time.DateTime dateTime9 = dateTime2.plusSeconds((int) (short) -1);
        org.joda.time.DateTime dateTime10 = dateTime9.withEarlierOffsetAtOverlap();
        int int11 = dateTime10.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 294 + "'", int11 == 294);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("+00:00:00.010");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("+00:00:00.010");
        jodaTimePermission1.checkGuard((java.lang.Object) jodaTimePermission3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("+00:00:00.010");
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("+00:00:00.010");
        jodaTimePermission6.checkGuard((java.lang.Object) jodaTimePermission8);
        java.lang.String str10 = jodaTimePermission6.getActions();
        java.lang.String str11 = jodaTimePermission6.getActions();
        boolean boolean12 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission6);
        java.lang.String str13 = jodaTimePermission6.getName();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00:00.010" + "'", str13.equals("+00:00:00.010"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        int int3 = dateTime2.getWeekOfWeekyear();
        int int4 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
        int int7 = dateTime2.getSecondOfDay();
        org.joda.time.DateTime.Property property8 = dateTime2.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        long long7 = dateTimeZone3.convertUTCToLocal((long) 24);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone8);
        try {
            long long15 = zonedChronology9.getDateTimeMillis((long) 2360, 1970, 415, 332, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 34L + "'", long7 == 34L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long5 = dateTimeZone1.convertUTCToLocal((long) 24);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        java.util.TimeZone timeZone7 = dateTimeZone1.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 34L + "'", long5 == 34L);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("ZonedChronology[GregorianChronology[UTC], +00:00:00.010]", false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 134, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMonths(24);
        org.joda.time.DateTime.Property property6 = dateTime5.minuteOfDay();
        int int7 = property6.getMinimumValueOverall();
        org.joda.time.DateTime dateTime8 = property6.roundCeilingCopy();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.hourOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology9.monthOfYear();
        org.joda.time.DateTime dateTime14 = dateTime8.toDateTime((org.joda.time.Chronology) gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfMinute(0, 538);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder2.appendTimeZoneOffset("2019-06-15T21:24:05.270+00:00:00.010", "166", true, 559, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        int int8 = property7.getLeapAmount();
        org.joda.time.DateTime dateTime10 = property7.addToCopy((-1));
        org.joda.time.DateTime dateTime12 = property7.addToCopy((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.lang.String str14 = dateTime12.toString(dateTimeFormatter13);
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter13.withLocale(locale15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
        java.lang.String str23 = fixedDateTimeZone21.getNameKey((long) 2360);
        java.lang.String str24 = fixedDateTimeZone21.getID();
        int int26 = fixedDateTimeZone21.getOffset(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter16.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        try {
            org.joda.time.LocalDate localDate29 = dateTimeFormatter16.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "00:10:01.294" + "'", str14.equals("00:10:01.294"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.010" + "'", str23.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.010" + "'", str24.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 2360);
        int int8 = fixedDateTimeZone4.getOffset((-1L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone4.getShortName((long) 236, locale10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
        try {
            long long23 = unsupportedDateTimeField20.remainder((long) 18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.append(dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfDay(24, 77046332);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        int int16 = offsetDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) (short) 1);
        int int24 = dateTime19.getMinuteOfDay();
        org.joda.time.DateTime dateTime26 = dateTime19.plusSeconds((int) (short) -1);
        long long27 = dateTime19.getMillis();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
        java.lang.Class<?> wildcardClass32 = timeOfDay31.getClass();
        org.joda.time.DateTime dateTime33 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay31, locale34);
        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField15.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone38);
        int int40 = dateTime39.getWeekOfWeekyear();
        int int41 = dateTime39.getMinuteOfHour();
        org.joda.time.DateTime dateTime43 = dateTime39.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime45 = dateTime39.minusSeconds(0);
        org.joda.time.DateTime dateTime47 = dateTime39.withHourOfDay(22);
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now(dateTimeZone49);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone51 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone49);
        long long53 = dateTimeZone49.convertUTCToLocal((long) 24);
        org.joda.time.DateTime dateTime54 = dateTime47.withZone(dateTimeZone49);
        org.joda.time.DateTime.Property property55 = dateTime47.dayOfYear();
        org.joda.time.DateTime.Property property56 = dateTime47.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder57.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder59.appendLiteral('a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.Chronology chronology63 = dateTimeFormatter62.getChronology();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder59.append(dateTimeFormatter62);
        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology65.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now(dateTimeZone68);
        org.joda.time.DateTime.Property property70 = dateTime69.year();
        org.joda.time.DateTime dateTime71 = property70.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime73 = property70.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property74 = dateTime73.minuteOfHour();
        org.joda.time.DateTime dateTime75 = property74.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType76 = property74.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, dateTimeFieldType76, 9700, 77045, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder59.appendFixedDecimal(dateTimeFieldType76, 134);
        org.joda.time.DateTime.Property property83 = dateTime47.property(dateTimeFieldType76);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField85 = new org.joda.time.field.DividedDateTimeField(dateTimeField36, dateTimeFieldType76, 18);
        int int88 = dividedDateTimeField85.getDifference((-9356732L), (-128044800000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1284L + "'", long27 == 1284L);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(timeOfDay31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(cachedDateTimeZone51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 34L + "'", long53 == 34L);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(dateTimeFormatter62);
        org.junit.Assert.assertNull(chronology63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(gregorianChronology65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(dateTimeFieldType76);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
        org.junit.Assert.assertNotNull(property83);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1975 + "'", int88 == 1975);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        long long4 = durationField1.subtract((long) 59, (long) 292278993);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-12626452497599941L) + "'", long4 == (-12626452497599941L));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.Locale locale5 = null;
        java.lang.String str6 = cachedDateTimeZone3.getName((long) '#', locale5);
        long long9 = cachedDateTimeZone3.convertLocalToUTC((long) 341, false);
        long long11 = cachedDateTimeZone3.previousTransition((long) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 331L + "'", long9 == 331L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        int int3 = dateTime2.getWeekOfWeekyear();
        int int4 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
        org.joda.time.DateTime dateTime10 = dateTime2.withHourOfDay(22);
        int int11 = dateTime10.getYearOfEra();
        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
        org.joda.time.DateTime dateTime13 = property12.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.DurationField durationField16 = offsetDateTimeField15.getLeapDurationField();
        org.joda.time.DurationField durationField17 = offsetDateTimeField15.getDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.hourOfDay();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone22);
        org.joda.time.DateTime.Property property24 = dateTime23.year();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(dateTimeZone26);
        int int28 = dateTime27.getWeekOfWeekyear();
        int int29 = dateTime27.getMinuteOfHour();
        int int30 = property24.getDifference((org.joda.time.ReadableInstant) dateTime27);
        boolean boolean31 = gregorianChronology18.equals((java.lang.Object) int30);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now(dateTimeZone33);
        org.joda.time.TimeOfDay timeOfDay35 = dateTime34.toTimeOfDay();
        long long37 = gregorianChronology18.set((org.joda.time.ReadablePartial) timeOfDay35, (-11L));
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay35, 0, locale39);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
        org.joda.time.TimeOfDay timeOfDay44 = dateTime43.toTimeOfDay();
        int[] intArray46 = null;
        java.util.Locale locale48 = null;
        try {
            int[] intArray49 = offsetDateTimeField15.set((org.joda.time.ReadablePartial) timeOfDay44, 0, intArray46, "134", locale48);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 134 for minuteOfHour must be in the range [77045,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(timeOfDay35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-86398706L) + "'", long37 == (-86398706L));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "0" + "'", str40.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(timeOfDay44);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        java.lang.String str4 = dateTime2.toString(dateTimeFormatter3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusHours((-292275054));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-001T00:00:01.294+00:00:00.010" + "'", str4.equals("1970-001T00:00:01.294+00:00:00.010"));
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
        org.joda.time.DateTime dateTime7 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime9 = property3.addWrapFieldToCopy(0);
        int int10 = property3.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-292275054) + "'", int10 == (-292275054));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology(chronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(10);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTimeZoneShortName(strMap9);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.Interval interval5 = property3.toInterval();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        int int13 = dateTime12.getWeekOfWeekyear();
        int int14 = dateTime12.getMinuteOfHour();
        int int15 = property9.getDifference((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.DateTime.Property property19 = dateTime18.year();
        org.joda.time.DateTime dateTime20 = property19.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime22 = property19.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property23 = dateTime22.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now(dateTimeZone25);
        org.joda.time.DateMidnight dateMidnight27 = dateTime26.toDateMidnight();
        boolean boolean28 = dateTime22.isEqual((org.joda.time.ReadableInstant) dateTime26);
        long long29 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime31 = dateTime22.withMillis(34L);
        org.joda.time.DateTime dateTime33 = dateTime22.plusDays(2019);
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.DateTime dateTime35 = dateTime33.plus(readablePeriod34);
        int int36 = property3.compareTo((org.joda.time.ReadableInstant) dateTime33);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateMidnight27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology(chronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendFractionOfSecond(18, 236);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendMonthOfYear(1975);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1970");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1970' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.Locale locale5 = null;
        java.lang.String str6 = cachedDateTimeZone3.getName((long) '#', locale5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
        int int14 = dateTime13.getWeekOfWeekyear();
        int int15 = dateTime13.getMinuteOfHour();
        int int16 = property10.getDifference((org.joda.time.ReadableInstant) dateTime13);
        boolean boolean17 = cachedDateTimeZone3.equals((java.lang.Object) int16);
        java.lang.String str19 = cachedDateTimeZone3.getShortName((long) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        org.joda.time.DurationField durationField21 = gregorianChronology20.eras();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00:00.010" + "'", str19.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.hourOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.year();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getWeekOfWeekyear();
        int int17 = dateTime15.getMinuteOfHour();
        int int18 = property12.getDifference((org.joda.time.ReadableInstant) dateTime15);
        boolean boolean19 = gregorianChronology6.equals((java.lang.Object) int18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        long long25 = gregorianChronology6.set((org.joda.time.ReadablePartial) timeOfDay23, (-11L));
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.DateTime.Property property31 = dateTime30.year();
        org.joda.time.DateTime dateTime32 = property31.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime34 = property31.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property35 = dateTime34.minuteOfHour();
        org.joda.time.DateTime dateTime36 = property35.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property35.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType37, 9700, 77045, 0);
        int int42 = offsetDateTimeField41.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField43 = offsetDateTimeField41.getWrappedField();
        long long45 = offsetDateTimeField41.roundHalfCeiling((long) '4');
        org.joda.time.ReadablePartial readablePartial46 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone49 = gregorianChronology47.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology50.secondOfDay();
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
        int[] intArray55 = gregorianChronology50.get((org.joda.time.ReadablePartial) localDateTime53, 0L);
        int[] intArray57 = gregorianChronology47.get((org.joda.time.ReadablePartial) localDateTime53, 14332974220L);
        int int58 = offsetDateTimeField41.getMinimumValue(readablePartial46, intArray57);
        try {
            gregorianChronology2.validate((org.joda.time.ReadablePartial) timeOfDay23, intArray57);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must not be larger than 23");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-86398706L) + "'", long25 == (-86398706L));
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 77045 + "'", int42 == 77045);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(localDateTime53);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 77045 + "'", int58 == 77045);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        int int16 = offsetDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) (short) 1);
        int int24 = dateTime19.getMinuteOfDay();
        org.joda.time.DateTime dateTime26 = dateTime19.plusSeconds((int) (short) -1);
        long long27 = dateTime19.getMillis();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
        java.lang.Class<?> wildcardClass32 = timeOfDay31.getClass();
        org.joda.time.DateTime dateTime33 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay31, locale34);
        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField15.getWrappedField();
        org.joda.time.DurationField durationField37 = offsetDateTimeField15.getDurationField();
        long long39 = offsetDateTimeField15.roundHalfCeiling((-328761356905L));
        long long41 = offsetDateTimeField15.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1284L + "'", long27 == 1284L);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(timeOfDay31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-328762800000L) + "'", long39 == (-328762800000L));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property5 = dateTime4.monthOfYear();
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((-292275054));
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        long long7 = dateTimeZone3.convertUTCToLocal((long) 24);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone8);
        java.lang.String str10 = zonedChronology9.toString();
        try {
            long long18 = zonedChronology9.getDateTimeMillis(77046338, 134, 67552, (-165), 559, 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -165 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 34L + "'", long7 == 34L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ZonedChronology[GregorianChronology[UTC], +00:00:00.010]" + "'", str10.equals("ZonedChronology[GregorianChronology[UTC], +00:00:00.010]"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        int int10 = dateTime9.getWeekOfWeekyear();
        int int11 = dateTime9.getMinuteOfHour();
        int int12 = property6.getDifference((org.joda.time.ReadableInstant) dateTime9);
        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) int12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.TimeOfDay timeOfDay17 = dateTime16.toTimeOfDay();
        long long19 = gregorianChronology0.set((org.joda.time.ReadablePartial) timeOfDay17, (-11L));
        org.joda.time.DurationField durationField20 = gregorianChronology0.weekyears();
        int int21 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(timeOfDay17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-86398706L) + "'", long19 == (-86398706L));
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology(chronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfEra(10, 236);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral("18:55:52.592");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendWeekyear((int) (byte) -1, 77047148);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
        long long10 = fixedDateTimeZone8.nextTransition((long) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str9 = iSOChronology8.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = iSOChronology8.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter3.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[+00:00:00.010]" + "'", str9.equals("ISOChronology[+00:00:00.010]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNull(dateTimePrinter12);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        int int8 = property7.getLeapAmount();
        org.joda.time.DateTime dateTime10 = property7.addToCopy((-1));
        org.joda.time.DateTime dateTime12 = property7.addToCopy((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.lang.String str14 = dateTime12.toString(dateTimeFormatter13);
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter13.withLocale(locale15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
        java.lang.String str23 = fixedDateTimeZone21.getNameKey((long) 2360);
        java.lang.String str24 = fixedDateTimeZone21.getID();
        int int26 = fixedDateTimeZone21.getOffset(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter16.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        int int29 = fixedDateTimeZone21.getOffset((long) 70);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "00:10:01.294" + "'", str14.equals("00:10:01.294"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.010" + "'", str23.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.010" + "'", str24.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 62, (java.lang.Number) 24, (java.lang.Number) (byte) 100);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException4.getSuppressed();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendLiteral('a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.Chronology chronology14 = dateTimeFormatter13.getChronology();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.append(dateTimeFormatter13);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.DateTime dateTime22 = property21.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime24 = property21.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property25 = dateTime24.minuteOfHour();
        org.joda.time.DateTime dateTime26 = property25.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property25.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, dateTimeFieldType27, 9700, 77045, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder10.appendFixedDecimal(dateTimeFieldType27, 134);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType27, (java.lang.Number) 1969, (java.lang.Number) (short) 100, (java.lang.Number) 236);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException37);
        java.lang.String str39 = illegalFieldValueException37.toString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 24 + "'", number5.equals(24));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "62" + "'", str6.equals("62"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1969 for minuteOfHour must be in the range [100,236]" + "'", str39.equals("org.joda.time.IllegalFieldValueException: Value 1969 for minuteOfHour must be in the range [100,236]"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.Locale locale5 = null;
        java.lang.String str6 = cachedDateTimeZone3.getName((long) '#', locale5);
        java.lang.String str8 = cachedDateTimeZone3.getNameKey((long) 77046332);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
        int int4 = dateTime2.getMillisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.plusHours(1282);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 294 + "'", int4 == 294);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.withDurationAdded(readableDuration4, (int) (short) 1);
        int int7 = dateTime2.getMinuteOfDay();
        org.joda.time.DateTime dateTime9 = dateTime2.plusSeconds((int) (short) -1);
        org.joda.time.DateTime dateTime10 = dateTime9.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime12 = dateTime9.minusWeeks(18);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.year();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getWeekOfWeekyear();
        int int17 = dateTime15.getMinuteOfHour();
        int int18 = property12.getDifference((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.year();
        org.joda.time.DateTime dateTime23 = property22.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime25 = property22.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property26 = dateTime25.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(dateTimeZone28);
        org.joda.time.DateMidnight dateMidnight30 = dateTime29.toDateMidnight();
        boolean boolean31 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime29);
        long long32 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime25);
        boolean boolean33 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime35 = dateTime6.withYearOfEra(24);
        org.joda.time.LocalTime localTime36 = dateTime6.toLocalTime();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateMidnight30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(localTime36);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        int int3 = dateTime2.getWeekOfWeekyear();
        int int4 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
        org.joda.time.DateTime dateTime10 = dateTime2.withHourOfDay(22);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = dateTimeZone12.convertUTCToLocal((long) 24);
        org.joda.time.DateTime dateTime17 = dateTime10.withZone(dateTimeZone12);
        org.joda.time.DateTime.Property property18 = dateTime10.dayOfYear();
        org.joda.time.DateTime dateTime20 = dateTime10.minusWeeks(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 34L + "'", long16 == 34L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.append(dateTimeFormatter5);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatterBuilder2.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimePrinter8);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology(chronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear(77047148);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfCentury(0);
        org.joda.time.DateTime.Property property4 = dateTime0.secondOfDay();
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long8 = dateTimeZone1.convertLocalToUTC((long) 9700, false, 0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9690L + "'", long8 == 9690L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        java.lang.String str5 = dateTimeZone1.getID();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = iSOChronology6.withZone(dateTimeZone7);
        org.joda.time.DurationField durationField9 = iSOChronology6.weeks();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.010" + "'", str3.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.010" + "'", str5.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        int int7 = dateTime6.getWeekOfWeekyear();
        int int8 = dateTime6.getMinuteOfHour();
        int int9 = property3.getDifference((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.year();
        org.joda.time.DateTime dateTime14 = property13.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime16 = property13.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        org.joda.time.DateMidnight dateMidnight21 = dateTime20.toDateMidnight();
        boolean boolean22 = dateTime16.isEqual((org.joda.time.ReadableInstant) dateTime20);
        long long23 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime25 = dateTime16.withMillis(34L);
        org.joda.time.DateTime dateTime27 = dateTime16.plusDays(2019);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.withPeriodAdded(readablePeriod28, 19);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateMidnight21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.util.Locale locale10 = null;
        java.lang.String str11 = cachedDateTimeZone8.getName((long) '#', locale10);
        long long14 = cachedDateTimeZone8.convertLocalToUTC((long) 341, false);
        int int16 = cachedDateTimeZone8.getStandardOffset((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone17 = cachedDateTimeZone8.getUncachedZone();
        java.lang.String str18 = cachedDateTimeZone8.getID();
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(0, (-165), 294, 236, 1283, (org.joda.time.DateTimeZone) cachedDateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 236 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.010" + "'", str11.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 331L + "'", long14 == 331L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.010" + "'", str18.equals("+00:00:00.010"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear(18);
        org.joda.time.Chronology chronology4 = dateTimeFormatter3.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(chronology4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        int int5 = dateTime4.getWeekOfWeekyear();
        int int6 = dateTime4.getMinuteOfHour();
        int int7 = dateTime4.getYear();
        boolean boolean8 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime4);
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime dateTime11 = dateTime4.minus(565L);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        int int7 = dateTime6.getWeekOfWeekyear();
        int int8 = dateTime6.getMinuteOfHour();
        int int9 = property3.getDifference((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.year();
        org.joda.time.DateTime dateTime14 = property13.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime16 = property13.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        org.joda.time.DateMidnight dateMidnight21 = dateTime20.toDateMidnight();
        boolean boolean22 = dateTime16.isEqual((org.joda.time.ReadableInstant) dateTime20);
        long long23 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime25 = dateTime16.withMillis(34L);
        org.joda.time.DateTime dateTime27 = dateTime16.plusDays(2019);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetMillis((int) 'a');
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((java.lang.Object) readablePeriod28, dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateMidnight21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeZone31);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        int int16 = offsetDateTimeField15.getMinimumValue();
        long long18 = offsetDateTimeField15.roundHalfCeiling(0L);
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField15.getAsText(0, locale20);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        int int3 = dateTime2.getWeekOfWeekyear();
        int int4 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
        org.joda.time.DateTime dateTime10 = dateTime2.withHourOfDay(22);
        int int11 = dateTime2.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.DurationField durationField16 = offsetDateTimeField15.getLeapDurationField();
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField15.getAsShortText(45, locale18);
        java.lang.String str21 = offsetDateTimeField15.getAsShortText(292278983L);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.secondOfDay();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime25 = dateTime24.toLocalDateTime();
        int[] intArray27 = gregorianChronology22.get((org.joda.time.ReadablePartial) localDateTime25, 0L);
        int[] intArray31 = new int[] { 448, 1969 };
        try {
            int[] intArray33 = offsetDateTimeField15.addWrapField((org.joda.time.ReadablePartial) localDateTime25, 19, intArray31, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "45" + "'", str19.equals("45"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9709" + "'", str21.equals("9709"));
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        int int3 = dateTime2.getWeekOfWeekyear();
        int int4 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
        org.joda.time.DateTime dateTime10 = dateTime2.withHourOfDay(22);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = dateTimeZone12.convertUTCToLocal((long) 24);
        org.joda.time.DateTime dateTime17 = dateTime10.withZone(dateTimeZone12);
        org.joda.time.DateTime.Property property18 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property19 = dateTime10.weekOfWeekyear();
        org.joda.time.DateTime.Property property20 = dateTime10.yearOfEra();
        org.joda.time.DurationFieldType durationFieldType21 = null;
        try {
            org.joda.time.DateTime dateTime23 = dateTime10.withFieldAdded(durationFieldType21, 77046332);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 34L + "'", long16 == 34L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.DateTime dateTime22 = property21.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime24 = property21.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property25 = dateTime24.minuteOfHour();
        org.joda.time.DateTime dateTime26 = property25.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property25.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, dateTimeFieldType27, 9700, 77045, 0);
        org.joda.time.DurationField durationField32 = offsetDateTimeField31.getLeapDurationField();
        long long34 = offsetDateTimeField31.roundHalfCeiling((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now(dateTimeZone36);
        org.joda.time.TimeOfDay timeOfDay38 = dateTime37.toTimeOfDay();
        boolean boolean39 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay38);
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField31.getAsShortText((org.joda.time.ReadablePartial) timeOfDay38, 134, locale41);
        int int43 = offsetDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay38);
        java.lang.String str45 = offsetDateTimeField15.getAsText((-76896L));
        try {
            long long48 = offsetDateTimeField15.add((-328762800000L), (long) 125);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9702 for minuteOfHour must be in the range [77045,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(timeOfDay38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "134" + "'", str42.equals("134"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9723" + "'", str45.equals("9723"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        int int8 = property7.getLeapAmount();
        org.joda.time.DateTime dateTime10 = property7.addToCopy((-1));
        org.joda.time.DateTime dateTime12 = property7.addToCopy((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.lang.String str14 = dateTime12.toString(dateTimeFormatter13);
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter13.withLocale(locale15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
        java.lang.String str23 = fixedDateTimeZone21.getNameKey((long) 2360);
        java.lang.String str24 = fixedDateTimeZone21.getID();
        int int26 = fixedDateTimeZone21.getOffset(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter16.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        java.lang.String str28 = fixedDateTimeZone21.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "00:10:01.294" + "'", str14.equals("00:10:01.294"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.010" + "'", str23.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.010" + "'", str24.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00:00.010" + "'", str28.equals("+00:00:00.010"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology(chronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(10);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTimeZoneName(strMap9);
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatterBuilder8.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(459, 1975);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 906525 + "'", int2 == 906525);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfMinute(24, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear((int) (short) 10, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendCenturyOfEra(332, 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendMinuteOfHour(455);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 2360);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long9 = fixedDateTimeZone4.convertUTCToLocal((-9350942L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9350942L) + "'", long9 == (-9350942L));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        long long23 = unsupportedDateTimeField20.add((-9350942L), (int) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now(dateTimeZone27);
        org.joda.time.DateTime.Property property29 = dateTime28.year();
        org.joda.time.DateTime dateTime30 = property29.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime32 = property29.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property33 = dateTime32.minuteOfHour();
        org.joda.time.DateTime dateTime34 = property33.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, dateTimeFieldType35, 9700, 77045, 0);
        int int40 = offsetDateTimeField39.getMinimumValue();
        long long42 = offsetDateTimeField39.roundHalfCeiling(0L);
        java.lang.String str43 = offsetDateTimeField39.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology44.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology44.getZone();
        org.joda.time.DurationField durationField47 = gregorianChronology44.eras();
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.hourOfDay();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology48.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime53 = org.joda.time.DateTime.now(dateTimeZone52);
        org.joda.time.DateTime.Property property54 = dateTime53.year();
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime57 = org.joda.time.DateTime.now(dateTimeZone56);
        int int58 = dateTime57.getWeekOfWeekyear();
        int int59 = dateTime57.getMinuteOfHour();
        int int60 = property54.getDifference((org.joda.time.ReadableInstant) dateTime57);
        boolean boolean61 = gregorianChronology48.equals((java.lang.Object) int60);
        org.joda.time.DateTimeZone dateTimeZone63 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now(dateTimeZone63);
        org.joda.time.TimeOfDay timeOfDay65 = dateTime64.toTimeOfDay();
        long long67 = gregorianChronology48.set((org.joda.time.ReadablePartial) timeOfDay65, (-11L));
        long long69 = gregorianChronology44.set((org.joda.time.ReadablePartial) timeOfDay65, (-328838400000L));
        java.util.Locale locale71 = null;
        java.lang.String str72 = offsetDateTimeField39.getAsShortText((org.joda.time.ReadablePartial) timeOfDay65, 448, locale71);
        java.util.Locale locale73 = null;
        try {
            java.lang.String str74 = unsupportedDateTimeField20.getAsText((org.joda.time.ReadablePartial) timeOfDay65, locale73);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 595449058L + "'", long23 == 595449058L);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 77045 + "'", int40 == 77045);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str43.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(dateTimeZone63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(timeOfDay65);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-86398706L) + "'", long67 == (-86398706L));
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-328838398706L) + "'", long69 == (-328838398706L));
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "448" + "'", str72.equals("448"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("+00:00:00.010");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("+00:00:00.010");
        jodaTimePermission1.checkGuard((java.lang.Object) jodaTimePermission3);
        java.security.PermissionCollection permissionCollection5 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology6.getZone();
        org.joda.time.DurationField durationField9 = gregorianChronology6.eras();
        boolean boolean10 = jodaTimePermission1.equals((java.lang.Object) gregorianChronology6);
        java.lang.String str11 = jodaTimePermission1.getName();
        org.junit.Assert.assertNotNull(permissionCollection5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.010" + "'", str11.equals("+00:00:00.010"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(382);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.hourOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.minuteOfDay();
        org.joda.time.DurationField durationField24 = gregorianChronology21.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
        try {
            int int27 = unsupportedDateTimeField25.getMinimumValue((-128044800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.weekyears();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        long long23 = unsupportedDateTimeField20.add((-9350942L), (int) (byte) 1);
        java.lang.String str24 = unsupportedDateTimeField20.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 595449058L + "'", long23 == 595449058L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UnsupportedDateTimeField" + "'", str24.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property5 = dateTime4.monthOfYear();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getLeapDurationField();
        boolean boolean22 = unsupportedDateTimeField20.isSupported();
        long long25 = unsupportedDateTimeField20.add((-328838400000L), 332);
        try {
            long long28 = unsupportedDateTimeField20.set((long) 788, (-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-128044800000L) + "'", long25 == (-128044800000L));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.Locale locale5 = null;
        java.lang.String str6 = cachedDateTimeZone3.getName((long) '#', locale5);
        long long9 = cachedDateTimeZone3.convertLocalToUTC((long) 341, false);
        int int11 = cachedDateTimeZone3.getStandardOffset((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone3.getUncachedZone();
        java.lang.String str13 = cachedDateTimeZone3.getID();
        int int15 = cachedDateTimeZone3.getStandardOffset((long) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 331L + "'", long9 == 331L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00:00.010" + "'", str13.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        int int16 = offsetDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) (short) 1);
        int int24 = dateTime19.getMinuteOfDay();
        org.joda.time.DateTime dateTime26 = dateTime19.plusSeconds((int) (short) -1);
        long long27 = dateTime19.getMillis();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
        java.lang.Class<?> wildcardClass32 = timeOfDay31.getClass();
        org.joda.time.DateTime dateTime33 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay31, locale34);
        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField15.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone38);
        int int40 = dateTime39.getWeekOfWeekyear();
        int int41 = dateTime39.getMinuteOfHour();
        org.joda.time.DateTime dateTime43 = dateTime39.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime45 = dateTime39.minusSeconds(0);
        org.joda.time.DateTime dateTime47 = dateTime39.withHourOfDay(22);
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now(dateTimeZone49);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone51 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone49);
        long long53 = dateTimeZone49.convertUTCToLocal((long) 24);
        org.joda.time.DateTime dateTime54 = dateTime47.withZone(dateTimeZone49);
        org.joda.time.DateTime.Property property55 = dateTime47.dayOfYear();
        org.joda.time.DateTime.Property property56 = dateTime47.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder57.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder59.appendLiteral('a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.Chronology chronology63 = dateTimeFormatter62.getChronology();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder59.append(dateTimeFormatter62);
        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology65.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now(dateTimeZone68);
        org.joda.time.DateTime.Property property70 = dateTime69.year();
        org.joda.time.DateTime dateTime71 = property70.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime73 = property70.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property74 = dateTime73.minuteOfHour();
        org.joda.time.DateTime dateTime75 = property74.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType76 = property74.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, dateTimeFieldType76, 9700, 77045, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder59.appendFixedDecimal(dateTimeFieldType76, 134);
        org.joda.time.DateTime.Property property83 = dateTime47.property(dateTimeFieldType76);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField85 = new org.joda.time.field.DividedDateTimeField(dateTimeField36, dateTimeFieldType76, 18);
        int int87 = dividedDateTimeField85.get((long) (byte) 100);
        long long89 = dividedDateTimeField85.roundFloor(10L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1284L + "'", long27 == 1284L);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(timeOfDay31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(cachedDateTimeZone51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 34L + "'", long53 == 34L);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(dateTimeFormatter62);
        org.junit.Assert.assertNull(chronology63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(gregorianChronology65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(dateTimeFieldType76);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
        org.junit.Assert.assertNotNull(property83);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 0L + "'", long89 == 0L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gregorianChronology0.add(readablePeriod5, (long) 565, 135);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 565L + "'", long8 == 565L);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.TimeOfDay timeOfDay6 = dateTime5.toTimeOfDay();
        int int7 = dateTime5.getMillisOfSecond();
        org.joda.time.DateTime dateTime9 = dateTime5.minusYears(0);
        org.joda.time.DateTime dateTime11 = dateTime9.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
        org.joda.time.DateTime.Property property15 = dateTime14.year();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        int int19 = dateTime18.getWeekOfWeekyear();
        int int20 = dateTime18.getMinuteOfHour();
        int int21 = property15.getDifference((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.LocalTime localTime22 = dateTime18.toLocalTime();
        org.joda.time.DateTime dateTime23 = dateTime9.withFields((org.joda.time.ReadablePartial) localTime22);
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadablePartial) localTime22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(timeOfDay6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 294 + "'", int7 == 294);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(localTime22);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) iSOChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property5 = dateTime4.monthOfYear();
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((-292275054));
        org.joda.time.DateTime dateTime9 = dateTime7.plus(0L);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis(148);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 10, (java.lang.Number) 565, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        int int8 = property7.getLeapAmount();
        org.joda.time.DateTime dateTime10 = property7.addToCopy((-1));
        org.joda.time.DateTime dateTime12 = property7.addToCopy((int) (byte) 10);
        org.joda.time.DateTime dateTime13 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.DateTime.Property property19 = dateTime18.year();
        org.joda.time.DateTime dateTime20 = property19.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime22 = property19.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property23 = dateTime22.minuteOfHour();
        org.joda.time.DateTime dateTime24 = property23.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, dateTimeFieldType25, 9700, 77045, 0);
        int int30 = offsetDateTimeField29.getMinimumValue();
        long long32 = offsetDateTimeField29.roundHalfCeiling(0L);
        java.lang.String str33 = offsetDateTimeField29.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology34.getZone();
        org.joda.time.DurationField durationField37 = gregorianChronology34.eras();
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.hourOfDay();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
        org.joda.time.DateTime.Property property44 = dateTime43.year();
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now(dateTimeZone46);
        int int48 = dateTime47.getWeekOfWeekyear();
        int int49 = dateTime47.getMinuteOfHour();
        int int50 = property44.getDifference((org.joda.time.ReadableInstant) dateTime47);
        boolean boolean51 = gregorianChronology38.equals((java.lang.Object) int50);
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now(dateTimeZone53);
        org.joda.time.TimeOfDay timeOfDay55 = dateTime54.toTimeOfDay();
        long long57 = gregorianChronology38.set((org.joda.time.ReadablePartial) timeOfDay55, (-11L));
        long long59 = gregorianChronology34.set((org.joda.time.ReadablePartial) timeOfDay55, (-328838400000L));
        java.util.Locale locale61 = null;
        java.lang.String str62 = offsetDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) timeOfDay55, 448, locale61);
        int int63 = dateTime12.get((org.joda.time.DateTimeField) offsetDateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 77045 + "'", int30 == 77045);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str33.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(timeOfDay55);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-86398706L) + "'", long57 == (-86398706L));
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-328838398706L) + "'", long59 == (-328838398706L));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "448" + "'", str62.equals("448"));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 9700 + "'", int63 == 9700);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 62, (java.lang.Number) 24, (java.lang.Number) (byte) 100);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number8 = illegalFieldValueException4.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 24 + "'", number5.equals(24));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "62" + "'", str6.equals("62"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 62 + "'", number8.equals(62));
        org.junit.Assert.assertNull(durationFieldType9);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        int int16 = offsetDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField15.getWrappedField();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology23.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.secondOfDay();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime29 = dateTime28.toLocalDateTime();
        int[] intArray31 = gregorianChronology26.get((org.joda.time.ReadablePartial) localDateTime29, 0L);
        int[] intArray33 = gregorianChronology23.get((org.joda.time.ReadablePartial) localDateTime29, 14332974220L);
        boolean boolean34 = fixedDateTimeZone22.isLocalDateTimeGap(localDateTime29);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.secondOfDay();
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime38 = dateTime37.toLocalDateTime();
        int[] intArray40 = gregorianChronology35.get((org.joda.time.ReadablePartial) localDateTime38, 0L);
        int int41 = offsetDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDateTime29, intArray40);
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now(dateTimeZone43);
        int int45 = dateTime44.getWeekOfWeekyear();
        int int46 = dateTime44.getMinuteOfHour();
        org.joda.time.DateTime dateTime48 = dateTime44.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime50 = dateTime44.minusSeconds(0);
        org.joda.time.DateTime dateTime52 = dateTime44.withHourOfDay(22);
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime55 = org.joda.time.DateTime.now(dateTimeZone54);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone56 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone54);
        long long58 = dateTimeZone54.convertUTCToLocal((long) 24);
        org.joda.time.DateTime dateTime59 = dateTime52.withZone(dateTimeZone54);
        org.joda.time.DateTime.Property property60 = dateTime52.dayOfYear();
        org.joda.time.DateTime.Property property61 = dateTime52.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder62.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder64.appendLiteral('a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter67 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.Chronology chronology68 = dateTimeFormatter67.getChronology();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder64.append(dateTimeFormatter67);
        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField71 = gregorianChronology70.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime74 = org.joda.time.DateTime.now(dateTimeZone73);
        org.joda.time.DateTime.Property property75 = dateTime74.year();
        org.joda.time.DateTime dateTime76 = property75.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime78 = property75.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property79 = dateTime78.minuteOfHour();
        org.joda.time.DateTime dateTime80 = property79.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType81 = property79.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField85 = new org.joda.time.field.OffsetDateTimeField(dateTimeField71, dateTimeFieldType81, 9700, 77045, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder87 = dateTimeFormatterBuilder64.appendFixedDecimal(dateTimeFieldType81, 134);
        org.joda.time.DateTime.Property property88 = dateTime52.property(dateTimeFieldType81);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField89 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, dateTimeFieldType81);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(localDateTime29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(localDateTime38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 77045 + "'", int41 == 77045);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(cachedDateTimeZone56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 34L + "'", long58 == 34L);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
        org.junit.Assert.assertNotNull(dateTimeFormatter67);
        org.junit.Assert.assertNull(chronology68);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
        org.junit.Assert.assertNotNull(gregorianChronology70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(dateTimeZone73);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(property75);
        org.junit.Assert.assertNotNull(dateTime76);
        org.junit.Assert.assertNotNull(dateTime78);
        org.junit.Assert.assertNotNull(property79);
        org.junit.Assert.assertNotNull(dateTime80);
        org.junit.Assert.assertNotNull(dateTimeFieldType81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder87);
        org.junit.Assert.assertNotNull(property88);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology(chronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withPivotYear(292278993);
        try {
            java.lang.String str6 = dateTimeFormatter4.print((long) 372);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
        java.lang.String str7 = fixedDateTimeZone5.getNameKey((long) 2360);
        long long9 = fixedDateTimeZone5.nextTransition(0L);
        java.util.TimeZone timeZone10 = fixedDateTimeZone5.toTimeZone();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 62, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str12 = fixedDateTimeZone5.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.010" + "'", str12.equals("+00:00:00.010"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology(chronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTimeZoneShortName(strMap10);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMinuteOfHour((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMinuteOfDay(67552);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendDayOfMonth(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendTwoDigitWeekyear(455);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        int int4 = dateTime3.getWeekOfWeekyear();
        int int5 = dateTime3.getMinuteOfHour();
        org.joda.time.DateTime dateTime7 = dateTime3.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime3.minusSeconds(0);
        org.joda.time.DateTime dateTime11 = dateTime3.withHourOfDay(22);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
        long long17 = dateTimeZone13.convertUTCToLocal((long) 24);
        org.joda.time.DateTime dateTime18 = dateTime11.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(obj0, dateTimeZone13);
        org.joda.time.DateTime dateTime21 = dateTime19.plus((long) 559);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(dateTimeZone23);
        java.lang.String str25 = dateTimeZone23.toString();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(dateTimeZone28);
        int int30 = dateTime29.getWeekOfWeekyear();
        int int31 = dateTime29.getMinuteOfHour();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime33 = dateTime32.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now(dateTimeZone35);
        int int37 = dateTime36.getWeekOfWeekyear();
        int int38 = dateTime36.getMinuteOfHour();
        int int39 = dateTime36.getYear();
        boolean boolean40 = dateTime32.isAfter((org.joda.time.ReadableInstant) dateTime36);
        org.joda.time.DateTime.Property property41 = dateTime36.year();
        int int42 = dateTime29.compareTo((org.joda.time.ReadableInstant) dateTime36);
        int int43 = dateTimeZone23.getOffset((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime44 = dateTime21.toDateTime(dateTimeZone23);
        org.joda.time.DurationFieldType durationFieldType45 = null;
        try {
            org.joda.time.DateTime dateTime47 = dateTime21.withFieldAdded(durationFieldType45, 135);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 34L + "'", long17 == 34L);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.010" + "'", str25.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1970 + "'", int39 == 1970);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
        org.junit.Assert.assertNotNull(dateTime44);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        java.util.Locale locale16 = null;
        int int17 = offsetDateTimeField15.getMaximumShortTextLength(locale16);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.Locale locale5 = null;
        java.lang.String str6 = cachedDateTimeZone3.getName((long) '#', locale5);
        long long8 = cachedDateTimeZone3.convertUTCToLocal((-1L));
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9L + "'", long8 == 9L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = iSOChronology0.equals(obj1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        int int3 = dateTime2.getWeekOfWeekyear();
        int int4 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
        org.joda.time.DateTime dateTime10 = dateTime2.withHourOfDay(22);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = dateTimeZone12.convertUTCToLocal((long) 24);
        org.joda.time.DateTime dateTime17 = dateTime10.withZone(dateTimeZone12);
        org.joda.time.DateTime.Property property18 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property19 = dateTime10.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField20 = property19.getField();
        org.joda.time.DurationField durationField21 = property19.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 34L + "'", long16 == 34L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNull(durationField21);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        int int16 = offsetDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) (short) 1);
        int int24 = dateTime19.getMinuteOfDay();
        org.joda.time.DateTime dateTime26 = dateTime19.plusSeconds((int) (short) -1);
        long long27 = dateTime19.getMillis();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
        java.lang.Class<?> wildcardClass32 = timeOfDay31.getClass();
        org.joda.time.DateTime dateTime33 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay31, locale34);
        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField15.getWrappedField();
        long long38 = offsetDateTimeField15.roundHalfEven(83L);
        boolean boolean40 = offsetDateTimeField15.isLeap((-128044800000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1284L + "'", long27 == 1284L);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(timeOfDay31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
        int int4 = dateTime2.getMillisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.minusYears(0);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime10.year();
        org.joda.time.DateTime dateTime12 = property11.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime14 = property11.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property15 = dateTime14.minuteOfHour();
        org.joda.time.DateTime dateTime16 = property15.withMinimumValue();
        boolean boolean17 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime16);
        int int18 = dateTime6.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 294 + "'", int4 == 294);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        int int3 = dateTime2.getWeekOfWeekyear();
        int int4 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
        int int7 = dateTime2.getSecondOfDay();
        int int8 = dateTime2.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1294 + "'", int8 == 1294);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology(chronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(10);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTimeZoneName(strMap9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMinuteOfHour(9700);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMinuteOfHour((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMinuteOfDay(67552);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendFractionOfSecond(0, 189);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder2.appendTimeZoneOffset("ISOChronology[UTC]", "18:55:57.663", false, (int) (short) 10, 45);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendWeekyear(788, 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMinuteOfHour((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMinuteOfDay(67552);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap7);
        boolean boolean9 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder2.appendMinuteOfHour((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.lang.Object obj2 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        int int6 = dateTime5.getWeekOfWeekyear();
        int int7 = dateTime5.getMinuteOfHour();
        org.joda.time.DateTime dateTime9 = dateTime5.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime11 = dateTime5.minusSeconds(0);
        org.joda.time.DateTime dateTime13 = dateTime5.withHourOfDay(22);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        long long19 = dateTimeZone15.convertUTCToLocal((long) 24);
        org.joda.time.DateTime dateTime20 = dateTime13.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(obj2, dateTimeZone15);
        java.lang.String str22 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 34L + "'", long19 == 34L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "T000001+0000" + "'", str22.equals("T000001+0000"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        int int16 = offsetDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField15.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        org.joda.time.TimeOfDay timeOfDay21 = dateTime20.toTimeOfDay();
        int int22 = dateTime20.getMillisOfSecond();
        org.joda.time.DateTime dateTime24 = dateTime20.minusYears(0);
        org.joda.time.DateTime.Property property25 = dateTime24.centuryOfEra();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendMillisOfSecond(24);
        boolean boolean29 = dateTimeFormatterBuilder28.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder28.appendMinuteOfHour(77045);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now(dateTimeZone33);
        int int35 = dateTime34.getWeekOfWeekyear();
        int int36 = dateTime34.getMinuteOfHour();
        org.joda.time.DateTime dateTime38 = dateTime34.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime40 = dateTime34.minusSeconds(0);
        org.joda.time.DateTime dateTime42 = dateTime34.withHourOfDay(22);
        org.joda.time.DateTime.Property property43 = dateTime34.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder28.appendShortText(dateTimeFieldType44);
        org.joda.time.DateTime.Property property46 = dateTime24.property(dateTimeFieldType44);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType44, 2019);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(timeOfDay21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 294 + "'", int22 == 294);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(property46);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology(chronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfEra(10, 236);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral("18:55:52.592");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMinuteOfHour(100);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getLeapDurationField();
        boolean boolean22 = unsupportedDateTimeField20.isSupported();
        long long25 = unsupportedDateTimeField20.add((-328838400000L), 332);
        java.lang.String str26 = unsupportedDateTimeField20.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-128044800000L) + "'", long25 == (-128044800000L));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "minuteOfHour" + "'", str26.equals("minuteOfHour"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        java.lang.String str4 = dateTime2.toString(dateTimeFormatter3);
        int int5 = dateTime2.getHourOfDay();
        int int6 = dateTime2.getYear();
        org.joda.time.DateTime dateTime8 = dateTime2.plusYears(6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-001T00:00:01.294+00:00:00.010" + "'", str4.equals("1970-001T00:00:01.294+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        long long23 = unsupportedDateTimeField20.add((-9350942L), (int) (byte) 1);
        long long26 = unsupportedDateTimeField20.getDifferenceAsLong((long) (short) 1, 31742L);
        try {
            long long28 = unsupportedDateTimeField20.roundHalfFloor((long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 595449058L + "'", long23 == 595449058L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        int int3 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        int int16 = offsetDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField15.getWrappedField();
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField15.getAsShortText((long) (byte) -1, locale19);
        int int21 = offsetDateTimeField15.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "9723" + "'", str20.equals("9723"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9700 + "'", int21 == 9700);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.DurationField durationField16 = offsetDateTimeField15.getLeapDurationField();
        org.joda.time.DurationField durationField17 = offsetDateTimeField15.getDurationField();
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField15.getAsShortText(1284L, locale19);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "9700" + "'", str20.equals("9700"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 189);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfDay();
        org.joda.time.DateTime dateTime9 = property8.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime10 = property8.withMaximumValue();
        org.joda.time.DateTime dateTime12 = dateTime10.minusWeeks(10);
        org.joda.time.DateTime dateTime13 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime15 = dateTime10.withCenturyOfEra(36);
        long long16 = dateTime10.getMillis();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31449658716L) + "'", long16 == (-31449658716L));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
        boolean boolean5 = dateTime2.isAfter((-9350942L));
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.hourOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.year();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getWeekOfWeekyear();
        int int17 = dateTime15.getMinuteOfHour();
        int int18 = property12.getDifference((org.joda.time.ReadableInstant) dateTime15);
        boolean boolean19 = gregorianChronology6.equals((java.lang.Object) int18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology6.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology6.getZone();
        org.joda.time.MutableDateTime mutableDateTime22 = dateTime2.toMutableDateTime((org.joda.time.Chronology) gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(mutableDateTime22);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        java.util.Locale locale7 = null;
        java.lang.String str8 = cachedDateTimeZone5.getName((long) '#', locale7);
        long long11 = cachedDateTimeZone5.convertLocalToUTC((long) 341, false);
        int int13 = cachedDateTimeZone5.getStandardOffset((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = cachedDateTimeZone5.getUncachedZone();
        boolean boolean15 = iSOChronology0.equals((java.lang.Object) dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.010" + "'", str8.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 331L + "'", long11 == 331L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        long long23 = unsupportedDateTimeField20.add((-9350942L), (int) (byte) 1);
        long long26 = unsupportedDateTimeField20.getDifferenceAsLong((long) (short) 1, 31742L);
        boolean boolean27 = unsupportedDateTimeField20.isLenient();
        try {
            long long30 = unsupportedDateTimeField20.set(6L, "448");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 595449058L + "'", long23 == 595449058L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.withDurationAdded(readableDuration4, (int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime2.minusYears(9);
        org.joda.time.DateTime dateTime11 = dateTime8.withDurationAdded((long) 788, 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology(chronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfEra(10, 236);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral("18:55:52.592");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("+00:00:00.010");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("+00:00:00.010");
        jodaTimePermission1.checkGuard((java.lang.Object) jodaTimePermission3);
        java.lang.String str5 = jodaTimePermission3.getName();
        java.lang.String str6 = jodaTimePermission3.getName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.010" + "'", str5.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.hourOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.minuteOfDay();
        org.joda.time.DurationField durationField24 = gregorianChronology21.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = unsupportedDateTimeField25.getType();
        long long29 = unsupportedDateTimeField25.getDifferenceAsLong((long) (byte) 100, 0L);
        try {
            long long31 = unsupportedDateTimeField25.roundHalfEven((long) 67552);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        int int16 = offsetDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) (short) 1);
        int int24 = dateTime19.getMinuteOfDay();
        org.joda.time.DateTime dateTime26 = dateTime19.plusSeconds((int) (short) -1);
        long long27 = dateTime19.getMillis();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
        java.lang.Class<?> wildcardClass32 = timeOfDay31.getClass();
        org.joda.time.DateTime dateTime33 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay31, locale34);
        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField15.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone38);
        int int40 = dateTime39.getWeekOfWeekyear();
        int int41 = dateTime39.getMinuteOfHour();
        org.joda.time.DateTime dateTime43 = dateTime39.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime45 = dateTime39.minusSeconds(0);
        org.joda.time.DateTime dateTime47 = dateTime39.withHourOfDay(22);
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now(dateTimeZone49);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone51 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone49);
        long long53 = dateTimeZone49.convertUTCToLocal((long) 24);
        org.joda.time.DateTime dateTime54 = dateTime47.withZone(dateTimeZone49);
        org.joda.time.DateTime.Property property55 = dateTime47.dayOfYear();
        org.joda.time.DateTime.Property property56 = dateTime47.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder57.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder59.appendLiteral('a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.Chronology chronology63 = dateTimeFormatter62.getChronology();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder59.append(dateTimeFormatter62);
        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology65.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now(dateTimeZone68);
        org.joda.time.DateTime.Property property70 = dateTime69.year();
        org.joda.time.DateTime dateTime71 = property70.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime73 = property70.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property74 = dateTime73.minuteOfHour();
        org.joda.time.DateTime dateTime75 = property74.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType76 = property74.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, dateTimeFieldType76, 9700, 77045, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder59.appendFixedDecimal(dateTimeFieldType76, 134);
        org.joda.time.DateTime.Property property83 = dateTime47.property(dateTimeFieldType76);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField85 = new org.joda.time.field.DividedDateTimeField(dateTimeField36, dateTimeFieldType76, 18);
        int int88 = dividedDateTimeField85.getDifference((long) 0, (long) 294);
        org.joda.time.DurationField durationField89 = dividedDateTimeField85.getDurationField();
        long long92 = dividedDateTimeField85.set((long) (-292275054), 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1284L + "'", long27 == 1284L);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(timeOfDay31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(cachedDateTimeZone51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 34L + "'", long53 == 34L);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(dateTimeFormatter62);
        org.junit.Assert.assertNull(chronology63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(gregorianChronology65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(dateTimeFieldType76);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
        org.junit.Assert.assertNotNull(property83);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertNotNull(durationField89);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + (-292275054L) + "'", long92 == (-292275054L));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        int int16 = offsetDateTimeField15.getMinimumValue();
        long long18 = offsetDateTimeField15.roundHalfCeiling(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology19.getZone();
        org.joda.time.DurationField durationField22 = gregorianChronology19.eras();
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.hourOfDay();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now(dateTimeZone27);
        org.joda.time.DateTime.Property property29 = dateTime28.year();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(dateTimeZone31);
        int int33 = dateTime32.getWeekOfWeekyear();
        int int34 = dateTime32.getMinuteOfHour();
        int int35 = property29.getDifference((org.joda.time.ReadableInstant) dateTime32);
        boolean boolean36 = gregorianChronology23.equals((java.lang.Object) int35);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone38);
        org.joda.time.TimeOfDay timeOfDay40 = dateTime39.toTimeOfDay();
        long long42 = gregorianChronology23.set((org.joda.time.ReadablePartial) timeOfDay40, (-11L));
        long long44 = gregorianChronology19.set((org.joda.time.ReadablePartial) timeOfDay40, (-328838400000L));
        java.util.Locale locale45 = null;
        java.lang.String str46 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay40, locale45);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(timeOfDay40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-86398706L) + "'", long42 == (-86398706L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-328838398706L) + "'", long44 == (-328838398706L));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "0" + "'", str46.equals("0"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
        long long10 = fixedDateTimeZone8.nextTransition((long) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        try {
            long long16 = zonedChronology11.getDateTimeMillis(2019, 77047148, 4, 538);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 77047148 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(zonedChronology11);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 77046332, 36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        int int3 = dateTime2.getWeekOfWeekyear();
        int int4 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
        org.joda.time.DateTime dateTime10 = dateTime2.withHourOfDay(22);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long16 = dateTimeZone12.convertUTCToLocal((long) 24);
        org.joda.time.DateTime dateTime17 = dateTime10.withZone(dateTimeZone12);
        org.joda.time.DateTime.Property property18 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property19 = dateTime10.weekOfWeekyear();
        org.joda.time.DateTime.Property property20 = dateTime10.yearOfEra();
        org.joda.time.DateTime dateTime22 = property20.setCopy(1283);
        java.util.Locale locale23 = null;
        java.lang.String str24 = property20.getAsShortText(locale23);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 34L + "'", long16 == 34L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1970" + "'", str24.equals("1970"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.hourOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.minuteOfDay();
        org.joda.time.DurationField durationField24 = gregorianChronology21.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = unsupportedDateTimeField25.getType();
        long long29 = unsupportedDateTimeField25.getDifferenceAsLong((long) (byte) 100, 0L);
        try {
            java.lang.String str31 = unsupportedDateTimeField25.getAsText((-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getLeapDurationField();
        boolean boolean22 = unsupportedDateTimeField20.isSupported();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime25 = dateTime23.minus((long) (byte) -1);
        org.joda.time.DateTime dateTime27 = dateTime25.withYear(448);
        org.joda.time.LocalDate localDate28 = dateTime27.toLocalDate();
        java.util.Locale locale29 = null;
        try {
            java.lang.String str30 = unsupportedDateTimeField20.getAsText((org.joda.time.ReadablePartial) localDate28, locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(localDate28);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        int int3 = dateTime2.getWeekOfWeekyear();
        int int4 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
        org.joda.time.DateTime dateTime10 = dateTime2.withDayOfMonth((int) (short) 1);
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded((long) 1439, 166);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "9721", "GregorianChronology[+00:00:00.052]");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.yearOfEra();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (byte) 0, 1284, (-101), 2019, 0, 67552, 1439, (org.joda.time.Chronology) iSOChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfCentury(0);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
        org.joda.time.DateTime dateTime6 = property4.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 62, (java.lang.Number) 24, (java.lang.Number) (byte) 100);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        java.lang.String str8 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 24 + "'", number5.equals(24));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "62" + "'", str6.equals("62"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 100 + "'", number7.equals((byte) 100));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.year();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getWeekOfWeekyear();
        int int17 = dateTime15.getMinuteOfHour();
        int int18 = property12.getDifference((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.year();
        org.joda.time.DateTime dateTime23 = property22.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime25 = property22.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property26 = dateTime25.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(dateTimeZone28);
        org.joda.time.DateMidnight dateMidnight30 = dateTime29.toDateMidnight();
        boolean boolean31 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime29);
        long long32 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime25);
        boolean boolean33 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.DateTime dateTime36 = dateTime25.withDurationAdded(readableDuration34, (int) (short) 100);
        org.joda.time.DateTime.Property property37 = dateTime36.weekyear();
        org.joda.time.DateTime dateTime39 = property37.addWrapFieldToCopy(341);
        try {
            org.joda.time.DateTime dateTime41 = dateTime39.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateMidnight30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime39);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        int int16 = offsetDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) (short) 1);
        int int24 = dateTime19.getMinuteOfDay();
        org.joda.time.DateTime dateTime26 = dateTime19.plusSeconds((int) (short) -1);
        long long27 = dateTime19.getMillis();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
        java.lang.Class<?> wildcardClass32 = timeOfDay31.getClass();
        org.joda.time.DateTime dateTime33 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay31, locale34);
        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField15.getWrappedField();
        long long38 = offsetDateTimeField15.roundHalfEven(83L);
        int int41 = offsetDateTimeField15.getDifference((long) 372, (long) (-165));
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now(dateTimeZone43);
        org.joda.time.TimeOfDay timeOfDay45 = dateTime44.toTimeOfDay();
        java.lang.Class<?> wildcardClass46 = timeOfDay45.getClass();
        java.util.Locale locale48 = null;
        java.lang.String str49 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) timeOfDay45, (int) (short) 10, locale48);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1284L + "'", long27 == 1284L);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(timeOfDay31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(timeOfDay45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "10" + "'", str49.equals("10"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        int int16 = offsetDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) (short) 1);
        int int24 = dateTime19.getMinuteOfDay();
        org.joda.time.DateTime dateTime26 = dateTime19.plusSeconds((int) (short) -1);
        long long27 = dateTime19.getMillis();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
        java.lang.Class<?> wildcardClass32 = timeOfDay31.getClass();
        org.joda.time.DateTime dateTime33 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay31, locale34);
        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField15.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone38);
        int int40 = dateTime39.getWeekOfWeekyear();
        int int41 = dateTime39.getMinuteOfHour();
        org.joda.time.DateTime dateTime43 = dateTime39.minusWeeks((int) ' ');
        org.joda.time.DateTime dateTime45 = dateTime39.minusSeconds(0);
        org.joda.time.DateTime dateTime47 = dateTime39.withHourOfDay(22);
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now(dateTimeZone49);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone51 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone49);
        long long53 = dateTimeZone49.convertUTCToLocal((long) 24);
        org.joda.time.DateTime dateTime54 = dateTime47.withZone(dateTimeZone49);
        org.joda.time.DateTime.Property property55 = dateTime47.dayOfYear();
        org.joda.time.DateTime.Property property56 = dateTime47.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder57.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder59.appendLiteral('a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.Chronology chronology63 = dateTimeFormatter62.getChronology();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder59.append(dateTimeFormatter62);
        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology65.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now(dateTimeZone68);
        org.joda.time.DateTime.Property property70 = dateTime69.year();
        org.joda.time.DateTime dateTime71 = property70.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime73 = property70.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property74 = dateTime73.minuteOfHour();
        org.joda.time.DateTime dateTime75 = property74.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType76 = property74.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, dateTimeFieldType76, 9700, 77045, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder59.appendFixedDecimal(dateTimeFieldType76, 134);
        org.joda.time.DateTime.Property property83 = dateTime47.property(dateTimeFieldType76);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField85 = new org.joda.time.field.DividedDateTimeField(dateTimeField36, dateTimeFieldType76, 18);
        int int87 = dividedDateTimeField85.get((long) (byte) 100);
        int int89 = dividedDateTimeField85.get((long) 2000);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1284L + "'", long27 == 1284L);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(timeOfDay31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(cachedDateTimeZone51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 34L + "'", long53 == 34L);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(dateTimeFormatter62);
        org.junit.Assert.assertNull(chronology63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(gregorianChronology65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(dateTimeFieldType76);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
        org.junit.Assert.assertNotNull(property83);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = iSOChronology0.equals(obj1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.TimeOfDay timeOfDay5 = dateTime4.toTimeOfDay();
        int int6 = dateTime4.getMillisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime4.minusYears(0);
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime13.year();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
        int int18 = dateTime17.getWeekOfWeekyear();
        int int19 = dateTime17.getMinuteOfHour();
        int int20 = property14.getDifference((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.LocalTime localTime21 = dateTime17.toLocalTime();
        org.joda.time.DateTime dateTime22 = dateTime8.withFields((org.joda.time.ReadablePartial) localTime21);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localTime21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(timeOfDay5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 294 + "'", int6 == 294);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 18, dateTimeZone2);
        org.joda.time.DateTime dateTime6 = dateTime4.withCenturyOfEra(0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMonths(24);
        org.joda.time.DateTime dateTime7 = dateTime5.withMillisOfDay(9);
        boolean boolean9 = dateTime5.isEqual((long) (short) -1);
        org.joda.time.DateTime dateTime10 = dateTime5.toDateTime();
        org.joda.time.DateTime dateTime12 = dateTime5.plusMonths(559);
        org.joda.time.DateTime dateTime13 = dateTime5.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
        int int4 = dateTime2.getMillisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime2.minusYears(0);
        org.joda.time.DateTime dateTime8 = dateTime2.withWeekyear((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime8.plus(1L);
        boolean boolean12 = dateTime8.isBefore((long) 415);
        int int13 = dateTime8.getMillisOfDay();
        org.joda.time.LocalTime localTime14 = dateTime8.toLocalTime();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 294 + "'", int4 == 294);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1294 + "'", int13 == 1294);
        org.junit.Assert.assertNotNull(localTime14);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", 1283, 0, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1283 for  must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.halfdays();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField4 = new org.joda.time.field.ScaledDurationField(durationField1, durationFieldType2, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        int int16 = offsetDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) (short) 1);
        int int24 = dateTime19.getMinuteOfDay();
        org.joda.time.DateTime dateTime26 = dateTime19.plusSeconds((int) (short) -1);
        long long27 = dateTime19.getMillis();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
        java.lang.Class<?> wildcardClass32 = timeOfDay31.getClass();
        org.joda.time.DateTime dateTime33 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay31, locale34);
        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField15.getWrappedField();
        org.joda.time.DurationField durationField37 = offsetDateTimeField15.getDurationField();
        boolean boolean38 = offsetDateTimeField15.isSupported();
        boolean boolean39 = offsetDateTimeField15.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1284L + "'", long27 == 1284L);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(timeOfDay31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(9690L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime8 = property7.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 36, "20");
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "9721");
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = cachedDateTimeZone3.getName((long) '#', locale5);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
//        org.joda.time.DateTime.Property property10 = dateTime9.year();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
//        int int14 = dateTime13.getWeekOfWeekyear();
//        int int15 = dateTime13.getMinuteOfHour();
//        int int16 = property10.getDifference((org.joda.time.ReadableInstant) dateTime13);
//        boolean boolean17 = cachedDateTimeZone3.equals((java.lang.Object) int16);
//        java.lang.String str19 = cachedDateTimeZone3.getShortName((long) ' ');
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone3);
//        org.joda.time.Chronology chronology21 = gregorianChronology20.withUTC();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.dayOfMonth();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00:00.010" + "'", str19.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
//        org.joda.time.DateTime dateTime5 = dateTime2.minusMonths(24);
//        org.joda.time.DateTime.Property property6 = dateTime5.minuteOfDay();
//        int int7 = property6.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime8 = property6.roundCeilingCopy();
//        java.lang.String str9 = property6.getAsShortText();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
//        org.joda.time.DateTime.Property property13 = dateTime12.year();
//        org.joda.time.DateTime dateTime14 = property13.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime16 = property13.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property17 = dateTime16.minuteOfHour();
//        int int18 = property17.getLeapAmount();
//        org.joda.time.DateTime dateTime20 = property17.addToCopy((-1));
//        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
//        int int22 = property6.compareTo((org.joda.time.ReadablePartial) localTime21);
//        org.joda.time.DateTime dateTime23 = property6.withMaximumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1284" + "'", str9.equals("1284"));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        long long23 = unsupportedDateTimeField20.add((-9350942L), (int) (byte) 1);
        boolean boolean24 = unsupportedDateTimeField20.isLenient();
        try {
            int int26 = unsupportedDateTimeField20.getLeapAmount((long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 595449058L + "'", long23 == 595449058L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 2360);
        int int8 = fixedDateTimeZone4.getOffset((-1L));
        long long10 = fixedDateTimeZone4.previousTransition((long) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DurationField durationField12 = gregorianChronology11.months();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        int int3 = dateTime2.getWeekOfWeekyear();
//        int int4 = dateTime2.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
//        org.joda.time.DateTime dateTime10 = dateTime2.withHourOfDay(22);
//        org.joda.time.DateTime.Property property11 = dateTime2.minuteOfDay();
//        java.lang.String str12 = property11.getAsText();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1284" + "'", str12.equals("1284"));
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getLeapDurationField();
        boolean boolean22 = unsupportedDateTimeField20.isSupported();
        long long25 = unsupportedDateTimeField20.add((-328838400000L), 332);
        org.joda.time.DurationField durationField26 = unsupportedDateTimeField20.getDurationField();
        java.lang.String str27 = unsupportedDateTimeField20.toString();
        java.lang.String str28 = unsupportedDateTimeField20.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-128044800000L) + "'", long25 == (-128044800000L));
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "UnsupportedDateTimeField" + "'", str27.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UnsupportedDateTimeField" + "'", str28.equals("UnsupportedDateTimeField"));
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
//        int int7 = dateTime6.getWeekOfWeekyear();
//        int int8 = dateTime6.getMinuteOfHour();
//        int int9 = property3.getDifference((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
//        org.joda.time.DateTime.Property property13 = dateTime12.year();
//        org.joda.time.DateTime dateTime14 = property13.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime16 = property13.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property17 = dateTime16.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
//        org.joda.time.DateMidnight dateMidnight21 = dateTime20.toDateMidnight();
//        boolean boolean22 = dateTime16.isEqual((org.joda.time.ReadableInstant) dateTime20);
//        long long23 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime25 = dateTime16.withMillis(34L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTime16.toString("18:55:52.592", locale27);
//        org.joda.time.DateTime dateTime30 = dateTime16.minusYears(1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateMidnight21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "18:55:52.592" + "'", str28.equals("18:55:52.592"));
//        org.junit.Assert.assertNotNull(dateTime30);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("+00:00:00.010");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("+00:00:00.010");
        jodaTimePermission1.checkGuard((java.lang.Object) jodaTimePermission3);
        java.lang.String str5 = jodaTimePermission1.getActions();
        java.lang.String str6 = jodaTimePermission1.getActions();
        java.lang.Object obj7 = null;
        jodaTimePermission1.checkGuard(obj7);
        java.lang.String str9 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfDay();
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear(18);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        long long12 = dateTimeZone5.getMillisKeepLocal(dateTimeZone9, 0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter3.withZone(dateTimeZone5);
        try {
            org.joda.time.MutableDateTime mutableDateTime15 = dateTimeFormatter3.parseMutableDateTime("ISOChronology[+00:00:00.010]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[+00:00:00.010]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long5 = dateTimeZone1.convertUTCToLocal((long) 24);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str7 = cachedDateTimeZone6.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 34L + "'", long5 == 34L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test292");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
//        int int4 = dateTime2.getMillisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusYears(0);
//        org.joda.time.DateTime dateTime8 = dateTime2.withWeekyear((int) ' ');
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfWeek();
//        int int12 = dateTime8.get(dateTimeField11);
//        org.joda.time.DateTime dateTime14 = dateTime8.minusHours(559);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.DateTime.Property property20 = dateTime19.year();
//        org.joda.time.DateTime dateTime21 = property20.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime23 = property20.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property24 = dateTime23.minuteOfHour();
//        org.joda.time.DateTime dateTime25 = property24.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, dateTimeFieldType26, 9700, 77045, 0);
//        int int31 = offsetDateTimeField30.getMinimumValue();
//        org.joda.time.DateTimeField dateTimeField32 = offsetDateTimeField30.getWrappedField();
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField30.getAsShortText((long) (byte) -1, locale34);
//        int int36 = dateTime14.get((org.joda.time.DateTimeField) offsetDateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 668 + "'", int4 == 668);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 77045 + "'", int31 == 77045);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "9723" + "'", str35.equals("9723"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 9714 + "'", int36 == 9714);
//    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
//        int int16 = offsetDateTimeField15.getMinimumValue();
//        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField15.getWrappedField();
//        long long19 = offsetDateTimeField15.roundHalfCeiling((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        int int23 = dateTime22.getWeekOfWeekyear();
//        int int24 = dateTime22.getMinuteOfHour();
//        org.joda.time.DateTime dateTime26 = dateTime22.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime28 = dateTime22.minusSeconds(0);
//        org.joda.time.DateTime dateTime30 = dateTime22.withHourOfDay(22);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now(dateTimeZone32);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone34 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone32);
//        long long36 = dateTimeZone32.convertUTCToLocal((long) 24);
//        org.joda.time.DateTime dateTime37 = dateTime30.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property38 = dateTime30.dayOfYear();
//        org.joda.time.DateTime.Property property39 = dateTime30.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder40.appendMillisOfSecond(24);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendLiteral('a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.Chronology chronology46 = dateTimeFormatter45.getChronology();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder42.append(dateTimeFormatter45);
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now(dateTimeZone51);
//        org.joda.time.DateTime.Property property53 = dateTime52.year();
//        org.joda.time.DateTime dateTime54 = property53.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime56 = property53.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property57 = dateTime56.minuteOfHour();
//        org.joda.time.DateTime dateTime58 = property57.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property57.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, dateTimeFieldType59, 9700, 77045, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder42.appendFixedDecimal(dateTimeFieldType59, 134);
//        org.joda.time.DateTime.Property property66 = dateTime30.property(dateTimeFieldType59);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, dateTimeFieldType59, 148);
//        java.lang.String str70 = offsetDateTimeField68.getAsShortText((long) 166);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 24 + "'", int23 == 24);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 34L + "'", long36 == 34L);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeFormatter45);
//        org.junit.Assert.assertNull(chronology46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
//        org.junit.Assert.assertNotNull(property66);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "9848" + "'", str70.equals("9848"));
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 62, (java.lang.Number) 24, (java.lang.Number) (byte) 100);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        illegalFieldValueException4.prependMessage("166");
        java.lang.Number number8 = illegalFieldValueException4.getUpperBound();
        illegalFieldValueException4.prependMessage("ZonedChronology[GregorianChronology[UTC], +00:00:00.010]");
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (byte) 100 + "'", number8.equals((byte) 100));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-328762800000L), (long) (-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: -328762800000 * -292275054");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 62, (java.lang.Number) 24, (java.lang.Number) (byte) 100);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        illegalFieldValueException4.prependMessage("166");
        java.lang.Number number8 = illegalFieldValueException4.getUpperBound();
        java.lang.String str9 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (byte) 100 + "'", number8.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("+00:00:00.010");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("+00:00:00.010");
        jodaTimePermission1.checkGuard((java.lang.Object) jodaTimePermission3);
        java.lang.String str5 = jodaTimePermission1.getActions();
        java.lang.String str6 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"+00:00:00.010\")" + "'", str6.equals("(\"org.joda.time.JodaTimePermission\" \"+00:00:00.010\")"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendMinuteOfHour(77045);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendFractionOfSecond((int) (byte) 1, 0);
        boolean boolean9 = dateTimeFormatterBuilder8.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(455);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear((int) '4', 0);
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
//        org.joda.time.TimeOfDay timeOfDay4 = dateTime3.toTimeOfDay();
//        int int5 = dateTime3.getMillisOfSecond();
//        org.joda.time.DateTime dateTime7 = dateTime3.minusYears(0);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
//        org.joda.time.DateTime.Property property13 = dateTime12.year();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
//        int int17 = dateTime16.getWeekOfWeekyear();
//        int int18 = dateTime16.getMinuteOfHour();
//        int int19 = property13.getDifference((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.LocalTime localTime20 = dateTime16.toLocalTime();
//        org.joda.time.DateTime dateTime21 = dateTime7.withFields((org.joda.time.ReadablePartial) localTime20);
//        java.lang.String str22 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localTime20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(timeOfDay4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 582 + "'", int5 == 582);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(localTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "21" + "'", str22.equals("21"));
//    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        int int5 = dateTime4.getWeekOfWeekyear();
//        int int6 = dateTime4.getMinuteOfHour();
//        int int7 = dateTime4.getYear();
//        boolean boolean8 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime0.getZone();
//        org.joda.time.DateTime dateTime11 = dateTime0.minus((long) 1282);
//        org.junit.Assert.assertNotNull(localDateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.hourOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.minuteOfDay();
        org.joda.time.DurationField durationField24 = gregorianChronology21.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
        org.joda.time.DurationField durationField26 = unsupportedDateTimeField25.getDurationField();
        try {
            long long28 = unsupportedDateTimeField25.roundHalfEven((long) 455);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
//        int int16 = offsetDateTimeField15.getMinimumValue();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) (short) 1);
//        int int24 = dateTime19.getMinuteOfDay();
//        org.joda.time.DateTime dateTime26 = dateTime19.plusSeconds((int) (short) -1);
//        long long27 = dateTime19.getMillis();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
//        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
//        java.lang.Class<?> wildcardClass32 = timeOfDay31.getClass();
//        org.joda.time.DateTime dateTime33 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay31);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay31, locale34);
//        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField15.getWrappedField();
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone38);
//        int int40 = dateTime39.getWeekOfWeekyear();
//        int int41 = dateTime39.getMinuteOfHour();
//        org.joda.time.DateTime dateTime43 = dateTime39.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime45 = dateTime39.minusSeconds(0);
//        org.joda.time.DateTime dateTime47 = dateTime39.withHourOfDay(22);
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now(dateTimeZone49);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone51 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone49);
//        long long53 = dateTimeZone49.convertUTCToLocal((long) 24);
//        org.joda.time.DateTime dateTime54 = dateTime47.withZone(dateTimeZone49);
//        org.joda.time.DateTime.Property property55 = dateTime47.dayOfYear();
//        org.joda.time.DateTime.Property property56 = dateTime47.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder57.appendMillisOfSecond(24);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder59.appendLiteral('a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.Chronology chronology63 = dateTimeFormatter62.getChronology();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder59.append(dateTimeFormatter62);
//        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology65.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now(dateTimeZone68);
//        org.joda.time.DateTime.Property property70 = dateTime69.year();
//        org.joda.time.DateTime dateTime71 = property70.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime73 = property70.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property74 = dateTime73.minuteOfHour();
//        org.joda.time.DateTime dateTime75 = property74.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = property74.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, dateTimeFieldType76, 9700, 77045, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder59.appendFixedDecimal(dateTimeFieldType76, 134);
//        org.joda.time.DateTime.Property property83 = dateTime47.property(dateTimeFieldType76);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField85 = new org.joda.time.field.DividedDateTimeField(dateTimeField36, dateTimeFieldType76, 18);
//        long long88 = dividedDateTimeField85.addWrapField((-11L), (-292275054));
//        long long91 = dividedDateTimeField85.add((long) (short) 1, (-86398706L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(timeOfDay20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1284 + "'", int24 == 1284);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560633865752L + "'", long27 == 1560633865752L);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(timeOfDay31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "24" + "'", str35.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 24 + "'", int40 == 24);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 24 + "'", int41 == 24);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone51);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 34L + "'", long53 == 34L);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertNotNull(dateTimeFormatter62);
//        org.junit.Assert.assertNull(chronology63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
//        org.junit.Assert.assertNotNull(gregorianChronology65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(property70);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(property74);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(dateTimeFieldType76);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
//        org.junit.Assert.assertNotNull(property83);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + (-11L) + "'", long88 == (-11L));
//        org.junit.Assert.assertTrue("'" + long91 + "' != '" + (-5598636148799999L) + "'", long91 == (-5598636148799999L));
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology(chronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfEra(10, 236);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral("18:55:52.592");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendYearOfCentury(1969, 22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendDayOfYear((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.weekyears();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.DurationField durationField16 = offsetDateTimeField15.getLeapDurationField();
        boolean boolean17 = offsetDateTimeField15.isSupported();
        int int18 = offsetDateTimeField15.getMinimumValue();
        int int19 = offsetDateTimeField15.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 77045 + "'", int18 == 77045);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField15.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        long long4 = property3.remainder();
//        java.util.Locale locale5 = null;
//        int int6 = property3.getMaximumTextLength(locale5);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 14333066658L + "'", long4 == 14333066658L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
//        int int16 = offsetDateTimeField15.getMinimumValue();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) (short) 1);
//        int int24 = dateTime19.getMinuteOfDay();
//        org.joda.time.DateTime dateTime26 = dateTime19.plusSeconds((int) (short) -1);
//        long long27 = dateTime19.getMillis();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
//        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
//        java.lang.Class<?> wildcardClass32 = timeOfDay31.getClass();
//        org.joda.time.DateTime dateTime33 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay31);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay31, locale34);
//        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField15.getWrappedField();
//        org.joda.time.DurationField durationField37 = offsetDateTimeField15.getDurationField();
//        boolean boolean38 = offsetDateTimeField15.isSupported();
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = offsetDateTimeField15.getAsText(455, locale40);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(timeOfDay20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1284 + "'", int24 == 1284);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560633866708L + "'", long27 == 1560633866708L);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(timeOfDay31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "24" + "'", str35.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "455" + "'", str41.equals("455"));
//    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
//        int int4 = dateTime3.getWeekOfWeekyear();
//        int int5 = dateTime3.getMinuteOfHour();
//        org.joda.time.DateTime dateTime7 = dateTime3.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime9 = dateTime3.minusSeconds(0);
//        org.joda.time.DateTime dateTime11 = dateTime3.withHourOfDay(22);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
//        long long17 = dateTimeZone13.convertUTCToLocal((long) 24);
//        org.joda.time.DateTime dateTime18 = dateTime11.withZone(dateTimeZone13);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(obj0, dateTimeZone13);
//        org.joda.time.DateTime dateTime21 = dateTime19.plus((long) 559);
//        org.joda.time.DateTime dateTime23 = dateTime21.withMonthOfYear(6);
//        int int24 = dateTime21.getHourOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime21.withEarlierOffsetAtOverlap();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 34L + "'", long17 == 34L);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 21 + "'", int24 == 21);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        long long10 = dateTimeZone6.convertUTCToLocal((long) 24);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(0, (int) (short) 1, 582, 1975, (-1), dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1975 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 34L + "'", long10 == 34L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        int int8 = property7.getLeapAmount();
        org.joda.time.DateTime dateTime10 = property7.addToCopy((-1));
        org.joda.time.DateTime.Property property11 = dateTime10.weekOfWeekyear();
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks(77044);
        try {
            org.joda.time.DateTime dateTime15 = dateTime13.withDayOfWeek(455);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 455 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime8 = property7.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        int int10 = property7.getLeapAmount();
        boolean boolean11 = property7.isLeap();
        org.joda.time.DurationField durationField12 = property7.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(durationField12);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
//        int int8 = property7.getLeapAmount();
//        org.joda.time.DateTime dateTime10 = property7.addToCopy((-1));
//        org.joda.time.DateTime dateTime12 = property7.addToCopy((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        java.lang.String str14 = dateTime12.toString(dateTimeFormatter13);
//        java.util.Locale locale15 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter13.withLocale(locale15);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
//        java.lang.String str23 = fixedDateTimeZone21.getNameKey((long) 2360);
//        java.lang.String str24 = fixedDateTimeZone21.getID();
//        int int26 = fixedDateTimeZone21.getOffset(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter16.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone21);
//        long long29 = fixedDateTimeZone21.nextTransition((long) (byte) 1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "21:34:27.933" + "'", str14.equals("21:34:27.933"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.010" + "'", str23.equals("+00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.010" + "'", str24.equals("+00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
//        int int16 = offsetDateTimeField15.getMinimumValue();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) (short) 1);
//        int int24 = dateTime19.getMinuteOfDay();
//        org.joda.time.DateTime dateTime26 = dateTime19.plusSeconds((int) (short) -1);
//        long long27 = dateTime19.getMillis();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
//        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
//        java.lang.Class<?> wildcardClass32 = timeOfDay31.getClass();
//        org.joda.time.DateTime dateTime33 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay31);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay31, locale34);
//        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField15.getWrappedField();
//        long long38 = offsetDateTimeField15.roundHalfEven(83L);
//        java.lang.String str40 = offsetDateTimeField15.getAsText((-74473862399955L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(timeOfDay20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1284 + "'", int24 == 1284);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560633867995L + "'", long27 == 1560633867995L);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(timeOfDay31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "24" + "'", str35.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "9700" + "'", str40.equals("9700"));
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
//        int int8 = property7.getLeapAmount();
//        org.joda.time.DateTime dateTime10 = property7.addToCopy((-1));
//        org.joda.time.LocalTime localTime11 = dateTime10.toLocalTime();
//        org.joda.time.DateTime dateTime13 = dateTime10.plusMinutes(77047148);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
//        org.joda.time.DateTime.Property property17 = dateTime16.year();
//        org.joda.time.DateTime dateTime18 = property17.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime20 = property17.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property21 = dateTime20.minuteOfHour();
//        org.joda.time.DateTime dateTime22 = property21.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property21.getFieldType();
//        int int24 = dateTime10.get(dateTimeFieldType23);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, "9700");
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 23 + "'", int24 == 23);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 62, (java.lang.Number) 24, (java.lang.Number) (byte) 100);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException4.getSuppressed();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendLiteral('a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.Chronology chronology14 = dateTimeFormatter13.getChronology();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.append(dateTimeFormatter13);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.DateTime dateTime22 = property21.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime24 = property21.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property25 = dateTime24.minuteOfHour();
        org.joda.time.DateTime dateTime26 = property25.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property25.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, dateTimeFieldType27, 9700, 77045, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder10.appendFixedDecimal(dateTimeFieldType27, 134);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType27, (java.lang.Number) 1969, (java.lang.Number) (short) 100, (java.lang.Number) 236);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException37);
        java.lang.String str39 = illegalFieldValueException37.getFieldName();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 24 + "'", number5.equals(24));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "62" + "'", str6.equals("62"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "minuteOfHour" + "'", str39.equals("minuteOfHour"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime11 = dateTime10.toLocalDateTime();
        int[] intArray13 = gregorianChronology8.get((org.joda.time.ReadablePartial) localDateTime11, 0L);
        int[] intArray15 = gregorianChronology5.get((org.joda.time.ReadablePartial) localDateTime11, 14332974220L);
        boolean boolean16 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime11);
        long long18 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology19);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        boolean boolean5 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfYear(366);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatterBuilder8.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.time();
        java.util.Locale locale11 = dateTimeFormatter10.getLocale();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.append(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNull(locale11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test321");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
//        int int4 = dateTime3.getWeekOfWeekyear();
//        int int5 = dateTime3.getMinuteOfHour();
//        org.joda.time.DateTime dateTime7 = dateTime3.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime9 = dateTime3.minusSeconds(0);
//        org.joda.time.DateTime dateTime11 = dateTime3.withHourOfDay(22);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
//        long long17 = dateTimeZone13.convertUTCToLocal((long) 24);
//        org.joda.time.DateTime dateTime18 = dateTime11.withZone(dateTimeZone13);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(obj0, dateTimeZone13);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone13.getShortName((-9424284L), locale21);
//        boolean boolean24 = dateTimeZone13.isStandardOffset((-31449658716L));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 34L + "'", long17 == 34L);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00:00.010" + "'", str22.equals("+00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test322");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.year();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getWeekOfWeekyear();
//        int int17 = dateTime15.getMinuteOfHour();
//        int int18 = property12.getDifference((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
//        org.joda.time.DateTime.Property property22 = dateTime21.year();
//        org.joda.time.DateTime dateTime23 = property22.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime25 = property22.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property26 = dateTime25.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateMidnight dateMidnight30 = dateTime29.toDateMidnight();
//        boolean boolean31 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime29);
//        long long32 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime25);
//        boolean boolean33 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime25);
//        try {
//            java.lang.String str35 = dateTime25.toString("ISOChronology[UTC]");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: I");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateMidnight30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property5 = dateTime4.monthOfYear();
        org.joda.time.DurationField durationField6 = property5.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(durationField6);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
//        int int16 = offsetDateTimeField15.getMinimumValue();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) (short) 1);
//        int int24 = dateTime19.getMinuteOfDay();
//        org.joda.time.DateTime dateTime26 = dateTime19.plusSeconds((int) (short) -1);
//        long long27 = dateTime19.getMillis();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
//        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
//        java.lang.Class<?> wildcardClass32 = timeOfDay31.getClass();
//        org.joda.time.DateTime dateTime33 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay31);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay31, locale34);
//        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField15.getWrappedField();
//        org.joda.time.DurationField durationField37 = offsetDateTimeField15.getDurationField();
//        long long39 = offsetDateTimeField15.roundHalfCeiling((-328761356905L));
//        long long41 = offsetDateTimeField15.roundHalfFloor((long) 292278993);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(timeOfDay20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1284 + "'", int24 == 1284);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560633868739L + "'", long27 == 1560633868739L);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(timeOfDay31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "24" + "'", str35.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-328762800000L) + "'", long39 == (-328762800000L));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 291600000L + "'", long41 == 291600000L);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        int int3 = dateTime2.getWeekOfWeekyear();
//        int int4 = dateTime2.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
//        org.joda.time.DateTime dateTime10 = dateTime2.withHourOfDay(22);
//        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
//        int int15 = dateTime14.getWeekOfWeekyear();
//        int int16 = dateTime14.getMinuteOfHour();
//        org.joda.time.DateTime dateTime18 = dateTime14.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime20 = dateTime14.minusSeconds(0);
//        org.joda.time.DateTime dateTime22 = dateTime14.withYear(10);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone24);
//        int int26 = dateTime25.getWeekOfWeekyear();
//        int int27 = dateTime25.getMinuteOfHour();
//        org.joda.time.DateTime dateTime29 = dateTime25.minusWeeks((int) ' ');
//        int int30 = dateTime25.getSecondOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = null;
//        java.lang.String str32 = dateTime25.toString(dateTimeFormatter31);
//        boolean boolean33 = dateTime22.isAfter((org.joda.time.ReadableInstant) dateTime25);
//        boolean boolean34 = dateTime11.equals((java.lang.Object) dateTime25);
//        org.joda.time.DateTime dateTime36 = dateTime11.minusHours(906525);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 24 + "'", int26 == 24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 24 + "'", int27 == 24);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 77068 + "'", int30 == 77068);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019-06-15T21:24:28.953+00:00:00.010" + "'", str32.equals("2019-06-15T21:24:28.953+00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(dateTime36);
//    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test326");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
//        int int4 = dateTime3.getWeekOfWeekyear();
//        int int5 = dateTime3.getMinuteOfHour();
//        org.joda.time.DateTime dateTime7 = dateTime3.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime9 = dateTime3.minusSeconds(0);
//        org.joda.time.DateTime dateTime11 = dateTime3.withHourOfDay(22);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
//        long long17 = dateTimeZone13.convertUTCToLocal((long) 24);
//        org.joda.time.DateTime dateTime18 = dateTime11.withZone(dateTimeZone13);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(obj0, dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        int int23 = dateTime22.getWeekOfWeekyear();
//        int int24 = dateTime22.getMinuteOfHour();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime26 = dateTime25.toLocalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(dateTimeZone28);
//        int int30 = dateTime29.getWeekOfWeekyear();
//        int int31 = dateTime29.getMinuteOfHour();
//        int int32 = dateTime29.getYear();
//        boolean boolean33 = dateTime25.isAfter((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.DateTime.Property property34 = dateTime29.year();
//        int int35 = dateTime22.compareTo((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.DateTime dateTime37 = dateTime29.plusMonths((int) (short) 0);
//        org.joda.time.ReadablePeriod readablePeriod38 = null;
//        org.joda.time.DateTime dateTime39 = dateTime29.minus(readablePeriod38);
//        int int40 = dateTime19.compareTo((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.DateTime dateTime42 = dateTime29.minusYears(582);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 34L + "'", long17 == 34L);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 24 + "'", int23 == 24);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 24 + "'", int30 == 24);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 24 + "'", int31 == 24);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(dateTime42);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime11 = dateTime10.toLocalDateTime();
        int[] intArray13 = gregorianChronology8.get((org.joda.time.ReadablePartial) localDateTime11, 0L);
        int[] intArray15 = gregorianChronology5.get((org.joda.time.ReadablePartial) localDateTime11, 14332974220L);
        boolean boolean16 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime11);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        boolean boolean20 = dateTime18.isSupported(dateTimeFieldType19);
        boolean boolean21 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeFieldType19);
        long long23 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 10);
        java.lang.String str25 = fixedDateTimeZone4.getNameKey((long) 366);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.010" + "'", str25.equals("+00:00:00.010"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        int int16 = offsetDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField15.getWrappedField();
        long long19 = offsetDateTimeField15.roundHalfCeiling((long) '4');
        long long22 = offsetDateTimeField15.getDifferenceAsLong((long) 9, (long) 559);
        java.lang.String str24 = offsetDateTimeField15.getAsText(77046328L);
        long long27 = offsetDateTimeField15.getDifferenceAsLong(595449058L, (long) (-165));
        org.joda.time.ReadablePartial readablePartial28 = null;
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField15.getAsText(readablePartial28, 77045, locale30);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9721" + "'", str24.equals("9721"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 165L + "'", long27 == 165L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "77045" + "'", str31.equals("77045"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology(chronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfEra(10, 236);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendFractionOfDay(23, 125);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.lang.String str6 = iSOChronology5.toString();
        org.joda.time.DurationField durationField7 = iSOChronology5.days();
        org.joda.time.Chronology chronology8 = iSOChronology5.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology10 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology5.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[+00:00:00.010]" + "'", str6.equals("ISOChronology[+00:00:00.010]"));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getLeapDurationField();
        boolean boolean22 = unsupportedDateTimeField20.isSupported();
        long long25 = unsupportedDateTimeField20.add((-328838400000L), 332);
        boolean boolean26 = unsupportedDateTimeField20.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-128044800000L) + "'", long25 == (-128044800000L));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        long long23 = unsupportedDateTimeField20.add((-9350942L), (int) (byte) 1);
        long long26 = unsupportedDateTimeField20.getDifferenceAsLong((long) (short) 1, 31742L);
        try {
            long long28 = unsupportedDateTimeField20.roundHalfFloor((long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 595449058L + "'", long23 == 595449058L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.lang.String str6 = iSOChronology5.toString();
        org.joda.time.DurationField durationField7 = iSOChronology5.days();
        org.joda.time.Chronology chronology8 = iSOChronology5.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology10 = iSOChronology5.withUTC();
        org.joda.time.Chronology chronology11 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology5.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[+00:00:00.010]" + "'", str6.equals("ISOChronology[+00:00:00.010]"));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test334");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.year();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
//        int int10 = dateTime9.getWeekOfWeekyear();
//        int int11 = dateTime9.getMinuteOfHour();
//        int int12 = property6.getDifference((org.joda.time.ReadableInstant) dateTime9);
//        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) int12);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
//        org.joda.time.TimeOfDay timeOfDay17 = dateTime16.toTimeOfDay();
//        long long19 = gregorianChronology0.set((org.joda.time.ReadablePartial) timeOfDay17, (-11L));
//        org.joda.time.DurationField durationField20 = gregorianChronology0.weekyears();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology0.year();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology0.halfdayOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(timeOfDay17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9330053L) + "'", long19 == (-9330053L));
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.withDurationAdded(readableDuration4, (int) (short) 1);
//        int int7 = dateTime2.getMinuteOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime2.dayOfMonth();
//        org.joda.time.DurationField durationField9 = property8.getDurationField();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1284 + "'", int7 == 1284);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(durationField9);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test336");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.withDurationAdded(readableDuration4, (int) (short) 1);
//        int int7 = dateTime2.getMinuteOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime2.dayOfMonth();
//        org.joda.time.DateTime dateTime10 = dateTime2.plusMonths(2360);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1284 + "'", int7 == 1284);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test337");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.year();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getWeekOfWeekyear();
//        int int17 = dateTime15.getMinuteOfHour();
//        int int18 = property12.getDifference((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
//        org.joda.time.DateTime.Property property22 = dateTime21.year();
//        org.joda.time.DateTime dateTime23 = property22.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime25 = property22.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property26 = dateTime25.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateMidnight dateMidnight30 = dateTime29.toDateMidnight();
//        boolean boolean31 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime29);
//        long long32 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime25);
//        boolean boolean33 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime25);
//        int int34 = dateTime25.getMinuteOfHour();
//        org.joda.time.JodaTimePermission jodaTimePermission36 = new org.joda.time.JodaTimePermission("+00:00:00.010");
//        org.joda.time.JodaTimePermission jodaTimePermission38 = new org.joda.time.JodaTimePermission("+00:00:00.010");
//        jodaTimePermission36.checkGuard((java.lang.Object) jodaTimePermission38);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder40.appendMillisOfSecond(24);
//        boolean boolean43 = dateTimeFormatterBuilder42.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder42.appendWeekyear(0, 292278993);
//        jodaTimePermission36.checkGuard((java.lang.Object) 0);
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49);
//        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology50.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology50.clockhourOfHalfday();
//        jodaTimePermission36.checkGuard((java.lang.Object) gregorianChronology50);
//        java.lang.String str54 = jodaTimePermission36.getActions();
//        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime57 = org.joda.time.DateTime.now(dateTimeZone56);
//        org.joda.time.DateTime.Property property58 = dateTime57.year();
//        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime61 = org.joda.time.DateTime.now(dateTimeZone60);
//        int int62 = dateTime61.getWeekOfWeekyear();
//        int int63 = dateTime61.getMinuteOfHour();
//        int int64 = property58.getDifference((org.joda.time.ReadableInstant) dateTime61);
//        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime67 = org.joda.time.DateTime.now(dateTimeZone66);
//        org.joda.time.DateTime.Property property68 = dateTime67.year();
//        org.joda.time.DateTime dateTime69 = property68.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime71 = property68.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property72 = dateTime71.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone74 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime75 = org.joda.time.DateTime.now(dateTimeZone74);
//        org.joda.time.DateMidnight dateMidnight76 = dateTime75.toDateMidnight();
//        boolean boolean77 = dateTime71.isEqual((org.joda.time.ReadableInstant) dateTime75);
//        long long78 = property58.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime71);
//        org.joda.time.DateTime dateTime80 = dateTime71.withMillis(34L);
//        java.util.Locale locale82 = null;
//        java.lang.String str83 = dateTime71.toString("18:55:52.592", locale82);
//        jodaTimePermission36.checkGuard((java.lang.Object) dateTime71);
//        boolean boolean85 = dateTime25.equals((java.lang.Object) jodaTimePermission36);
//        java.security.PermissionCollection permissionCollection86 = jodaTimePermission36.newPermissionCollection();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateMidnight30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 24 + "'", int34 == 24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(gregorianChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 24 + "'", int62 == 24);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 24 + "'", int63 == 24);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone66);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(property72);
//        org.junit.Assert.assertNotNull(dateTimeZone74);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(dateMidnight76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "18:55:52.592" + "'", str83.equals("18:55:52.592"));
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertNotNull(permissionCollection86);
//    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test338");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
//        int int16 = offsetDateTimeField15.getMinimumValue();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) (short) 1);
//        int int24 = dateTime19.getMinuteOfDay();
//        org.joda.time.DateTime dateTime26 = dateTime19.plusSeconds((int) (short) -1);
//        long long27 = dateTime19.getMillis();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
//        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
//        java.lang.Class<?> wildcardClass32 = timeOfDay31.getClass();
//        org.joda.time.DateTime dateTime33 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay31);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay31, locale34);
//        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField15.getWrappedField();
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone38);
//        int int40 = dateTime39.getWeekOfWeekyear();
//        int int41 = dateTime39.getMinuteOfHour();
//        org.joda.time.DateTime dateTime43 = dateTime39.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime45 = dateTime39.minusSeconds(0);
//        org.joda.time.DateTime dateTime47 = dateTime39.withHourOfDay(22);
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now(dateTimeZone49);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone51 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone49);
//        long long53 = dateTimeZone49.convertUTCToLocal((long) 24);
//        org.joda.time.DateTime dateTime54 = dateTime47.withZone(dateTimeZone49);
//        org.joda.time.DateTime.Property property55 = dateTime47.dayOfYear();
//        org.joda.time.DateTime.Property property56 = dateTime47.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder57.appendMillisOfSecond(24);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder59.appendLiteral('a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.Chronology chronology63 = dateTimeFormatter62.getChronology();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder59.append(dateTimeFormatter62);
//        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology65.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now(dateTimeZone68);
//        org.joda.time.DateTime.Property property70 = dateTime69.year();
//        org.joda.time.DateTime dateTime71 = property70.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime73 = property70.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property74 = dateTime73.minuteOfHour();
//        org.joda.time.DateTime dateTime75 = property74.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = property74.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, dateTimeFieldType76, 9700, 77045, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder59.appendFixedDecimal(dateTimeFieldType76, 134);
//        org.joda.time.DateTime.Property property83 = dateTime47.property(dateTimeFieldType76);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField85 = new org.joda.time.field.DividedDateTimeField(dateTimeField36, dateTimeFieldType76, 18);
//        int int88 = dividedDateTimeField85.getDifference((long) 0, (long) 294);
//        org.joda.time.DurationField durationField89 = dividedDateTimeField85.getDurationField();
//        int int91 = dividedDateTimeField85.getMaximumValue((long) 559);
//        long long94 = dividedDateTimeField85.set((long) 1970, 0);
//        boolean boolean95 = dividedDateTimeField85.isLenient();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(timeOfDay20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1284 + "'", int24 == 1284);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560633871204L + "'", long27 == 1560633871204L);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(timeOfDay31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "24" + "'", str35.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 24 + "'", int40 == 24);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 24 + "'", int41 == 24);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone51);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 34L + "'", long53 == 34L);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertNotNull(dateTimeFormatter62);
//        org.junit.Assert.assertNull(chronology63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
//        org.junit.Assert.assertNotNull(gregorianChronology65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(property70);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(property74);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(dateTimeFieldType76);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
//        org.junit.Assert.assertNotNull(property83);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
//        org.junit.Assert.assertNotNull(durationField89);
//        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
//        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 1970L + "'", long94 == 1970L);
//        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearText();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatterBuilder5.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property5 = dateTime4.monthOfYear();
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((-292275054));
        org.joda.time.DateTime dateTime9 = dateTime7.plus(0L);
        org.joda.time.DateTime.Property property10 = dateTime9.monthOfYear();
        java.util.Locale locale12 = null;
        try {
            org.joda.time.DateTime dateTime13 = property10.setCopy("", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.Locale locale5 = null;
        java.lang.String str6 = cachedDateTimeZone3.getName((long) '#', locale5);
        long long9 = cachedDateTimeZone3.convertLocalToUTC((long) 341, false);
        int int11 = cachedDateTimeZone3.getStandardOffset((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone3.getUncachedZone();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        int int15 = cachedDateTimeZone3.getStandardOffset((long) 189);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 331L + "'", long9 == 331L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test342");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(24);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfMinute(24, (int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
//        org.joda.time.DateTime.Property property11 = dateTime10.year();
//        org.joda.time.DateTime dateTime12 = property11.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime14 = property11.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property15 = dateTime14.minuteOfHour();
//        int int16 = property15.getLeapAmount();
//        org.joda.time.DateTime dateTime18 = property15.addToCopy((-1));
//        org.joda.time.DateTime dateTime20 = property15.addToCopy((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        java.lang.String str22 = dateTime20.toString(dateTimeFormatter21);
//        java.util.Locale locale23 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter21.withLocale(locale23);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder7.append(dateTimeFormatter21);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder25.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendTimeZoneName();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "21:34:32.027" + "'", str22.equals("21:34:32.027"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test343");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.withDurationAdded(readableDuration4, (int) (short) 1);
//        int int7 = dateTime2.getMinuteOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime2.plusSeconds((int) (short) -1);
//        long long10 = dateTime2.getMillis();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime2.toMutableDateTimeISO();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1284 + "'", int7 == 1284);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560633872086L + "'", long10 == 1560633872086L);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test344");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfDay();
//        org.joda.time.DateTime dateTime9 = property8.roundHalfFloorCopy();
//        long long10 = property8.remainder();
//        java.util.Locale locale11 = null;
//        int int12 = property8.getMaximumShortTextLength(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property8.getFieldType();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32130L + "'", long10 == 32130L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test345");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.year();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getWeekOfWeekyear();
//        int int17 = dateTime15.getMinuteOfHour();
//        int int18 = property12.getDifference((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
//        org.joda.time.DateTime.Property property22 = dateTime21.year();
//        org.joda.time.DateTime dateTime23 = property22.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime25 = property22.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property26 = dateTime25.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateMidnight dateMidnight30 = dateTime29.toDateMidnight();
//        boolean boolean31 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime29);
//        long long32 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime25);
//        boolean boolean33 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.ReadableDuration readableDuration34 = null;
//        org.joda.time.DateTime dateTime36 = dateTime25.withDurationAdded(readableDuration34, (int) (short) 100);
//        org.joda.time.DateTime.Property property37 = dateTime36.weekyear();
//        java.util.Locale locale39 = null;
//        org.joda.time.DateTime dateTime40 = property37.setCopy("0", locale39);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateMidnight30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTime40);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfDay();
        org.joda.time.DateTime dateTime9 = property8.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime10 = property8.withMaximumValue();
        boolean boolean11 = property8.isLeap();
        int int12 = property8.getMinimumValueOverall();
        int int13 = property8.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.withDurationAdded(readableDuration6, (int) '4');
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime4.minus(readableDuration9);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfCentury(0);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (short) 1);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test350");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
//        int int16 = offsetDateTimeField15.getMinimumValue();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) (short) 1);
//        int int24 = dateTime19.getMinuteOfDay();
//        org.joda.time.DateTime dateTime26 = dateTime19.plusSeconds((int) (short) -1);
//        long long27 = dateTime19.getMillis();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
//        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
//        java.lang.Class<?> wildcardClass32 = timeOfDay31.getClass();
//        org.joda.time.DateTime dateTime33 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay31);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay31, locale34);
//        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField15.getWrappedField();
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone38);
//        int int40 = dateTime39.getWeekOfWeekyear();
//        int int41 = dateTime39.getMinuteOfHour();
//        org.joda.time.DateTime dateTime43 = dateTime39.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime45 = dateTime39.minusSeconds(0);
//        org.joda.time.DateTime dateTime47 = dateTime39.withHourOfDay(22);
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now(dateTimeZone49);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone51 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone49);
//        long long53 = dateTimeZone49.convertUTCToLocal((long) 24);
//        org.joda.time.DateTime dateTime54 = dateTime47.withZone(dateTimeZone49);
//        org.joda.time.DateTime.Property property55 = dateTime47.dayOfYear();
//        org.joda.time.DateTime.Property property56 = dateTime47.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder57.appendMillisOfSecond(24);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder59.appendLiteral('a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.Chronology chronology63 = dateTimeFormatter62.getChronology();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder59.append(dateTimeFormatter62);
//        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology65.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now(dateTimeZone68);
//        org.joda.time.DateTime.Property property70 = dateTime69.year();
//        org.joda.time.DateTime dateTime71 = property70.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime73 = property70.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property74 = dateTime73.minuteOfHour();
//        org.joda.time.DateTime dateTime75 = property74.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = property74.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, dateTimeFieldType76, 9700, 77045, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder59.appendFixedDecimal(dateTimeFieldType76, 134);
//        org.joda.time.DateTime.Property property83 = dateTime47.property(dateTimeFieldType76);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField85 = new org.joda.time.field.DividedDateTimeField(dateTimeField36, dateTimeFieldType76, 18);
//        int int88 = dividedDateTimeField85.getDifference((long) 0, (long) 294);
//        boolean boolean89 = dividedDateTimeField85.isLenient();
//        int int91 = dividedDateTimeField85.get(1L);
//        int int92 = dividedDateTimeField85.getMinimumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(timeOfDay20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1284 + "'", int24 == 1284);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560633872718L + "'", long27 == 1560633872718L);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(timeOfDay31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "24" + "'", str35.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 24 + "'", int40 == 24);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 24 + "'", int41 == 24);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone51);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 34L + "'", long53 == 34L);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertNotNull(dateTimeFormatter62);
//        org.junit.Assert.assertNull(chronology63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
//        org.junit.Assert.assertNotNull(gregorianChronology65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(property70);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(property74);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(dateTimeFieldType76);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
//        org.junit.Assert.assertNotNull(property83);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfDay();
        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime6.plus((long) 67552);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test353");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.year();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
//        int int10 = dateTime9.getWeekOfWeekyear();
//        int int11 = dateTime9.getMinuteOfHour();
//        int int12 = property6.getDifference((org.joda.time.ReadableInstant) dateTime9);
//        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) int12);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology0.weekyear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        java.io.Writer writer3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.LocalDateTime localDateTime5 = dateTime4.toLocalDateTime();
        org.joda.time.DateTime dateTime7 = dateTime4.withYearOfCentury(0);
        org.joda.time.DateMidnight dateMidnight8 = dateTime4.toDateMidnight();
        java.util.Locale locale9 = null;
        java.util.Calendar calendar10 = dateMidnight8.toCalendar(locale9);
        try {
            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadableInstant) dateMidnight8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(localDateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(calendar10);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test355");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        java.lang.String str4 = dateTime2.toString(dateTimeFormatter3);
//        org.joda.time.DateTime dateTime6 = dateTime2.withYearOfEra(372);
//        org.joda.time.DateTime.Property property7 = dateTime2.dayOfMonth();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-166T21:24:33.612+00:00:00.010" + "'", str4.equals("2019-166T21:24:33.612+00:00:00.010"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test356");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.minus((long) (byte) -1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withYear(448);
//        int int5 = dateTime2.getHourOfDay();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 21 + "'", int5 == 21);
//    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test357");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        int int3 = dateTime2.getWeekOfWeekyear();
//        int int4 = dateTime2.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
//        int int7 = dateTime2.getSecondOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = null;
//        java.lang.String str9 = dateTime2.toString(dateTimeFormatter8);
//        int int10 = dateTime2.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 77073 + "'", int7 == 77073);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019-06-15T21:24:33.652+00:00:00.010" + "'", str9.equals("2019-06-15T21:24:33.652+00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        int int16 = offsetDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField15.getWrappedField();
        boolean boolean19 = offsetDateTimeField15.isLeap((long) 1969);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser2);
        java.lang.Appendable appendable4 = null;
        try {
            dateTimeFormatter3.printTo(appendable4, (long) 18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime5 = property3.roundHalfCeilingCopy();
        int int6 = property3.getMinimumValue();
        org.joda.time.DurationField durationField7 = property3.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-292275054) + "'", int6 == (-292275054));
        org.junit.Assert.assertNotNull(durationField7);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test361");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
//        int int16 = offsetDateTimeField15.getMinimumValue();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) (short) 1);
//        int int24 = dateTime19.getMinuteOfDay();
//        org.joda.time.DateTime dateTime26 = dateTime19.plusSeconds((int) (short) -1);
//        long long27 = dateTime19.getMillis();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
//        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
//        java.lang.Class<?> wildcardClass32 = timeOfDay31.getClass();
//        org.joda.time.DateTime dateTime33 = dateTime19.withFields((org.joda.time.ReadablePartial) timeOfDay31);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay31, locale34);
//        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField15.getWrappedField();
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone38);
//        int int40 = dateTime39.getWeekOfWeekyear();
//        int int41 = dateTime39.getMinuteOfHour();
//        org.joda.time.DateTime dateTime43 = dateTime39.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime45 = dateTime39.minusSeconds(0);
//        org.joda.time.DateTime dateTime47 = dateTime39.withHourOfDay(22);
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now(dateTimeZone49);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone51 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone49);
//        long long53 = dateTimeZone49.convertUTCToLocal((long) 24);
//        org.joda.time.DateTime dateTime54 = dateTime47.withZone(dateTimeZone49);
//        org.joda.time.DateTime.Property property55 = dateTime47.dayOfYear();
//        org.joda.time.DateTime.Property property56 = dateTime47.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder57.appendMillisOfSecond(24);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder59.appendLiteral('a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.Chronology chronology63 = dateTimeFormatter62.getChronology();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder59.append(dateTimeFormatter62);
//        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology65.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now(dateTimeZone68);
//        org.joda.time.DateTime.Property property70 = dateTime69.year();
//        org.joda.time.DateTime dateTime71 = property70.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime73 = property70.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property74 = dateTime73.minuteOfHour();
//        org.joda.time.DateTime dateTime75 = property74.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = property74.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, dateTimeFieldType76, 9700, 77045, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder59.appendFixedDecimal(dateTimeFieldType76, 134);
//        org.joda.time.DateTime.Property property83 = dateTime47.property(dateTimeFieldType76);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField85 = new org.joda.time.field.DividedDateTimeField(dateTimeField36, dateTimeFieldType76, 18);
//        int int88 = dividedDateTimeField85.getDifference((long) 0, (long) 294);
//        int int91 = dividedDateTimeField85.getDifference(1560633866708L, 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(timeOfDay20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1284 + "'", int24 == 1284);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560633873787L + "'", long27 == 1560633873787L);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(timeOfDay31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "24" + "'", str35.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 24 + "'", int40 == 24);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 24 + "'", int41 == 24);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone51);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 34L + "'", long53 == 34L);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertNotNull(dateTimeFormatter62);
//        org.junit.Assert.assertNull(chronology63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
//        org.junit.Assert.assertNotNull(gregorianChronology65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(property70);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(property74);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(dateTimeFieldType76);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
//        org.junit.Assert.assertNotNull(property83);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
//        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 24083 + "'", int91 == 24083);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "1284");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test363");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
//        int int4 = dateTime2.getMillisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusYears(0);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.year();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getWeekOfWeekyear();
//        int int17 = dateTime15.getMinuteOfHour();
//        int int18 = property12.getDifference((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.LocalTime localTime19 = dateTime15.toLocalTime();
//        org.joda.time.DateTime dateTime20 = dateTime6.withFields((org.joda.time.ReadablePartial) localTime19);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.010", "+00:00:00.010", (int) (byte) 0, 0);
//        long long27 = fixedDateTimeZone25.nextTransition((long) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
//        org.joda.time.DateTime dateTime29 = dateTime20.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 508 + "'", int4 == 508);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test364");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.minus((long) (byte) -1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withYear(448);
//        org.joda.time.DateTime dateTime6 = dateTime4.plusMillis(77045);
//        int int7 = dateTime6.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 51 + "'", int7 == 51);
//    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test365");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
//        int int16 = offsetDateTimeField15.getMinimumValue();
//        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField15.getWrappedField();
//        long long19 = offsetDateTimeField15.roundHalfCeiling((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        int int23 = dateTime22.getWeekOfWeekyear();
//        int int24 = dateTime22.getMinuteOfHour();
//        org.joda.time.DateTime dateTime26 = dateTime22.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime28 = dateTime22.minusSeconds(0);
//        org.joda.time.DateTime dateTime30 = dateTime22.withHourOfDay(22);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now(dateTimeZone32);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone34 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone32);
//        long long36 = dateTimeZone32.convertUTCToLocal((long) 24);
//        org.joda.time.DateTime dateTime37 = dateTime30.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property38 = dateTime30.dayOfYear();
//        org.joda.time.DateTime.Property property39 = dateTime30.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder40.appendMillisOfSecond(24);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendLiteral('a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.Chronology chronology46 = dateTimeFormatter45.getChronology();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder42.append(dateTimeFormatter45);
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now(dateTimeZone51);
//        org.joda.time.DateTime.Property property53 = dateTime52.year();
//        org.joda.time.DateTime dateTime54 = property53.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime56 = property53.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property57 = dateTime56.minuteOfHour();
//        org.joda.time.DateTime dateTime58 = property57.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property57.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, dateTimeFieldType59, 9700, 77045, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder42.appendFixedDecimal(dateTimeFieldType59, 134);
//        org.joda.time.DateTime.Property property66 = dateTime30.property(dateTimeFieldType59);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, dateTimeFieldType59, 148);
//        long long70 = offsetDateTimeField68.roundHalfCeiling(0L);
//        org.joda.time.ReadablePartial readablePartial71 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology73 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField74 = gregorianChronology73.secondOfDay();
//        org.joda.time.DateTime dateTime75 = new org.joda.time.DateTime();
//        org.joda.time.LocalDateTime localDateTime76 = dateTime75.toLocalDateTime();
//        int[] intArray78 = gregorianChronology73.get((org.joda.time.ReadablePartial) localDateTime76, 0L);
//        try {
//            int[] intArray80 = offsetDateTimeField68.set(readablePartial71, (int) (short) 0, intArray78, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for minuteOfHour must be in the range [77193,148]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 77045 + "'", int16 == 77045);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 24 + "'", int23 == 24);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 34L + "'", long36 == 34L);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeFormatter45);
//        org.junit.Assert.assertNull(chronology46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
//        org.junit.Assert.assertNotNull(property66);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology73);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertNotNull(localDateTime76);
//        org.junit.Assert.assertNotNull(intArray78);
//    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test366");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        int int3 = dateTime2.getWeekOfWeekyear();
//        int int4 = dateTime2.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = dateTime2.minusWeeks((int) ' ');
//        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds(0);
//        org.joda.time.DateTime dateTime10 = dateTime2.withHourOfDay(22);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
//        long long16 = dateTimeZone12.convertUTCToLocal((long) 24);
//        org.joda.time.DateTime dateTime17 = dateTime10.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property18 = dateTime10.dayOfYear();
//        org.joda.time.DateTime.Property property19 = dateTime10.weekOfWeekyear();
//        org.joda.time.DateTime.Property property20 = dateTime10.yearOfEra();
//        org.joda.time.DateTime dateTime22 = property20.setCopy(1283);
//        int int23 = property20.getMinimumValueOverall();
//        org.joda.time.DurationField durationField24 = property20.getDurationField();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 34L + "'", long16 == 34L);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(durationField24);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 21, 77068);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.hourOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.minuteOfDay();
        org.joda.time.DurationField durationField24 = gregorianChronology21.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
        try {
            java.lang.String str27 = unsupportedDateTimeField25.getAsText(1970L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.centuryOfEra();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis(1560633871204L, 1294, 0, 45, 125);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1294 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test370");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 9700, 77045, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.minuteOfDay();
//        org.joda.time.DurationField durationField19 = gregorianChronology16.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
//        long long23 = unsupportedDateTimeField20.add((-9350942L), (int) (byte) 1);
//        boolean boolean24 = unsupportedDateTimeField20.isLenient();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
//        org.joda.time.DateTime.Property property31 = dateTime30.year();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now(dateTimeZone33);
//        int int35 = dateTime34.getWeekOfWeekyear();
//        int int36 = dateTime34.getMinuteOfHour();
//        int int37 = property31.getDifference((org.joda.time.ReadableInstant) dateTime34);
//        boolean boolean38 = gregorianChronology25.equals((java.lang.Object) int37);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now(dateTimeZone40);
//        org.joda.time.TimeOfDay timeOfDay42 = dateTime41.toTimeOfDay();
//        long long44 = gregorianChronology25.set((org.joda.time.ReadablePartial) timeOfDay42, (-11L));
//        boolean boolean45 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay42);
//        java.util.Locale locale46 = null;
//        try {
//            java.lang.String str47 = unsupportedDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) timeOfDay42, locale46);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 595449058L + "'", long23 == 595449058L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 24 + "'", int35 == 24);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 24 + "'", int36 == 24);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(timeOfDay42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-9325118L) + "'", long44 == (-9325118L));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test371");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.year();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getWeekOfWeekyear();
//        int int17 = dateTime15.getMinuteOfHour();
//        int int18 = property12.getDifference((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
//        org.joda.time.DateTime.Property property22 = dateTime21.year();
//        org.joda.time.DateTime dateTime23 = property22.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime25 = property22.addToCopy((long) (byte) -1);
//        org.joda.time.DateTime.Property property26 = dateTime25.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateMidnight dateMidnight30 = dateTime29.toDateMidnight();
//        boolean boolean31 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime29);
//        long long32 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime25);
//        boolean boolean33 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime35 = dateTime25.withYearOfEra(19);
//        org.joda.time.DateTime dateTime37 = dateTime25.withCenturyOfEra(10);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateMidnight30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//    }
//}

