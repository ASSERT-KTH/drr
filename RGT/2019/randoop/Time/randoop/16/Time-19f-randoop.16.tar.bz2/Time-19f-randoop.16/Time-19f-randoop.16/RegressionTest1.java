import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
        int int8 = offsetDateTimeField6.getLeapAmount(0L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText(2191787586692L, locale10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime15.toMutableDateTime();
        org.joda.time.DateTime dateTime17 = dateTime15.toDateTime();
        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
        boolean boolean20 = dateTime17.equals((java.lang.Object) (-171));
        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField6.getAsText((org.joda.time.ReadablePartial) yearMonthDay21, 9, locale23);
        org.joda.time.DateTimeField dateTimeField25 = offsetDateTimeField6.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "58" + "'", str11.equals("58"));
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(yearMonthDay21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9" + "'", str24.equals("9"));
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0L, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = property1.roundCeilingCopy();
        java.lang.String str3 = property1.getAsText();
        org.joda.time.DateTime dateTime5 = property1.addWrapFieldToCopy(119);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "20" + "'", str3.equals("20"));
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        long long9 = dateTimeZone6.convertLocalToUTC(1560635586792L, true);
        org.joda.time.Chronology chronology10 = gregorianChronology4.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime11 = dateTime3.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime13 = dateTime3.plusDays(0);
        boolean boolean15 = dateTime3.isEqual((long) (byte) 0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560635586692L + "'", long9 == 1560635586692L);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = iSOChronology3.withUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) (short) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        java.lang.String str11 = zonedChronology10.toString();
        org.joda.time.Chronology chronology12 = zonedChronology10.withUTC();
        try {
            long long18 = zonedChronology10.getDateTimeMillis((long) 53597, 292278993, 23, 5, 168);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ZonedChronology[ISOChronology[UTC], -01:01]" + "'", str11.equals("ZonedChronology[ISOChronology[UTC], -01:01]"));
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("2019-07-15T21:53:33.780+00:00:00.100");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2019-07-15T21:53:33.780+00:00:00.100/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.LocalTime localTime6 = dateTime3.toLocalTime();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localTime6);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.io.Writer writer1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.clockhourOfDay();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
//        org.joda.time.DateTime dateTime14 = property13.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime15 = dateTime14.toLocalDateTime();
//        int[] intArray17 = gregorianChronology9.get((org.joda.time.ReadablePartial) localDateTime15, 100L);
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology9.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.clockhourOfDay();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property23 = dateTime22.centuryOfEra();
//        org.joda.time.DateTime dateTime24 = property23.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime25 = dateTime24.toLocalDateTime();
//        int[] intArray27 = gregorianChronology19.get((org.joda.time.ReadablePartial) localDateTime25, 100L);
//        long long29 = gregorianChronology9.set((org.joda.time.ReadablePartial) localDateTime25, (long) (short) 10);
//        int int30 = offsetDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) localDateTime25);
//        java.util.Locale locale31 = null;
//        int int32 = offsetDateTimeField8.getMaximumShortTextLength(locale31);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) 53597);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property36 = dateTime35.centuryOfEra();
//        org.joda.time.DateTime dateTime38 = dateTime35.plusHours((int) 'a');
//        org.joda.time.DateTime.Property property39 = dateTime38.dayOfMonth();
//        org.joda.time.DateTime dateTime41 = dateTime38.plusHours((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone42 = dateTime38.getZone();
//        org.joda.time.Chronology chronology43 = null;
//        org.joda.time.MutableDateTime mutableDateTime44 = dateTime38.toMutableDateTime(chronology43);
//        int int45 = dateTime38.getHourOfDay();
//        org.joda.time.LocalDateTime localDateTime46 = dateTime38.toLocalDateTime();
//        org.joda.time.DateTime dateTime47 = dateTime34.withFields((org.joda.time.ReadablePartial) localDateTime46);
//        java.util.Locale locale49 = null;
//        java.lang.String str50 = offsetDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDateTime46, (-5), locale49);
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDateTime46);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(localDateTime15);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 4102444799900L + "'", long29 == 4102444799900L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 119 + "'", int30 == 119);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(mutableDateTime44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 9 + "'", int45 == 9);
//        org.junit.Assert.assertNotNull(localDateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "-5" + "'", str50.equals("-5"));
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
//        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
//        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.clockhourOfDay();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property14 = dateTime13.centuryOfEra();
//        org.joda.time.DateTime dateTime15 = property14.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime16 = dateTime15.toLocalDateTime();
//        int[] intArray18 = gregorianChronology10.get((org.joda.time.ReadablePartial) localDateTime16, 100L);
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology10.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.clockhourOfDay();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property24 = dateTime23.centuryOfEra();
//        org.joda.time.DateTime dateTime25 = property24.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime26 = dateTime25.toLocalDateTime();
//        int[] intArray28 = gregorianChronology20.get((org.joda.time.ReadablePartial) localDateTime26, 100L);
//        long long30 = gregorianChronology10.set((org.joda.time.ReadablePartial) localDateTime26, (long) (short) 10);
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology10.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 59);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.appendCenturyOfEra(10, (-1));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder34.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder42.appendTwoDigitWeekyear((int) (short) 100, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder46.appendCenturyOfEra(10, (-1));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder46.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder46.appendHourOfDay(19);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder57.appendCenturyOfEra(10, (-1));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder57.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder57.appendHourOfDay(19);
//        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property69 = dateTime68.centuryOfEra();
//        org.joda.time.DateTime dateTime70 = property69.roundCeilingCopy();
//        org.joda.time.DateTime.Property property71 = dateTime70.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = property71.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder67.appendShortText(dateTimeFieldType72);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder76 = dateTimeFormatterBuilder46.appendFraction(dateTimeFieldType72, (int) (byte) 0, (int) (short) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder45.appendDecimal(dateTimeFieldType72, 3, (int) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField83 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, dateTimeFieldType72, 100, 170, (-53597));
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField84 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType72);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localDateTime16);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 4102444799900L + "'", long30 == 4102444799900L);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//        org.junit.Assert.assertNotNull(property69);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(property71);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder76);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfEven((long) (short) -1);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
//        org.joda.time.DateTime.Property property13 = dateTime12.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType14, 19, (int) '4', (int) '4');
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField6.getType();
//        int int20 = offsetDateTimeField6.getOffset();
//        boolean boolean22 = offsetDateTimeField6.isLeap(100L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 19 + "'", int20 == 19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.Interval interval6 = property5.toInterval();
        int int7 = property5.getMinimumValueOverall();
        org.joda.time.DurationField durationField8 = property5.getDurationField();
        long long11 = durationField8.subtract((-171L), 0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-171L) + "'", long11 == (-171L));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        boolean boolean4 = dateTime3.isBeforeNow();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTime dateTime7 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.YearMonthDay yearMonthDay8 = dateTime3.toYearMonthDay();
        org.joda.time.Chronology chronology9 = dateTime3.getChronology();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(yearMonthDay8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readableDuration6);
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTime();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.append(dateTimeParser6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendEraText();
        boolean boolean12 = dateTimeFormatterBuilder10.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter15 = dateTimeFormatter14.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.append(dateTimeParser16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParser16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder3.appendMonthOfYear(22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimePrinter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.clockhourOfDay();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime13 = dateTime12.toLocalDateTime();
//        int[] intArray15 = gregorianChronology7.get((org.joda.time.ReadablePartial) localDateTime13, 100L);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology7.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.clockhourOfDay();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property21 = dateTime20.centuryOfEra();
//        org.joda.time.DateTime dateTime22 = property21.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime23 = dateTime22.toLocalDateTime();
//        int[] intArray25 = gregorianChronology17.get((org.joda.time.ReadablePartial) localDateTime23, 100L);
//        long long27 = gregorianChronology7.set((org.joda.time.ReadablePartial) localDateTime23, (long) (short) 10);
//        int int28 = offsetDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDateTime23);
//        boolean boolean30 = offsetDateTimeField6.isLeap((-1L));
//        int int31 = offsetDateTimeField6.getMinimumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localDateTime13);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(localDateTime23);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 4102444799900L + "'", long27 == 4102444799900L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 119 + "'", int28 == 119);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 20 + "'", int31 == 20);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) -1, 52, 86, (-53597), 4, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -53597 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "2019-06-19T22:53:29.523+00:00:00.100");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        long long8 = offsetDateTimeField6.roundHalfCeiling((long) 1);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-100L) + "'", long8 == (-100L));
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(32400200, 168, 100, 53597, 32400200);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53597 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfEven((long) (short) -1);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
//        org.joda.time.DateTime.Property property13 = dateTime12.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType14, 19, (int) '4', (int) '4');
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField6.getType();
//        int int20 = offsetDateTimeField6.getOffset();
//        boolean boolean21 = offsetDateTimeField6.isLenient();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 19 + "'", int20 == 19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = dateTime3.plusHours((int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime3.getZone();
        org.joda.time.DateTime dateTime8 = dateTime3.toDateTimeISO();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendHourOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.appendPattern("20");
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
        org.joda.time.DateTime dateTime17 = property16.roundCeilingCopy();
        org.joda.time.DateTime.Property property18 = dateTime17.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, "");
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType19, 15, (int) (byte) 0, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder14.appendFraction(dateTimeFieldType19, (int) (byte) 100, (int) 'a');
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) (byte) 10, "-01:01");
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = illegalFieldValueException31.getDateTimeFieldType();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        java.lang.Class<?> wildcardClass2 = dateTime0.getClass();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported", (java.lang.Number) 1560635586692L, (java.lang.Number) (-1.0f), (java.lang.Number) (-1.0f));
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        illegalFieldValueException4.prependMessage("+00:00:00.100");
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0f) + "'", number5.equals((-1.0f)));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfCentury();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField3 = gregorianChronology0.millis();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTime4.toString("0", locale6);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfCentury();
//        long long5 = gregorianChronology0.add(0L, 28800000L, (int) ' ');
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property8 = dateTime7.centuryOfEra();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.DateTime dateTime12 = dateTime10.toDateTime();
//        org.joda.time.DateTime.Property property13 = dateTime12.yearOfEra();
//        java.lang.String str14 = dateTime12.toString();
//        org.joda.time.DateTime dateTime16 = dateTime12.plusHours(170);
//        org.joda.time.DateTime.Property property17 = dateTime12.yearOfEra();
//        int int18 = dateTime12.getYear();
//        org.joda.time.DateTime dateTime20 = dateTime12.plusMillis(3);
//        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
//        long long23 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDateTime21, 1546329600100L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 921600000L + "'", long5 == 921600000L);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019-01-05T09:00:00.200+00:00:00.100" + "'", str14.equals("2019-01-05T09:00:00.200+00:00:00.100"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localDateTime21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546678800203L + "'", long23 == 1546678800203L);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = property2.roundCeilingCopy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime9 = dateTime6.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime9.toMutableDateTime();
        int int13 = dateTimeFormatter4.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "hi!", 0);
        int int14 = dateTime3.compareTo((org.joda.time.ReadableInstant) mutableDateTime10);
        int int17 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "", 53597);
        java.util.Locale locale18 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter0.withLocale(locale18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter0.withDefaultYear(10);
        try {
            org.joda.time.DateTime dateTime23 = dateTimeFormatter21.parseDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-53598) + "'", int17 == (-53598));
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = property1.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime3 = dateTime2.toLocalDateTime();
        int int4 = dateTime2.getHourOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(localDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.clockhourOfDay();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime13 = dateTime12.toLocalDateTime();
//        int[] intArray15 = gregorianChronology7.get((org.joda.time.ReadablePartial) localDateTime13, 100L);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology7.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.clockhourOfDay();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property21 = dateTime20.centuryOfEra();
//        org.joda.time.DateTime dateTime22 = property21.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime23 = dateTime22.toLocalDateTime();
//        int[] intArray25 = gregorianChronology17.get((org.joda.time.ReadablePartial) localDateTime23, 100L);
//        long long27 = gregorianChronology7.set((org.joda.time.ReadablePartial) localDateTime23, (long) (short) 10);
//        int int28 = offsetDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDateTime23);
//        boolean boolean30 = offsetDateTimeField6.isLeap((-1L));
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property32 = dateTime31.centuryOfEra();
//        org.joda.time.DateTime dateTime34 = dateTime31.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime35 = dateTime34.toMutableDateTime();
//        org.joda.time.DateTime dateTime36 = dateTime34.toDateTime();
//        org.joda.time.LocalDateTime localDateTime37 = dateTime34.toLocalDateTime();
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = offsetDateTimeField6.getAsText((org.joda.time.ReadablePartial) localDateTime37, locale38);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localDateTime13);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(localDateTime23);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 4102444799900L + "'", long27 == 4102444799900L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 119 + "'", int28 == 119);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(localDateTime37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "19" + "'", str39.equals("19"));
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
//        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone4);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
//        long long10 = dateTimeZone4.convertLocalToUTC((-1594775188062L), true, 5301590400010L);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1594775188162L) + "'", long10 == (-1594775188162L));
//        org.junit.Assert.assertNotNull(iSOChronology11);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.plus((long) 49);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime10.toMutableDateTime(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-52) + "'", int1 == (-52));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException5.prependMessage("");
        jodaTimePermission1.checkGuard((java.lang.Object) "");
        java.security.PermissionCollection permissionCollection9 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str10 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(permissionCollection9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("38", "2019-06-19T22:53:29.854+00:00:00.100", 119, (int) '4');
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        int int8 = fixedDateTimeZone4.getOffset((long) (byte) 1);
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 119 + "'", int6 == 119);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 119 + "'", int8 == 119);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
        int int8 = offsetDateTimeField6.getLeapAmount(0L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText(2191787586692L, locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField6.getType();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "58" + "'", str11.equals("58"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfEven((long) (short) -1);
//        java.lang.String str10 = offsetDateTimeField6.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[yearOfCentury]" + "'", str10.equals("DateTimeField[yearOfCentury]"));
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendHourOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.appendPattern("20");
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
        org.joda.time.DateTime dateTime17 = property16.roundCeilingCopy();
        org.joda.time.DateTime.Property property18 = dateTime17.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, "");
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType19, 15, (int) (byte) 0, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder14.appendFraction(dateTimeFieldType19, (int) (byte) 100, (int) 'a');
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property30 = dateTime29.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder14.appendFixedSignedDecimal(dateTimeFieldType31, (int) (short) 100);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 22, "ISOChronology[+00:00:00.100]");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(168);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.joda.time.DateTime.Property property11 = dateTime10.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "");
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType12, 15, (int) (byte) 0, 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder5.appendDecimal(dateTimeFieldType12, (-53597), 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("38");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"38/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean7 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission6);
        jodaTimePermission3.checkGuard((java.lang.Object) (-100L));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear((int) (byte) 1, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime6 = property5.roundCeilingCopy();
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withEra(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendHourOfDay(19);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
        org.joda.time.DateTime dateTime13 = property12.roundCeilingCopy();
        org.joda.time.DateTime.Property property14 = dateTime13.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatter17.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder10.append(dateTimeFormatter17);
        java.lang.Appendable appendable21 = null;
        try {
            dateTimeFormatter17.printTo(appendable21, (long) 2922789);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimePrinter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
//        org.joda.time.DateTime.Property property6 = dateTime3.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = property6.roundFloorCopy();
//        int int8 = dateTime7.getMonthOfYear();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = iSOChronology3.withUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) (short) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        java.lang.String str11 = zonedChronology10.toString();
        org.joda.time.Chronology chronology12 = zonedChronology10.withUTC();
        org.joda.time.Chronology chronology13 = zonedChronology10.withUTC();
        org.joda.time.DurationField durationField14 = zonedChronology10.seconds();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ZonedChronology[ISOChronology[UTC], -01:01]" + "'", str11.equals("ZonedChronology[ISOChronology[UTC], -01:01]"));
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfCentury();
//        long long5 = gregorianChronology0.add(0L, 28800000L, (int) ' ');
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.clockhourOfDay();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property10 = dateTime9.centuryOfEra();
//        org.joda.time.DateTime dateTime11 = property10.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
//        int[] intArray14 = gregorianChronology6.get((org.joda.time.ReadablePartial) localDateTime12, 100L);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology6.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.millisOfSecond();
//        org.joda.time.DurationField durationField18 = gregorianChronology16.days();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology16.weekyearOfCentury();
//        org.joda.time.DurationField durationField20 = gregorianChronology16.weekyears();
//        boolean boolean21 = gregorianChronology6.equals((java.lang.Object) gregorianChronology16);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property23 = dateTime22.centuryOfEra();
//        org.joda.time.DateTime dateTime25 = dateTime22.plusHours((int) 'a');
//        boolean boolean26 = dateTime25.isBeforeNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology27.getZone();
//        org.joda.time.DateTime dateTime29 = dateTime25.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.Chronology chronology30 = gregorianChronology6.withZone(dateTimeZone28);
//        int int32 = dateTimeZone28.getOffsetFromLocal((long) (byte) 1);
//        org.joda.time.Chronology chronology33 = gregorianChronology0.withZone(dateTimeZone28);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 921600000L + "'", long5 == 921600000L);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDateTime12);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
//        org.junit.Assert.assertNotNull(chronology33);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone7);
        java.lang.Object obj9 = null;
        boolean boolean10 = zonedChronology8.equals(obj9);
        org.joda.time.DateTimeZone dateTimeZone11 = zonedChronology8.getZone();
        try {
            long long16 = zonedChronology8.getDateTimeMillis(0, (int) (byte) 100, 0, 23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        long long9 = dateTimeZone6.convertLocalToUTC(1560635586792L, true);
        org.joda.time.Chronology chronology10 = gregorianChronology4.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime11 = dateTime3.withZone(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime3.minus(readableDuration12);
        try {
            org.joda.time.DateTime dateTime17 = dateTime13.withDate((-171), 9, 32400200);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32400200 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560635586692L + "'", long9 == 1560635586692L);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
//        boolean boolean6 = gregorianChronology1.equals((java.lang.Object) dateTimeZone5);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
//        java.lang.String str9 = cachedDateTimeZone7.getNameKey(100L);
//        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(2191787586692L, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology10 = zonedChronology8.withZone(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) ' ', (int) ' ', 23, 100, 9, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("");
        java.lang.Number number5 = illegalFieldValueException2.getLowerBound();
        java.lang.String str6 = illegalFieldValueException2.toString();
        java.lang.Number number7 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.Throwable[] throwableArray8 = illegalFieldValueException2.getSuppressed();
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported" + "'", str6.equals("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported"));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNull(durationFieldType9);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfFloor((long) '4');
//        int int10 = offsetDateTimeField6.getMinimumValue();
//        long long13 = offsetDateTimeField6.add((long) 7, (long) (byte) 0);
//        java.lang.String str15 = offsetDateTimeField6.getAsText((long) 23);
//        long long18 = offsetDateTimeField6.add((long) (-171), 0L);
//        int int20 = offsetDateTimeField6.get(315532799900L);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = offsetDateTimeField6.getAsShortText(0L, locale22);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 7L + "'", long13 == 7L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "89" + "'", str15.equals("89"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-171L) + "'", long18 == (-171L));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 99 + "'", int20 == 99);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "89" + "'", str23.equals("89"));
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2149-06-19T23:53:21.885-07:00", (java.lang.Number) 4102473600000L, (java.lang.Number) (byte) 1, (java.lang.Number) (-1L));
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException7.prependMessage("");
        java.lang.Number number10 = illegalFieldValueException7.getLowerBound();
        java.lang.String str11 = illegalFieldValueException7.toString();
        java.lang.Number number12 = illegalFieldValueException7.getIllegalNumberValue();
        java.lang.Throwable[] throwableArray13 = illegalFieldValueException7.getSuppressed();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        java.lang.Number number15 = illegalFieldValueException7.getUpperBound();
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported" + "'", str11.equals("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported"));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNull(number15);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = iSOChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.Chronology chronology6 = iSOChronology3.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        boolean boolean12 = gregorianChronology7.equals((java.lang.Object) dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology3, dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(zonedChronology17);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.millisOfSecond();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(2149, 0, (int) (byte) 0, 0, (-52), (int) (short) -1, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -52 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
//        java.lang.String str7 = dateTime5.toString();
//        org.joda.time.DateTime dateTime9 = dateTime5.plusHours(170);
//        org.joda.time.DateTime.Property property10 = dateTime5.yearOfEra();
//        org.joda.time.DateTime dateTime12 = property10.addToCopy(15);
//        org.joda.time.DateTime dateTime14 = property10.addWrapFieldToCopy((-53597));
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-01-05T09:00:00.200+00:00:00.100" + "'", str7.equals("2019-01-05T09:00:00.200+00:00:00.100"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property5 = dateTime4.centuryOfEra();
        org.joda.time.DateTime dateTime6 = property5.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime7 = dateTime6.toLocalDateTime();
        int[] intArray9 = gregorianChronology1.get((org.joda.time.ReadablePartial) localDateTime7, 100L);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology1.yearOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.millisOfSecond();
        org.joda.time.DurationField durationField13 = gregorianChronology11.days();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.weekyearOfCentury();
        org.joda.time.DurationField durationField15 = gregorianChronology11.weekyears();
        boolean boolean16 = gregorianChronology1.equals((java.lang.Object) gregorianChronology11);
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        boolean boolean18 = iSOChronology0.equals((java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField20 = iSOChronology0.weeks();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.plusHours((int) 'a');
        boolean boolean5 = dateTime4.isBeforeNow();
        int int6 = dateTime4.getYearOfCentury();
        org.joda.time.Chronology chronology7 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime dateTime10 = dateTime8.withMillis(0L);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((-53597));
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfEven((long) (short) -1);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
//        org.joda.time.DateTime.Property property13 = dateTime12.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType14, 19, (int) '4', (int) '4');
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField6.getType();
//        int int20 = offsetDateTimeField6.getOffset();
//        try {
//            long long23 = offsetDateTimeField6.set((long) (short) 1, (-1));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfCentury must be in the range [20,119]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 19 + "'", int20 == 19);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long4 = gregorianChronology0.add(0L, (-1595124383515L), 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1595124383515L) + "'", long4 == (-1595124383515L));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        try {
            long long9 = gregorianChronology0.getDateTimeMillis((int) ' ', (int) (byte) 10, 119, 0, 0, 0, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 119 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
//        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
//        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.clockhourOfDay();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property14 = dateTime13.centuryOfEra();
//        org.joda.time.DateTime dateTime15 = property14.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime16 = dateTime15.toLocalDateTime();
//        int[] intArray18 = gregorianChronology10.get((org.joda.time.ReadablePartial) localDateTime16, 100L);
//        long long20 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDateTime16, (long) (short) 10);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, 59);
//        boolean boolean25 = offsetDateTimeField23.isLeap((long) (-53598));
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology27.getZone();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology27);
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 19);
//        org.joda.time.DurationField durationField33 = offsetDateTimeField32.getLeapDurationField();
//        long long35 = offsetDateTimeField32.roundHalfEven((long) (short) -1);
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property37 = dateTime36.centuryOfEra();
//        org.joda.time.DateTime dateTime38 = property37.roundCeilingCopy();
//        org.joda.time.DateTime.Property property39 = dateTime38.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField32, dateTimeFieldType40, 19, (int) '4', (int) '4');
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property46 = dateTime45.centuryOfEra();
//        org.joda.time.DateTime dateTime47 = property46.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime48 = dateTime47.toLocalDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone51 = gregorianChronology50.getZone();
//        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology50.clockhourOfDay();
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property54 = dateTime53.centuryOfEra();
//        org.joda.time.DateTime dateTime55 = property54.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
//        int[] intArray58 = gregorianChronology50.get((org.joda.time.ReadablePartial) localDateTime56, 100L);
//        int[] intArray60 = offsetDateTimeField44.add((org.joda.time.ReadablePartial) localDateTime48, 59, intArray58, 0);
//        java.util.Locale locale62 = null;
//        java.lang.String str63 = offsetDateTimeField23.getAsShortText((org.joda.time.ReadablePartial) localDateTime48, 100, locale62);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localDateTime16);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 4102444799900L + "'", long20 == 4102444799900L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNull(durationField33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-100L) + "'", long35 == (-100L));
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(localDateTime48);
//        org.junit.Assert.assertNotNull(gregorianChronology50);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(localDateTime56);
//        org.junit.Assert.assertNotNull(intArray58);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "100" + "'", str63.equals("100"));
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfFloor((long) '4');
//        int int10 = offsetDateTimeField6.getMinimumValue();
//        long long13 = offsetDateTimeField6.addWrapField(1560635586692L, 20);
//        long long16 = offsetDateTimeField6.add((long) 15, 28800000L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2191787586692L + "'", long13 == 2191787586692L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 908840217600000015L + "'", long16 == 908840217600000015L);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("21", (java.lang.Number) (-1.0d), (java.lang.Number) 15, (java.lang.Number) (-18900L));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra(19, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.hours();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray7 = iSOChronology3.get(readablePeriod5, (long) 2922789);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readableDuration6);
        org.joda.time.DateTime.Property property8 = dateTime7.hourOfDay();
        org.joda.time.Interval interval9 = property8.toInterval();
        org.joda.time.DurationField durationField10 = property8.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property8.getFieldType();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = property2.roundCeilingCopy();
        org.joda.time.DateTime.Property property4 = dateTime3.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property4.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType5, "");
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField8 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        boolean boolean4 = dateTime3.isBeforeNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
//        org.joda.time.DateTime dateTime7 = dateTime3.withZoneRetainFields(dateTimeZone6);
//        org.joda.time.DateTime.Property property8 = dateTime7.era();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 19);
//        long long17 = offsetDateTimeField15.roundHalfEven(1560635586792L);
//        java.lang.String str19 = offsetDateTimeField15.getAsText((long) (-1));
//        long long22 = offsetDateTimeField15.add(10L, (long) 168);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology24.getZone();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology24);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology24.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology30.getZone();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.clockhourOfDay();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property34 = dateTime33.centuryOfEra();
//        org.joda.time.DateTime dateTime35 = property34.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime36 = dateTime35.toLocalDateTime();
//        int[] intArray38 = gregorianChronology30.get((org.joda.time.ReadablePartial) localDateTime36, 100L);
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology30.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone41 = gregorianChronology40.getZone();
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.clockhourOfDay();
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property44 = dateTime43.centuryOfEra();
//        org.joda.time.DateTime dateTime45 = property44.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime46 = dateTime45.toLocalDateTime();
//        int[] intArray48 = gregorianChronology40.get((org.joda.time.ReadablePartial) localDateTime46, 100L);
//        long long50 = gregorianChronology30.set((org.joda.time.ReadablePartial) localDateTime46, (long) (short) 10);
//        int int51 = offsetDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDateTime46);
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) localDateTime46, locale52);
//        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology54.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone58 = gregorianChronology57.getZone();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology57);
//        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology57.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, 19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone64 = gregorianChronology63.getZone();
//        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology63.clockhourOfDay();
//        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property67 = dateTime66.centuryOfEra();
//        org.joda.time.DateTime dateTime68 = property67.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime69 = dateTime68.toLocalDateTime();
//        int[] intArray71 = gregorianChronology63.get((org.joda.time.ReadablePartial) localDateTime69, 100L);
//        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology63.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology73 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone74 = gregorianChronology73.getZone();
//        org.joda.time.DateTimeField dateTimeField75 = gregorianChronology73.clockhourOfDay();
//        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property77 = dateTime76.centuryOfEra();
//        org.joda.time.DateTime dateTime78 = property77.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime79 = dateTime78.toLocalDateTime();
//        int[] intArray81 = gregorianChronology73.get((org.joda.time.ReadablePartial) localDateTime79, 100L);
//        long long83 = gregorianChronology63.set((org.joda.time.ReadablePartial) localDateTime79, (long) (short) 10);
//        int int84 = offsetDateTimeField62.getMaximumValue((org.joda.time.ReadablePartial) localDateTime79);
//        long long86 = gregorianChronology54.set((org.joda.time.ReadablePartial) localDateTime79, 1546329600000L);
//        java.util.Locale locale87 = null;
//        java.lang.String str88 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDateTime79, locale87);
//        int int89 = property8.compareTo((org.joda.time.ReadablePartial) localDateTime79);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546300799900L + "'", long17 == 1546300799900L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "89" + "'", str19.equals("89"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 5301590400010L + "'", long22 == 5301590400010L);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(localDateTime36);
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(localDateTime46);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 4102444799900L + "'", long50 == 4102444799900L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 119 + "'", int51 == 119);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "0" + "'", str53.equals("0"));
//        org.junit.Assert.assertNotNull(gregorianChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(gregorianChronology57);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertNotNull(property67);
//        org.junit.Assert.assertNotNull(dateTime68);
//        org.junit.Assert.assertNotNull(localDateTime69);
//        org.junit.Assert.assertNotNull(intArray71);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertNotNull(gregorianChronology73);
//        org.junit.Assert.assertNotNull(dateTimeZone74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertNotNull(property77);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertNotNull(localDateTime79);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 4102444799900L + "'", long83 == 4102444799900L);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 119 + "'", int84 == 119);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 4102444799900L + "'", long86 == 4102444799900L);
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "0" + "'", str88.equals("0"));
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
//        boolean boolean11 = gregorianChronology6.equals((java.lang.Object) dateTimeZone10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
//        boolean boolean14 = cachedDateTimeZone13.isFixed();
//        try {
//            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(540, 0, 2149, 2922789, (int) (short) 0, 3600, (org.joda.time.DateTimeZone) cachedDateTimeZone13);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology8.getZone();
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = dateTimeZone10.isLocalDateTimeGap(localDateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("86");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withDurationAdded(readableDuration2, (int) (short) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes((int) (short) 10);
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = dateTime1.toString("2019-06-19T22:53:38.591+00:00:00.100", locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
//        boolean boolean8 = dateTime5.equals((java.lang.Object) (-171));
//        org.joda.time.DateTime.Property property9 = dateTime5.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTime5.getZone();
//        org.joda.time.DateTime dateTime12 = dateTime5.minusMinutes(0);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property14 = dateTime13.centuryOfEra();
//        org.joda.time.DateTime dateTime16 = dateTime13.plusHours((int) 'a');
//        boolean boolean17 = dateTime16.isBeforeNow();
//        int int18 = dateTime16.getYearOfCentury();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology22.getZone();
//        boolean boolean24 = gregorianChronology19.equals((java.lang.Object) dateTimeZone23);
//        org.joda.time.DateTime dateTime25 = dateTime16.withZoneRetainFields(dateTimeZone23);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone23.getName((-1595149603157L), locale27);
//        org.joda.time.DateTime dateTime29 = dateTime5.withZoneRetainFields(dateTimeZone23);
//        org.joda.time.DateTime dateTime32 = dateTime5.withDurationAdded(5663109201710L, 3);
//        int int33 = dateTime5.getMinuteOfDay();
//        int int34 = dateTime5.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 19 + "'", int18 == 19);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00:00.100" + "'", str28.equals("+00:00:00.100"));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 540 + "'", int33 == 540);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime7 = dateTime3.minusDays((int) (short) 10);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        long long9 = dateTimeZone6.convertLocalToUTC(1560635586792L, true);
        org.joda.time.Chronology chronology10 = gregorianChronology4.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime11 = dateTime3.withZone(dateTimeZone6);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560635586692L + "'", long9 == 1560635586692L);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
//        boolean boolean8 = dateTime5.equals((java.lang.Object) (-171));
//        org.joda.time.DateTime.Property property9 = dateTime5.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTime5.getZone();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 53597);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property14 = dateTime13.centuryOfEra();
//        org.joda.time.DateTime dateTime16 = dateTime13.plusHours((int) 'a');
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfMonth();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone20 = dateTime16.getZone();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MutableDateTime mutableDateTime22 = dateTime16.toMutableDateTime(chronology21);
//        int int23 = dateTime16.getHourOfDay();
//        org.joda.time.LocalDateTime localDateTime24 = dateTime16.toLocalDateTime();
//        org.joda.time.DateTime dateTime25 = dateTime12.withFields((org.joda.time.ReadablePartial) localDateTime24);
//        org.joda.time.DateTime dateTime26 = dateTime5.withFields((org.joda.time.ReadablePartial) localDateTime24);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property29 = dateTime28.centuryOfEra();
//        org.joda.time.DateTime dateTime30 = property29.roundCeilingCopy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.yearMonth();
//        org.joda.time.format.DateTimePrinter dateTimePrinter32 = dateTimeFormatter31.getPrinter();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property34 = dateTime33.centuryOfEra();
//        org.joda.time.DateTime dateTime36 = dateTime33.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime37 = dateTime36.toMutableDateTime();
//        int int40 = dateTimeFormatter31.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime37, "hi!", 0);
//        int int41 = dateTime30.compareTo((org.joda.time.ReadableInstant) mutableDateTime37);
//        int int44 = dateTimeFormatter27.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime37, "", 53597);
//        java.util.Locale locale45 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter27.withLocale(locale45);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = dateTimeFormatter27.withDefaultYear(10);
//        java.lang.String str49 = dateTime26.toString(dateTimeFormatter48);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
//        org.junit.Assert.assertNotNull(localDateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimePrinter32);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(mutableDateTime37);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-53598) + "'", int44 == (-53598));
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(dateTimeFormatter48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2019-01-05T09" + "'", str49.equals("2019-01-05T09"));
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        boolean boolean6 = dateTime3.isBeforeNow();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 665, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
//        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone4);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
//        java.lang.String str8 = cachedDateTimeZone6.getNameKey((long) (byte) 100);
//        long long10 = cachedDateTimeZone6.nextTransition((long) '4');
//        java.lang.String str12 = cachedDateTimeZone6.getName((long) (short) 100);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.100" + "'", str12.equals("+00:00:00.100"));
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 19, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
//        java.lang.String str7 = dateTime5.toString();
//        org.joda.time.DateTime dateTime9 = dateTime5.minusSeconds((int) 'a');
//        int int10 = dateTime9.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-01-05T09:00:00.200+00:00:00.100" + "'", str7.equals("2019-01-05T09:00:00.200+00:00:00.100"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 23 + "'", int10 == 23);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        try {
            int[] intArray17 = gregorianChronology0.get(readablePeriod14, (long) 89, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) (-53598), 23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        int int6 = dateTime5.getDayOfYear();
//        org.joda.time.DateTime dateTime8 = dateTime5.plus((long) (short) 10);
//        int int9 = dateTime8.getHourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        long long14 = dateTimeZone11.convertLocalToUTC(1560635586792L, true);
//        java.lang.String str15 = dateTimeZone11.getID();
//        long long19 = dateTimeZone11.convertLocalToUTC((long) (byte) 10, false, (long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime20 = dateTime8.toMutableDateTime(dateTimeZone11);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone11);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560635586692L + "'", long14 == 1560635586692L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.100" + "'", str15.equals("+00:00:00.100"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-90L) + "'", long19 == (-90L));
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
//        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
//        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfEra();
//        java.lang.String str10 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.minuteOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[+00:00:00.100]" + "'", str10.equals("GregorianChronology[+00:00:00.100]"));
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "ZonedChronology[GregorianChronology[UTC], UTC]", "38");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported", "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusMonths((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DurationField durationField6 = gregorianChronology4.days();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime3.toMutableDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime dateTime10 = dateTime3.minusMonths((int) (byte) 1);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        java.lang.Appendable appendable4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property6 = dateTime5.centuryOfEra();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.DateTime.Property property8 = dateTime7.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.DateTime dateTime11 = property8.addToCopy(59);
        try {
            dateTimeFormatter0.printTo(appendable4, (org.joda.time.ReadableInstant) dateTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
//        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
//        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.clockhourOfDay();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property14 = dateTime13.centuryOfEra();
//        org.joda.time.DateTime dateTime15 = property14.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime16 = dateTime15.toLocalDateTime();
//        int[] intArray18 = gregorianChronology10.get((org.joda.time.ReadablePartial) localDateTime16, 100L);
//        long long20 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDateTime16, (long) (short) 10);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, 59);
//        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField23.getWrappedField();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localDateTime16);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 946684799900L + "'", long20 == 946684799900L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
//        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
//        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.millisOfSecond();
//        org.joda.time.DurationField durationField12 = gregorianChronology10.days();
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.weekyearOfCentury();
//        org.joda.time.DurationField durationField14 = gregorianChronology10.weekyears();
//        boolean boolean15 = gregorianChronology0.equals((java.lang.Object) gregorianChronology10);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology0.centuryOfEra();
//        java.lang.String str18 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology0.millisOfSecond();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "GregorianChronology[+00:00:00.100]" + "'", str18.equals("GregorianChronology[+00:00:00.100]"));
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        long long8 = offsetDateTimeField6.roundHalfEven(1560635586792L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 19);
//        long long17 = offsetDateTimeField15.roundHalfEven(1560635586792L);
//        java.lang.String str19 = offsetDateTimeField15.getAsText((long) (-1));
//        long long22 = offsetDateTimeField15.add(10L, (long) 168);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology24.getZone();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology24);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology24.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology30.getZone();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.clockhourOfDay();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property34 = dateTime33.centuryOfEra();
//        org.joda.time.DateTime dateTime35 = property34.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime36 = dateTime35.toLocalDateTime();
//        int[] intArray38 = gregorianChronology30.get((org.joda.time.ReadablePartial) localDateTime36, 100L);
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology30.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone41 = gregorianChronology40.getZone();
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.clockhourOfDay();
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property44 = dateTime43.centuryOfEra();
//        org.joda.time.DateTime dateTime45 = property44.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime46 = dateTime45.toLocalDateTime();
//        int[] intArray48 = gregorianChronology40.get((org.joda.time.ReadablePartial) localDateTime46, 100L);
//        long long50 = gregorianChronology30.set((org.joda.time.ReadablePartial) localDateTime46, (long) (short) 10);
//        int int51 = offsetDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDateTime46);
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) localDateTime46, locale52);
//        java.util.Locale locale54 = null;
//        java.lang.String str55 = offsetDateTimeField6.getAsText((org.joda.time.ReadablePartial) localDateTime46, locale54);
//        int int58 = offsetDateTimeField6.getDifference((long) (-53597), (long) 15);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546300799900L + "'", long8 == 1546300799900L);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546300799900L + "'", long17 == 1546300799900L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "89" + "'", str19.equals("89"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 5301590400010L + "'", long22 == 5301590400010L);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(localDateTime36);
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(localDateTime46);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 946684799900L + "'", long50 == 946684799900L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 119 + "'", int51 == 119);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "0" + "'", str53.equals("0"));
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0" + "'", str55.equals("0"));
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        boolean boolean4 = dateTime3.isBeforeNow();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTime dateTime7 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property10 = dateTime9.centuryOfEra();
        org.joda.time.DateTime dateTime12 = dateTime9.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime12.toMutableDateTime();
        org.joda.time.DateTime.Property property14 = dateTime12.centuryOfEra();
        org.joda.time.Interval interval15 = property14.toInterval();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.centuryOfEra();
        org.joda.time.DateTime dateTime18 = property17.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
        long long20 = property14.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime23 = dateTime18.withEra(0);
        try {
            long long24 = property8.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(interval15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((int) '4');
        org.joda.time.DateTime.Property property9 = dateTime5.dayOfWeek();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime5.withPeriodAdded(readablePeriod10, 168);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property8 = dateTime7.centuryOfEra();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.DateTime dateTime12 = dateTime10.toDateTime();
//        org.joda.time.DateTime.Property property13 = dateTime12.yearOfEra();
//        boolean boolean15 = dateTime12.equals((java.lang.Object) (-171));
//        org.joda.time.DateTime.Property property16 = dateTime12.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone17 = dateTime12.getZone();
//        org.joda.time.DateTime dateTime19 = dateTime12.minusMinutes(0);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property21 = dateTime20.centuryOfEra();
//        org.joda.time.DateTime dateTime23 = dateTime20.plusHours((int) 'a');
//        boolean boolean24 = dateTime23.isBeforeNow();
//        int int25 = dateTime23.getYearOfCentury();
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology26.getZone();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
//        boolean boolean31 = gregorianChronology26.equals((java.lang.Object) dateTimeZone30);
//        org.joda.time.DateTime dateTime32 = dateTime23.withZoneRetainFields(dateTimeZone30);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = dateTimeZone30.getName((-1595149603157L), locale34);
//        org.joda.time.DateTime dateTime36 = dateTime12.withZoneRetainFields(dateTimeZone30);
//        int int37 = property6.compareTo((org.joda.time.ReadableInstant) dateTime36);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 70 + "'", int25 == 70);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "+00:00:00.100" + "'", str35.equals("+00:00:00.100"));
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = zonedChronology8.getZone();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property18 = dateTime17.centuryOfEra();
        org.joda.time.DateTime dateTime20 = dateTime17.plusHours((int) 'a');
        org.joda.time.DateTime.Property property21 = dateTime20.dayOfMonth();
        org.joda.time.DateTime dateTime23 = dateTime20.plusHours((int) '#');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime20.getZone();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((int) (byte) 1, 3, 10, 5, 9, 0, 15, dateTimeZone24);
        boolean boolean26 = zonedChronology8.equals((java.lang.Object) dateTimeZone24);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendHourOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.appendPattern("20");
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
        org.joda.time.DateTime dateTime17 = property16.roundCeilingCopy();
        org.joda.time.DateTime.Property property18 = dateTime17.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, "");
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType19, 15, (int) (byte) 0, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder14.appendFraction(dateTimeFieldType19, (int) (byte) 100, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendHourOfHalfday(2149);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder28.appendDayOfWeek((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.year();
        org.joda.time.DurationField durationField12 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.millisOfSecond();
        org.joda.time.DurationField durationField12 = gregorianChronology10.days();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.weekyearOfCentury();
        org.joda.time.DurationField durationField14 = gregorianChronology10.weekyears();
        boolean boolean15 = gregorianChronology0.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField4 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.clockhourOfDay();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime13 = dateTime12.toLocalDateTime();
//        int[] intArray15 = gregorianChronology7.get((org.joda.time.ReadablePartial) localDateTime13, 100L);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology7.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.clockhourOfDay();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property21 = dateTime20.centuryOfEra();
//        org.joda.time.DateTime dateTime22 = property21.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime23 = dateTime22.toLocalDateTime();
//        int[] intArray25 = gregorianChronology17.get((org.joda.time.ReadablePartial) localDateTime23, 100L);
//        long long27 = gregorianChronology7.set((org.joda.time.ReadablePartial) localDateTime23, (long) (short) 10);
//        int int28 = offsetDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDateTime23);
//        java.util.Locale locale29 = null;
//        int int30 = offsetDateTimeField6.getMaximumShortTextLength(locale29);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) 53597);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property34 = dateTime33.centuryOfEra();
//        org.joda.time.DateTime dateTime36 = dateTime33.plusHours((int) 'a');
//        org.joda.time.DateTime.Property property37 = dateTime36.dayOfMonth();
//        org.joda.time.DateTime dateTime39 = dateTime36.plusHours((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone40 = dateTime36.getZone();
//        org.joda.time.Chronology chronology41 = null;
//        org.joda.time.MutableDateTime mutableDateTime42 = dateTime36.toMutableDateTime(chronology41);
//        int int43 = dateTime36.getHourOfDay();
//        org.joda.time.LocalDateTime localDateTime44 = dateTime36.toLocalDateTime();
//        org.joda.time.DateTime dateTime45 = dateTime32.withFields((org.joda.time.ReadablePartial) localDateTime44);
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = offsetDateTimeField6.getAsText((org.joda.time.ReadablePartial) localDateTime44, (-5), locale47);
//        int int50 = offsetDateTimeField6.get((long) 99);
//        long long52 = offsetDateTimeField6.roundCeiling(0L);
//        long long54 = offsetDateTimeField6.roundHalfCeiling((long) (-1));
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localDateTime13);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(localDateTime23);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 946684799900L + "'", long27 == 946684799900L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 119 + "'", int28 == 119);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(mutableDateTime42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertNotNull(localDateTime44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "-5" + "'", str48.equals("-5"));
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 89 + "'", int50 == 89);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 31535999900L + "'", long52 == 31535999900L);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-100L) + "'", long54 == (-100L));
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = dateTime2.plusHours((int) 'a');
        boolean boolean6 = dateTime5.isBeforeNow();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.DateTime dateTime9 = dateTime5.withZoneRetainFields(dateTimeZone8);
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime5.toYearMonthDay();
        boolean boolean11 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay10);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) yearMonthDay10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendTwoDigitWeekyear((int) (short) 100, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder13.appendClockhourOfHalfday(2019);
        jodaTimePermission3.checkGuard((java.lang.Object) dateTimeFormatterBuilder13);
        java.lang.String str20 = jodaTimePermission3.getName();
        java.security.PermissionCollection permissionCollection21 = jodaTimePermission3.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertNotNull(permissionCollection21);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "89");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "2019-06-19T15:53:19.665-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear((int) (short) 100, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendClockhourOfHalfday(2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday(1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendWeekOfWeekyear(168);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendTimeZoneOffset("2149-06-19T23:53:21.796-07:00", true, 70, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
//        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone4);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
//        java.lang.String str8 = cachedDateTimeZone6.getNameKey(100L);
//        int int10 = cachedDateTimeZone6.getOffset(1L);
//        java.lang.String str11 = cachedDateTimeZone6.toString();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
//        org.joda.time.DateTime dateTime15 = dateTime12.minusMonths((-1));
//        org.joda.time.DateTime.Property property16 = dateTime15.minuteOfDay();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        org.joda.time.DateTime dateTime19 = property16.getDateTime();
//        org.joda.time.DateTime.Property property20 = dateTime19.hourOfDay();
//        boolean boolean21 = cachedDateTimeZone6.equals((java.lang.Object) property20);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.100" + "'", str11.equals("+00:00:00.100"));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        boolean boolean4 = dateTime3.isBeforeNow();
        org.joda.time.DateTime.Property property5 = dateTime3.era();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone7);
        java.lang.Object obj9 = null;
        boolean boolean10 = zonedChronology8.equals(obj9);
        java.lang.String str11 = zonedChronology8.toString();
        java.lang.String str12 = zonedChronology8.toString();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        try {
            int[] intArray16 = zonedChronology8.get(readablePeriod13, 1560635586792L, (long) 86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str11.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str12.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        long long9 = dateTimeZone6.convertLocalToUTC(1560635586792L, true);
        org.joda.time.Chronology chronology10 = gregorianChronology4.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime11 = dateTime3.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime13 = dateTime3.plusDays(0);
        org.joda.time.DateTime dateTime15 = dateTime3.minusHours((int) (short) 10);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560635586692L + "'", long9 == 1560635586692L);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = property2.roundCeilingCopy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime9 = dateTime6.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime9.toMutableDateTime();
        int int13 = dateTimeFormatter4.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "hi!", 0);
        int int14 = dateTime3.compareTo((org.joda.time.ReadableInstant) mutableDateTime10);
        int int17 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "", 53597);
        java.util.Locale locale18 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter0.withLocale(locale18);
        java.lang.Appendable appendable20 = null;
        try {
            dateTimeFormatter0.printTo(appendable20, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-53598) + "'", int17 == (-53598));
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        boolean boolean4 = dateTime3.isBeforeNow();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTime dateTime7 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime3.minusWeeks(0);
        org.joda.time.DateTime dateTime10 = dateTime3.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property5 = dateTime4.centuryOfEra();
//        org.joda.time.DateTime dateTime6 = property5.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime7 = dateTime6.toLocalDateTime();
//        int[] intArray9 = gregorianChronology1.get((org.joda.time.ReadablePartial) localDateTime7, 100L);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology1.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.millisOfSecond();
//        org.joda.time.DurationField durationField13 = gregorianChronology11.days();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.weekyearOfCentury();
//        org.joda.time.DurationField durationField15 = gregorianChronology11.weekyears();
//        boolean boolean16 = gregorianChronology1.equals((java.lang.Object) gregorianChronology11);
//        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
//        boolean boolean18 = iSOChronology0.equals((java.lang.Object) gregorianChronology1);
//        java.lang.String str19 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology0.millisOfSecond();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDateTime7);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[+00:00:00.100]" + "'", str19.equals("ISOChronology[+00:00:00.100]"));
//        org.junit.Assert.assertNotNull(dateTimeField20);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfEven((long) (short) -1);
//        org.joda.time.DurationField durationField10 = offsetDateTimeField6.getLeapDurationField();
//        java.util.Locale locale13 = null;
//        long long14 = offsetDateTimeField6.set((long) 1, "58", locale13);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertNull(durationField10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-978307199999L) + "'", long14 == (-978307199999L));
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder3.appendHourOfDay(19);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property15 = dateTime14.centuryOfEra();
        org.joda.time.DateTime dateTime16 = property15.roundCeilingCopy();
        org.joda.time.DateTime.Property property17 = dateTime16.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder13.appendShortText(dateTimeFieldType18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder1.appendShortText(dateTimeFieldType18);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.millisOfSecond();
        org.joda.time.DurationField durationField23 = gregorianChronology21.days();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.weekyearOfCentury();
        org.joda.time.DurationField durationField25 = gregorianChronology21.weekyears();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology21.minuteOfDay();
        org.joda.time.DurationField durationField27 = gregorianChronology21.seconds();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DurationField durationField32 = iSOChronology31.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField33 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType18, durationField27, durationField32);
        org.joda.time.DurationField durationField34 = preciseDateTimeField33.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(durationField34);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) -1, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(1439, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1536 + "'", int2 == 1536);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime7 = dateTime3.minusYears(0);
        org.joda.time.DateTime dateTime9 = dateTime3.plusYears((int) '#');
        boolean boolean11 = dateTime3.isBefore(0L);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfFloor((long) '4');
//        int int10 = offsetDateTimeField6.getMinimumValue();
//        int int12 = offsetDateTimeField6.getMaximumValue((-1595149610804L));
//        long long15 = offsetDateTimeField6.add((-1595124372090L), 0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 119 + "'", int12 == 119);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1595124372090L) + "'", long15 == (-1595124372090L));
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withLocale(locale3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        boolean boolean4 = dateTime3.isBeforeNow();
//        int int5 = dateTime3.getYearOfCentury();
//        org.joda.time.DateTime dateTime7 = dateTime3.plus((long) (-1));
//        boolean boolean8 = dateTime3.isAfterNow();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendCenturyOfEra(10, (-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 19);
//        org.joda.time.DurationField durationField20 = offsetDateTimeField19.getLeapDurationField();
//        long long22 = offsetDateTimeField19.roundHalfEven((long) (short) -1);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property24 = dateTime23.centuryOfEra();
//        org.joda.time.DateTime dateTime25 = property24.roundCeilingCopy();
//        org.joda.time.DateTime.Property property26 = dateTime25.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField19, dateTimeFieldType27, 19, (int) '4', (int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType27);
//        org.joda.time.DateTime.Property property33 = dateTime3.property(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 70 + "'", int5 == 70);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNull(durationField20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-100L) + "'", long22 == (-100L));
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(property33);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.append(dateTimeParser6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatter10.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimePrinter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        java.util.Locale locale3 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withDefaultYear((int) '#');
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((int) '4');
        org.joda.time.DateTime.Property property9 = dateTime5.dayOfWeek();
        org.joda.time.DateTime dateTime10 = property9.withMaximumValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 170);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfEven((long) (short) -1);
//        java.util.Locale locale10 = null;
//        int int11 = offsetDateTimeField6.getMaximumTextLength(locale10);
//        long long14 = offsetDateTimeField6.add(100L, (int) '4');
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1640995200100L + "'", long14 == 1640995200100L);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear((int) (short) 100, false);
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatterBuilder8.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder8.appendFractionOfSecond(3, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatterBuilder15.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusMonths((-1));
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsShortText(locale5);
//        org.joda.time.DateTime dateTime7 = property4.getDateTime();
//        org.joda.time.DurationField durationField8 = property4.getRangeDurationField();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(durationField8);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.centuryOfEra();
        org.joda.time.DurationField durationField3 = property2.getRangeDurationField();
        org.joda.time.DateTime dateTime4 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.getDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property2.getFieldType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField7 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("38", "2019-06-19T22:53:29.854+00:00:00.100", 119, (int) '4');
//        int int6 = fixedDateTimeZone4.getOffsetFromLocal(0L);
//        int int8 = fixedDateTimeZone4.getOffset((long) (byte) 1);
//        int int10 = fixedDateTimeZone4.getStandardOffset((long) 7);
//        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getName(921600000L, locale14);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 119 + "'", int6 == 119);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 119 + "'", int8 == 119);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-1595149603157L), (long) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -23927244047355");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        boolean boolean4 = dateTime3.isBeforeNow();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTime dateTime7 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime3.minusWeeks(0);
        try {
            org.joda.time.DateTime dateTime11 = dateTime9.withDayOfMonth(2922789);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
//        org.joda.time.Interval interval6 = property5.toInterval();
//        int int7 = property5.getMinimumValueOverall();
//        org.joda.time.DurationField durationField8 = property5.getDurationField();
//        org.joda.time.DateTime dateTime9 = property5.roundCeilingCopy();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology11);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 19);
//        org.joda.time.DurationField durationField17 = offsetDateTimeField16.getLeapDurationField();
//        long long19 = offsetDateTimeField16.roundHalfFloor((long) '4');
//        int int20 = offsetDateTimeField16.getMinimumValue();
//        int int23 = offsetDateTimeField16.getDifference((long) 119, 0L);
//        org.joda.time.ReadablePartial readablePartial24 = null;
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = offsetDateTimeField16.getAsShortText(readablePartial24, 86, locale26);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property29 = dateTime28.centuryOfEra();
//        org.joda.time.DateTime dateTime31 = dateTime28.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime32 = dateTime31.toMutableDateTime();
//        org.joda.time.DateTime dateTime33 = dateTime31.toDateTime();
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfEra();
//        java.lang.String str35 = dateTime33.toString();
//        org.joda.time.DateTime dateTime37 = dateTime33.plusHours(170);
//        org.joda.time.DateTime.Property property38 = dateTime33.yearOfEra();
//        boolean boolean39 = property38.isLeap();
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property41 = dateTime40.centuryOfEra();
//        org.joda.time.DateTime dateTime42 = property41.roundCeilingCopy();
//        org.joda.time.DateTime.Property property43 = dateTime42.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
//        boolean boolean45 = property38.equals((java.lang.Object) dateTimeFieldType44);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType44, 292278993, (-5), 7);
//        org.joda.time.DateTime.Property property50 = dateTime9.property(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(interval6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-100L) + "'", long19 == (-100L));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 20 + "'", int20 == 20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "86" + "'", str27.equals("86"));
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1970-01-05T01:00:00.104+00:00:00.100" + "'", str35.equals("1970-01-05T01:00:00.104+00:00:00.100"));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(property50);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getYearOfCentury();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds((int) (byte) 1);
//        org.joda.time.DateTime.Property property4 = dateTime0.secondOfDay();
//        org.joda.time.DateTime dateTime5 = property4.withMinimumValue();
//        java.lang.String str6 = property4.getAsString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 70 + "'", int1 == 70);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readableDuration6);
        org.joda.time.DateTime.Property property8 = dateTime5.dayOfYear();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
//        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
//        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.clockhourOfDay();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property14 = dateTime13.centuryOfEra();
//        org.joda.time.DateTime dateTime15 = property14.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime16 = dateTime15.toLocalDateTime();
//        int[] intArray18 = gregorianChronology10.get((org.joda.time.ReadablePartial) localDateTime16, 100L);
//        long long20 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDateTime16, (long) (short) 10);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, 59);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendCenturyOfEra(10, (-1));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder24.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendTwoDigitWeekyear((int) (short) 100, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendCenturyOfEra(10, (-1));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder36.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder36.appendHourOfDay(19);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder47.appendCenturyOfEra(10, (-1));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder47.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder47.appendHourOfDay(19);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property59 = dateTime58.centuryOfEra();
//        org.joda.time.DateTime dateTime60 = property59.roundCeilingCopy();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder57.appendShortText(dateTimeFieldType62);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder36.appendFraction(dateTimeFieldType62, (int) (byte) 0, (int) (short) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder35.appendDecimal(dateTimeFieldType62, 3, (int) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField73 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, dateTimeFieldType62, 100, 170, (-53597));
//        int int75 = offsetDateTimeField73.getLeapAmount(10L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localDateTime16);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 946684799900L + "'", long20 == 946684799900L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
//        org.junit.Assert.assertNotNull(property59);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
//        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone4);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone6);
//        boolean boolean8 = cachedDateTimeZone6.isFixed();
//        int int10 = cachedDateTimeZone6.getOffset(0L);
//        long long12 = cachedDateTimeZone6.nextTransition(100L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
//        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
//        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.millisOfSecond();
//        org.joda.time.DurationField durationField12 = gregorianChronology10.days();
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.weekyearOfCentury();
//        org.joda.time.DurationField durationField14 = gregorianChronology10.weekyears();
//        boolean boolean15 = gregorianChronology0.equals((java.lang.Object) gregorianChronology10);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.centuryOfEra();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) 'a');
//        boolean boolean20 = dateTime19.isBeforeNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
//        org.joda.time.DateTime dateTime23 = dateTime19.withZoneRetainFields(dateTimeZone22);
//        org.joda.time.Chronology chronology24 = gregorianChronology0.withZone(dateTimeZone22);
//        int int26 = dateTimeZone22.getOffsetFromLocal((long) (byte) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology27.getZone();
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology30.getZone();
//        boolean boolean32 = gregorianChronology27.equals((java.lang.Object) dateTimeZone31);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone31);
//        java.lang.String str35 = cachedDateTimeZone33.getNameKey(100L);
//        int int37 = cachedDateTimeZone33.getOffset(1L);
//        java.lang.String str38 = cachedDateTimeZone33.toString();
//        try {
//            org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((java.lang.Object) (byte) 1, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Byte");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
//        org.junit.Assert.assertNull(str35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 100 + "'", int37 == 100);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "+00:00:00.100" + "'", str38.equals("+00:00:00.100"));
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder3.appendHourOfDay(19);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property15 = dateTime14.centuryOfEra();
        org.joda.time.DateTime dateTime16 = property15.roundCeilingCopy();
        org.joda.time.DateTime.Property property17 = dateTime16.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder13.appendShortText(dateTimeFieldType18);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType18, 100, 119, (int) (short) 100);
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) (-1595124380001L), (java.lang.Number) 2000, (java.lang.Number) 1L);
        org.joda.time.DurationFieldType durationFieldType28 = illegalFieldValueException27.getDurationFieldType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNull(durationFieldType28);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        int int6 = dateTime5.getDayOfYear();
//        org.joda.time.DateTime dateTime8 = dateTime5.plus((long) (short) 10);
//        int int9 = dateTime8.getHourOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime8.minus((-100L));
//        org.joda.time.DateTime dateTime13 = dateTime8.plus(0L);
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime8.getZone();
//        java.lang.String str15 = dateTimeZone14.getID();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.100" + "'", str15.equals("+00:00:00.100"));
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        boolean boolean4 = dateTime3.isBeforeNow();
        int int5 = dateTime3.getYearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        boolean boolean11 = gregorianChronology6.equals((java.lang.Object) dateTimeZone10);
        org.joda.time.DateTime dateTime12 = dateTime3.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime3.withWeekyear((int) (short) -1);
        org.joda.time.DateTime.Property property15 = dateTime3.weekOfWeekyear();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.centuryOfEra();
        org.joda.time.DateTime dateTime18 = property17.roundCeilingCopy();
        org.joda.time.DateTime.Property property19 = dateTime18.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property19.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "");
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType20, 15, (int) (byte) 0, 100);
        org.joda.time.DateTime.Property property27 = dateTime3.property(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 70 + "'", int5 == 70);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(property27);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        boolean boolean4 = dateTime3.isBeforeNow();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property6 = dateTime5.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = dateTime5.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTime();
//        org.joda.time.DateTime dateTime10 = dateTime8.toDateTime();
//        int int11 = dateTime10.getDayOfYear();
//        org.joda.time.DateTime dateTime13 = dateTime10.plus((long) (short) 10);
//        org.joda.time.DateTime dateTime15 = dateTime10.withWeekyear(0);
//        boolean boolean16 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("38", "2019-06-19T22:53:29.854+00:00:00.100", 119, (int) '4');
//        int int23 = fixedDateTimeZone21.getOffsetFromLocal(0L);
//        boolean boolean25 = fixedDateTimeZone21.isStandardOffset(1560635586792L);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime10.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone21);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 119 + "'", int23 == 119);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        org.joda.time.TimeOfDay timeOfDay6 = dateTime3.toTimeOfDay();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.centuryOfEra();
        org.joda.time.DateTime dateTime10 = dateTime7.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        org.joda.time.DateTime dateTime12 = dateTime10.toDateTime();
        org.joda.time.DateTime.Property property13 = dateTime12.yearOfEra();
        boolean boolean15 = dateTime12.equals((java.lang.Object) (-171));
        org.joda.time.DateTime.Property property16 = dateTime12.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        long long26 = dateTimeZone23.convertLocalToUTC(1560635586792L, true);
        org.joda.time.Chronology chronology27 = gregorianChronology21.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime28 = dateTime20.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime29 = dateTime12.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime30 = dateTime3.toDateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime32 = dateTime3.minusMillis(1536);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(timeOfDay6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560635586692L + "'", long26 == 1560635586692L);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            long long2 = dateTimeFormatter0.parseMillis("9");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"9\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendHourOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.appendPattern("20");
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
        org.joda.time.DateTime dateTime17 = property16.roundCeilingCopy();
        org.joda.time.DateTime.Property property18 = dateTime17.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, "");
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType19, 15, (int) (byte) 0, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder14.appendFraction(dateTimeFieldType19, (int) (byte) 100, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder28.appendYear(2922789, (-5));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder31.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = dateTime3.plusHours((int) '#');
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.plus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime3.era();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        int int11 = property9.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((int) '4');
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfSecond();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField5 = gregorianChronology2.minutes();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder3.appendHourOfDay(19);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property15 = dateTime14.centuryOfEra();
        org.joda.time.DateTime dateTime16 = property15.roundCeilingCopy();
        org.joda.time.DateTime.Property property17 = dateTime16.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder13.appendShortText(dateTimeFieldType18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder1.appendShortText(dateTimeFieldType18);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.millisOfSecond();
        org.joda.time.DurationField durationField23 = gregorianChronology21.days();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.weekyearOfCentury();
        org.joda.time.DurationField durationField25 = gregorianChronology21.weekyears();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology21.minuteOfDay();
        org.joda.time.DurationField durationField27 = gregorianChronology21.seconds();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DurationField durationField32 = iSOChronology31.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField33 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType18, durationField27, durationField32);
        long long36 = durationField27.subtract((long) (-52), (-648349596408L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 648349596407948L + "'", long36 == 648349596407948L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.weekyears();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) 292278993);
        int int6 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
//        java.lang.String str7 = dateTime5.toString();
//        org.joda.time.DateTime.Property property8 = dateTime5.yearOfCentury();
//        boolean boolean9 = dateTime5.isBeforeNow();
//        org.joda.time.DurationFieldType durationFieldType10 = null;
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime5.withFieldAdded(durationFieldType10, 2019);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-05T01:00:00.104+00:00:00.100" + "'", str7.equals("1970-01-05T01:00:00.104+00:00:00.100"));
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException5.prependMessage("");
        jodaTimePermission1.checkGuard((java.lang.Object) "");
        java.security.PermissionCollection permissionCollection9 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
        org.joda.time.DateTime dateTime13 = dateTime10.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime13.toMutableDateTime();
        org.joda.time.DateTime.Property property15 = dateTime13.centuryOfEra();
        org.joda.time.Interval interval16 = property15.toInterval();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(chronology17);
        jodaTimePermission1.checkGuard((java.lang.Object) chronology17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(permissionCollection9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(interval16);
        org.junit.Assert.assertNotNull(chronology17);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        boolean boolean10 = gregorianChronology5.equals((java.lang.Object) dateTimeZone9);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone11);
//        boolean boolean13 = cachedDateTimeZone12.isFixed();
//        try {
//            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((-52), 1, 53597, 0, 89, (org.joda.time.DateTimeZone) cachedDateTimeZone12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 89 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "ZonedChronology[GregorianChronology[UTC], UTC]", "38");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        int int6 = dateTime5.getDayOfYear();
//        org.joda.time.DateTime dateTime8 = dateTime5.plus((long) (short) 10);
//        org.joda.time.DateTime dateTime10 = dateTime5.withWeekyear(0);
//        org.joda.time.DateTime.Property property11 = dateTime5.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = property11.roundHalfCeilingCopy();
//        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
//        java.lang.String str14 = property13.getAsText();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "20" + "'", str14.equals("20"));
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusMonths(2922789);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DurationField durationField2 = property1.getRangeDurationField();
        org.joda.time.DateTime dateTime3 = property1.withMaximumValue();
        org.joda.time.DateTime dateTime4 = property1.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.withYear(0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        int int8 = offsetDateTimeField6.getLeapAmount(0L);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField6.getAsShortText(2191787586692L, locale10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
//        org.joda.time.DateTime dateTime15 = dateTime12.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime16 = dateTime15.toMutableDateTime();
//        org.joda.time.DateTime dateTime17 = dateTime15.toDateTime();
//        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
//        boolean boolean20 = dateTime17.equals((java.lang.Object) (-171));
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField6.getAsText((org.joda.time.ReadablePartial) yearMonthDay21, 9, locale23);
//        long long26 = offsetDateTimeField6.roundFloor(5301590400010L);
//        long long28 = offsetDateTimeField6.roundCeiling((long) 15);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "58" + "'", str11.equals("58"));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9" + "'", str24.equals("9"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 5301590399900L + "'", long26 == 5301590399900L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999900L + "'", long28 == 31535999900L);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property5 = dateTime4.centuryOfEra();
        org.joda.time.DateTime dateTime6 = property5.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime7 = dateTime6.toLocalDateTime();
        int[] intArray9 = gregorianChronology1.get((org.joda.time.ReadablePartial) localDateTime7, 100L);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology1.yearOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.millisOfSecond();
        org.joda.time.DurationField durationField13 = gregorianChronology11.days();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.weekyearOfCentury();
        org.joda.time.DurationField durationField15 = gregorianChronology11.weekyears();
        boolean boolean16 = gregorianChronology1.equals((java.lang.Object) gregorianChronology11);
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        boolean boolean18 = iSOChronology0.equals((java.lang.Object) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra(19, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendDayOfWeek(665);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendMinuteOfHour(100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfFloor((long) '4');
//        int int10 = offsetDateTimeField6.getMinimumValue();
//        long long13 = offsetDateTimeField6.add((long) 10, 10L);
//        boolean boolean15 = offsetDateTimeField6.isLeap(0L);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.centuryOfEra();
//        org.joda.time.DateTime dateTime18 = property17.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology22.getZone();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology22);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 19);
//        org.joda.time.DurationField durationField28 = offsetDateTimeField27.getLeapDurationField();
//        long long30 = offsetDateTimeField27.roundHalfEven((long) (short) -1);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property32 = dateTime31.centuryOfEra();
//        org.joda.time.DateTime dateTime33 = property32.roundCeilingCopy();
//        org.joda.time.DateTime.Property property34 = dateTime33.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField27, dateTimeFieldType35, 19, (int) '4', (int) '4');
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property41 = dateTime40.centuryOfEra();
//        org.joda.time.DateTime dateTime43 = dateTime40.plusHours((int) 'a');
//        org.joda.time.DateTime.Property property44 = dateTime43.dayOfMonth();
//        org.joda.time.DateTime dateTime46 = dateTime43.plusHours((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone47 = dateTime43.getZone();
//        org.joda.time.Chronology chronology48 = null;
//        org.joda.time.MutableDateTime mutableDateTime49 = dateTime43.toMutableDateTime(chronology48);
//        int int50 = dateTime43.getHourOfDay();
//        org.joda.time.LocalDateTime localDateTime51 = dateTime43.toLocalDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology52.getZone();
//        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology52.clockhourOfDay();
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property56 = dateTime55.centuryOfEra();
//        org.joda.time.DateTime dateTime57 = property56.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime58 = dateTime57.toLocalDateTime();
//        int[] intArray60 = gregorianChronology52.get((org.joda.time.ReadablePartial) localDateTime58, 100L);
//        int int61 = offsetDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) localDateTime51, intArray60);
//        try {
//            int[] intArray63 = offsetDateTimeField6.set((org.joda.time.ReadablePartial) localDateTime19, (int) 'a', intArray60, (-53598));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -53598 for yearOfCentury must be in the range [20,119]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 315532800010L + "'", long13 == 315532800010L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNull(durationField28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-100L) + "'", long30 == (-100L));
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(mutableDateTime49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(localDateTime51);
//        org.junit.Assert.assertNotNull(gregorianChronology52);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(localDateTime58);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 52 + "'", int61 == 52);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = iSOChronology3.withUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) (short) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("38", "2019-06-19T22:53:29.854+00:00:00.100", 119, (int) '4');
        int int17 = fixedDateTimeZone15.getOffsetFromLocal(0L);
        org.joda.time.Chronology chronology18 = zonedChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        java.util.Locale locale20 = null;
        java.lang.String str21 = fixedDateTimeZone15.getShortName((long) 10, locale20);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 119 + "'", int17 == 119);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.119" + "'", str21.equals("+00:00:00.119"));
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        int int6 = dateTime5.getDayOfYear();
//        org.joda.time.DateTime dateTime8 = dateTime5.plus((long) (short) 10);
//        org.joda.time.DateTime dateTime10 = dateTime5.withWeekyear(0);
//        org.joda.time.DateTime.Property property11 = dateTime5.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = property11.roundHalfCeilingCopy();
//        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
//        boolean boolean14 = dateTime12.isEqualNow();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfEven((long) (short) -1);
//        long long11 = offsetDateTimeField6.roundFloor((long) '4');
//        long long13 = offsetDateTimeField6.roundFloor(315532800010L);
//        java.lang.String str14 = offsetDateTimeField6.getName();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-100L) + "'", long11 == (-100L));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 315532799900L + "'", long13 == 315532799900L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "yearOfCentury" + "'", str14.equals("yearOfCentury"));
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.plus((long) 49);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DurationField durationField2 = property1.getRangeDurationField();
        int int3 = property1.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNull(durationField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2922789 + "'", int3 == 2922789);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfFloor((long) '4');
//        int int10 = offsetDateTimeField6.getMinimumValue();
//        long long13 = offsetDateTimeField6.add((long) 7, (long) (byte) 0);
//        long long15 = offsetDateTimeField6.roundHalfEven(1L);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, 7);
//        long long20 = offsetDateTimeField6.set((long) 2149, (int) (byte) 100);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 7L + "'", long13 == 7L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-100L) + "'", long15 == (-100L));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 347155202149L + "'", long20 == 347155202149L);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        boolean boolean6 = gregorianChronology1.equals((java.lang.Object) dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime0.toMutableDateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Chronology chronology8 = dateTime0.getChronology();
        org.joda.time.DateTime dateTime10 = dateTime0.minusMinutes(53597);
        long long11 = dateTime0.getMillis();
        org.joda.time.DateTime dateTime13 = dateTime0.plusMonths(540);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4L + "'", long11 == 4L);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(0, 53597);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone7);
        java.lang.Object obj9 = null;
        boolean boolean10 = zonedChronology8.equals(obj9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
        org.joda.time.DateTime dateTime14 = dateTime11.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime14.toMutableDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.centuryOfEra();
        org.joda.time.Interval interval17 = property16.toInterval();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property19 = dateTime18.centuryOfEra();
        org.joda.time.DateTime dateTime20 = property19.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        long long22 = property16.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime23 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime25 = dateTime23.minusDays((int) (short) 0);
        org.joda.time.DateTime dateTime27 = dateTime23.withWeekOfWeekyear(1);
        boolean boolean28 = zonedChronology8.equals((java.lang.Object) dateTime27);
        org.joda.time.DateTime dateTime30 = dateTime27.minusMillis((int) (short) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(interval17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.Chronology chronology6 = iSOChronology3.withZone(dateTimeZone5);
        java.lang.String str7 = iSOChronology3.toString();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology3.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[-01:01]" + "'", str7.equals("ISOChronology[-01:01]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime3.dayOfMonth();
//        org.joda.time.DateTime dateTime6 = dateTime3.plusHours((int) '#');
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime3.plus(readableDuration7);
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
//        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
//        long long12 = property11.remainder();
//        java.lang.String str13 = property11.toString();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 349200104L + "'", long12 == 349200104L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[centuryOfEra]" + "'", str13.equals("Property[centuryOfEra]"));
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfFloor((long) '4');
//        int int10 = offsetDateTimeField6.getMinimumValue();
//        long long13 = offsetDateTimeField6.add((long) 7, (long) (byte) 0);
//        java.lang.String str15 = offsetDateTimeField6.getAsText((long) 23);
//        java.util.Locale locale16 = null;
//        int int17 = offsetDateTimeField6.getMaximumTextLength(locale16);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology22.getZone();
//        boolean boolean24 = gregorianChronology19.equals((java.lang.Object) dateTimeZone23);
//        org.joda.time.MutableDateTime mutableDateTime25 = dateTime18.toMutableDateTime((org.joda.time.Chronology) gregorianChronology19);
//        org.joda.time.Chronology chronology26 = dateTime18.getChronology();
//        org.joda.time.DateTime dateTime28 = dateTime18.minusMinutes(53597);
//        long long29 = dateTime18.getMillis();
//        org.joda.time.YearMonthDay yearMonthDay30 = dateTime18.toYearMonthDay();
//        java.util.Locale locale31 = null;
//        try {
//            java.lang.String str32 = offsetDateTimeField6.getAsText((org.joda.time.ReadablePartial) yearMonthDay30, locale31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfCentury' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 7L + "'", long13 == 7L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "89" + "'", str15.equals("89"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 4L + "'", long29 == 4L);
//        org.junit.Assert.assertNotNull(yearMonthDay30);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime7 = dateTime3.minusYears(0);
        org.joda.time.DateTime dateTime9 = dateTime3.plusYears((int) '#');
        org.joda.time.DateTime dateTime11 = dateTime3.withMillisOfSecond(0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, 292278993, (int) '4', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for dayOfWeek must be in the range [52,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(665, 59);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendTimeZoneName(strMap9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
//        boolean boolean8 = dateTime5.equals((java.lang.Object) (-171));
//        org.joda.time.DateTime.Property property9 = dateTime5.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTime5.getZone();
//        org.joda.time.DateTime dateTime12 = dateTime5.minusMinutes(0);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property14 = dateTime13.centuryOfEra();
//        org.joda.time.DateTime dateTime16 = dateTime13.plusHours((int) 'a');
//        boolean boolean17 = dateTime16.isBeforeNow();
//        int int18 = dateTime16.getYearOfCentury();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology22.getZone();
//        boolean boolean24 = gregorianChronology19.equals((java.lang.Object) dateTimeZone23);
//        org.joda.time.DateTime dateTime25 = dateTime16.withZoneRetainFields(dateTimeZone23);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone23.getName((-1595149603157L), locale27);
//        org.joda.time.DateTime dateTime29 = dateTime5.withZoneRetainFields(dateTimeZone23);
//        org.joda.time.DateTime dateTime32 = dateTime5.withDurationAdded(5663109201710L, 3);
//        int int33 = dateTime5.getMinuteOfDay();
//        org.joda.time.DateTime dateTime35 = dateTime5.withYearOfCentury(0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 70 + "'", int18 == 70);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00:00.100" + "'", str28.equals("+00:00:00.100"));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 60 + "'", int33 == 60);
//        org.junit.Assert.assertNotNull(dateTime35);
//    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
//        java.lang.String str7 = dateTime5.toString();
//        org.joda.time.DateTime dateTime9 = dateTime5.plusHours(170);
//        org.joda.time.DateTime.Property property10 = dateTime5.yearOfEra();
//        int int11 = dateTime5.getYear();
//        org.joda.time.DateTime dateTime13 = dateTime5.plusMillis(3);
//        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime18 = dateTime15.minusMonths((-1));
//        boolean boolean19 = dateTime13.isAfter((org.joda.time.ReadableInstant) dateTime15);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-05T01:00:00.104+00:00:00.100" + "'", str7.equals("1970-01-05T01:00:00.104+00:00:00.100"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(localDateTime14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "58");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        int int6 = dateTime5.getDayOfYear();
//        org.joda.time.DateTime dateTime8 = dateTime5.plus((long) (short) 10);
//        int int9 = dateTime8.getHourOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime8.minus((-100L));
//        org.joda.time.DateTime dateTime13 = dateTime8.plus(0L);
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime8.getZone();
//        org.joda.time.DateTime dateTime16 = dateTime8.withYear(7);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property25 = dateTime24.centuryOfEra();
//        org.joda.time.DateTime dateTime27 = dateTime24.plusHours((int) 'a');
//        org.joda.time.DateTime.Property property28 = dateTime27.dayOfMonth();
//        org.joda.time.DateTime dateTime30 = dateTime27.plusHours((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone31 = dateTime27.getZone();
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((int) (byte) 1, 3, 10, 5, 9, 0, 15, dateTimeZone31);
//        boolean boolean33 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime16, (java.lang.Object) dateTime32);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        int int6 = dateTime5.getDayOfYear();
//        org.joda.time.DateTime dateTime8 = dateTime5.plus((long) (short) 10);
//        org.joda.time.DateTime dateTime10 = dateTime5.withWeekyear(0);
//        org.joda.time.DateTime dateTime12 = dateTime10.withYearOfEra(3600);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-1595149607071L), (java.lang.Number) (-31507200000L), number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusMonths((-1));
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean6 = property4.equals((java.lang.Object) dateTimeFormatter5);
//        org.joda.time.DateTime dateTime7 = property4.getDateTime();
//        int int8 = dateTime7.getDayOfYear();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.Interval interval6 = property5.toInterval();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
        long long11 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime9);
        int int12 = property5.getMaximumValue();
        int int13 = property5.getMinimumValueOverall();
        java.util.Locale locale15 = null;
        try {
            org.joda.time.DateTime dateTime16 = property5.setCopy("-01:01", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"-01:01\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2922789 + "'", int12 == 2922789);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((int) '4');
        int int9 = dateTime8.getDayOfYear();
        org.joda.time.DateTime dateTime11 = dateTime8.minusMillis(10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime8.minus(readableDuration12);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 19);
//        org.joda.time.DurationField durationField9 = offsetDateTimeField8.getLeapDurationField();
//        long long11 = offsetDateTimeField8.roundHalfEven((long) (short) -1);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
//        org.joda.time.DateTime dateTime14 = property13.roundCeilingCopy();
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType16, 19, (int) '4', (int) '4');
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property22 = dateTime21.centuryOfEra();
//        org.joda.time.DateTime dateTime24 = dateTime21.plusHours((int) 'a');
//        org.joda.time.DateTime.Property property25 = dateTime24.dayOfMonth();
//        org.joda.time.DateTime dateTime27 = dateTime24.plusHours((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone28 = dateTime24.getZone();
//        org.joda.time.Chronology chronology29 = null;
//        org.joda.time.MutableDateTime mutableDateTime30 = dateTime24.toMutableDateTime(chronology29);
//        int int31 = dateTime24.getHourOfDay();
//        org.joda.time.LocalDateTime localDateTime32 = dateTime24.toLocalDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology33.getZone();
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.clockhourOfDay();
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property37 = dateTime36.centuryOfEra();
//        org.joda.time.DateTime dateTime38 = property37.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime39 = dateTime38.toLocalDateTime();
//        int[] intArray41 = gregorianChronology33.get((org.joda.time.ReadablePartial) localDateTime39, 100L);
//        int int42 = offsetDateTimeField20.getMinimumValue((org.joda.time.ReadablePartial) localDateTime32, intArray41);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDateTime32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNull(durationField9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-100L) + "'", long11 == (-100L));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(localDateTime32);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(localDateTime39);
//        org.junit.Assert.assertNotNull(intArray41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 52 + "'", int42 == 52);
//    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfEven((long) (short) -1);
//        long long11 = offsetDateTimeField6.roundFloor((long) '4');
//        long long13 = offsetDateTimeField6.roundCeiling(4102473600000L);
//        try {
//            long long16 = offsetDateTimeField6.set((long) 86, "1999");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1999 for yearOfCentury must be in the range [20,119]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-100L) + "'", long11 == (-100L));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 4133980799900L + "'", long13 == 4133980799900L);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfFloor((long) '4');
//        int int10 = offsetDateTimeField6.getMinimumValue();
//        long long13 = offsetDateTimeField6.add((long) 10, 10L);
//        int int16 = offsetDateTimeField6.getDifference((long) 0, 315532799900L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 315532800010L + "'", long13 == 315532800010L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-9) + "'", int16 == (-9));
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(5, (-53597), 19, (int) (byte) 10, 292278993, 23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.Chronology chronology2 = dateTime0.getChronology();
        org.joda.time.DateTime dateTime4 = dateTime0.withDayOfYear(60);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        long long9 = dateTimeZone6.convertLocalToUTC(1560635586792L, true);
        org.joda.time.Chronology chronology10 = gregorianChronology4.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime11 = dateTime3.withZone(dateTimeZone6);
        org.joda.time.DateTime.Property property12 = dateTime11.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        boolean boolean15 = dateTime11.isBeforeNow();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560635586692L + "'", long9 == 1560635586692L);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = property2.roundCeilingCopy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime9 = dateTime6.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime9.toMutableDateTime();
        int int13 = dateTimeFormatter4.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "hi!", 0);
        int int14 = dateTime3.compareTo((org.joda.time.ReadableInstant) mutableDateTime10);
        int int17 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "", 53597);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-53598) + "'", int17 == (-53598));
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfCentury(119, (-5));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology0.weekyears();
        org.joda.time.DurationField durationField7 = gregorianChronology0.months();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        try {
            int[] intArray11 = gregorianChronology0.get(readablePeriod9, (-1595149607071L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime3.plusMonths(3);
        int int8 = dateTime7.getCenturyOfEra();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        boolean boolean2 = property1.isLeap();
//        long long3 = property1.remainder();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property1.getAsText(locale4);
//        org.joda.time.DateTime dateTime6 = property1.withMaximumValue();
//        boolean boolean8 = dateTime6.isAfter((long) 20);
//        int int9 = dateTime6.getYearOfEra();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 104L + "'", long3 == 104L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19" + "'", str5.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 292278970 + "'", int9 == 292278970);
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfFloor((long) '4');
//        int int10 = offsetDateTimeField6.getMinimumValue();
//        long long13 = offsetDateTimeField6.add((long) 7, (long) (byte) 0);
//        long long15 = offsetDateTimeField6.roundHalfEven(1L);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, 7);
//        long long20 = offsetDateTimeField6.getDifferenceAsLong((-31535999990L), 7L);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property22 = dateTime21.centuryOfEra();
//        org.joda.time.DateTime dateTime24 = dateTime21.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime25 = dateTime24.toMutableDateTime();
//        org.joda.time.DateTime dateTime26 = dateTime24.toDateTime();
//        org.joda.time.LocalDateTime localDateTime27 = dateTime24.toLocalDateTime();
//        int int28 = offsetDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDateTime27);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 7L + "'", long13 == 7L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-100L) + "'", long15 == (-100L));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(localDateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 119 + "'", int28 == 119);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = property1.roundCeilingCopy();
        org.joda.time.DurationField durationField3 = property1.getLeapDurationField();
        int int4 = property1.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property1.getDateTime();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2922789 + "'", int4 == 2922789);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendEraText();
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder4.appendHourOfDay(19);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
        org.joda.time.DateTime dateTime17 = property16.roundCeilingCopy();
        org.joda.time.DateTime.Property property18 = dateTime17.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder14.appendShortText(dateTimeFieldType19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder2.appendShortText(dateTimeFieldType19);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.millisOfSecond();
        org.joda.time.DurationField durationField24 = gregorianChronology22.days();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DurationField durationField26 = gregorianChronology22.weekyears();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology22.minuteOfDay();
        org.joda.time.DurationField durationField28 = gregorianChronology22.seconds();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.DurationField durationField33 = iSOChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField34 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType19, durationField28, durationField33);
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(durationField33);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-1609430399800L), (java.lang.Number) (-18900L), (java.lang.Number) 648349596407948L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.clockhourOfDay();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime13 = dateTime12.toLocalDateTime();
//        int[] intArray15 = gregorianChronology7.get((org.joda.time.ReadablePartial) localDateTime13, 100L);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology7.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.clockhourOfDay();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property21 = dateTime20.centuryOfEra();
//        org.joda.time.DateTime dateTime22 = property21.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime23 = dateTime22.toLocalDateTime();
//        int[] intArray25 = gregorianChronology17.get((org.joda.time.ReadablePartial) localDateTime23, 100L);
//        long long27 = gregorianChronology7.set((org.joda.time.ReadablePartial) localDateTime23, (long) (short) 10);
//        int int28 = offsetDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDateTime23);
//        long long30 = offsetDateTimeField6.roundHalfCeiling((long) 1);
//        long long32 = offsetDateTimeField6.roundCeiling((-1L));
//        int int33 = offsetDateTimeField6.getMinimumValue();
//        long long35 = offsetDateTimeField6.roundCeiling((-1595124372090L));
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localDateTime13);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(localDateTime23);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 946684799900L + "'", long27 == 946684799900L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 119 + "'", int28 == 119);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-100L) + "'", long30 == (-100L));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 31535999900L + "'", long32 == 31535999900L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 20 + "'", int33 == 20);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-1577923200100L) + "'", long35 == (-1577923200100L));
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readableDuration6);
        org.joda.time.DateTime.Property property8 = dateTime7.hourOfDay();
        org.joda.time.Interval interval9 = property8.toInterval();
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval9);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
        boolean boolean8 = dateTime5.equals((java.lang.Object) (-171));
        org.joda.time.DateTime.Property property9 = dateTime5.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime5.getZone();
        java.util.Locale locale11 = null;
        java.util.Calendar calendar12 = dateTime5.toCalendar(locale11);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(calendar12);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.security.PermissionCollection permissionCollection5 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str6 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(permissionCollection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1970-01-05T01:00:00.104+00:00:00.100");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1970-01-05T01:00:00.104+00:00:00.100' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfFloor((long) '4');
//        int int10 = offsetDateTimeField6.getMinimumValue();
//        long long13 = offsetDateTimeField6.add((long) 7, (long) (byte) 0);
//        java.lang.String str15 = offsetDateTimeField6.getAsText((long) 23);
//        java.util.Locale locale16 = null;
//        int int17 = offsetDateTimeField6.getMaximumTextLength(locale16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField6.getAsText((long) 1970, locale19);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 7L + "'", long13 == 7L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "89" + "'", str15.equals("89"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "89" + "'", str20.equals("89"));
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.minuteOfDay();
        int int11 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        int int6 = dateTime5.getDayOfYear();
//        org.joda.time.DateTime dateTime8 = dateTime5.plus((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        boolean boolean10 = dateTime5.isSupported(dateTimeFieldType9);
//        org.joda.time.DateTime dateTime11 = dateTime5.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("yearOfCentury");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"yearOfCentury/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfFloor((long) '4');
//        int int10 = offsetDateTimeField6.getMinimumValue();
//        long long13 = offsetDateTimeField6.add((long) 10, 10L);
//        int int14 = offsetDateTimeField6.getOffset();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 315532800010L + "'", long13 == 315532800010L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
//        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone4);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
//        java.lang.String str8 = cachedDateTimeZone6.getNameKey(100L);
//        boolean boolean9 = cachedDateTimeZone6.isFixed();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
//        boolean boolean15 = gregorianChronology10.equals((java.lang.Object) dateTimeZone14);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone16);
//        long long19 = cachedDateTimeZone6.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone17, 100L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone17);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendHourOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendMinuteOfHour(53597);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.appendMillisOfDay(119);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendMonthOfYearShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendSecondOfDay((-171));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendHourOfDay(19);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
        org.joda.time.DateTime dateTime13 = property12.roundCeilingCopy();
        org.joda.time.DateTime.Property property14 = dateTime13.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder10.appendSecondOfDay((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder10.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendMillisOfDay(7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
//        java.lang.String str7 = dateTime5.toString();
//        org.joda.time.DateTime dateTime9 = dateTime5.plusHours(170);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime5.toMutableDateTime();
//        boolean boolean11 = dateTime5.isAfterNow();
//        org.joda.time.DateTime dateTime13 = dateTime5.minusMinutes((int) 'a');
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-05T01:00:00.104+00:00:00.100" + "'", str7.equals("1970-01-05T01:00:00.104+00:00:00.100"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis(4, 52, 665, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = property1.roundCeilingCopy();
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("38", "2019-06-19T22:53:29.854+00:00:00.100", 119, (int) '4');
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedDateTimeZone4.equals(obj5);
        int int8 = fixedDateTimeZone4.getStandardOffset((-31507200000L));
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("", 292278993, 23, 3, 'a', 53597, 0, 100, false, 3);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("hi!", (int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.DurationField durationField5 = gregorianChronology3.centuries();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
//        boolean boolean11 = gregorianChronology6.equals((java.lang.Object) dateTimeZone10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
//        boolean boolean14 = cachedDateTimeZone12.isFixed();
//        int int16 = cachedDateTimeZone12.getOffset(0L);
//        org.joda.time.Chronology chronology17 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
//        boolean boolean18 = gregorianChronology0.equals((java.lang.Object) cachedDateTimeZone12);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.minuteOfDay();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("", 292278993, 23, 3, 'a', 53597, 0, 100, false, 3);
        java.io.DataOutput dataOutput13 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", dataOutput13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime3.plusMonths(3);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        java.util.Locale locale6 = null;
        int int7 = property5.getMaximumTextLength(locale6);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2019-06-19T15:53:19.665-07:00", false);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("PST", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.setStandardOffset(15);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder8.addCutover(23, 'a', 0, 2922789, 0, true, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone7);
        java.lang.Object obj9 = null;
        boolean boolean10 = zonedChronology8.equals(obj9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
        org.joda.time.DateTime dateTime14 = dateTime11.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime14.toMutableDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.centuryOfEra();
        org.joda.time.Interval interval17 = property16.toInterval();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property19 = dateTime18.centuryOfEra();
        org.joda.time.DateTime dateTime20 = property19.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        long long22 = property16.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime23 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime25 = dateTime23.minusDays((int) (short) 0);
        org.joda.time.DateTime dateTime27 = dateTime23.withWeekOfWeekyear(1);
        boolean boolean28 = zonedChronology8.equals((java.lang.Object) dateTime27);
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(interval17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(chronology29);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long10 = offsetDateTimeField6.addWrapField((-1595149601709L), (int) '#');
//        long long12 = offsetDateTimeField6.roundHalfEven((long) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField6.getType();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-490612001709L) + "'", long10 == (-490612001709L));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-100L) + "'", long12 == (-100L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfEven((long) (short) -1);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
//        org.joda.time.DateTime.Property property13 = dateTime12.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType14, 19, (int) '4', (int) '4');
//        try {
//            long long21 = offsetDateTimeField18.add((long) 52, (-31507200000L));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -31507200000");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("38", "2019-06-19T22:53:29.854+00:00:00.100", 119, (int) '4');
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        int int8 = fixedDateTimeZone4.getOffset((long) (byte) 1);
        int int10 = fixedDateTimeZone4.getStandardOffset((long) 7);
        java.util.Locale locale12 = null;
        java.lang.String str13 = fixedDateTimeZone4.getShortName(5663109201710L, locale12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 119 + "'", int6 == 119);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 119 + "'", int8 == 119);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00:00.119" + "'", str13.equals("+00:00:00.119"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendHourOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter13.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter15.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter14, dateTimeParser17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder19.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder28.appendEraText();
        boolean boolean30 = dateTimeFormatterBuilder28.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder28.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter33 = dateTimeFormatter32.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser34 = dateTimeFormatter32.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder31.append(dateTimeParser34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder19.appendOptional(dateTimeParser34);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter38 = dateTimeFormatter37.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser39 = dateTimeFormatter37.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter41 = dateTimeFormatter40.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser42 = dateTimeFormatter40.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder43.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder43.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder51.appendTwoDigitWeekyear((int) (short) 100, false);
        org.joda.time.format.DateTimeParser dateTimeParser55 = dateTimeFormatterBuilder51.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder56.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder56.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder65.appendEraText();
        boolean boolean67 = dateTimeFormatterBuilder65.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder65.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter69 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter70 = dateTimeFormatter69.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser71 = dateTimeFormatter69.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder72 = dateTimeFormatterBuilder68.append(dateTimeParser71);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder56.appendOptional(dateTimeParser71);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray74 = new org.joda.time.format.DateTimeParser[] { dateTimeParser34, dateTimeParser39, dateTimeParser42, dateTimeParser55, dateTimeParser71 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder12.append(dateTimePrinter14, dateTimeParserArray74);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder12.appendFractionOfSecond(0, 5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimePrinter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimePrinter33);
        org.junit.Assert.assertNotNull(dateTimeParser34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimePrinter38);
        org.junit.Assert.assertNotNull(dateTimeParser39);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimePrinter41);
        org.junit.Assert.assertNotNull(dateTimeParser42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeParser55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertNotNull(dateTimeFormatter69);
        org.junit.Assert.assertNotNull(dateTimePrinter70);
        org.junit.Assert.assertNotNull(dateTimeParser71);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder72);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
        org.junit.Assert.assertNotNull(dateTimeParserArray74);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        boolean boolean4 = dateTime3.isAfterNow();
        org.joda.time.DateTime.Property property5 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.append(dateTimeParser6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendEraText();
        boolean boolean12 = dateTimeFormatterBuilder10.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter15 = dateTimeFormatter14.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.append(dateTimeParser16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParser16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.joda.time.format.DateTimePrinter dateTimePrinter20 = dateTimeFormatterBuilder19.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter20, dateTimeParser22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimePrinter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimePrinter20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeParser22);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 100, 53597);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatter7.getParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.append(dateTimePrinter6, dateTimeParser8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeParser8);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.Chronology chronology12 = iSOChronology11.withUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        boolean boolean17 = dateTimeZone15.isStandardOffset((long) (short) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance(chronology12, dateTimeZone15);
        org.joda.time.Chronology chronology19 = gregorianChronology0.withZone(dateTimeZone15);
        long long23 = dateTimeZone15.convertLocalToUTC((-490612001709L), false, (long) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-490608341709L) + "'", long23 == (-490608341709L));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.minuteOfHour();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 0, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = property1.roundCeilingCopy();
        java.lang.String str3 = property1.getAsText();
        java.lang.String str4 = property1.getName();
        org.joda.time.Interval interval5 = property1.toInterval();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval5);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "19" + "'", str3.equals("19"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "centuryOfEra" + "'", str4.equals("centuryOfEra"));
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(0L, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test264");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
//        boolean boolean8 = dateTime5.equals((java.lang.Object) (-171));
//        org.joda.time.DateTime.Property property9 = dateTime5.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTime5.getZone();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 53597);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property14 = dateTime13.centuryOfEra();
//        org.joda.time.DateTime dateTime16 = dateTime13.plusHours((int) 'a');
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfMonth();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone20 = dateTime16.getZone();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MutableDateTime mutableDateTime22 = dateTime16.toMutableDateTime(chronology21);
//        int int23 = dateTime16.getHourOfDay();
//        org.joda.time.LocalDateTime localDateTime24 = dateTime16.toLocalDateTime();
//        org.joda.time.DateTime dateTime25 = dateTime12.withFields((org.joda.time.ReadablePartial) localDateTime24);
//        org.joda.time.DateTime dateTime26 = dateTime5.withFields((org.joda.time.ReadablePartial) localDateTime24);
//        boolean boolean27 = dateTime5.isEqualNow();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(localDateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        long long8 = offsetDateTimeField6.roundHalfEven(1560635586792L);
//        java.lang.String str10 = offsetDateTimeField6.getAsShortText((long) 'a');
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546300799900L + "'", long8 == 1546300799900L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "89" + "'", str10.equals("89"));
//    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
//        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone4);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone6);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone7);
//        long long10 = cachedDateTimeZone7.previousTransition((long) (-171));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-171L) + "'", long10 == (-171L));
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("38", "2019-06-19T22:53:29.854+00:00:00.100", 119, (int) '4');
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        boolean boolean8 = fixedDateTimeZone4.isStandardOffset(1560635586792L);
        java.lang.String str10 = fixedDateTimeZone4.getNameKey(5301590400010L);
        int int12 = fixedDateTimeZone4.getOffset(0L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 119 + "'", int6 == 119);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-19T22:53:29.854+00:00:00.100" + "'", str10.equals("2019-06-19T22:53:29.854+00:00:00.100"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 119 + "'", int12 == 119);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
//        org.joda.time.Interval interval6 = property5.toInterval();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property8 = dateTime7.centuryOfEra();
//        org.joda.time.DateTime dateTime9 = property8.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
//        long long11 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = property5.withMinimumValue();
//        int int13 = dateTime12.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(interval6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localDateTime10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 60 + "'", int13 == 60);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = property1.roundCeilingCopy();
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property3.getFieldType();
        org.joda.time.DateTime dateTime6 = property3.addToCopy(59);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        boolean boolean8 = property7.isLeap();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = property1.roundCeilingCopy();
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property3.getFieldType();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property6 = dateTime5.centuryOfEra();
        org.joda.time.DateTime dateTime8 = dateTime5.plusHours((int) 'a');
        boolean boolean9 = dateTime8.isBeforeNow();
        int int10 = dateTime8.getYearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        boolean boolean16 = gregorianChronology11.equals((java.lang.Object) dateTimeZone15);
        org.joda.time.DateTime dateTime17 = dateTime8.withZoneRetainFields(dateTimeZone15);
        org.joda.time.DateTime dateTime19 = dateTime8.withWeekyear((int) (short) -1);
        org.joda.time.DateTime dateTime21 = dateTime8.withDayOfYear((int) (byte) 1);
        long long22 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime21);
        java.lang.String str23 = property3.getAsText();
        java.lang.String str24 = property3.getAsShortText();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 70 + "'", int10 == 70);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 29L + "'", long22 == 29L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1999" + "'", str23.equals("1999"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1999" + "'", str24.equals("1999"));
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfFloor((long) '4');
//        int int10 = offsetDateTimeField6.getMinimumValue();
//        long long13 = offsetDateTimeField6.add((long) 7, (long) (byte) 0);
//        java.lang.String str15 = offsetDateTimeField6.getAsText((long) 23);
//        long long18 = offsetDateTimeField6.add((long) (-171), 0L);
//        long long20 = offsetDateTimeField6.remainder((long) 292278993);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 7L + "'", long13 == 7L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "89" + "'", str15.equals("89"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-171L) + "'", long18 == (-171L));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 292279093L + "'", long20 == 292279093L);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test272");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
//        org.joda.time.DateTime dateTime6 = dateTime3.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
//        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
//        java.lang.String str10 = dateTime8.toString();
//        org.joda.time.DateTime dateTime12 = dateTime8.plusHours(170);
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime8.toMutableDateTime();
//        int int16 = dateTimeFormatter2.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime13, "2019-06-19T22:53:29.523+00:00:00.100", (-171));
//        java.io.Writer writer17 = null;
//        try {
//            dateTimeFormatter2.printTo(writer17, 315532800010L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970-01-05T01:00:00.104+00:00:00.100" + "'", str10.equals("1970-01-05T01:00:00.104+00:00:00.100"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-171) + "'", int16 == (-171));
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("", 292278993, 23, 3, 'a', 53597, 0, 100, false, 3);
        java.io.OutputStream outputStream13 = null;
        try {
            dateTimeZoneBuilder11.writeTo("org.joda.time.IllegalFieldValueException: Value \"\" for hi! is not supported", outputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
        int int8 = offsetDateTimeField6.getLeapAmount(0L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText(2191787586692L, locale10);
        java.lang.String str12 = offsetDateTimeField6.toString();
        boolean boolean13 = offsetDateTimeField6.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "58" + "'", str11.equals("58"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[yearOfCentury]" + "'", str12.equals("DateTimeField[yearOfCentury]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property5 = dateTime4.centuryOfEra();
        org.joda.time.DateTime dateTime7 = dateTime4.plusHours((int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = dateTime7.plusHours((int) '#');
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime7.getZone();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime7.toMutableDateTime(chronology12);
        int int16 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime13, "Property[centuryOfEra]", 168);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-169) + "'", int16 == (-169));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.millisOfSecond();
        org.joda.time.DurationField durationField12 = gregorianChronology10.days();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.weekyearOfCentury();
        org.joda.time.DurationField durationField14 = gregorianChronology10.weekyears();
        boolean boolean15 = gregorianChronology0.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField17 = gregorianChronology0.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test277");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 2149);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property5 = dateTime4.centuryOfEra();
//        org.joda.time.DateTime dateTime7 = dateTime4.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime7.toMutableDateTime();
//        org.joda.time.DateTime.Property property9 = dateTime7.centuryOfEra();
//        org.joda.time.Interval interval10 = property9.toInterval();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
//        org.joda.time.DateTime dateTime13 = property12.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
//        long long15 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.LocalDateTime localDateTime17 = dateTime13.toLocalDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology20.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, 19);
//        org.joda.time.DurationField durationField26 = offsetDateTimeField25.getLeapDurationField();
//        long long28 = offsetDateTimeField25.roundHalfEven((long) (short) -1);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property30 = dateTime29.centuryOfEra();
//        org.joda.time.DateTime dateTime31 = property30.roundCeilingCopy();
//        org.joda.time.DateTime.Property property32 = dateTime31.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField25, dateTimeFieldType33, 19, (int) '4', (int) '4');
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property39 = dateTime38.centuryOfEra();
//        org.joda.time.DateTime dateTime40 = property39.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime41 = dateTime40.toLocalDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone44 = gregorianChronology43.getZone();
//        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology43.clockhourOfDay();
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property47 = dateTime46.centuryOfEra();
//        org.joda.time.DateTime dateTime48 = property47.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime49 = dateTime48.toLocalDateTime();
//        int[] intArray51 = gregorianChronology43.get((org.joda.time.ReadablePartial) localDateTime49, 100L);
//        int[] intArray53 = offsetDateTimeField37.add((org.joda.time.ReadablePartial) localDateTime41, 59, intArray51, 0);
//        java.util.Locale locale55 = null;
//        try {
//            int[] intArray56 = offsetDateTimeField3.set((org.joda.time.ReadablePartial) localDateTime17, 9, intArray51, "2019-06-19T15:53:18.168-07:00", locale55);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-19T15:53:18.168-07:00\" for weekyearOfCentury is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(interval10);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(localDateTime14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localDateTime17);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNull(durationField26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-100L) + "'", long28 == (-100L));
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(localDateTime41);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(localDateTime49);
//        org.junit.Assert.assertNotNull(intArray51);
//        org.junit.Assert.assertNotNull(intArray53);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = dateTime3.plusHours((int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime3.getZone();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime3.toMutableDateTime(chronology8);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.DateTime dateTime12 = dateTime3.withFieldAdded(durationFieldType10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        org.joda.time.DateTimeField dateTimeField0 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendCenturyOfEra(10, (-1));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendEraText();
//        boolean boolean12 = dateTimeFormatterBuilder10.canBuildParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.yearMonth();
//        org.joda.time.format.DateTimePrinter dateTimePrinter15 = dateTimeFormatter14.getPrinter();
//        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter14.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.append(dateTimeParser16);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendOptional(dateTimeParser16);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder1.appendYearOfCentury(1, (int) (short) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology23);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 19);
//        org.joda.time.DurationField durationField29 = offsetDateTimeField28.getLeapDurationField();
//        long long31 = offsetDateTimeField28.roundHalfEven((long) (short) -1);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property33 = dateTime32.centuryOfEra();
//        org.joda.time.DateTime dateTime34 = property33.roundCeilingCopy();
//        org.joda.time.DateTime.Property property35 = dateTime34.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property35.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField28, dateTimeFieldType36, 19, (int) '4', (int) '4');
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField28.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder1.appendFixedSignedDecimal(dateTimeFieldType41, 99);
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField44 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType41);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimePrinter15);
//        org.junit.Assert.assertNotNull(dateTimeParser16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNull(durationField29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-100L) + "'", long31 == (-100L));
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((int) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths(168);
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfHour();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DurationField durationField2 = property1.getRangeDurationField();
        org.joda.time.DateTime dateTime3 = property1.withMaximumValue();
        org.joda.time.DateTime dateTime4 = property1.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        boolean boolean6 = dateTime4.isBeforeNow();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra(19, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendDayOfWeek(665);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendMinuteOfHour(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder5.appendClockhourOfHalfday(59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder5.appendYear(86, 292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder5.appendFractionOfMinute(59, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("", 292278993, 23, 3, 'a', 53597, 0, 100, false, 3);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder11.addRecurringSavings("1999", 0, (int) (byte) 100, 70, ' ', 89, 5, 2019, false, 53597);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(168);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfEven((long) (short) -1);
//        java.util.Locale locale10 = null;
//        int int11 = offsetDateTimeField6.getMaximumTextLength(locale10);
//        long long14 = offsetDateTimeField6.add(10L, (-1L));
//        long long16 = offsetDateTimeField6.roundHalfCeiling((long) 168);
//        int int18 = offsetDateTimeField6.getLeapAmount(292279093L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-31535999990L) + "'", long14 == (-31535999990L));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-100L) + "'", long16 == (-100L));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        boolean boolean6 = gregorianChronology1.equals((java.lang.Object) dateTimeZone5);
        org.joda.time.DurationField durationField7 = gregorianChronology1.weekyears();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology1.getZone();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(5663109201710L, dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        java.util.Locale locale3 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test289");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusMonths((-1));
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsShortText(locale5);
//        org.joda.time.DateTime dateTime7 = property4.getDateTime();
//        int int8 = property4.getMaximumValueOverall();
//        org.joda.time.DateTime dateTime10 = property4.addWrapFieldToCopy(2149);
//        org.joda.time.DateTime dateTime12 = dateTime10.withMinuteOfHour(19);
//        org.joda.time.DateTime.Property property13 = dateTime12.minuteOfDay();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1439 + "'", int8 == 1439);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
//        org.joda.time.DateTime dateTime5 = dateTime2.plusHours((int) 'a');
//        org.joda.time.DateTime.Property property6 = dateTime5.dayOfMonth();
//        org.joda.time.DateTime dateTime8 = dateTime5.plusHours((int) '#');
//        java.lang.String str9 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "19700105" + "'", str9.equals("19700105"));
//    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
//        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
//        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.clockhourOfDay();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property14 = dateTime13.centuryOfEra();
//        org.joda.time.DateTime dateTime15 = property14.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime16 = dateTime15.toLocalDateTime();
//        int[] intArray18 = gregorianChronology10.get((org.joda.time.ReadablePartial) localDateTime16, 100L);
//        long long20 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDateTime16, (long) (short) 10);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology0.dayOfMonth();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localDateTime16);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 946684799900L + "'", long20 == 946684799900L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test292");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusMonths((-1));
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsShortText(locale5);
//        org.joda.time.DateTime dateTime7 = property4.getDateTime();
//        org.joda.time.DateTime.Property property8 = dateTime7.hourOfDay();
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((-53598));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -53598 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, 292278970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendTimeZoneOffset("2019-06-19T15:53:12.294-07:00", "86", true, 1439, (-53597));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = iSOChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.era();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        boolean boolean10 = dateTimeZone8.isStandardOffset((long) (short) -1);
        org.joda.time.Chronology chronology11 = iSOChronology3.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology3.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        long long16 = iSOChronology3.add(readablePeriod13, (-100L), 1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-100L) + "'", long16 == (-100L));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("38", "2019-06-19T22:53:29.854+00:00:00.100", 119, (int) '4');
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedDateTimeZone4.equals(obj5);
        long long8 = fixedDateTimeZone4.previousTransition(315532799800L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 315532799800L + "'", long8 == 315532799800L);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test297");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        java.lang.String str8 = offsetDateTimeField6.getAsShortText(0L);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "89" + "'", str8.equals("89"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test298");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendEraText();
//        boolean boolean8 = dateTimeFormatterBuilder7.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendCenturyOfEra(10, (-1));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder9.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder9.appendHourOfDay(19);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property21 = dateTime20.centuryOfEra();
//        org.joda.time.DateTime dateTime22 = property21.roundCeilingCopy();
//        org.joda.time.DateTime.Property property23 = dateTime22.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType24);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendShortText(dateTimeFieldType24);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder3.appendDecimal(dateTimeFieldType24, (int) '#', (-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone32 = gregorianChronology31.getZone();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology31);
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology31.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 19);
//        org.joda.time.DurationField durationField37 = offsetDateTimeField36.getLeapDurationField();
//        long long39 = offsetDateTimeField36.roundHalfFloor((long) '4');
//        int int40 = offsetDateTimeField36.getMinimumValue();
//        long long43 = offsetDateTimeField36.add((long) 7, (long) (byte) 0);
//        long long45 = offsetDateTimeField36.roundHalfEven(1L);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField36, 7);
//        long long50 = offsetDateTimeField36.getDifferenceAsLong((-31535999990L), 7L);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property52 = dateTime51.centuryOfEra();
//        org.joda.time.DateTime dateTime53 = property52.roundCeilingCopy();
//        org.joda.time.DateTime.Property property54 = dateTime53.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property54.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException57 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType55, "");
//        java.lang.String str58 = illegalFieldValueException57.toString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = illegalFieldValueException57.getDateTimeFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField61 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField36, dateTimeFieldType59, (int) (short) -1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder29.appendFraction(dateTimeFieldType59, 2149, 20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-100L) + "'", long39 == (-100L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 20 + "'", int40 == 20);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 7L + "'", long43 == 7L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-100L) + "'", long45 == (-100L));
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for weekyear is not supported" + "'", str58.equals("org.joda.time.IllegalFieldValueException: Value \"\" for weekyear is not supported"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = property1.roundCeilingCopy();
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours(19);
        org.joda.time.DateTime dateTime6 = dateTime4.plusMonths((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyearOfCentury();
        boolean boolean9 = dateTime6.equals((java.lang.Object) dateTimeField8);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime9 = dateTime6.minusMonths((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.millisOfSecond();
        org.joda.time.DurationField durationField12 = gregorianChronology10.days();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.weekyearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime9.toMutableDateTime((org.joda.time.Chronology) gregorianChronology10);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(1, 292278970, 59, 540, 2149, 0, (org.joda.time.Chronology) gregorianChronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 540 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
        boolean boolean8 = dateTime5.equals((java.lang.Object) (-171));
        org.joda.time.DateTime.Property property9 = dateTime5.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        long long19 = dateTimeZone16.convertLocalToUTC(1560635586792L, true);
        org.joda.time.Chronology chronology20 = gregorianChronology14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime21 = dateTime13.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = dateTime5.withZone(dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560635586692L + "'", long19 == 1560635586692L);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTimeISO();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = iSOChronology3.hours();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property6 = dateTime5.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = dateTime5.plusHours((int) 'a');
//        boolean boolean9 = dateTime8.isBeforeNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.DateTime dateTime12 = dateTime8.withZoneRetainFields(dateTimeZone11);
//        org.joda.time.YearMonthDay yearMonthDay13 = dateTime8.toYearMonthDay();
//        long long15 = iSOChronology3.set((org.joda.time.ReadablePartial) yearMonthDay13, (long) (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(yearMonthDay13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 431999999L + "'", long15 == 431999999L);
//    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        long long8 = offsetDateTimeField6.roundHalfEven(1560635586792L);
//        java.lang.String str10 = offsetDateTimeField6.getAsText((long) (-1));
//        long long13 = offsetDateTimeField6.add(10L, (long) 168);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology15);
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.clockhourOfDay();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property25 = dateTime24.centuryOfEra();
//        org.joda.time.DateTime dateTime26 = property25.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime27 = dateTime26.toLocalDateTime();
//        int[] intArray29 = gregorianChronology21.get((org.joda.time.ReadablePartial) localDateTime27, 100L);
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology21.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone32 = gregorianChronology31.getZone();
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.clockhourOfDay();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property35 = dateTime34.centuryOfEra();
//        org.joda.time.DateTime dateTime36 = property35.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime37 = dateTime36.toLocalDateTime();
//        int[] intArray39 = gregorianChronology31.get((org.joda.time.ReadablePartial) localDateTime37, 100L);
//        long long41 = gregorianChronology21.set((org.joda.time.ReadablePartial) localDateTime37, (long) (short) 10);
//        int int42 = offsetDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) localDateTime37);
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = offsetDateTimeField6.getAsText((org.joda.time.ReadablePartial) localDateTime37, locale43);
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone49 = gregorianChronology48.getZone();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology48);
//        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology48.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, 19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone55 = gregorianChronology54.getZone();
//        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology54.clockhourOfDay();
//        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property58 = dateTime57.centuryOfEra();
//        org.joda.time.DateTime dateTime59 = property58.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime60 = dateTime59.toLocalDateTime();
//        int[] intArray62 = gregorianChronology54.get((org.joda.time.ReadablePartial) localDateTime60, 100L);
//        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology54.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology64 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone65 = gregorianChronology64.getZone();
//        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology64.clockhourOfDay();
//        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property68 = dateTime67.centuryOfEra();
//        org.joda.time.DateTime dateTime69 = property68.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime70 = dateTime69.toLocalDateTime();
//        int[] intArray72 = gregorianChronology64.get((org.joda.time.ReadablePartial) localDateTime70, 100L);
//        long long74 = gregorianChronology54.set((org.joda.time.ReadablePartial) localDateTime70, (long) (short) 10);
//        int int75 = offsetDateTimeField53.getMaximumValue((org.joda.time.ReadablePartial) localDateTime70);
//        long long77 = gregorianChronology45.set((org.joda.time.ReadablePartial) localDateTime70, 1546329600000L);
//        java.util.Locale locale78 = null;
//        java.lang.String str79 = offsetDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDateTime70, locale78);
//        java.util.Locale locale81 = null;
//        java.lang.String str82 = offsetDateTimeField6.getAsText((-1), locale81);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546300799900L + "'", long8 == 1546300799900L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "89" + "'", str10.equals("89"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 5301590400010L + "'", long13 == 5301590400010L);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(localDateTime27);
//        org.junit.Assert.assertNotNull(intArray29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(localDateTime37);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 946684799900L + "'", long41 == 946684799900L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 119 + "'", int42 == 119);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "0" + "'", str44.equals("0"));
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(gregorianChronology54);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(localDateTime60);
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertNotNull(gregorianChronology64);
//        org.junit.Assert.assertNotNull(dateTimeZone65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(localDateTime70);
//        org.junit.Assert.assertNotNull(intArray72);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 946684799900L + "'", long74 == 946684799900L);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 119 + "'", int75 == 119);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 946684799900L + "'", long77 == 946684799900L);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "0" + "'", str79.equals("0"));
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "-1" + "'", str82.equals("-1"));
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = property1.addToCopy((long) 99);
        int int4 = property1.get();
        java.lang.String str5 = property1.toString();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[centuryOfEra]" + "'", str5.equals("Property[centuryOfEra]"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder6.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder6.appendHourOfDay(19);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property18 = dateTime17.centuryOfEra();
        org.joda.time.DateTime dateTime19 = property18.roundCeilingCopy();
        org.joda.time.DateTime.Property property20 = dateTime19.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder16.appendShortText(dateTimeFieldType21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType21);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.millisOfSecond();
        org.joda.time.DurationField durationField26 = gregorianChronology24.days();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology24.weekyearOfCentury();
        org.joda.time.DurationField durationField28 = gregorianChronology24.weekyears();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology24.minuteOfDay();
        org.joda.time.DurationField durationField30 = gregorianChronology24.seconds();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField36 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType21, durationField30, durationField35);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType21, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfFloor((long) '4');
//        int int10 = offsetDateTimeField6.getMinimumValue();
//        int int13 = offsetDateTimeField6.getDifference((long) 119, 0L);
//        long long15 = offsetDateTimeField6.roundCeiling(0L);
//        long long18 = offsetDateTimeField6.getDifferenceAsLong((-100L), 1560635624446L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology20.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, 19);
//        org.joda.time.DurationField durationField26 = offsetDateTimeField25.getLeapDurationField();
//        long long28 = offsetDateTimeField25.roundHalfEven((long) (short) -1);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property30 = dateTime29.centuryOfEra();
//        org.joda.time.DateTime dateTime31 = property30.roundCeilingCopy();
//        org.joda.time.DateTime.Property property32 = dateTime31.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField25, dateTimeFieldType33, 19, (int) '4', (int) '4');
//        java.lang.String str39 = offsetDateTimeField37.getAsShortText((long) 2019);
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone42 = gregorianChronology41.getZone();
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology41);
//        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology41.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone48 = gregorianChronology47.getZone();
//        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.clockhourOfDay();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property51 = dateTime50.centuryOfEra();
//        org.joda.time.DateTime dateTime52 = property51.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
//        int[] intArray55 = gregorianChronology47.get((org.joda.time.ReadablePartial) localDateTime53, 100L);
//        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology47.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone58 = gregorianChronology57.getZone();
//        org.joda.time.DateTimeField dateTimeField59 = gregorianChronology57.clockhourOfDay();
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property61 = dateTime60.centuryOfEra();
//        org.joda.time.DateTime dateTime62 = property61.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime63 = dateTime62.toLocalDateTime();
//        int[] intArray65 = gregorianChronology57.get((org.joda.time.ReadablePartial) localDateTime63, 100L);
//        long long67 = gregorianChronology47.set((org.joda.time.ReadablePartial) localDateTime63, (long) (short) 10);
//        int int68 = offsetDateTimeField46.getMaximumValue((org.joda.time.ReadablePartial) localDateTime63);
//        java.util.Locale locale69 = null;
//        java.lang.String str70 = offsetDateTimeField37.getAsShortText((org.joda.time.ReadablePartial) localDateTime63, locale69);
//        java.util.Locale locale71 = null;
//        java.lang.String str72 = offsetDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDateTime63, locale71);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999900L + "'", long15 == 31535999900L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-49L) + "'", long18 == (-49L));
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNull(durationField26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-100L) + "'", long28 == (-100L));
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "108" + "'", str39.equals("108"));
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(localDateTime53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(gregorianChronology57);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(localDateTime63);
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 946684799900L + "'", long67 == 946684799900L);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 119 + "'", int68 == 119);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "1999" + "'", str70.equals("1999"));
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "0" + "'", str72.equals("0"));
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        boolean boolean4 = dateTime3.isBeforeNow();
        int int5 = dateTime3.getYearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        boolean boolean11 = gregorianChronology6.equals((java.lang.Object) dateTimeZone10);
        org.joda.time.DateTime dateTime12 = dateTime3.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime12.withYearOfCentury(52);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 70 + "'", int5 == 70);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        int int6 = dateTime5.getDayOfYear();
//        org.joda.time.DateTime dateTime8 = dateTime5.plus((long) (short) 10);
//        int int9 = dateTime8.getHourOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime8.minus((-100L));
//        int int12 = dateTime8.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        boolean boolean4 = dateTime3.isBeforeNow();
        int int5 = dateTime3.getYearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        boolean boolean11 = gregorianChronology6.equals((java.lang.Object) dateTimeZone10);
        org.joda.time.DateTime dateTime12 = dateTime3.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime12.withMillisOfSecond(0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 70 + "'", int5 == 70);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneOffset("2019-06-19T22:53:48.016+00:00:00.100", false, (int) (byte) 10, 2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfMonth(3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder3.appendHourOfDay(19);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property15 = dateTime14.centuryOfEra();
        org.joda.time.DateTime dateTime16 = property15.roundCeilingCopy();
        org.joda.time.DateTime.Property property17 = dateTime16.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder13.appendShortText(dateTimeFieldType18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder1.appendShortText(dateTimeFieldType18);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.millisOfSecond();
        org.joda.time.DurationField durationField23 = gregorianChronology21.days();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.weekyearOfCentury();
        org.joda.time.DurationField durationField25 = gregorianChronology21.weekyears();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology21.minuteOfDay();
        org.joda.time.DurationField durationField27 = gregorianChronology21.seconds();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DurationField durationField32 = iSOChronology31.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField33 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType18, durationField27, durationField32);
        boolean boolean34 = preciseDateTimeField33.isLenient();
        boolean boolean35 = preciseDateTimeField33.isLenient();
        boolean boolean36 = preciseDateTimeField33.isLenient();
        org.joda.time.DurationField durationField37 = preciseDateTimeField33.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(durationField37);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.Interval interval6 = property5.toInterval();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
        long long11 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime9);
        int int12 = property5.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property5.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime14 = property5.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2922789 + "'", int12 == 2922789);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendEraText();
        boolean boolean11 = dateTimeFormatterBuilder9.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter13.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.append(dateTimeParser15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendFractionOfDay(4, 292278993);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((-1595124380001L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 14 + "'", int1 == 14);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra(19, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendDayOfWeek(665);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendPattern("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
        org.joda.time.DurationField durationField9 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendWeekOfWeekyear(168);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendLiteral('a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.append(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        boolean boolean4 = dateTime3.isBeforeNow();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTime dateTime7 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime3.minusWeeks(0);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.clockhourOfDay();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property15 = dateTime14.centuryOfEra();
        org.joda.time.DateTime dateTime16 = property15.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime17 = dateTime16.toLocalDateTime();
        int[] intArray19 = gregorianChronology11.get((org.joda.time.ReadablePartial) localDateTime17, 100L);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology11.yearOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.millisOfSecond();
        org.joda.time.DurationField durationField23 = gregorianChronology21.days();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.weekyearOfCentury();
        org.joda.time.DurationField durationField25 = gregorianChronology21.weekyears();
        boolean boolean26 = gregorianChronology11.equals((java.lang.Object) gregorianChronology21);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property28 = dateTime27.centuryOfEra();
        org.joda.time.DateTime dateTime30 = dateTime27.plusHours((int) 'a');
        boolean boolean31 = dateTime30.isBeforeNow();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone33 = gregorianChronology32.getZone();
        org.joda.time.DateTime dateTime34 = dateTime30.withZoneRetainFields(dateTimeZone33);
        org.joda.time.Chronology chronology35 = gregorianChronology11.withZone(dateTimeZone33);
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology11.secondOfDay();
        org.joda.time.DateTime dateTime37 = dateTime9.withChronology((org.joda.time.Chronology) gregorianChronology11);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDateTime17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTime37);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withDefaultYear(168);
        int int5 = dateTimeFormatter4.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 168 + "'", int5 == 168);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.Interval interval6 = property5.toInterval();
        int int7 = property5.getMinimumValueOverall();
        org.joda.time.Interval interval8 = property5.toInterval();
        java.lang.String str9 = property5.toString();
        org.joda.time.DateTime dateTime10 = property5.roundCeilingCopy();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[centuryOfEra]" + "'", str9.equals("Property[centuryOfEra]"));
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = dateTime3.plusHours((int) '#');
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.plus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime3.centuryOfEra();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
//        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
//        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime6, 100L);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.clockhourOfDay();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property14 = dateTime13.centuryOfEra();
//        org.joda.time.DateTime dateTime15 = property14.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime16 = dateTime15.toLocalDateTime();
//        int[] intArray18 = gregorianChronology10.get((org.joda.time.ReadablePartial) localDateTime16, 100L);
//        long long20 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDateTime16, (long) (short) 10);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, 59);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendCenturyOfEra(10, (-1));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder24.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendTwoDigitWeekyear((int) (short) 100, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendCenturyOfEra(10, (-1));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder36.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder36.appendHourOfDay(19);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder47.appendCenturyOfEra(10, (-1));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder47.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder47.appendHourOfDay(19);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property59 = dateTime58.centuryOfEra();
//        org.joda.time.DateTime dateTime60 = property59.roundCeilingCopy();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder57.appendShortText(dateTimeFieldType62);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder36.appendFraction(dateTimeFieldType62, (int) (byte) 0, (int) (short) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder35.appendDecimal(dateTimeFieldType62, 3, (int) '4');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField73 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, dateTimeFieldType62, 100, 170, (-53597));
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField73.getAsShortText(7258147200000L, locale75);
//        int int79 = offsetDateTimeField73.getDifference(5301590399900L, 315532799900L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localDateTime16);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 946684799900L + "'", long20 == 946684799900L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
//        org.junit.Assert.assertNotNull(property59);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "122" + "'", str76.equals("122"));
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.minusMonths((-1));
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        long long10 = dateTimeZone7.convertLocalToUTC(1560635586792L, true);
        org.joda.time.Chronology chronology11 = gregorianChronology5.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime12 = dateTime3.toDateTime(chronology11);
        org.joda.time.TimeOfDay timeOfDay13 = dateTime12.toTimeOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560635586692L + "'", long10 == 1560635586692L);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(timeOfDay13);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYear(89, (-5));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime7 = dateTime3.minusYears(0);
        org.joda.time.DateTime dateTime9 = dateTime3.withCenturyOfEra(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.clockhourOfDay();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property14 = dateTime13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = property14.roundCeilingCopy();
        org.joda.time.LocalDateTime localDateTime16 = dateTime15.toLocalDateTime();
        int[] intArray18 = gregorianChronology10.get((org.joda.time.ReadablePartial) localDateTime16, 100L);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology10.yearOfEra();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology10.millisOfDay();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology10.year();
        org.joda.time.DateTime dateTime22 = dateTime3.withChronology((org.joda.time.Chronology) gregorianChronology10);
        try {
            long long30 = gregorianChronology10.getDateTimeMillis(292278993, (int) (byte) 100, 49, 15, 15, 21, 292278970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278970 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localDateTime16);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test329");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long10 = offsetDateTimeField6.addWrapField((-1595149601709L), (int) '#');
//        long long12 = offsetDateTimeField6.roundHalfEven((long) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
//        boolean boolean18 = gregorianChronology13.equals((java.lang.Object) dateTimeZone17);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology13, dateTimeZone20);
//        java.lang.Object obj22 = null;
//        boolean boolean23 = zonedChronology21.equals(obj22);
//        java.lang.String str24 = zonedChronology21.toString();
//        boolean boolean26 = zonedChronology21.equals((java.lang.Object) (-1L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology27.getZone();
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology30.getZone();
//        boolean boolean32 = gregorianChronology27.equals((java.lang.Object) dateTimeZone31);
//        org.joda.time.DurationField durationField33 = gregorianChronology27.weekyears();
//        org.joda.time.DurationField durationField34 = gregorianChronology27.months();
//        boolean boolean35 = zonedChronology21.equals((java.lang.Object) gregorianChronology27);
//        int int36 = gregorianChronology27.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property38 = dateTime37.centuryOfEra();
//        org.joda.time.DateTime dateTime40 = dateTime37.plusHours((int) 'a');
//        java.lang.String str41 = dateTime37.toString();
//        org.joda.time.TimeOfDay timeOfDay42 = dateTime37.toTimeOfDay();
//        int[] intArray44 = gregorianChronology27.get((org.joda.time.ReadablePartial) timeOfDay42, 7258147200000L);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = offsetDateTimeField6.getAsText((org.joda.time.ReadablePartial) timeOfDay42, 32400200, locale46);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-490612001709L) + "'", long10 == (-490612001709L));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-100L) + "'", long12 == (-100L));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str24.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1970-01-01T00:00:00.104+00:00:00.100" + "'", str41.equals("1970-01-01T00:00:00.104+00:00:00.100"));
//        org.junit.Assert.assertNotNull(timeOfDay42);
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "32400200" + "'", str47.equals("32400200"));
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = iSOChronology3.withUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) (short) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("38", "2019-06-19T22:53:29.854+00:00:00.100", 119, (int) '4');
        int int17 = fixedDateTimeZone15.getOffsetFromLocal(0L);
        org.joda.time.Chronology chronology18 = zonedChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        int int20 = fixedDateTimeZone15.getOffset((-1609081199800L));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 119 + "'", int17 == 119);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 119 + "'", int20 == 119);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.clockhourOfDay();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime13 = dateTime12.toLocalDateTime();
//        int[] intArray15 = gregorianChronology7.get((org.joda.time.ReadablePartial) localDateTime13, 100L);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology7.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.clockhourOfDay();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property21 = dateTime20.centuryOfEra();
//        org.joda.time.DateTime dateTime22 = property21.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime23 = dateTime22.toLocalDateTime();
//        int[] intArray25 = gregorianChronology17.get((org.joda.time.ReadablePartial) localDateTime23, 100L);
//        long long27 = gregorianChronology7.set((org.joda.time.ReadablePartial) localDateTime23, (long) (short) 10);
//        int int28 = offsetDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDateTime23);
//        java.util.Locale locale29 = null;
//        int int30 = offsetDateTimeField6.getMaximumShortTextLength(locale29);
//        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField6.getWrappedField();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localDateTime13);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(localDateTime23);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 946684799900L + "'", long27 == 946684799900L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 119 + "'", int28 == 119);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test332");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        long long8 = offsetDateTimeField6.roundHalfEven(1560635586792L);
//        java.lang.String str10 = offsetDateTimeField6.getAsText(110L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546300799900L + "'", long8 == 1546300799900L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "89" + "'", str10.equals("89"));
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        try {
            long long2 = dateTimeFormatter0.parseMillis("2019-06-19T15:53:25.431-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-19T15:53:25.431-07:00\" is malformed at \"-19T15:53:25.431-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property2 = dateTime1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = property2.roundCeilingCopy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonth();
//        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime9.toMutableDateTime();
//        int int13 = dateTimeFormatter4.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "hi!", 0);
//        int int14 = dateTime3.compareTo((org.joda.time.ReadableInstant) mutableDateTime10);
//        int int17 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "", 53597);
//        java.util.Locale locale18 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter0.withLocale(locale18);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property22 = dateTime21.centuryOfEra();
//        org.joda.time.DateTime dateTime23 = property22.roundCeilingCopy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.yearMonth();
//        org.joda.time.format.DateTimePrinter dateTimePrinter25 = dateTimeFormatter24.getPrinter();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property27 = dateTime26.centuryOfEra();
//        org.joda.time.DateTime dateTime29 = dateTime26.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime30 = dateTime29.toMutableDateTime();
//        int int33 = dateTimeFormatter24.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime30, "hi!", 0);
//        int int34 = dateTime23.compareTo((org.joda.time.ReadableInstant) mutableDateTime30);
//        int int37 = dateTimeFormatter20.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime30, "", 53597);
//        java.lang.String str38 = dateTimeFormatter19.print((org.joda.time.ReadableInstant) mutableDateTime30);
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology39.millisOfSecond();
//        org.joda.time.DurationField durationField41 = gregorianChronology39.days();
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology39.weekyearOfCentury();
//        org.joda.time.DurationField durationField43 = gregorianChronology39.weekyears();
//        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology39.minuteOfDay();
//        org.joda.time.DurationField durationField45 = gregorianChronology39.seconds();
//        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology39.hourOfDay();
//        org.joda.time.DurationField durationField47 = gregorianChronology39.weeks();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = dateTimeFormatter19.withChronology((org.joda.time.Chronology) gregorianChronology39);
//        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology39.hourOfHalfday();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimePrinter5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-53598) + "'", int17 == (-53598));
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTimePrinter25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-53598) + "'", int37 == (-53598));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970-01-05T01" + "'", str38.equals("1970-01-05T01"));
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeFormatter48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test336");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfFloor((long) '4');
//        int int10 = offsetDateTimeField6.getMinimumValue();
//        long long13 = offsetDateTimeField6.add((long) 7, (long) (byte) 0);
//        long long15 = offsetDateTimeField6.roundHalfEven(1L);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, 7);
//        java.util.Locale locale18 = null;
//        int int19 = offsetDateTimeField17.getMaximumTextLength(locale18);
//        java.util.Locale locale20 = null;
//        int int21 = offsetDateTimeField17.getMaximumShortTextLength(locale20);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 7L + "'", long13 == 7L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-100L) + "'", long15 == (-100L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = property1.roundCeilingCopy();
        org.joda.time.DateTime dateTime3 = property1.withMinimumValue();
        org.joda.time.DateTime dateTime5 = property1.setCopy(665);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test338");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.DateTime dateTime5 = dateTime3.minusWeeks((int) '#');
//        int int6 = dateTime3.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 921600000L, (java.lang.Number) 19, (java.lang.Number) (-1595149607071L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test340");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfEven((long) (short) -1);
//        java.util.Locale locale10 = null;
//        int int11 = offsetDateTimeField6.getMaximumTextLength(locale10);
//        int int13 = offsetDateTimeField6.getMaximumValue((long) (byte) 10);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 119 + "'", int13 == 119);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-01-05T09:00:00.200+00:00:00.100", (java.lang.Number) 1546678800203L, (java.lang.Number) 32, (java.lang.Number) 2191787586692L);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2191787586692L + "'", number5.equals(2191787586692L));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        boolean boolean4 = dateTime3.isBeforeNow();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTime dateTime7 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(0L, dateTimeZone9);
        org.joda.time.DateTime dateTime11 = dateTime3.toDateTime(dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime15 = dateTime12.withDurationAdded(0L, (-1));
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder3.appendHourOfDay(19);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property15 = dateTime14.centuryOfEra();
        org.joda.time.DateTime dateTime16 = property15.roundCeilingCopy();
        org.joda.time.DateTime.Property property17 = dateTime16.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder13.appendShortText(dateTimeFieldType18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder1.appendShortText(dateTimeFieldType18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder1.append(dateTimeParser22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendSecondOfMinute(10);
        boolean boolean26 = dateTimeFormatterBuilder25.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeParser22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = property1.roundCeilingCopy();
        org.joda.time.DurationField durationField3 = property1.getLeapDurationField();
        int int4 = property1.getMaximumValue();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property1.getAsText(locale5);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2922789 + "'", int4 == 2922789);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (-490608341709L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendHourOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendDayOfYear(100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.append(dateTimeParser6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendEraText();
        boolean boolean12 = dateTimeFormatterBuilder10.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter15 = dateTimeFormatter14.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.append(dateTimeParser16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParser16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder3.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimePrinter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendDayOfWeek(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendLiteral(' ');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("");
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException7.prependMessage("");
        java.lang.Number number10 = illegalFieldValueException7.getLowerBound();
        java.lang.String str11 = illegalFieldValueException7.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = illegalFieldValueException7.getDateTimeFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        java.lang.Throwable throwable14 = null;
        try {
            illegalFieldValueException7.addSuppressed(throwable14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported" + "'", str11.equals("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported"));
        org.junit.Assert.assertNull(dateTimeFieldType12);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("9", (java.lang.Number) 154L, (java.lang.Number) 10.0d, (java.lang.Number) (-1609081199800L));
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        illegalFieldValueException4.prependMessage("9");
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 154L + "'", number5.equals(154L));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test353");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfFloor((long) '4');
//        int int10 = offsetDateTimeField6.getMinimumValue();
//        long long13 = offsetDateTimeField6.add((long) 7, (long) (byte) 0);
//        long long15 = offsetDateTimeField6.roundHalfEven(1L);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, 7);
//        long long20 = offsetDateTimeField17.add(315532800010L, 2149);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 7L + "'", long13 == 7L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-100L) + "'", long15 == (-100L));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 68131497600010L + "'", long20 == 68131497600010L);
//    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test354");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfFloor((long) '4');
//        int int10 = offsetDateTimeField6.getMinimumValue();
//        int int13 = offsetDateTimeField6.getDifference((long) 119, 0L);
//        long long15 = offsetDateTimeField6.roundHalfEven(946684799900L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 946684799900L + "'", long15 == 946684799900L);
//    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test355");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withDefaultYear(168);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        boolean boolean10 = gregorianChronology5.equals((java.lang.Object) dateTimeZone9);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone9.getName((-1595149607071L), locale13);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter4.withZone(dateTimeZone9);
//        boolean boolean16 = dateTimeFormatter15.isOffsetParsed();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.100" + "'", str14.equals("+00:00:00.100"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test356");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DurationField durationField2 = gregorianChronology0.centuries();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.centuries();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        boolean boolean9 = gregorianChronology4.equals((java.lang.Object) dateTimeZone8);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
//        boolean boolean12 = cachedDateTimeZone10.isFixed();
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone10, 3);
//        org.joda.time.Chronology chronology15 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test357");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property2 = dateTime1.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = dateTime1.plusHours((int) 'a');
//        boolean boolean5 = dateTime4.isBeforeNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZoneRetainFields(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.era();
//        java.lang.String str10 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime8.withDurationAdded(readableDuration11, 20);
//        org.joda.time.DateTime.Property property14 = dateTime8.yearOfEra();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970005" + "'", str10.equals("1970005"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "ZonedChronology[GregorianChronology[UTC], UTC]", "38");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "20", "GregorianChronology[America/Los_Angeles]");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "108", "19700105");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 100, 53597);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendEraText();
        boolean boolean8 = dateTimeFormatterBuilder6.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatter10.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.append(dateTimeParser12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter15 = dateTimeFormatter14.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendEraText();
        boolean boolean18 = dateTimeFormatterBuilder16.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter21 = dateTimeFormatter20.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatter20.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder19.append(dateTimeParser22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder9.append(dateTimePrinter15, dateTimeParser22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimeParser22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendFractionOfDay(52, 7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimePrinter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimePrinter15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimePrinter21);
        org.junit.Assert.assertNotNull(dateTimeParser22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test361");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 19);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
//        long long9 = offsetDateTimeField6.roundHalfFloor((long) '4');
//        int int10 = offsetDateTimeField6.getMinimumValue();
//        long long13 = offsetDateTimeField6.add((long) 7, (long) (byte) 0);
//        long long15 = offsetDateTimeField6.roundHalfEven(1L);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, 7);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField6.getAsShortText(15, locale19);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-100L) + "'", long9 == (-100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 7L + "'", long13 == 7L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-100L) + "'", long15 == (-100L));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("2019-06-19T22:53:39.593+00:00:00.100", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2019-06-19T22:53:39.593+00:00:00.100/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(292278970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendHourOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology8.getZone();
        org.joda.time.DateTimeZone dateTimeZone11 = zonedChronology8.getZone();
        org.joda.time.DurationField durationField12 = zonedChronology8.hours();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        boolean boolean6 = dateTimeFormatterBuilder4.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendYear((int) (short) 100, 53597);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendEraText();
        boolean boolean12 = dateTimeFormatterBuilder10.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter15 = dateTimeFormatter14.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.append(dateTimeParser16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatter18.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder20.appendEraText();
        boolean boolean22 = dateTimeFormatterBuilder20.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter25 = dateTimeFormatter24.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser26 = dateTimeFormatter24.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder23.append(dateTimeParser26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder13.append(dateTimePrinter19, dateTimeParser26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder4.append(dateTimeParser26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder3.append(dateTimeParser26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendMillisOfSecond(292278993);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimePrinter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimePrinter25);
        org.junit.Assert.assertNotNull(dateTimeParser26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder3.appendHourOfDay(19);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property15 = dateTime14.centuryOfEra();
        org.joda.time.DateTime dateTime16 = property15.roundCeilingCopy();
        org.joda.time.DateTime.Property property17 = dateTime16.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder13.appendShortText(dateTimeFieldType18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder1.appendShortText(dateTimeFieldType18);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.millisOfSecond();
        org.joda.time.DurationField durationField23 = gregorianChronology21.days();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.weekyearOfCentury();
        org.joda.time.DurationField durationField25 = gregorianChronology21.weekyears();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology21.minuteOfDay();
        org.joda.time.DurationField durationField27 = gregorianChronology21.seconds();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DurationField durationField32 = iSOChronology31.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField33 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType18, durationField27, durationField32);
        boolean boolean34 = preciseDateTimeField33.isLenient();
        int int35 = preciseDateTimeField33.getRange();
        org.joda.time.DurationField durationField36 = preciseDateTimeField33.getRangeDurationField();
        long long38 = preciseDateTimeField33.roundFloor(0L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3600 + "'", int35 == 3600);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2019-06-19T15:53:19.665-07:00", false);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("PST", false);
        java.io.DataOutput dataOutput8 = null;
        try {
            dateTimeZoneBuilder0.writeTo("PST", dataOutput8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "88");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test370");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.Chronology chronology4 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) (byte) 1);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) (short) -1);
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
//        org.joda.time.DateTime dateTime14 = dateTime11.plusHours((int) 'a');
//        boolean boolean15 = dateTime14.isBeforeNow();
//        int int16 = dateTime14.getYearOfCentury();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
//        boolean boolean22 = gregorianChronology17.equals((java.lang.Object) dateTimeZone21);
//        org.joda.time.DateTime dateTime23 = dateTime14.withZoneRetainFields(dateTimeZone21);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone21.getName((-1595149603157L), locale25);
//        org.joda.time.Chronology chronology27 = zonedChronology10.withZone(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(zonedChronology10);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 70 + "'", int16 == 70);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00:00.100" + "'", str26.equals("+00:00:00.100"));
//        org.junit.Assert.assertNotNull(chronology27);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear((int) (short) 100, false);
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatterBuilder8.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendEraText();
        boolean boolean15 = dateTimeFormatterBuilder13.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatter17.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.append(dateTimeParser19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter22 = dateTimeFormatter21.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder23.appendEraText();
        boolean boolean25 = dateTimeFormatterBuilder23.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = dateTimeFormatter27.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter27.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder26.append(dateTimeParser29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder16.append(dateTimePrinter22, dateTimeParser29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder16.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder33.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder33.appendHourOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder44.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder44.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder44.appendHourOfDay(19);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property56 = dateTime55.centuryOfEra();
        org.joda.time.DateTime dateTime57 = property56.roundCeilingCopy();
        org.joda.time.DateTime.Property property58 = dateTime57.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder54.appendShortText(dateTimeFieldType59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder33.appendFraction(dateTimeFieldType59, (int) (byte) 0, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder16.appendFixedSignedDecimal(dateTimeFieldType59, 32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder8.appendFixedSignedDecimal(dateTimeFieldType59, 59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimePrinter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimePrinter22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimePrinter28);
        org.junit.Assert.assertNotNull(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime5 = dateTime2.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTime();
        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime6, "hi!", 0);
        org.joda.time.MutableDateTime mutableDateTime10 = mutableDateTime6.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendHourOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendMonthOfYear(19);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.util.Locale locale15 = dateTimeFormatter14.getLocale();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder12.appendOptional(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNull(locale15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear((int) (short) 100, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder12.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder12.appendHourOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendCenturyOfEra(10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder23.appendTimeZoneOffset("", false, (int) (short) 1, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder23.appendHourOfDay(19);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property35 = dateTime34.centuryOfEra();
        org.joda.time.DateTime dateTime36 = property35.roundCeilingCopy();
        org.joda.time.DateTime.Property property37 = dateTime36.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder33.appendShortText(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder12.appendFraction(dateTimeFieldType38, (int) (byte) 0, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder11.appendDecimal(dateTimeFieldType38, 3, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder11.appendFractionOfHour(15, (int) '4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DurationField durationField2 = property1.getRangeDurationField();
        org.joda.time.DateTime dateTime3 = property1.withMaximumValue();
        org.joda.time.DateTime dateTime4 = property1.getDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property1.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType5, (java.lang.Number) 4102473600000L, (java.lang.Number) 1, (java.lang.Number) 4102444799900L);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
        org.joda.time.DurationField durationField12 = property11.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField12);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test376");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
//        int int6 = dateTime5.getDayOfYear();
//        org.joda.time.DateTime dateTime8 = dateTime5.plus((long) (short) 10);
//        org.joda.time.DateTime dateTime10 = dateTime5.withWeekyear(0);
//        org.joda.time.DateTime.Property property11 = dateTime5.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = property11.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property14 = dateTime13.centuryOfEra();
//        org.joda.time.DateTime dateTime16 = dateTime13.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime17 = dateTime16.toMutableDateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.toDateTime();
//        org.joda.time.DateTime.Property property19 = dateTime18.yearOfEra();
//        java.lang.String str20 = dateTime18.toString();
//        org.joda.time.DateTime dateTime22 = dateTime18.plusHours(170);
//        org.joda.time.DateTime.Property property23 = dateTime18.yearOfEra();
//        boolean boolean24 = property23.isLeap();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.centuryOfEra();
//        org.joda.time.DateTime dateTime27 = property26.roundCeilingCopy();
//        org.joda.time.DateTime.Property property28 = dateTime27.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        boolean boolean30 = property23.equals((java.lang.Object) dateTimeFieldType29);
//        int int31 = dateTime12.get(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01-05T01:00:00.104+00:00:00.100" + "'", str20.equals("1970-01-05T01:00:00.104+00:00:00.100"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1999 + "'", int31 == 1999);
//    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test377");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
//        boolean boolean6 = gregorianChronology1.equals((java.lang.Object) dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = zonedChronology9.centuryOfEra();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
//        org.joda.time.DateTime dateTime14 = dateTime11.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime14.toMutableDateTime();
//        org.joda.time.DateTime dateTime16 = dateTime14.toDateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
//        java.lang.String str18 = dateTime16.toString();
//        org.joda.time.DateTime dateTime20 = dateTime16.plusHours(170);
//        org.joda.time.DateTime.Property property21 = dateTime16.yearOfEra();
//        boolean boolean22 = property21.isLeap();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property24 = dateTime23.centuryOfEra();
//        org.joda.time.DateTime dateTime25 = property24.roundCeilingCopy();
//        org.joda.time.DateTime.Property property26 = dateTime25.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
//        boolean boolean28 = property21.equals((java.lang.Object) dateTimeFieldType27);
//        org.joda.time.DateTimeField dateTimeField29 = property21.getField();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone35 = new org.joda.time.tz.FixedDateTimeZone("38", "2019-06-19T22:53:29.854+00:00:00.100", 119, (int) '4');
//        java.lang.Object obj36 = null;
//        boolean boolean37 = fixedDateTimeZone35.equals(obj36);
//        int int39 = fixedDateTimeZone35.getStandardOffset((-31507200000L));
//        java.lang.String str41 = fixedDateTimeZone35.getNameKey((long) 1);
//        java.lang.Object obj42 = null;
//        boolean boolean43 = fixedDateTimeZone35.equals(obj42);
//        java.lang.String str44 = fixedDateTimeZone35.toString();
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(0L, (org.joda.time.DateTimeZone) fixedDateTimeZone35);
//        int int46 = property21.getDifference((org.joda.time.ReadableInstant) dateTime45);
//        boolean boolean47 = zonedChronology9.equals((java.lang.Object) dateTime45);
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((java.lang.Object) "2019-06-15T21:53:48.934+00:00:00.100", (org.joda.time.Chronology) zonedChronology9);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(zonedChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-01-05T01:00:00.104+00:00:00.100" + "'", str18.equals("1970-01-05T01:00:00.104+00:00:00.100"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 52 + "'", int39 == 52);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2019-06-19T22:53:29.854+00:00:00.100" + "'", str41.equals("2019-06-19T22:53:29.854+00:00:00.100"));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "38" + "'", str44.equals("38"));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withWeekOfWeekyear((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes(15);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "58");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test380");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property5 = dateTime4.centuryOfEra();
//        org.joda.time.DateTime dateTime6 = property5.roundCeilingCopy();
//        org.joda.time.LocalDateTime localDateTime7 = dateTime6.toLocalDateTime();
//        int[] intArray9 = gregorianChronology1.get((org.joda.time.ReadablePartial) localDateTime7, 100L);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology1.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.millisOfSecond();
//        org.joda.time.DurationField durationField13 = gregorianChronology11.days();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.weekyearOfCentury();
//        org.joda.time.DurationField durationField15 = gregorianChronology11.weekyears();
//        boolean boolean16 = gregorianChronology1.equals((java.lang.Object) gregorianChronology11);
//        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
//        boolean boolean18 = iSOChronology0.equals((java.lang.Object) gregorianChronology1);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property20 = dateTime19.centuryOfEra();
//        boolean boolean21 = property20.isLeap();
//        long long22 = property20.remainder();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = property20.getAsText(locale23);
//        org.joda.time.DateTime dateTime25 = property20.withMaximumValue();
//        boolean boolean27 = dateTime25.isAfter((long) 20);
//        boolean boolean28 = iSOChronology0.equals((java.lang.Object) dateTime25);
//        org.joda.time.Chronology chronology29 = iSOChronology0.withUTC();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property31 = dateTime30.centuryOfEra();
//        org.joda.time.DateTime dateTime33 = dateTime30.plusHours((int) 'a');
//        org.joda.time.MutableDateTime mutableDateTime34 = dateTime33.toMutableDateTime();
//        org.joda.time.DateTime dateTime35 = dateTime33.toDateTime();
//        int int36 = dateTime35.getDayOfYear();
//        org.joda.time.DateTime dateTime38 = dateTime35.plus((long) (short) 10);
//        org.joda.time.DateTime dateTime40 = dateTime35.withWeekyear(0);
//        org.joda.time.DateTime.Property property41 = dateTime35.centuryOfEra();
//        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) property41);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDateTime7);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 104L + "'", long22 == 104L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "19" + "'", str24.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }
//}

