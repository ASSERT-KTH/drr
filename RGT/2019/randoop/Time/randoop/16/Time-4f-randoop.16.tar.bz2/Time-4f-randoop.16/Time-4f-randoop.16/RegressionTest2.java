import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        boolean boolean3 = julianChronology1.equals((java.lang.Object) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology5, readableDateTime6, readableDateTime7);
        org.joda.time.DurationField durationField9 = limitChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField10 = limitChronology8.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        long long14 = delegatedDateTimeField11.add((long) (byte) 1, (long) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField15.getAsText(0L, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipDateTimeField15.getType();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = julianChronology21.clockhourOfDay();
        org.joda.time.DurationField durationField23 = julianChronology21.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        try {
            int int26 = unsupportedDateTimeField24.getMinimumValue(1560553200002L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31557600000001L + "'", long14 == 31557600000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        boolean boolean3 = julianChronology1.equals((java.lang.Object) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology5, readableDateTime6, readableDateTime7);
        org.joda.time.DurationField durationField9 = limitChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField10 = limitChronology8.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        long long14 = delegatedDateTimeField11.add((long) (byte) 1, (long) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField15.getAsText(0L, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipDateTimeField15.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField15, (-1));
        long long24 = offsetDateTimeField21.add((long) (-25200000), 21);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int int26 = offsetDateTimeField21.getMinimumValue(readablePartial25);
        int int27 = offsetDateTimeField21.getMinimumValue();
        java.util.Locale locale28 = null;
        int int29 = offsetDateTimeField21.getMaximumTextLength(locale28);
        long long32 = offsetDateTimeField21.add((-210863764378000L), 10L);
        org.joda.time.DurationField durationField33 = offsetDateTimeField21.getRangeDurationField();
        try {
            long long36 = offsetDateTimeField21.add(28800000L, 33136588800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 3313658880000000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31557600000001L + "'", long14 == 31557600000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 66270934800000L + "'", long24 == 66270934800000L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 7 + "'", int29 == 7);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-179306164378000L) + "'", long32 == (-179306164378000L));
        org.junit.Assert.assertNotNull(durationField33);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter2.withZone(dateTimeZone4);
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
        org.joda.time.LocalDate localDate10 = localDate6.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = localDate6.toDateTimeAtMidnight();
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        java.util.Date date13 = dateTime11.toDate();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.withPeriodAdded(readablePeriod14, 2);
        org.joda.time.DateTime dateTime18 = dateTime16.plusYears(0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology2, readableDateTime3, readableDateTime4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        java.lang.String str8 = dateTimeZone7.getID();
        org.joda.time.Chronology chronology9 = julianChronology2.withZone(dateTimeZone7);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone7);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((-3L), dateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+01:00" + "'", str8.equals("+01:00"));
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(gJChronology12);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
        org.joda.time.LocalDate localDate10 = localDate6.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = localDate6.toDateTimeAtMidnight();
        org.joda.time.DateTime dateTime12 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        boolean boolean14 = dateTime12.isSupported(dateTimeFieldType13);
        org.joda.time.DateTime dateTime16 = dateTime12.plus((-60526368422000L));
        boolean boolean18 = dateTime12.isEqual((long) 10);
        org.joda.time.DateTime dateTime20 = dateTime12.minusMonths(0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("LimitChronology[JulianChronology[America/Los_Angeles], NoLimit, NoLimit]", "2035-06-02", 100, (int) (byte) 10);
        int int27 = fixedDateTimeZone25.getOffsetFromLocal(0L);
        java.lang.String str29 = fixedDateTimeZone25.getNameKey((long) 24);
        org.joda.time.DateTime dateTime30 = dateTime12.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 100 + "'", int27 == 100);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2035-06-02" + "'", str29.equals("2035-06-02"));
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        boolean boolean3 = julianChronology1.equals((java.lang.Object) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology5, readableDateTime6, readableDateTime7);
        org.joda.time.DurationField durationField9 = limitChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField10 = limitChronology8.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        long long14 = delegatedDateTimeField11.add((long) (byte) 1, (long) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField15.getAsText(0L, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipDateTimeField15.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField15, (-1));
        long long24 = offsetDateTimeField21.add((long) (-25200000), 21);
        org.joda.time.DurationField durationField25 = offsetDateTimeField21.getLeapDurationField();
        long long27 = offsetDateTimeField21.roundHalfCeiling((-62L));
        int int28 = offsetDateTimeField21.getOffset();
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((java.lang.Object) (-56803680421999L));
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(0L);
        int[] intArray34 = localDate33.getValues();
        java.util.Locale locale36 = null;
        try {
            int[] intArray37 = offsetDateTimeField21.set((org.joda.time.ReadablePartial) localDate30, 31, intArray34, "GregorianChronology[UTC]", locale36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[UTC]\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31557600000001L + "'", long14 == 31557600000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 66270934800000L + "'", long24 == 66270934800000L);
        org.junit.Assert.assertNull(durationField25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 979426800000L + "'", long27 == 979426800000L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(intArray34);
    }

//    @Test
//    public void test09() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test09");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
//        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
//        org.joda.time.LocalDate localDate10 = localDate6.plusMonths((int) (short) -1);
//        int int11 = localDate10.getEra();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.LocalDate localDate13 = localDate10.minus(readablePeriod12);
//        int int14 = localDate10.getWeekOfWeekyear();
//        org.joda.time.DurationFieldType durationFieldType15 = null;
//        boolean boolean16 = localDate10.isSupported(durationFieldType15);
//        java.lang.Object obj17 = null;
//        boolean boolean18 = localDate10.equals(obj17);
//        org.joda.time.LocalDate.Property property19 = localDate10.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 40 + "'", int14 == 40);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(property19);
//    }

//    @Test
//    public void test10() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test10");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
//        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
//        org.joda.time.LocalDate localDate10 = localDate6.minusDays((int) (byte) 100);
//        org.joda.time.DateTime dateTime11 = localDate6.toDateTimeAtMidnight();
//        org.joda.time.DateTime dateTime13 = dateTime11.plusHours(0);
//        org.joda.time.DateTime dateTime15 = dateTime11.minusMinutes((int) (short) 0);
//        java.util.Locale locale16 = null;
//        java.util.Calendar calendar17 = dateTime15.toCalendar(locale16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime.Property property19 = dateTime15.hourOfDay();
//        long long20 = property19.remainder();
//        java.lang.String str21 = property19.getAsString();
//        org.joda.time.DateTime dateTime23 = property19.addWrapFieldToCopy((int) (short) 100);
//        org.joda.time.DateTime dateTime25 = dateTime23.withMillisOfSecond(31);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(calendar17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1573686000000L + "'", long18 == 1573686000000L);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

//    @Test
//    public void test11() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test11");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(31557600000001L, locale3);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(iSOChronology5);
//    }

//    @Test
//    public void test12() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test12");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
//        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
//        org.joda.time.LocalDate localDate10 = localDate6.minusDays((int) (byte) 100);
//        org.joda.time.DateTime dateTime11 = localDate6.toDateTimeAtMidnight();
//        org.joda.time.LocalDate.Property property12 = localDate6.weekyear();
//        long long13 = property12.remainder();
//        org.joda.time.LocalDate localDate14 = property12.getLocalDate();
//        org.joda.time.LocalDate localDate15 = property12.roundHalfFloorCopy();
//        org.joda.time.LocalDate localDate17 = localDate15.withMonthOfYear((int) (byte) 1);
//        org.joda.time.LocalDate.Property property18 = localDate15.dayOfYear();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 26265600000L + "'", long13 == 26265600000L);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(property18);
//    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.Chronology chronology8 = limitChronology4.withZone(dateTimeZone6);
        java.lang.String str9 = limitChronology4.toString();
        long long13 = limitChronology4.add((long) (short) -1, 0L, 10);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology15, readableDateTime16, readableDateTime17);
        org.joda.time.DurationField durationField19 = limitChronology18.centuries();
        org.joda.time.DateTime dateTime20 = limitChronology18.getLowerLimit();
        org.joda.time.DurationField durationField21 = limitChronology18.weeks();
        org.joda.time.DurationField durationField22 = limitChronology18.centuries();
        boolean boolean23 = limitChronology4.equals((java.lang.Object) durationField22);
        long long26 = durationField22.subtract((long) (-25200000), 0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+01:00" + "'", str7.equals("+01:00"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LimitChronology[JulianChronology[+01:00], NoLimit, NoLimit]" + "'", str9.equals("LimitChronology[JulianChronology[+01:00], NoLimit, NoLimit]"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNull(dateTime20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-25200000L) + "'", long26 == (-25200000L));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str1 = gJChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.Chronology chronology6 = gJChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        java.lang.String str9 = dateTimeZone8.getID();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology11 = gJChronology0.withZone(dateTimeZone8);
        org.joda.time.Instant instant12 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+01:00" + "'", str4.equals("+01:00"));
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+01:00" + "'", str9.equals("+01:00"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
        org.joda.time.LocalDate localDate10 = localDate6.plusMonths((int) (short) -1);
        int int11 = localDate10.getEra();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.LocalDate localDate13 = localDate10.minus(readablePeriod12);
        int[] intArray14 = localDate10.getValues();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateMidnight dateMidnight16 = localDate10.toDateMidnight(dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate10.withDayOfYear(10);
        int int19 = localDate10.getYear();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        boolean boolean3 = julianChronology1.equals((java.lang.Object) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology5, readableDateTime6, readableDateTime7);
        org.joda.time.DurationField durationField9 = limitChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField10 = limitChronology8.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        long long14 = delegatedDateTimeField11.add((long) (byte) 1, (long) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField15.getAsText(0L, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipDateTimeField15.getType();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = julianChronology21.clockhourOfDay();
        org.joda.time.DurationField durationField23 = julianChronology21.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        try {
            java.lang.String str26 = unsupportedDateTimeField24.getAsText(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31557600000001L + "'", long14 == 31557600000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
        org.joda.time.LocalDate localDate10 = localDate6.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = localDate6.toDateTimeAtMidnight();
        org.joda.time.DateTime dateTime12 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        boolean boolean14 = dateTime12.isSupported(dateTimeFieldType13);
        org.joda.time.DateTime dateTime16 = dateTime12.plus((-60526368422000L));
        boolean boolean18 = dateTime12.isEqual((long) 10);
        org.joda.time.DateTime dateTime20 = dateTime12.minusMonths(0);
        java.util.Locale locale21 = null;
        java.util.Calendar calendar22 = dateTime20.toCalendar(locale21);
        org.joda.time.LocalDate localDate23 = org.joda.time.LocalDate.fromCalendarFields(calendar22);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(calendar22);
        org.junit.Assert.assertNotNull(localDate23);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
        org.joda.time.LocalDate localDate10 = localDate6.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = localDate6.toDateTimeAtMidnight();
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime dateTime13 = property12.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime dateTime16 = dateTime15.toDateTimeISO();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("LimitChronology[JulianChronology[America/Los_Angeles], NoLimit, NoLimit]", "2035-06-02", 100, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 24);
        long long10 = fixedDateTimeZone4.nextTransition(2440587L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.ReadableInstant readableInstant12 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant12, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 15");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2035-06-02" + "'", str8.equals("2035-06-02"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2440587L + "'", long10 == 2440587L);
        org.junit.Assert.assertNotNull(buddhistChronology11);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 3018, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.Chronology chronology8 = limitChronology4.withZone(dateTimeZone6);
        java.lang.String str9 = limitChronology4.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology11, readableDateTime12, readableDateTime13);
        org.joda.time.DurationField durationField15 = limitChronology14.centuries();
        org.joda.time.DateTimeField dateTimeField16 = limitChronology14.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
        java.util.Locale locale19 = null;
        java.lang.String str20 = delegatedDateTimeField17.getAsText(1L, locale19);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField17, (int) (short) 100);
        int int24 = skipUndoDateTimeField22.get(0L);
        long long27 = skipUndoDateTimeField22.set(31557600000001L, 3);
        java.lang.String str28 = skipUndoDateTimeField22.toString();
        long long30 = skipUndoDateTimeField22.roundHalfFloor((long) 0);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipUndoDateTimeField22, 153, 20, 3019);
        int int36 = skipUndoDateTimeField22.get((long) 20);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+01:00" + "'", str7.equals("+01:00"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LimitChronology[JulianChronology[+01:00], NoLimit, NoLimit]" + "'", str9.equals("LimitChronology[JulianChronology[+01:00], NoLimit, NoLimit]"));
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(limitChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "20" + "'", str20.equals("20"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 21 + "'", int24 == 21);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-56803679999999L) + "'", long27 == (-56803679999999L));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str28.equals("DateTimeField[centuryOfEra]"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 979426800000L + "'", long30 == 979426800000L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 21 + "'", int36 == 21);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
        org.joda.time.LocalDate localDate10 = localDate6.minusDays((int) (byte) 100);
        int int11 = localDate6.getMonthOfYear();
        org.joda.time.LocalDate.Property property12 = localDate6.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property12.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, (java.lang.Number) 6, (java.lang.Number) 10.0d, (java.lang.Number) (short) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "0");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "19");
        java.lang.Number number22 = illegalFieldValueException21.getLowerBound();
        java.lang.String str23 = illegalFieldValueException21.toString();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"19\" for weekyear is not supported" + "'", str23.equals("org.joda.time.IllegalFieldValueException: Value \"19\" for weekyear is not supported"));
    }

//    @Test
//    public void test25() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test25");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
//        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
//        org.joda.time.LocalDate localDate10 = localDate6.minusDays((int) (byte) 100);
//        org.joda.time.DateTime dateTime11 = localDate6.toDateTimeAtMidnight();
//        org.joda.time.DateTime.Property property12 = dateTime11.millisOfDay();
//        java.util.Date date13 = dateTime11.toDate();
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime11.withDurationAdded(readableDuration14, (int) (byte) -1);
//        org.joda.time.Instant instant17 = dateTime16.toInstant();
//        boolean boolean19 = instant17.isEqual(0L);
//        long long20 = instant17.getMillis();
//        org.joda.time.ReadableInstant readableInstant21 = null;
//        boolean boolean22 = instant17.isBefore(readableInstant21);
//        org.joda.time.Chronology chronology23 = instant17.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime24 = instant17.toMutableDateTime();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(instant17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1573686000000L + "'", long20 == 1573686000000L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("LimitChronology[JulianChronology[America/Los_Angeles], NoLimit, NoLimit]", "2035-06-02", 100, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) (byte) -1);
        int int10 = fixedDateTimeZone4.getOffset(34713360000000L);
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime11);
        long long14 = fixedDateTimeZone4.nextTransition(33134961600100L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2035-06-02" + "'", str8.equals("2035-06-02"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 33134961600100L + "'", long14 == 33134961600100L);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(12873600000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440736.5d + "'", double1 == 2440736.5d);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter6.withZone(dateTimeZone8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone8.getName((long) 22, locale11);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(0, (int) 'a', (-2922729), (int) 'a', 0, 0, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+01:00" + "'", str12.equals("+01:00"));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
        org.joda.time.LocalDate localDate10 = localDate6.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = localDate6.toDateTimeAtMidnight();
        org.joda.time.DateTime dateTime12 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        boolean boolean14 = dateTime12.isSupported(dateTimeFieldType13);
        org.joda.time.DateTime dateTime16 = dateTime12.plus((-60526368422000L));
        boolean boolean18 = dateTime12.isEqual((long) 10);
        org.joda.time.DateTime dateTime20 = dateTime12.minusMonths(0);
        org.joda.time.DateTime dateTime21 = dateTime12.withTimeAtStartOfDay();
        int int22 = dateTime21.getSecondOfDay();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
        org.joda.time.LocalDate localDate10 = localDate6.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = localDate6.toDateTimeAtMidnight();
        org.joda.time.DateTime dateTime13 = dateTime11.plusHours(0);
        org.joda.time.DateTime dateTime15 = dateTime11.minusMinutes((int) (short) 0);
        org.joda.time.DateTime dateTime17 = dateTime15.plusMillis((int) 'a');
        org.joda.time.DateTime.Property property18 = dateTime17.dayOfYear();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        java.lang.String str1 = copticChronology0.toString();
        boolean boolean3 = copticChronology0.equals((java.lang.Object) 18934560000000L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[+01:00]" + "'", str1.equals("CopticChronology[+01:00]"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test32() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test32");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
//        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
//        org.joda.time.LocalDate localDate10 = localDate6.minusDays((int) (byte) 100);
//        org.joda.time.DateTime dateTime11 = localDate6.toDateTimeAtMidnight();
//        org.joda.time.LocalDate.Property property12 = localDate6.weekyear();
//        int int13 = localDate6.getDayOfYear();
//        org.joda.time.LocalTime localTime14 = null;
//        org.joda.time.DateTime dateTime15 = localDate6.toDateTime(localTime14);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 305 + "'", int13 == 305);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test33() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test33");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
//        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
//        org.joda.time.LocalDate localDate10 = localDate6.minusDays((int) (byte) 100);
//        org.joda.time.DateTime dateTime11 = localDate6.toDateTimeAtMidnight();
//        org.joda.time.DateTime.Property property12 = dateTime11.millisOfDay();
//        int int13 = property12.getMinimumValue();
//        java.util.Locale locale15 = null;
//        org.joda.time.DateTime dateTime16 = property12.setCopy("2", locale15);
//        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime.Property property18 = dateTime16.monthOfYear();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1573686000002L + "'", long17 == 1573686000002L);
//        org.junit.Assert.assertNotNull(property18);
//    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-3600000L), 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10800000L) + "'", long2 == (-10800000L));
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        boolean boolean3 = julianChronology1.equals((java.lang.Object) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology5, readableDateTime6, readableDateTime7);
        org.joda.time.DurationField durationField9 = limitChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField10 = limitChronology8.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        long long14 = delegatedDateTimeField11.add((long) (byte) 1, (long) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField15.getAsText(0L, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipDateTimeField15.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField15, (-1));
        long long24 = offsetDateTimeField21.add((long) (-25200000), 21);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int int26 = offsetDateTimeField21.getMinimumValue(readablePartial25);
        int int27 = offsetDateTimeField21.getMinimumValue();
        int int29 = offsetDateTimeField21.getLeapAmount((long) (byte) 0);
        long long31 = offsetDateTimeField21.remainder((long) ' ');
        int int34 = offsetDateTimeField21.getDifference(0L, (long) 124);
        long long37 = offsetDateTimeField21.addWrapField((-10800000L), 0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31557600000001L + "'", long14 == 31557600000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 66270934800000L + "'", long24 == 66270934800000L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 3600032L + "'", long31 == 3600032L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-10800000L) + "'", long37 == (-10800000L));
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DurationField durationField8 = limitChronology7.centuries();
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology7);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate11 = localDate9.minus(readablePeriod10);
        org.joda.time.LocalDate localDate13 = localDate9.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime14 = localDate9.toDateTimeAtMidnight();
        org.joda.time.DateTime.Property property15 = dateTime14.millisOfDay();
        int int16 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, 0L, 3);
        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.clockhourOfHalfday();
        try {
            long long25 = gJChronology19.getDateTimeMillis(2020, (int) (byte) 100, (int) '4', (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+01:00" + "'", str2.equals("+01:00"));
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3600000 + "'", int16 == 3600000);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

//    @Test
//    public void test37() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test37");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
//        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
//        org.joda.time.LocalDate localDate10 = localDate6.plusMonths((int) (short) -1);
//        org.joda.time.LocalDate.Property property11 = localDate10.dayOfMonth();
//        java.lang.String str12 = property11.getAsText();
//        org.joda.time.LocalDate localDate14 = property11.addWrapFieldToCopy((int) (short) -1);
//        org.joda.time.LocalDate localDate15 = property11.roundHalfEvenCopy();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate15);
//    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial2 = partial0.plus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.Partial partial5 = partial0.withPeriodAdded(readablePeriod3, 1);
        java.lang.String str6 = partial5.toStringList();
        org.junit.Assert.assertNotNull(partial2);
        org.junit.Assert.assertNotNull(partial5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        long long10 = delegatedDateTimeField7.add((long) (byte) 1, (long) (byte) 10);
        int int11 = delegatedDateTimeField7.getMaximumValue();
        java.lang.String str13 = delegatedDateTimeField7.getAsShortText((long) 57307);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 31557600000001L + "'", long10 == 31557600000001L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2922730 + "'", int11 == 2922730);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "20" + "'", str13.equals("20"));
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        boolean boolean3 = julianChronology1.equals((java.lang.Object) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology5, readableDateTime6, readableDateTime7);
        org.joda.time.DurationField durationField9 = limitChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField10 = limitChronology8.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        long long14 = delegatedDateTimeField11.add((long) (byte) 1, (long) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField15.getAsText(0L, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipDateTimeField15.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField15, (-1));
        long long24 = offsetDateTimeField21.add((long) (-25200000), 21);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int int26 = offsetDateTimeField21.getMinimumValue(readablePartial25);
        int int27 = offsetDateTimeField21.getMinimumValue();
        int int29 = offsetDateTimeField21.getLeapAmount((long) (byte) 0);
        long long31 = offsetDateTimeField21.remainder((long) ' ');
        long long33 = offsetDateTimeField21.roundHalfFloor((long) 10);
        org.joda.time.DurationField durationField34 = offsetDateTimeField21.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31557600000001L + "'", long14 == 31557600000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 66270934800000L + "'", long24 == 66270934800000L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 3600032L + "'", long31 == 3600032L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 979426800000L + "'", long33 == 979426800000L);
        org.junit.Assert.assertNull(durationField34);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.Chronology chronology8 = julianChronology1.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology1.weekOfWeekyear();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology1);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+01:00" + "'", str7.equals("+01:00"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("3019-W22-3");
        org.joda.time.Instant instant3 = instant1.withMillis(1560553200002L);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
    }

//    @Test
//    public void test43() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test43");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
//        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
//        org.joda.time.LocalDate.Property property9 = localDate8.dayOfMonth();
//        org.joda.time.LocalDate localDate10 = property9.withMinimumValue();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(0L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        int int14 = localDate12.indexOf(dateTimeFieldType13);
//        org.joda.time.DateTime dateTime15 = localDate12.toDateTimeAtMidnight();
//        int int16 = property9.compareTo((org.joda.time.ReadablePartial) localDate12);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forID("America/Los_Angeles");
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = localDate12.toDateTimeAtStartOfDay(dateTimeZone18);
//        org.joda.time.DateTime dateTime22 = dateTime20.minusMillis((int) 'a');
//        org.joda.time.DateTime.Property property23 = dateTime20.monthOfYear();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//    }

//    @Test
//    public void test44() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test44");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
//        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
//        org.joda.time.LocalDate localDate10 = localDate6.minusDays((int) (byte) 100);
//        org.joda.time.DateTime dateTime11 = localDate6.toDateTimeAtMidnight();
//        org.joda.time.LocalDate.Property property12 = localDate6.weekyear();
//        long long13 = property12.remainder();
//        org.joda.time.LocalDate localDate14 = property12.getLocalDate();
//        org.joda.time.LocalDate localDate16 = localDate14.withYearOfCentury((int) '#');
//        org.joda.time.LocalDate localDate18 = localDate16.withYear((int) (byte) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = null;
//        java.lang.String str20 = localDate16.toString(dateTimeFormatter19);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray21 = localDate16.getFieldTypes();
//        org.joda.time.LocalDate localDate23 = localDate16.withCenturyOfEra(19);
//        int int24 = localDate23.getYearOfEra();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 26265600000L + "'", long13 == 26265600000L);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2035-11-01" + "'", str20.equals("2035-11-01"));
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray21);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1835 + "'", int24 == 1835);
//    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        boolean boolean3 = julianChronology1.equals((java.lang.Object) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology5, readableDateTime6, readableDateTime7);
        org.joda.time.DurationField durationField9 = limitChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField10 = limitChronology8.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        long long14 = delegatedDateTimeField11.add((long) (byte) 1, (long) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField15.getAsText(0L, locale17);
        java.util.Locale locale19 = null;
        int int20 = skipDateTimeField15.getMaximumTextLength(locale19);
        int int22 = skipDateTimeField15.getMaximumValue(1578988800000L);
        int int24 = skipDateTimeField15.get(32537059200000L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31557600000001L + "'", long14 == 31557600000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 7 + "'", int20 == 7);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2922730 + "'", int22 == 2922730);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 31 + "'", int24 == 31);
    }

//    @Test
//    public void test46() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test46");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
//        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
//        org.joda.time.LocalDate.Property property9 = localDate8.dayOfMonth();
//        org.joda.time.LocalDate localDate10 = property9.withMinimumValue();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(0L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        int int14 = localDate12.indexOf(dateTimeFieldType13);
//        org.joda.time.DateTime dateTime15 = localDate12.toDateTimeAtMidnight();
//        int int16 = property9.compareTo((org.joda.time.ReadablePartial) localDate12);
//        int int17 = localDate12.size();
//        org.joda.time.LocalDate.Property property18 = localDate12.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateMidnight dateMidnight21 = localDate12.toDateMidnight(dateTimeZone19);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateMidnight21);
//    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gJChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        boolean boolean3 = julianChronology1.equals((java.lang.Object) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology5, readableDateTime6, readableDateTime7);
        org.joda.time.DurationField durationField9 = limitChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField10 = limitChronology8.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        long long14 = delegatedDateTimeField11.add((long) (byte) 1, (long) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField15.getAsText(0L, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipDateTimeField15.getType();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = julianChronology21.clockhourOfDay();
        org.joda.time.DurationField durationField23 = julianChronology21.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        java.util.Locale locale27 = null;
        try {
            long long28 = unsupportedDateTimeField24.set(200L, "+00:00:00.100", locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31557600000001L + "'", long14 == 31557600000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology3, readableDateTime4, readableDateTime5);
        org.joda.time.DurationField durationField7 = limitChronology6.centuries();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology6);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate10 = localDate8.minus(readablePeriod9);
        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime13 = localDate8.toDateTimeAtMidnight();
        org.joda.time.DateTime dateTime14 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone15 = dateTime13.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter0.withZone(dateTimeZone15);
        try {
            org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
    }

//    @Test
//    public void test50() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test50");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("LimitChronology[JulianChronology[America/Los_Angeles], NoLimit, NoLimit]", "2035-06-02", 100, (int) (byte) 10);
//        int int6 = fixedDateTimeZone4.getOffsetFromLocal(0L);
//        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) (byte) -1);
//        java.lang.String str10 = fixedDateTimeZone4.getNameKey(63L);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
//        org.joda.time.ReadableDateTime readableDateTime13 = null;
//        org.joda.time.ReadableDateTime readableDateTime14 = null;
//        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology12, readableDateTime13, readableDateTime14);
//        org.joda.time.DurationField durationField16 = limitChronology15.centuries();
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology15);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.LocalDate localDate19 = localDate17.minus(readablePeriod18);
//        org.joda.time.LocalDate localDate21 = localDate17.plusMonths((int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone23.getName(31557600000001L, locale25);
//        org.joda.time.DateTime dateTime27 = localDate21.toDateTimeAtStartOfDay(dateTimeZone23);
//        boolean boolean28 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2035-06-02" + "'", str8.equals("2035-06-02"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2035-06-02" + "'", str10.equals("2035-06-02"));
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(limitChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Coordinated Universal Time" + "'", str26.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
        org.joda.time.LocalDate localDate10 = localDate6.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = localDate6.toDateTimeAtMidnight();
        org.joda.time.DateTime dateTime12 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology14, readableDateTime15, readableDateTime16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        java.lang.String str20 = dateTimeZone19.getID();
        org.joda.time.Chronology chronology21 = julianChronology14.withZone(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField22 = julianChronology14.hourOfDay();
        org.joda.time.DateTime dateTime23 = dateTime11.toDateTime((org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTime.Property property24 = dateTime23.minuteOfHour();
        int int25 = dateTime23.getYear();
        org.joda.time.DateTime.Property property26 = dateTime23.millisOfSecond();
        org.joda.time.DateTime dateTime28 = dateTime23.minusWeeks(12020);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+01:00" + "'", str20.equals("+01:00"));
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        java.util.Locale locale9 = null;
        java.lang.String str10 = delegatedDateTimeField7.getAsText(1L, locale9);
        int int12 = delegatedDateTimeField7.getLeapAmount(0L);
        java.lang.String str14 = delegatedDateTimeField7.getAsShortText((long) (byte) 1);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField7.getAsShortText(10L, locale16);
        java.lang.String str19 = delegatedDateTimeField7.getAsText(37869120000153L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "20" + "'", str10.equals("20"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "20" + "'", str14.equals("20"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "20" + "'", str17.equals("20"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "32" + "'", str19.equals("32"));
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        boolean boolean3 = julianChronology1.equals((java.lang.Object) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology5, readableDateTime6, readableDateTime7);
        org.joda.time.DurationField durationField9 = limitChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField10 = limitChronology8.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        long long14 = delegatedDateTimeField11.add((long) (byte) 1, (long) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        long long17 = skipDateTimeField15.roundCeiling(0L);
        java.lang.String str19 = skipDateTimeField15.getAsShortText((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.ReadableDateTime readableDateTime22 = null;
        org.joda.time.ReadableDateTime readableDateTime23 = null;
        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology21, readableDateTime22, readableDateTime23);
        org.joda.time.DurationField durationField25 = limitChronology24.centuries();
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology24);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.LocalDate localDate28 = localDate26.minus(readablePeriod27);
        org.joda.time.LocalDate localDate30 = localDate26.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime31 = localDate26.toDateTimeAtMidnight();
        org.joda.time.LocalDate.Property property32 = localDate26.weekyear();
        org.joda.time.LocalDate.Property property33 = localDate26.dayOfYear();
        org.joda.time.DateTimeField dateTimeField34 = property33.getField();
        org.joda.time.LocalDate localDate36 = property33.addToCopy(0);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone38);
        org.joda.time.ReadableDateTime readableDateTime40 = null;
        org.joda.time.ReadableDateTime readableDateTime41 = null;
        org.joda.time.chrono.LimitChronology limitChronology42 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology39, readableDateTime40, readableDateTime41);
        org.joda.time.DurationField durationField43 = limitChronology42.centuries();
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology42);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.LocalDate localDate46 = localDate44.minus(readablePeriod45);
        org.joda.time.LocalDate localDate48 = localDate44.plusMonths((int) (short) -1);
        int int49 = localDate48.getEra();
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.LocalDate localDate51 = localDate48.minus(readablePeriod50);
        int[] intArray52 = localDate48.getValues();
        try {
            int[] intArray54 = skipDateTimeField15.addWrapPartial((org.joda.time.ReadablePartial) localDate36, 3600000, intArray52, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3600000");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31557600000001L + "'", long14 == 31557600000001L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 979426800000L + "'", long17 == 979426800000L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "20" + "'", str19.equals("20"));
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(limitChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertNotNull(limitChronology42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(intArray52);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        boolean boolean3 = julianChronology1.equals((java.lang.Object) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology5, readableDateTime6, readableDateTime7);
        org.joda.time.DurationField durationField9 = limitChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField10 = limitChronology8.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        long long14 = delegatedDateTimeField11.add((long) (byte) 1, (long) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField15.getAsText(0L, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipDateTimeField15.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField15, (-1));
        long long24 = offsetDateTimeField21.add((long) (-25200000), 21);
        int int27 = offsetDateTimeField21.getDifference((long) (short) 0, (long) 153);
        long long29 = offsetDateTimeField21.roundHalfEven(0L);
        org.joda.time.DurationField durationField30 = offsetDateTimeField21.getRangeDurationField();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31557600000001L + "'", long14 == 31557600000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 66270934800000L + "'", long24 == 66270934800000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 979426800000L + "'", long29 == 979426800000L);
        org.junit.Assert.assertNotNull(durationField30);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial2 = partial0.plus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.Partial partial4 = partial2.minus(readablePeriod3);
        try {
            int int6 = partial4.getValue(8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(partial2);
        org.junit.Assert.assertNotNull(partial4);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = julianChronology1.millis();
        long long8 = durationField5.subtract((long) (-2922729), 2019);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2924748L) + "'", long8 == (-2924748L));
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
        org.joda.time.DateTime dateTime6 = limitChronology4.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField7 = limitChronology4.millisOfDay();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        java.lang.String str11 = dateTimeZone10.getID();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) limitChronology4, readableDateTime8, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTime((org.joda.time.Chronology) copticChronology14);
        org.joda.time.DateTime dateTime17 = dateTime12.withYear(251980);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime19 = dateTime12.plus(readableDuration18);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+01:00" + "'", str11.equals("+01:00"));
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology3, readableDateTime4, readableDateTime5);
        org.joda.time.DurationField durationField7 = limitChronology6.centuries();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology6);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate10 = localDate8.minus(readablePeriod9);
        org.joda.time.LocalDate localDate12 = localDate8.minusDays((int) (byte) 100);
        int int13 = localDate8.getMonthOfYear();
        org.joda.time.LocalDate.Property property14 = localDate8.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, (java.lang.Number) 6, (java.lang.Number) 10.0d, (java.lang.Number) (short) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, "0");
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, "19");
        boolean boolean24 = localDate1.isSupported(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

//    @Test
//    public void test60() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test60");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forID("America/Los_Angeles");
//        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj0, dateTimeZone5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
//        org.joda.time.ReadableDateTime readableDateTime10 = null;
//        org.joda.time.ReadableDateTime readableDateTime11 = null;
//        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology9, readableDateTime10, readableDateTime11);
//        org.joda.time.DurationField durationField13 = limitChronology12.centuries();
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology12);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.LocalDate localDate16 = localDate14.minus(readablePeriod15);
//        org.joda.time.LocalDate localDate18 = localDate14.minusDays((int) (byte) 100);
//        org.joda.time.DateTime dateTime19 = localDate14.toDateTimeAtMidnight();
//        org.joda.time.DateTime.Property property20 = dateTime19.millisOfDay();
//        java.util.Date date21 = dateTime19.toDate();
//        org.joda.time.DateTime dateTime22 = dateTime19.withLaterOffsetAtOverlap();
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime19.plus(readablePeriod23);
//        org.joda.time.ReadableDuration readableDuration25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.minus(readableDuration25);
//        boolean boolean28 = dateTime24.isBefore((long) (short) 1);
//        java.lang.String str29 = dateTimeFormatter7.print((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime24, (int) (short) 1);
//        org.joda.time.Instant instant32 = gJChronology31.getGregorianCutover();
//        try {
//            long long40 = gJChronology31.getDateTimeMillis((-11), 0, 0, 14, 2922729, 44, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922729 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(julianChronology9);
//        org.junit.Assert.assertNotNull(limitChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019-W44-4" + "'", str29.equals("2019-W44-4"));
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(instant32);
//    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        boolean boolean3 = julianChronology1.equals((java.lang.Object) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology5, readableDateTime6, readableDateTime7);
        org.joda.time.DurationField durationField9 = limitChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField10 = limitChronology8.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        long long14 = delegatedDateTimeField11.add((long) (byte) 1, (long) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField15.getAsText(0L, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipDateTimeField15.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField15, (-1));
        int int23 = offsetDateTimeField21.getLeapAmount(0L);
        org.joda.time.Partial partial24 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.Partial partial26 = partial24.plus(readablePeriod25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.Partial partial28 = partial26.minus(readablePeriod27);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray29 = partial28.getFieldTypes();
        int int30 = offsetDateTimeField21.getMinimumValue((org.joda.time.ReadablePartial) partial28);
        long long32 = offsetDateTimeField21.roundCeiling((long) 2922730);
        java.lang.String str34 = offsetDateTimeField21.getAsShortText(2077502822000L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31557600000001L + "'", long14 == 31557600000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(partial26);
        org.junit.Assert.assertNotNull(partial28);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 979426800000L + "'", long32 == 979426800000L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "20" + "'", str34.equals("20"));
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.lang.Integer int2 = dateTimeFormatter1.getPivotYear();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTimeFormatter1.parseMutableDateTime("2019-W44-4");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("20", dateTimeFormatter1);
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withLocale(locale6);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(int2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
        org.joda.time.LocalDate localDate10 = localDate6.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = localDate6.toDateTimeAtMidnight();
        org.joda.time.LocalDate.Property property12 = localDate6.weekyear();
        org.joda.time.LocalDate.Property property13 = localDate6.dayOfMonth();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("LimitChronology[JulianChronology[America/Los_Angeles], NoLimit, NoLimit]", "2035-06-02", 100, (int) (byte) 10);
        int int20 = fixedDateTimeZone18.getOffsetFromLocal(0L);
        boolean boolean21 = fixedDateTimeZone18.isFixed();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours(20);
        long long25 = fixedDateTimeZone18.getMillisKeepLocal(dateTimeZone23, 33136588800000L);
        int int27 = fixedDateTimeZone18.getStandardOffset(0L);
        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        int int29 = localDate6.compareTo((org.joda.time.ReadablePartial) localDate28);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 33136516800100L + "'", long25 == 33136516800100L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial2 = partial0.plus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.Partial partial4 = partial2.minus(readablePeriod3);
        java.lang.String str5 = partial2.toString();
        java.lang.String str6 = partial2.toStringList();
        org.junit.Assert.assertNotNull(partial2);
        org.junit.Assert.assertNotNull(partial4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
    }

//    @Test
//    public void test65() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test65");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        java.lang.String str7 = dateTimeZone6.getID();
//        org.joda.time.Chronology chronology8 = julianChronology1.withZone(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField9 = julianChronology1.year();
//        org.joda.time.DateTimeField dateTimeField10 = julianChronology1.halfdayOfDay();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
//        org.joda.time.ReadableDateTime readableDateTime13 = null;
//        org.joda.time.ReadableDateTime readableDateTime14 = null;
//        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology12, readableDateTime13, readableDateTime14);
//        org.joda.time.DurationField durationField16 = limitChronology15.centuries();
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology15);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.LocalDate localDate19 = localDate17.minus(readablePeriod18);
//        org.joda.time.LocalDate localDate21 = localDate17.plusMonths((int) (short) -1);
//        int int22 = localDate21.getEra();
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.LocalDate localDate24 = localDate21.minus(readablePeriod23);
//        int[] intArray25 = localDate21.getValues();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateMidnight dateMidnight27 = localDate21.toDateMidnight(dateTimeZone26);
//        org.joda.time.DateTime dateTime28 = localDate21.toDateTimeAtCurrentTime();
//        int[] intArray30 = julianChronology1.get((org.joda.time.ReadablePartial) localDate21, (long) (short) 100);
//        org.joda.time.LocalDate localDate32 = localDate21.minusYears(3019);
//        int int33 = localDate21.getDayOfWeek();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+01:00" + "'", str7.equals("+01:00"));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(limitChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertNotNull(dateMidnight27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        boolean boolean3 = julianChronology1.equals((java.lang.Object) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology5, readableDateTime6, readableDateTime7);
        org.joda.time.DurationField durationField9 = limitChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField10 = limitChronology8.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        long long14 = delegatedDateTimeField11.add((long) (byte) 1, (long) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField15.getAsText(0L, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipDateTimeField15.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField15, (-1));
        long long24 = offsetDateTimeField21.add((long) (-25200000), 21);
        long long27 = offsetDateTimeField21.add((long) 22, (-97L));
        java.lang.String str28 = offsetDateTimeField21.getName();
        boolean boolean29 = offsetDateTimeField21.isLenient();
        try {
            long long32 = offsetDateTimeField21.add(33118182000000L, 979426800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 97942680000000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31557600000001L + "'", long14 == 31557600000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 66270934800000L + "'", long24 == 66270934800000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-306108719999978L) + "'", long27 == (-306108719999978L));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "centuryOfEra" + "'", str28.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test67");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, readableDateTime2, readableDateTime3);
        org.joda.time.DurationField durationField5 = limitChronology4.centuries();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology4);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.Partial partial9 = partial7.minus(readablePeriod8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology11, readableDateTime12, readableDateTime13);
        org.joda.time.DurationField durationField15 = limitChronology14.centuries();
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((org.joda.time.Chronology) limitChronology14);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate16.minus(readablePeriod17);
        org.joda.time.LocalDate localDate20 = localDate16.minusDays((int) (byte) 100);
        int int21 = localDate16.getMonthOfYear();
        org.joda.time.LocalDate.Property property22 = localDate16.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 6, (java.lang.Number) 10.0d, (java.lang.Number) (short) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, "0");
        try {
            org.joda.time.Partial.Property property30 = partial9.property(dateTimeFieldType23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(partial9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(limitChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test68");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        boolean boolean3 = julianChronology1.equals((java.lang.Object) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology5, readableDateTime6, readableDateTime7);
        org.joda.time.DurationField durationField9 = limitChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField10 = limitChronology8.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        long long14 = delegatedDateTimeField11.add((long) (byte) 1, (long) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField15.getAsText(0L, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipDateTimeField15.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField15, (-1));
        long long24 = offsetDateTimeField21.add((long) (-25200000), 21);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int int26 = offsetDateTimeField21.getMinimumValue(readablePartial25);
        int int27 = offsetDateTimeField21.getMinimumValue();
        java.util.Locale locale28 = null;
        int int29 = offsetDateTimeField21.getMaximumTextLength(locale28);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, 292272992);
        boolean boolean32 = offsetDateTimeField21.isSupported();
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField21.getAsText((long) 14, locale34);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31557600000001L + "'", long14 == 31557600000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 66270934800000L + "'", long24 == 66270934800000L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 7 + "'", int29 == 7);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "19" + "'", str35.equals("19"));
    }
}

