import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) 0, periodType3, chronology5);
        try {
            org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) 100, chronology5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        org.joda.time.Period period13 = period5.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType14 = null;
        try {
            org.joda.time.Period period16 = period5.withField(durationFieldType14, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test004");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        try {
            long long10 = iSOChronology1.getDateTimeMillis((int) (short) 0, (int) (byte) 100, 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) '#', (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34L + "'", long2 == 34L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = new org.joda.time.DurationFieldType[] {};
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology2 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(10L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 34L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField6 = iSOChronology1.years();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField9 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType7, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-65L), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.era();
        org.joda.time.Chronology chronology7 = iSOChronology1.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-1L), 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period23 = new org.joda.time.Period((int) (byte) 100, (int) (short) 10, (int) 'a', (int) '4', (int) (short) 100, (int) '4', 0, (int) (byte) 1);
        boolean boolean24 = org.joda.time.field.FieldUtils.equals((java.lang.Object) str14, (java.lang.Object) (byte) 100);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT-0.097S" + "'", str14.equals("PT-0.097S"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test023");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560628303058L + "'", long1 == 1560628303058L);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1.0d), (java.lang.Number) (short) -1, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.withMillis((int) (short) 1);
        org.joda.time.Period period10 = period5.withMillis((int) (short) 1);
        int int11 = period5.getYears();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (byte) 10);
        try {
            int int3 = period1.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 100, (int) '4', (-1), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 100);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.weekyears();
//        try {
//            long long7 = gregorianChronology0.getDateTimeMillis(10, (int) (byte) 100, (int) (byte) 100, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str1.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField2);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(9L, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (-1), chronology3);
        org.joda.time.Period period6 = period4.withMonths((int) (short) 10);
        org.joda.time.Period period8 = period6.minusMonths((int) (short) 100);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 1, (int) (byte) 1, (int) 'a');
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test037");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.weekyears();
//        org.joda.time.ReadablePartial readablePartial3 = null;
//        try {
//            long long5 = gregorianChronology0.set(readablePartial3, (long) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str1.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField2);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.Period period0 = new org.joda.time.Period();
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.lang.Object obj0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) 0, periodType5, chronology7);
        org.joda.time.PeriodType periodType9 = periodType5.withYearsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType9);
        java.lang.String str11 = periodType9.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period13 = new org.joda.time.Period(obj0, periodType9, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DurationFieldType durationFieldType14 = null;
        try {
            org.joda.time.Period period16 = period13.withFieldAdded(durationFieldType14, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PeriodType[DayTime]" + "'", str11.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("-00:00:00.001", (int) (byte) 1, (int) '#', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for -00:00:00.001 must be in the range [35,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-65L));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            int[] intArray4 = gregorianChronology1.get(readablePartial2, (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (byte) 100, (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Days days7 = period5.toStandardDays();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period9 = period5.normalizedStandard(periodType8);
        int int10 = period9.getHours();
        try {
            org.joda.time.Period period12 = period9.minusMillis((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(days7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.lang.Object obj0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) 0, periodType5, chronology7);
        org.joda.time.PeriodType periodType9 = periodType5.withYearsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType9);
        java.lang.String str11 = periodType9.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period13 = new org.joda.time.Period(obj0, periodType9, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType15, (int) (byte) 0, 10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PeriodType[DayTime]" + "'", str11.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        org.joda.time.DurationFieldType[] durationFieldTypeArray1 = new org.joda.time.DurationFieldType[] { durationFieldType0 };
        try {
            org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.forFields(durationFieldTypeArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not contain null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        java.lang.Object obj13 = null;
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period12, obj13);
        java.lang.Class<?> wildcardClass15 = period12.getClass();
        int int16 = period12.getWeeks();
        int int17 = period12.getSeconds();
        org.joda.time.DurationFieldType durationFieldType18 = null;
        boolean boolean19 = period12.isSupported(durationFieldType18);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.Period period2 = new org.joda.time.Period((long) '4', (long) (-1));
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.Period period5 = period2.withField(durationFieldType3, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (-1), chronology3);
        org.joda.time.Period period6 = period4.withMonths((int) (short) 10);
        org.joda.time.Period period7 = period4.negated();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        org.joda.time.Period period13 = period5.normalizedStandard();
        int int14 = period5.getHours();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "PT-0.097S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("PeriodType[DayTime]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PeriodType[DayTime]\" is malformed at \"eriodType[DayTime]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract(0L, (long) (short) 1);
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) '4', 0, 0, 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "PT0.011S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 0, (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("LenientChronology[ISOChronology[-00:00:00.001]]", (int) 'a', 100, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for LenientChronology[ISOChronology[-00:00:00.001]] must be in the range [100,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long6 = cachedDateTimeZone4.previousTransition(34L);
        long long9 = cachedDateTimeZone4.adjustOffset((long) (byte) 100, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 34L + "'", long6 == 34L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            int[] intArray8 = iSOChronology5.get(readablePartial6, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) 32L, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType3, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, 0, 0, 0);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, (int) (short) 100, (int) (byte) 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [0,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (short) -1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.withYears((int) (byte) 0);
        org.joda.time.Period period6 = period2.plusDays((int) ' ');
        try {
            int int8 = period2.getValue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((-1));
        org.joda.time.Period period3 = period1.plusYears(10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) 0, periodType3, chronology5);
        org.joda.time.PeriodType periodType7 = periodType3.withWeeksRemoved();
        org.joda.time.Chronology chronology8 = null;
        try {
            org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) "", periodType7, chronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-115199968L));
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
//        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, 10L, chronology6);
//        int int8 = period7.getDays();
//        org.joda.time.Days days9 = period7.toStandardDays();
//        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.seconds();
//        org.joda.time.Period period11 = period7.normalizedStandard(periodType10);
//        int[] intArray14 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L, 34L);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField17 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField15, dateTimeFieldType16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str1.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(days9);
//        org.junit.Assert.assertNotNull(periodType10);
//        org.junit.Assert.assertNotNull(period11);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        boolean boolean3 = periodType1.isSupported(durationFieldType2);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.withYears((int) (byte) 0);
        org.joda.time.Period period6 = period2.plusDays((int) ' ');
        org.joda.time.Period period8 = period6.minusWeeks((int) (byte) 0);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period8.toDurationTo(readableInstant9);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (short) 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000011576d + "'", double1 == 2440587.5000011576d);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str2 = gregorianChronology1.toString();
//        org.joda.time.DurationField durationField3 = gregorianChronology1.weekyears();
//        try {
//            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField4 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str2.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField3);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 10, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported");
        org.joda.time.Period period10 = new org.joda.time.Period((int) (short) 1, (int) (byte) 0, (int) (short) 10, 100, 10, 0, (int) (short) -1, (int) '#');
        boolean boolean11 = jodaTimePermission1.equals((java.lang.Object) 10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        long long17 = iSOChronology13.add(0L, (long) 1, (int) ' ');
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval21);
        org.joda.time.Period period23 = new org.joda.time.Period((long) 'a', (long) 0, periodType20, chronology22);
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval27 = null;
        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval27);
        org.joda.time.Period period29 = new org.joda.time.Period((long) 'a', (long) 0, periodType26, chronology28);
        org.joda.time.Period period30 = period23.withPeriodType(periodType26);
        org.joda.time.format.PeriodFormatter periodFormatter31 = null;
        java.lang.String str32 = period30.toString(periodFormatter31);
        org.joda.time.Seconds seconds33 = period30.toStandardSeconds();
        long long36 = iSOChronology13.add((org.joda.time.ReadablePeriod) period30, (long) (short) -1, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology13.minuteOfHour();
        boolean boolean38 = jodaTimePermission1.equals((java.lang.Object) dateTimeField37);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder39 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder42 = dateTimeZoneBuilder39.setFixedSavings("GregorianChronology[America/Los_Angeles]", (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder45 = dateTimeZoneBuilder39.setFixedSavings("GregorianChronology[America/Los_Angeles]", (int) (byte) -1);
        boolean boolean46 = jodaTimePermission1.equals((java.lang.Object) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 32L + "'", long17 == 32L);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PT-0.097S" + "'", str32.equals("PT-0.097S"));
        org.junit.Assert.assertNotNull(seconds33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1L) + "'", long36 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder42);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField6 = iSOChronology1.years();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) -1, 10L, chronology11);
        int int13 = period12.getDays();
        org.joda.time.Period period15 = period12.withMillis((int) (short) 1);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) (short) 1);
        long long20 = iSOChronology1.add(0L, 8L, (int) (short) 0);
        org.joda.time.DurationField durationField21 = iSOChronology1.days();
        org.joda.time.DurationFieldType durationFieldType22 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField23 = new org.joda.time.field.DecoratedDurationField(durationField21, durationFieldType22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        org.joda.time.Period period13 = period5.normalizedStandard();
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period13.toDurationTo(readableInstant14);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        try {
            org.joda.time.Period period18 = period13.withFieldAdded(durationFieldType16, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        java.lang.Object obj13 = null;
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period12, obj13);
        java.lang.Class<?> wildcardClass15 = period12.getClass();
        int int16 = period12.getWeeks();
        int int17 = period12.getSeconds();
        try {
            org.joda.time.Period period19 = period12.withMonths(0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long6 = iSOChronology2.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.era();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long12 = dateTimeZone9.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.Chronology chronology14 = iSOChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone13);
        org.joda.time.Period period15 = new org.joda.time.Period(8L, chronology14);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField6 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType4, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("PT-0.097S");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PT-0.097S/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "GregorianChronology[America/Los_Angeles]", "PeriodType[DayTime]");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100 for -00:00:00.001 must be in the range [0,10]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(2440587.5000011576d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 97L, "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("");
        illegalFieldValueException2.prependMessage("PeriodType[DayTime]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException9.prependMessage("");
        illegalFieldValueException9.prependMessage("PeriodType[DayTime]");
        java.lang.Throwable[] throwableArray14 = illegalFieldValueException9.getSuppressed();
        boolean boolean15 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException18.prependMessage("");
        java.lang.String str21 = illegalFieldValueException18.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = illegalFieldValueException18.getDateTimeFieldType();
        illegalFieldValueException9.addSuppressed((java.lang.Throwable) illegalFieldValueException18);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException18);
        java.lang.Number number25 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported" + "'", str21.equals("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported"));
        org.junit.Assert.assertNull(dateTimeFieldType22);
        org.junit.Assert.assertNull(number25);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Seconds seconds15 = period12.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType16 = null;
        try {
            org.joda.time.Period period18 = period12.withFieldAdded(durationFieldType16, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT-0.097S" + "'", str14.equals("PT-0.097S"));
        org.junit.Assert.assertNotNull(seconds15);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 100, (int) (short) 10, (int) 'a', (int) '4', (int) (short) 100, (int) '4', 0, (int) (byte) 1);
        org.joda.time.Period period10 = period8.multipliedBy(0);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period8.toDurationFrom(readableInstant11);
        org.joda.time.Period period14 = period8.minusMinutes((int) (short) 10);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.Period period1 = org.joda.time.Period.hours(0);
        org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(minutes2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.withMillis((int) (short) 1);
        java.lang.Object obj9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) 'a', (long) 0, periodType14, chronology16);
        org.joda.time.PeriodType periodType18 = periodType14.withYearsRemoved();
        org.joda.time.Period period19 = new org.joda.time.Period(readableDuration10, readableInstant11, periodType18);
        java.lang.String str20 = periodType18.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period22 = new org.joda.time.Period(obj9, periodType18, (org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.PeriodType periodType23 = periodType18.withHoursRemoved();
        org.joda.time.Period period24 = period5.withPeriodType(periodType23);
        int int25 = period5.getWeeks();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PeriodType[DayTime]" + "'", str20.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("PeriodType[DayTime]");
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            long long4 = iSOChronology1.set(readablePartial2, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.4999999884d + "'", double1 == 2440587.4999999884d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.Object obj0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) 0, periodType5, chronology7);
        org.joda.time.PeriodType periodType9 = periodType5.withYearsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType9);
        java.lang.String str11 = periodType9.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period13 = new org.joda.time.Period(obj0, periodType9, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType15, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PeriodType[DayTime]" + "'", str11.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(4, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 0, "org.joda.time.IllegalFieldValueException: Value 100 for -00:00:00.001 must be in the range [0,10]");
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 10L + "'", long0 == 10L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 10, (java.lang.Number) (-1.0f), number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.withMillis((int) (short) 1);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period5.toString(periodFormatter9);
        org.joda.time.Duration duration11 = period5.toStandardDuration();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT0.011S" + "'", str10.equals("PT0.011S"));
        org.junit.Assert.assertNotNull(duration11);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "PeriodType[DayTime]", "LenientChronology[ISOChronology[-00:00:00.001]]");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported", "GregorianChronology[America/Los_Angeles]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) ' ', (int) (byte) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("");
        illegalFieldValueException2.prependMessage("PeriodType[DayTime]");
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException2.getSuppressed();
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(durationFieldType9);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.withMillis((int) (short) 1);
        java.lang.Object obj9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) 'a', (long) 0, periodType14, chronology16);
        org.joda.time.PeriodType periodType18 = periodType14.withYearsRemoved();
        org.joda.time.Period period19 = new org.joda.time.Period(readableDuration10, readableInstant11, periodType18);
        java.lang.String str20 = periodType18.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period22 = new org.joda.time.Period(obj9, periodType18, (org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.PeriodType periodType23 = periodType18.withHoursRemoved();
        org.joda.time.Period period24 = period5.withPeriodType(periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMillisRemoved();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PeriodType[DayTime]" + "'", str20.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType8 = periodType4.withYearsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType8);
        java.lang.String str10 = periodType8.toString();
        java.lang.String str11 = periodType8.toString();
        org.joda.time.DurationField durationField12 = org.joda.time.field.MillisDurationField.INSTANCE;
        boolean boolean13 = periodType8.equals((java.lang.Object) durationField12);
        long long16 = durationField12.subtract(9L, (int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField19 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType17, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PeriodType[DayTime]" + "'", str10.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PeriodType[DayTime]" + "'", str11.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 8L + "'", long16 == 8L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.Period period14 = period7.withPeriodType(periodType10);
        org.joda.time.Period period15 = period7.normalizedStandard();
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period15.toDurationTo(readableInstant16);
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration17);
        boolean boolean19 = periodType0.equals((java.lang.Object) readableInstant1);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("PT-0.097S", 0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) '#', (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(97L, 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 970L + "'", long2 == 970L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
//        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, 10L, chronology6);
//        int int8 = period7.getDays();
//        org.joda.time.Days days9 = period7.toStandardDays();
//        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.seconds();
//        org.joda.time.Period period11 = period7.normalizedStandard(periodType10);
//        int[] intArray14 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L, 34L);
//        org.joda.time.DurationField durationField15 = gregorianChronology0.days();
//        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.ReadableInterval readableInterval19 = null;
//        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval19);
//        org.joda.time.Period period21 = new org.joda.time.Period((long) 'a', (long) 0, periodType18, chronology20);
//        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.ReadableInterval readableInterval25 = null;
//        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval25);
//        org.joda.time.Period period27 = new org.joda.time.Period((long) 'a', (long) 0, periodType24, chronology26);
//        org.joda.time.Period period28 = period21.withPeriodType(periodType24);
//        java.lang.Object obj29 = null;
//        boolean boolean30 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period28, obj29);
//        java.lang.Class<?> wildcardClass31 = period28.getClass();
//        int int32 = period28.getWeeks();
//        int int33 = period28.getSeconds();
//        org.joda.time.Period period35 = period28.plusDays((int) (byte) 0);
//        org.joda.time.PeriodType periodType36 = period35.getPeriodType();
//        org.joda.time.PeriodType periodType37 = periodType36.withWeeksRemoved();
//        boolean boolean38 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField15, (java.lang.Object) periodType36);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str1.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(days9);
//        org.junit.Assert.assertNotNull(periodType10);
//        org.junit.Assert.assertNotNull(period11);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(periodType18);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(periodType24);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(periodType36);
//        org.junit.Assert.assertNotNull(periodType37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (-1), true, 9L);
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = dateTimeZone1.getOffset(readableInstant6);
        java.lang.String str8 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-00:00:00.001" + "'", str8.equals("-00:00:00.001"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(10);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.Hours hours12 = period11.toStandardHours();
        int int13 = period11.getMinutes();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(hours12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(8, 10000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80000 + "'", int2 == 80000);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = null;
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(10L, (long) 80000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 800000 + "'", int2 == 800000);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField6 = iSOChronology1.years();
        java.lang.Class<?> wildcardClass7 = iSOChronology1.getClass();
        try {
            org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) iSOChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PT-0.097S", (java.lang.Number) (-1L), (java.lang.Number) (short) 1, number3);
        java.lang.String str5 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value -1 for PT-0.097S must not be smaller than 1" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value -1 for PT-0.097S must not be smaller than 1"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "GregorianChronology[-00:00:00.001]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "Weeks");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.year();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology1.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType3 = periodType0.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.Days days6 = period5.toStandardDays();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.Period period9 = period5.withField(durationFieldType7, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(days6);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(100L, 320L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32000 + "'", int2 == 32000);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(durationFieldType4);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        int int2 = periodType0.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long4 = dateTimeZone1.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str7 = dateTimeZone1.getShortName((long) (-1));
        java.lang.String str9 = dateTimeZone1.getShortName(34L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-00:00:00.001" + "'", str7.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-00:00:00.001" + "'", str9.equals("-00:00:00.001"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        try {
            long long11 = iSOChronology5.getDateTimeMillis((long) (short) 100, (-1), 0, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.withMillis((int) (short) 1);
        java.lang.Object obj9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) 'a', (long) 0, periodType14, chronology16);
        org.joda.time.PeriodType periodType18 = periodType14.withYearsRemoved();
        org.joda.time.Period period19 = new org.joda.time.Period(readableDuration10, readableInstant11, periodType18);
        java.lang.String str20 = periodType18.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period22 = new org.joda.time.Period(obj9, periodType18, (org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.PeriodType periodType23 = periodType18.withHoursRemoved();
        org.joda.time.Period period24 = period5.withPeriodType(periodType23);
        int int25 = period24.getSeconds();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PeriodType[DayTime]" + "'", str20.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("GregorianChronology[America/Los_Angeles]", (int) (short) 10, 0, (int) (byte) -1, 'a', (int) 'a', 10, 0, true, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder11.toDateTimeZone("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported", true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (-1), true, 9L);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        long long9 = dateTimeZone1.convertLocalToUTC(10L, false);
        boolean boolean11 = dateTimeZone1.isStandardOffset(9L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 11L + "'", long9 == 11L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("Weeks");
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-1L), (java.lang.Number) 34L, (java.lang.Number) 970L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(32L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 8);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 8L + "'", long6 == 8L);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology3.era();
        org.joda.time.Period period9 = new org.joda.time.Period((long) 'a', (-65L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField10 = iSOChronology3.months();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField12 = new org.joda.time.field.DecoratedDurationField(durationField10, durationFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[America/Los_Angeles]", (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[America/Los_Angeles]", (int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeZoneBuilder0.toDateTimeZone("GregorianChronology[-00:00:00.001]", true);
        java.io.OutputStream outputStream11 = null;
        try {
            dateTimeZoneBuilder0.writeTo("LenientChronology[ISOChronology[-00:00:00.001]]", outputStream11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 36000000 + "'", int3 == 36000000);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long8 = cachedDateTimeZone4.convertLocalToUTC((long) 10, true, (long) (short) 10);
        int int10 = cachedDateTimeZone4.getOffsetFromLocal(100L);
        java.lang.Object obj11 = null;
        boolean boolean12 = cachedDateTimeZone4.equals(obj11);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 11L + "'", long8 == 11L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Seconds seconds15 = period12.toStandardSeconds();
        org.joda.time.Period period17 = period12.minusDays((int) (byte) 100);
        org.joda.time.DurationFieldType durationFieldType18 = null;
        int int19 = period12.indexOf(durationFieldType18);
        org.joda.time.Period period21 = period12.plusHours(0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT-0.097S" + "'", str14.equals("PT-0.097S"));
        org.junit.Assert.assertNotNull(seconds15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) 'a', (long) 0, periodType14, chronology16);
        org.joda.time.Period period18 = period11.withPeriodType(periodType14);
        org.joda.time.format.PeriodFormatter periodFormatter19 = null;
        java.lang.String str20 = period18.toString(periodFormatter19);
        org.joda.time.Seconds seconds21 = period18.toStandardSeconds();
        long long24 = iSOChronology1.add((org.joda.time.ReadablePeriod) period18, (long) (short) -1, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType26, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PT-0.097S" + "'", str20.equals("PT-0.097S"));
        org.junit.Assert.assertNotNull(seconds21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weekyears();
        org.joda.time.DurationField durationField3 = gregorianChronology0.centuries();
        org.joda.time.Chronology chronology4 = gregorianChronology0.withUTC();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology5.dayOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField8 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str1.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        org.joda.time.Period period7 = period5.plusMonths(0);
        int int8 = period7.getMonths();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-97L), "PeriodType[DayTime]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("");
        illegalFieldValueException2.prependMessage("PeriodType[DayTime]");
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException2.getSuppressed();
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException11.prependMessage("");
        java.lang.String str14 = illegalFieldValueException11.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = illegalFieldValueException11.getDateTimeFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException11);
        java.lang.String str17 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str18 = illegalFieldValueException2.toString();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported" + "'", str14.equals("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported"));
        org.junit.Assert.assertNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.joda.time.IllegalFieldValueException: PeriodType[DayTime]: : Value \"\" for hi! is not supported" + "'", str18.equals("org.joda.time.IllegalFieldValueException: PeriodType[DayTime]: : Value \"\" for hi! is not supported"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long6 = iSOChronology2.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField9 = iSOChronology2.months();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-65L) + "'", long6 == (-65L));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, 0, 0, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType7, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField6 = iSOChronology1.years();
        java.lang.Class<?> wildcardClass7 = iSOChronology1.getClass();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology1.halfdayOfDay();
        org.joda.time.DurationField durationField9 = iSOChronology1.halfdays();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField11 = new org.joda.time.field.DecoratedDurationField(durationField9, durationFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        boolean boolean2 = periodType0.isSupported(durationFieldType1);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 10, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) -1, (int) (short) -1, 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("");
        illegalFieldValueException2.prependMessage("PeriodType[DayTime]");
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException2.getSuppressed();
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Throwable[] throwableArray9 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long4 = gregorianChronology0.add(0L, (long) 'a', (int) (byte) 0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant7, readableInstant8);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) -1, 10L, chronology9);
        int int11 = period10.getDays();
        org.joda.time.Days days12 = period10.toStandardDays();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period14 = period10.normalizedStandard(periodType13);
        long long17 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period14, 0L, 0);
        org.joda.time.ReadablePartial readablePartial18 = null;
        try {
            long long20 = gregorianChronology0.set(readablePartial18, 320L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(days12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DurationField durationField3 = gregorianChronology1.weekyears();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) "", (java.lang.Object) durationField4);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str2.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 11L, (java.lang.Number) (-115199968L), number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'ISOChronology[UTC]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = dateTimeZone5.getOffset(readableInstant6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.Chronology chronology9 = gregorianChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        org.joda.time.Period period10 = new org.joda.time.Period(10L, (long) (-1), chronology9);
        org.joda.time.Period period12 = period10.plusYears((int) ' ');
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str3.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("PeriodType[DayTime]", (int) (short) 10, 800000, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for PeriodType[DayTime] must be in the range [800000,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[America/Los_Angeles]", (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 100);
        java.io.OutputStream outputStream7 = null;
        try {
            dateTimeZoneBuilder5.writeTo("PeriodType[DayTime]", outputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (byte) -1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.Period period1 = new org.joda.time.Period(1L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (byte) 100);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffset((long) (byte) 0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        int int8 = cachedDateTimeZone4.getOffset(readableInstant7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        java.lang.Object obj13 = null;
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period12, obj13);
        java.lang.Class<?> wildcardClass15 = period12.getClass();
        int int16 = period12.getWeeks();
        int int17 = period12.getSeconds();
        org.joda.time.Period period19 = period12.plusDays((int) (byte) 0);
        org.joda.time.PeriodType periodType20 = period19.getPeriodType();
        java.lang.Class<?> wildcardClass21 = period19.getClass();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType8, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str1.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "-00:00:00.001");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.halfdayOfDay();
        java.lang.String str9 = lenientChronology6.toString();
        org.joda.time.DateTimeField dateTimeField10 = lenientChronology6.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField10, dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LenientChronology[ISOChronology[-00:00:00.001]]" + "'", str9.equals("LenientChronology[ISOChronology[-00:00:00.001]]"));
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("GregorianChronology[America/Los_Angeles]", (int) (short) 10, 0, (int) (byte) -1, 'a', (int) 'a', 10, 0, true, (int) '#');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("", 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder25 = dateTimeZoneBuilder14.addRecurringSavings("PT-0.097S", 20, 4, 80000, ' ', 8, (int) (byte) 100, (int) (short) 1, true, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) '4', 80000, (int) (short) 1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 27 + "'", int4 == 27);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.Period period4 = new org.joda.time.Period(320L, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Period period6 = period4.minusMillis(4);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str6 = dateTimeZone1.getShortName(8L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.001" + "'", str6.equals("-00:00:00.001"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.Period period3 = new org.joda.time.Period(0L, (long) 4, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 9L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865982400000L) + "'", long1 == (-210865982400000L));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) 'a', (long) 0, periodType16, chronology18);
        org.joda.time.Period period20 = period13.withPeriodType(periodType16);
        java.lang.Object obj21 = null;
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period20, obj21);
        java.lang.Class<?> wildcardClass23 = period20.getClass();
        int int24 = period20.getWeeks();
        int int25 = period20.getSeconds();
        org.joda.time.Period period27 = period20.plusDays((int) (byte) 0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
        try {
            org.joda.time.Period period30 = new org.joda.time.Period(0, (int) 'a', (int) ' ', 27, 800000, 100, 34, (int) (short) 10, periodType29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(periodType29);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant6, readableDuration7);
        long long11 = iSOChronology1.add((org.joda.time.ReadablePeriod) period8, (long) 1, (int) ' ');
        org.joda.time.Period period13 = period8.minusDays((int) '#');
        org.joda.time.Minutes minutes14 = period13.toStandardMinutes();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(minutes14);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.Period period2 = new org.joda.time.Period((long) '4', (long) (-1));
        int int3 = period2.getSeconds();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.Object obj0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) 0, periodType5, chronology7);
        org.joda.time.PeriodType periodType9 = periodType5.withYearsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType9);
        java.lang.String str11 = periodType9.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period13 = new org.joda.time.Period(obj0, periodType9, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField14, dateTimeFieldType15, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PeriodType[DayTime]" + "'", str11.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long6 = iSOChronology2.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField7 = iSOChronology2.minutes();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField8 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-65L) + "'", long6 == (-65L));
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("GregorianChronology[America/Los_Angeles]", (int) (short) 10, 0, (int) (byte) -1, 'a', (int) 'a', 10, 0, true, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder11.toDateTimeZone("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported", true);
        org.joda.time.DateTimeZone dateTimeZone17 = dateTimeZoneBuilder11.toDateTimeZone("org.joda.time.IllegalFieldValueException: Value -1 for PT-0.097S must not be smaller than 1", true);
        java.lang.String str18 = dateTimeZone17.getID();
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.joda.time.IllegalFieldValueException: Value -1 for PT-0.097S must not be smaller than 1" + "'", str18.equals("org.joda.time.IllegalFieldValueException: Value -1 for PT-0.097S must not be smaller than 1"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 'a', 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 87L + "'", long2 == 87L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Days days7 = period5.toStandardDays();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period9 = period5.normalizedStandard(periodType8);
        int[] intArray10 = period9.getValues();
        org.joda.time.Period period12 = period9.multipliedBy((int) '4');
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(days7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[America/Los_Angeles]", (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[America/Los_Angeles]", (int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeZoneBuilder0.toDateTimeZone("GregorianChronology[-00:00:00.001]", true);
        java.io.DataOutput dataOutput11 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", dataOutput11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[America/Los_Angeles]", (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[America/Los_Angeles]", (int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeZoneBuilder0.toDateTimeZone("GregorianChronology[-00:00:00.001]", true);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-00:00:00.001" + "'", str12.equals("-00:00:00.001"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported", "PT0.011S");
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 'a', "hi!");
        java.lang.String str3 = illegalInstantException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.097 (hi!)" + "'", str3.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.097 (hi!)"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 0, 36000000, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [36000000,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        java.lang.Object obj13 = null;
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period12, obj13);
        java.lang.Class<?> wildcardClass15 = period12.getClass();
        org.joda.time.Period period17 = period12.multipliedBy(10);
        try {
            int int19 = period12.getValue(800000);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = periodType0.withDaysRemoved();
        java.lang.String str3 = periodType0.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Standard" + "'", str3.equals("Standard"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        int int4 = dateTimeZone2.getOffset(readableInstant3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        long long9 = cachedDateTimeZone5.convertLocalToUTC((long) 10, true, (long) (short) 10);
        java.lang.String str11 = cachedDateTimeZone5.getShortName(32L);
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 11L + "'", long9 == 11L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str1.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        org.joda.time.Period period13 = period5.normalizedStandard();
        org.joda.time.Seconds seconds14 = period13.toStandardSeconds();
        org.joda.time.Period period16 = period13.withSeconds(0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(seconds14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 8);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str9 = fixedDateTimeZone4.getNameKey(34L);
        int int11 = fixedDateTimeZone4.getOffsetFromLocal((long) 10000);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 8L + "'", long6 == 8L);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PT0.011S" + "'", str9.equals("PT0.011S"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long6 = iSOChronology2.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField7 = iSOChronology2.years();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) (short) -1, 10L, chronology12);
        int int14 = period13.getDays();
        org.joda.time.Period period16 = period13.withMillis((int) (short) 1);
        boolean boolean17 = iSOChronology2.equals((java.lang.Object) (short) 1);
        long long21 = iSOChronology2.add(0L, 8L, (int) (short) 0);
        org.joda.time.DurationField durationField22 = iSOChronology2.days();
        long long25 = durationField22.subtract((long) 100, 10000);
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-65L) + "'", long6 == (-65L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-863999999900L) + "'", long25 == (-863999999900L));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long8 = cachedDateTimeZone4.convertLocalToUTC((long) 10, true, (long) (short) 10);
        java.lang.String str10 = cachedDateTimeZone4.getShortName(32L);
        java.util.TimeZone timeZone11 = cachedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 11L + "'", long8 == 11L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-00:00:00.001" + "'", str10.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.years();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(1);
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder0.writeTo("Weeks", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-1L), (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-33L) + "'", long2 == (-33L));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.097 (hi!)", 10000, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10000 for org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.097 (hi!) must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.time();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period((int) (short) 100, 1, 10000, 80000, 80000, 10, (int) (byte) 0, 4, periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (short) 1, (int) (byte) 0, (int) (short) 10, 100, 10, 0, (int) (short) -1, (int) '#');
        org.joda.time.Period period10 = period8.plusHours((-1));
        org.joda.time.Period period12 = period10.withHours((int) '4');
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(52L, (int) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2704L + "'", long2 == 2704L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.convertLocalToUTC((long) 'a', true);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone0.isLocalDateTimeGap(localDateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        java.lang.Object obj13 = null;
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period12, obj13);
        java.lang.Class<?> wildcardClass15 = period12.getClass();
        org.joda.time.Period period17 = period12.minusSeconds((int) (byte) 10);
        org.joda.time.Period period19 = period12.withMinutes((int) (short) 100);
        int int20 = period19.getHours();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        int int2 = periodType1.size();
        org.joda.time.PeriodType periodType3 = periodType1.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType5 = periodType1.getFieldType(0);
        java.lang.Number number6 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(durationFieldType5, number6, (java.lang.Number) (-863999999900L), (java.lang.Number) 2440587.5000011576d);
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField11 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType5, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(durationFieldType5);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, 0, 0, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType7, (int) (byte) 100, (int) '4', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(10000, 8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        java.lang.String str2 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-01:00" + "'", str2.equals("-01:00"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.joda.time.DurationField durationField3 = iSOChronology0.centuries();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant6, readableDuration7);
        long long11 = iSOChronology1.add((org.joda.time.ReadablePeriod) period8, (long) 1, (int) ' ');
        org.joda.time.DurationField durationField12 = iSOChronology1.months();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.monthOfYear();
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval18 = null;
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) 'a', (long) 0, periodType17, chronology19);
        int[] intArray21 = period20.getValues();
        try {
            iSOChronology1.validate(readablePartial14, intArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PT-0.097S", "PT-0.097S");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PT-0.097S" + "'", str3.equals("PT-0.097S"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(100.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858120000000L) + "'", long1 == (-210858120000000L));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.field.FieldUtils.verifyValueBounds("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported", 100, 100, 100);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(100);
        org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(minutes2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (-1), chronology3);
        org.joda.time.Period period6 = period4.withMonths((int) (short) 10);
        java.lang.String str7 = period4.toString();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT-0.001S" + "'", str7.equals("PT-0.001S"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, 10L, chronology6);
        int int8 = period7.getDays();
        org.joda.time.Days days9 = period7.toStandardDays();
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period11 = period7.normalizedStandard(periodType10);
        int[] intArray14 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L, 34L);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.monthOfYear();
        int int16 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField17 = gregorianChronology0.millis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str1.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(days9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.field.FieldUtils.verifyValueBounds("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported", (int) (short) 0, (int) (short) -1, (int) ' ');
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(100L, 8000010L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 800001000 + "'", int2 == 800001000);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.Period period2 = new org.joda.time.Period((-115199968L), (long) (byte) 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.year();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, 33, 800000, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 33 for year must be in the range [800000,3]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType9, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long6 = iSOChronology2.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField7 = iSOChronology2.years();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) (short) -1, 10L, chronology12);
        int int14 = period13.getDays();
        org.joda.time.Period period16 = period13.withMillis((int) (short) 1);
        boolean boolean17 = iSOChronology2.equals((java.lang.Object) (short) 1);
        org.joda.time.DurationField durationField18 = iSOChronology2.months();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        long long24 = iSOChronology20.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant25, readableDuration26);
        long long30 = iSOChronology20.add((org.joda.time.ReadablePeriod) period27, (long) 1, (int) ' ');
        org.joda.time.DurationField durationField31 = iSOChronology20.months();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology20.monthOfYear();
        org.joda.time.DurationField durationField33 = iSOChronology20.hours();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField34 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField18, durationField33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-65L) + "'", long6 == (-65L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-65L) + "'", long24 == (-65L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.lang.Object obj0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) 0, periodType5, chronology7);
        org.joda.time.PeriodType periodType9 = periodType5.withYearsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType9);
        java.lang.String str11 = periodType9.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period13 = new org.joda.time.Period(obj0, periodType9, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.hourOfDay();
        org.joda.time.Chronology chronology15 = gregorianChronology12.withUTC();
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PeriodType[DayTime]" + "'", str11.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("GregorianChronology[America/Los_Angeles]", (int) (short) 10, 0, (int) (byte) -1, 'a', (int) 'a', 10, 0, true, (int) '#');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder24 = dateTimeZoneBuilder13.addRecurringSavings("Standard", 33, 4, (int) (short) 1, ' ', (int) (byte) 0, (int) '4', (int) (byte) -1, true, 34);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder24);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfMonth();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis((-1), 0, (int) '4', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str1.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField6 = iSOChronology1.years();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) -1, 10L, chronology11);
        int int13 = period12.getDays();
        org.joda.time.Period period15 = period12.withMillis((int) (short) 1);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) (short) 1);
        long long20 = iSOChronology1.add(0L, 8L, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.ReadablePartial readablePartial22 = null;
        try {
            long long24 = iSOChronology1.set(readablePartial22, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long11 = dateTimeZone8.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.Chronology chronology13 = iSOChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        long long17 = cachedDateTimeZone12.convertLocalToUTC((long) 10, true, (long) (short) 0);
        org.joda.time.Period period19 = org.joda.time.Period.minutes(1);
        org.joda.time.PeriodType periodType20 = period19.getPeriodType();
        boolean boolean21 = cachedDateTimeZone12.equals((java.lang.Object) periodType20);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant23, readableInstant24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (-1), chronology25);
        org.joda.time.Days days27 = period26.toStandardDays();
        boolean boolean28 = cachedDateTimeZone12.equals((java.lang.Object) days27);
        java.lang.String str29 = cachedDateTimeZone12.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 11L + "'", long17 == 11L);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(days27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "-00:00:00.001" + "'", str29.equals("-00:00:00.001"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) 'a', (long) 0, periodType6, chronology8);
        org.joda.time.PeriodType periodType10 = periodType6.withYearsRemoved();
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration2, readableInstant3, periodType10);
        java.lang.String str12 = periodType10.toString();
        try {
            org.joda.time.Period period13 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PeriodType[DayTime]" + "'", str12.equals("PeriodType[DayTime]"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long4 = dateTimeZone1.convertLocalToUTC(0L, true);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        java.lang.String str8 = dateTimeZone1.getShortName((long) (short) 1);
        long long10 = dateTimeZone1.convertUTCToLocal((long) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-00:00:00.001" + "'", str8.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 99L + "'", long10 == 99L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 10, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 10000, "org.joda.time.IllegalFieldValueException: Value -1 for PT-0.097S must not be smaller than 1");
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = fixedDateTimeZone4.getOffset(readableInstant5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField6 = iSOChronology1.years();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) -1, 10L, chronology11);
        int int13 = period12.getDays();
        org.joda.time.Period period15 = period12.withMillis((int) (short) 1);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) (short) 1);
        long long20 = iSOChronology1.add(0L, 8L, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.ReadablePartial readablePartial22 = null;
        try {
            long long24 = iSOChronology1.set(readablePartial22, (-65L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.plusMillis((int) '#');
        org.joda.time.Period period6 = period2.minusSeconds((int) 'a');
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(20, 32000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 640000 + "'", int2 == 640000);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(1);
        int int2 = period1.getMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.days();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        long long13 = lenientChronology6.getDateTimeMillis((long) 4, (int) (short) 1, 0, 10000, (int) '#');
        boolean boolean15 = lenientChronology6.equals((java.lang.Object) 2704L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 13600036L + "'", long13 == 13600036L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(32000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (-1), chronology3);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.yearDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        long long11 = iSOChronology7.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField13 = lenientChronology12.yearOfEra();
        org.joda.time.DateTimeField dateTimeField14 = lenientChronology12.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField15 = lenientChronology12.weekyearOfCentury();
        try {
            org.joda.time.Period period16 = new org.joda.time.Period((java.lang.Object) chronology3, periodType5, (org.joda.time.Chronology) lenientChronology12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        long long17 = offsetDateTimeField15.roundHalfEven(97L);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = offsetDateTimeField15.getAsShortText(readablePartial18, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135596799999L) + "'", long17 == (-62135596799999L));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        int int4 = periodType3.size();
        org.joda.time.PeriodType periodType5 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType7 = periodType3.getFieldType(0);
        int int8 = periodType0.indexOf(durationFieldType7);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) (short) -1);
        long long12 = preciseDurationField10.getMillis(100);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-100L) + "'", long12 == (-100L));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 8);
        org.joda.time.ReadableInstant readableInstant7 = null;
        int int8 = fixedDateTimeZone4.getOffset(readableInstant7);
        int int10 = fixedDateTimeZone4.getOffset((-65L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 8L + "'", long6 == 8L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (-1), true, 9L);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadablePartial readablePartial7 = null;
        try {
            int[] intArray9 = gregorianChronology6.get(readablePartial7, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology6);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.withYears((int) (byte) 0);
        org.joda.time.Period period6 = period2.plusDays((int) ' ');
        int int7 = period2.getSeconds();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((-62135596799999L), "org.joda.time.IllegalFieldValueException: Value 100 for -00:00:00.001 must be in the range [0,10]");
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858120000000L) + "'", long1 == (-210858120000000L));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        long long17 = offsetDateTimeField15.roundHalfEven(97L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField15.getAsShortText((int) (byte) -1, locale19);
        long long22 = offsetDateTimeField15.roundHalfCeiling((long) (short) 1);
        try {
            long long25 = offsetDateTimeField15.add((long) '#', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135596799999L) + "'", long17 == (-62135596799999L));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-1" + "'", str20.equals("-1"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62135596799999L) + "'", long22 == (-62135596799999L));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-1), 3, 32000, 640000);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 608003 + "'", int4 == 608003);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-33L), 1560628303058L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1560628303091L) + "'", long2 == (-1560628303091L));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.lang.Object obj0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) 0, periodType5, chronology7);
        org.joda.time.PeriodType periodType9 = periodType5.withYearsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType9);
        java.lang.String str11 = periodType9.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period13 = new org.joda.time.Period(obj0, periodType9, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.PeriodType periodType14 = periodType9.withHoursRemoved();
        org.joda.time.PeriodType periodType15 = periodType14.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PeriodType[DayTime]" + "'", str11.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) 100, 20, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt((-210858120000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -210858120000000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        org.joda.time.Period period13 = period5.normalizedStandard();
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period13.toDurationTo(readableInstant14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.PeriodType periodType17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration15, readableInstant16, periodType17);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.seconds();
        int int20 = periodType19.size();
        org.joda.time.PeriodType periodType21 = periodType19.withMinutesRemoved();
        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) periodType17, periodType21);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(periodType21);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weekyears();
        org.joda.time.DurationField durationField3 = gregorianChronology0.centuries();
        org.joda.time.Chronology chronology4 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.secondOfMinute();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis(0, 34, 33, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 34 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str1.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.097 (hi!)", 10000, (int) (byte) -1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10000 for org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.097 (hi!) must be in the range [-1,35]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffset((long) (byte) 0);
        java.lang.String str7 = cachedDateTimeZone4.getID();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant8);
        boolean boolean10 = cachedDateTimeZone4.equals((java.lang.Object) readableInstant8);
        boolean boolean11 = cachedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone4.getUncachedZone();
        long long15 = dateTimeZone12.convertLocalToUTC(0L, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-00:00:00.001" + "'", str7.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.Period period1 = new org.joda.time.Period(0L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("GregorianChronology[America/Los_Angeles]", (int) (short) 10, 0, (int) (byte) -1, 'a', (int) 'a', 10, 0, true, (int) '#');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addCutover(800000, 'a', (int) (short) 100, (int) (byte) -1, 100, false, 33);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder27 = dateTimeZoneBuilder19.addCutover(640000, '4', 10000, (int) (short) 100, (int) '#', false, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.lang.Object obj0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) 0, periodType5, chronology7);
        org.joda.time.PeriodType periodType9 = periodType5.withYearsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType9);
        java.lang.String str11 = periodType9.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period13 = new org.joda.time.Period(obj0, periodType9, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.hourOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, dateTimeFieldType16, (int) (short) -1, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PeriodType[DayTime]" + "'", str11.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("");
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException2.getSuppressed();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException2.getSuppressed();
        java.lang.String str7 = illegalFieldValueException2.getFieldName();
        java.lang.String str8 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        org.joda.time.DurationField durationField16 = offsetDateTimeField15.getRangeDurationField();
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField15.getWrappedField();
        try {
            long long20 = offsetDateTimeField15.set(87L, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 6 for era must be in the range [20,21]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 800000);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-141746760000000L) + "'", long1 == (-141746760000000L));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.weeks();
        java.lang.String str9 = periodType8.getName();
        try {
            org.joda.time.Period period10 = new org.joda.time.Period(0, (int) (short) 1, 608003, 0, (int) (byte) 0, 2, (int) (short) 1, 3, periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Weeks" + "'", str9.equals("Weeks"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName((long) 0, locale3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+10:00" + "'", str4.equals("+10:00"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) (byte) 100, (int) (short) 10, (int) 'a', (int) '4', (int) (short) 100, (int) '4', 0, (int) (byte) 1);
        org.joda.time.Period period11 = period9.multipliedBy(0);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period9.toDurationFrom(readableInstant12);
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration13);
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration13);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3245547120001L + "'", long15 == 3245547120001L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
        org.joda.time.DurationField durationField5 = iSOChronology2.centuries();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField6 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfDay();
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType0, (java.lang.Object) dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField8 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType6, 800000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) '4', 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 104 + "'", int2 == 104);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Seconds seconds15 = period12.toStandardSeconds();
        try {
            org.joda.time.Period period17 = period12.plusMonths(6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT-0.097S" + "'", str14.equals("PT-0.097S"));
        org.junit.Assert.assertNotNull(seconds15);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        org.joda.time.DurationField durationField16 = offsetDateTimeField15.getDurationField();
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = offsetDateTimeField15.getAsText(readablePartial17, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        org.joda.time.DurationField durationField16 = offsetDateTimeField15.getDurationField();
        try {
            long long18 = offsetDateTimeField15.remainder((-9223372036854775808L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Adding time zone offset caused overflow");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period2 = new org.joda.time.Period(11L, (org.joda.time.Chronology) gregorianChronology1);
        int int3 = period2.getWeeks();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("");
        java.lang.String str5 = illegalFieldValueException2.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException2.getDateTimeFieldType();
        boolean boolean7 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException10.prependMessage("");
        illegalFieldValueException10.prependMessage("PeriodType[DayTime]");
        java.lang.Throwable[] throwableArray15 = illegalFieldValueException10.getSuppressed();
        boolean boolean16 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException10);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        java.lang.String str18 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported" + "'", str5.equals("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported"));
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 2704L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        try {
            org.joda.time.Period period14 = period5.withWeeks((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale21 = null;
        try {
            java.lang.String str22 = offsetDateTimeField15.getAsText(readablePartial20, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800086L + "'", long19 == 62135596800086L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        java.util.Locale locale18 = null;
        int int19 = offsetDateTimeField15.getMaximumShortTextLength(locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, dateTimeFieldType20, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(8, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        org.joda.time.DurationField durationField16 = offsetDateTimeField15.getDurationField();
        try {
            long long19 = durationField16.subtract((-62135596799999L), 7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("97", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType8 = periodType4.withYearsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType8);
        java.lang.String str10 = periodType8.toString();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        boolean boolean12 = periodType8.isSupported(durationFieldType11);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PeriodType[DayTime]" + "'", str10.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long11 = dateTimeZone8.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.Chronology chronology13 = iSOChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        long long17 = cachedDateTimeZone12.convertLocalToUTC((long) 10, true, (long) (short) 0);
        org.joda.time.Period period19 = org.joda.time.Period.minutes(1);
        org.joda.time.PeriodType periodType20 = period19.getPeriodType();
        boolean boolean21 = cachedDateTimeZone12.equals((java.lang.Object) periodType20);
        int int23 = cachedDateTimeZone12.getOffset((long) 3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 11L + "'", long17 == 11L);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.Period period1 = new org.joda.time.Period((long) ' ');
        org.joda.time.Period period3 = period1.minusSeconds((int) (short) -1);
        org.joda.time.PeriodType periodType4 = period1.getPeriodType();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant7, readableInstant8);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) -1, 10L, chronology9);
        int int11 = period10.getDays();
        org.joda.time.Period period13 = period10.withMillis((int) (short) 1);
        org.joda.time.Period period15 = period10.plusWeeks(4);
        org.joda.time.Minutes minutes16 = period15.toStandardMinutes();
        org.joda.time.Period period18 = period15.plusMinutes(1);
        org.joda.time.Period period20 = period18.minusDays((int) ' ');
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        int int22 = periodType21.size();
        org.joda.time.PeriodType periodType23 = periodType21.withMonthsRemoved();
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.seconds();
        int int25 = periodType24.size();
        org.joda.time.PeriodType periodType26 = periodType24.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType28 = periodType24.getFieldType(0);
        int int29 = periodType21.indexOf(durationFieldType28);
        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType28, (long) (short) -1);
        org.joda.time.Period period33 = period20.withField(durationFieldType28, 2);
        int int34 = period1.indexOf(durationFieldType28);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(minutes16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology3.millisOfDay();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) '4');
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, 10L, chronology6);
        int int8 = period7.getDays();
        org.joda.time.Period period10 = period7.withMillis((int) (short) 1);
        org.joda.time.Period period12 = period10.plusSeconds((int) (short) 10);
        org.joda.time.Period period13 = period1.plus((org.joda.time.ReadablePeriod) period10);
        int int14 = period13.getMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        java.lang.Object obj13 = null;
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period12, obj13);
        java.lang.Class<?> wildcardClass15 = period12.getClass();
        org.joda.time.Period period17 = period12.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) 'a', (long) 0, periodType23, chronology25);
        org.joda.time.PeriodType periodType27 = periodType23.withYearsRemoved();
        org.joda.time.Period period28 = new org.joda.time.Period(readableDuration19, readableInstant20, periodType27);
        org.joda.time.PeriodType periodType29 = periodType27.withHoursRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(10L, periodType27);
        org.joda.time.PeriodType periodType31 = periodType27.withHoursRemoved();
        org.joda.time.PeriodType periodType32 = org.joda.time.PeriodType.standard();
        boolean boolean33 = periodType27.equals((java.lang.Object) periodType32);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.seconds();
        int int35 = periodType34.size();
        org.joda.time.PeriodType periodType36 = periodType34.withMonthsRemoved();
        org.joda.time.PeriodType periodType37 = org.joda.time.PeriodType.seconds();
        int int38 = periodType37.size();
        org.joda.time.PeriodType periodType39 = periodType37.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType41 = periodType37.getFieldType(0);
        int int42 = periodType34.indexOf(durationFieldType41);
        int int43 = periodType27.indexOf(durationFieldType41);
        org.joda.time.Period period45 = period12.withField(durationFieldType41, 0);
        try {
            org.joda.time.Period period47 = period12.withMonths((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(durationFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 3 + "'", int43 == 3);
        org.junit.Assert.assertNotNull(period45);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.lang.Object obj0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) 0, periodType5, chronology7);
        org.joda.time.PeriodType periodType9 = periodType5.withYearsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType9);
        java.lang.String str11 = periodType9.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period13 = new org.joda.time.Period(obj0, periodType9, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType15, 10, (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PeriodType[DayTime]" + "'", str11.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        int int4 = periodType3.size();
        org.joda.time.PeriodType periodType5 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType7 = periodType3.getFieldType(0);
        int int8 = periodType0.indexOf(durationFieldType7);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) (short) -1);
        int int13 = preciseDurationField10.getDifference(0L, (long) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = gregorianChronology14.withZone(dateTimeZone16);
        boolean boolean18 = preciseDurationField10.equals((java.lang.Object) gregorianChronology14);
        org.joda.time.ReadablePartial readablePartial19 = null;
        int[] intArray23 = new int[] { (-34), 36000000, 34 };
        try {
            gregorianChronology14.validate(readablePartial19, intArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period2 = new org.joda.time.Period(11L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Chronology chronology3 = gregorianChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.year();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long10 = dateTimeZone7.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        org.joda.time.Chronology chronology12 = iSOChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((-1));
        org.joda.time.Period period3 = period1.plusWeeks(0);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationTo(readableInstant4);
        int int6 = period3.getWeeks();
        org.joda.time.Period period8 = period3.withMillis((-1));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
        org.joda.time.DurationField durationField3 = iSOChronology1.hours();
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException6.prependMessage("");
        illegalFieldValueException6.prependMessage("PeriodType[DayTime]");
        java.lang.Throwable[] throwableArray11 = illegalFieldValueException6.getSuppressed();
        boolean boolean12 = iSOChronology1.equals((java.lang.Object) illegalFieldValueException6);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 0, (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported", "Weeks", 608003, 10000);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant22, readableInstant23);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (-1), chronology24);
        org.joda.time.Period period27 = period25.withDays(0);
        int[] intArray28 = period27.getValues();
        int int29 = offsetDateTimeField15.getMinimumValue(readablePartial20, intArray28);
        java.lang.String str30 = offsetDateTimeField15.getName();
        try {
            long long33 = offsetDateTimeField15.add(9L, 33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800086L + "'", long19 == 62135596800086L);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "era" + "'", str30.equals("era"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str11 = gregorianChronology10.toString();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant14 = null;
        int int15 = dateTimeZone13.getOffset(readableInstant14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
        org.joda.time.Chronology chronology17 = gregorianChronology10.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone16);
        org.joda.time.Period period18 = new org.joda.time.Period(10L, (long) (-1), chronology17);
        org.joda.time.DurationFieldType durationFieldType19 = null;
        int int20 = period18.get(durationFieldType19);
        long long23 = iSOChronology1.add((org.joda.time.ReadablePeriod) period18, 970L, (int) ' ');
        org.joda.time.Period period25 = period18.minusSeconds((int) 'a');
        org.joda.time.Duration duration26 = period25.toStandardDuration();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str11.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 618L + "'", long23 == 618L);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(duration26);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        java.lang.Object obj13 = null;
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period12, obj13);
        java.lang.Class<?> wildcardClass15 = period12.getClass();
        org.joda.time.Period period17 = period12.minusSeconds((int) (byte) 10);
        org.joda.time.Period period19 = period12.withMinutes((int) (short) 100);
        org.joda.time.Period period21 = period19.minusMillis(1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException(durationFieldType4, "PT0.011S");
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException6.getDurationFieldType();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertNotNull(durationFieldType7);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        try {
            int int20 = offsetDateTimeField15.getDifference((long) '#', (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long8 = cachedDateTimeZone4.convertLocalToUTC((long) 10, true, (long) (short) 10);
        boolean boolean9 = cachedDateTimeZone4.isFixed();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        long long16 = fixedDateTimeZone14.previousTransition((long) 8);
        java.util.TimeZone timeZone17 = fixedDateTimeZone14.toTimeZone();
        java.util.TimeZone timeZone18 = fixedDateTimeZone14.toTimeZone();
        int int20 = fixedDateTimeZone14.getOffset(34L);
        boolean boolean21 = cachedDateTimeZone4.equals((java.lang.Object) fixedDateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long26 = dateTimeZone23.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone23);
        java.lang.String str28 = cachedDateTimeZone27.getID();
        java.util.TimeZone timeZone29 = cachedDateTimeZone27.toTimeZone();
        boolean boolean30 = fixedDateTimeZone14.equals((java.lang.Object) cachedDateTimeZone27);
        java.lang.String str32 = fixedDateTimeZone14.getNameKey((long) (-1));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 11L + "'", long8 == 11L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 8L + "'", long16 == 8L);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-00:00:00.001" + "'", str28.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PT0.011S" + "'", str32.equals("PT0.011S"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        java.util.Locale locale18 = null;
        int int19 = offsetDateTimeField15.getMaximumTextLength(locale18);
        int int21 = offsetDateTimeField15.get(3L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 21 + "'", int21 == 21);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("-00:00:00.001", (java.lang.Number) 100, (java.lang.Number) 0, (java.lang.Number) (short) 10);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNull(durationFieldType6);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        int int3 = periodType2.size();
        org.joda.time.PeriodType periodType4 = periodType2.withMinutesRemoved();
        org.joda.time.PeriodType periodType5 = periodType2.withMillisRemoved();
        org.joda.time.PeriodType periodType6 = periodType2.withMonthsRemoved();
        org.joda.time.Period period7 = new org.joda.time.Period(34L, (long) (-34), periodType2);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (-1), chronology3);
        org.joda.time.Period period6 = period4.plusWeeks((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period4.toDurationFrom(readableInstant7);
        int int10 = period4.getValue((int) (short) 1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long11 = dateTimeZone8.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.Chronology chronology13 = iSOChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        try {
            long long18 = iSOChronology1.getDateTimeMillis(0, (int) (byte) 100, 4, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
        org.joda.time.DurationField durationField3 = iSOChronology1.hours();
        long long6 = durationField3.subtract((-6652800000L), (long) (short) 0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-6652800000L) + "'", long6 == (-6652800000L));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField7 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported");
        org.joda.time.Period period10 = new org.joda.time.Period((int) (short) 1, (int) (byte) 0, (int) (short) 10, 100, 10, 0, (int) (short) -1, (int) '#');
        boolean boolean11 = jodaTimePermission1.equals((java.lang.Object) 10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        long long17 = iSOChronology13.add(0L, (long) 1, (int) ' ');
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval21);
        org.joda.time.Period period23 = new org.joda.time.Period((long) 'a', (long) 0, periodType20, chronology22);
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval27 = null;
        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval27);
        org.joda.time.Period period29 = new org.joda.time.Period((long) 'a', (long) 0, periodType26, chronology28);
        org.joda.time.Period period30 = period23.withPeriodType(periodType26);
        org.joda.time.format.PeriodFormatter periodFormatter31 = null;
        java.lang.String str32 = period30.toString(periodFormatter31);
        org.joda.time.Seconds seconds33 = period30.toStandardSeconds();
        long long36 = iSOChronology13.add((org.joda.time.ReadablePeriod) period30, (long) (short) -1, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology13.minuteOfHour();
        boolean boolean38 = jodaTimePermission1.equals((java.lang.Object) dateTimeField37);
        java.lang.String str39 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 32L + "'", long17 == 32L);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PT-0.097S" + "'", str32.equals("PT-0.097S"));
        org.junit.Assert.assertNotNull(seconds33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1L) + "'", long36 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported\")" + "'", str39.equals("(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported\")"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        org.joda.time.DurationField durationField18 = offsetDateTimeField15.getLeapDurationField();
        try {
            long long21 = offsetDateTimeField15.add((long) (-34), (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(durationField18);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType8 = periodType4.withYearsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType8);
        org.joda.time.PeriodType periodType10 = periodType8.withDaysRemoved();
        org.joda.time.PeriodType periodType11 = periodType8.withYearsRemoved();
        org.joda.time.PeriodType periodType12 = periodType11.withHoursRemoved();
        org.joda.time.PeriodType periodType13 = periodType11.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant22, readableInstant23);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (-1), chronology24);
        org.joda.time.Period period27 = period25.withDays(0);
        int[] intArray28 = period27.getValues();
        int int29 = offsetDateTimeField15.getMinimumValue(readablePartial20, intArray28);
        org.joda.time.ReadablePartial readablePartial30 = null;
        java.util.Locale locale31 = null;
        try {
            java.lang.String str32 = offsetDateTimeField15.getAsShortText(readablePartial30, locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800086L + "'", long19 == 62135596800086L);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        int int18 = offsetDateTimeField15.getOffset();
        int int19 = offsetDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField15.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 20 + "'", int18 == 20);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((-1));
        org.joda.time.Period period3 = period1.withMonths((int) (byte) 10);
        org.joda.time.Period period5 = period1.withMonths(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant22, readableInstant23);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (-1), chronology24);
        org.joda.time.Period period27 = period25.withDays(0);
        int[] intArray28 = period27.getValues();
        int int29 = offsetDateTimeField15.getMinimumValue(readablePartial20, intArray28);
        java.lang.String str30 = offsetDateTimeField15.getName();
        boolean boolean32 = offsetDateTimeField15.isLeap((long) ' ');
        org.joda.time.ReadablePartial readablePartial33 = null;
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField15.getAsShortText(readablePartial33, (int) 'a', locale35);
        org.joda.time.ReadablePartial readablePartial37 = null;
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant41, readableInstant42);
        org.joda.time.Period period44 = new org.joda.time.Period((long) (short) -1, 10L, chronology43);
        int int45 = period44.getDays();
        org.joda.time.Days days46 = period44.toStandardDays();
        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period48 = period44.normalizedStandard(periodType47);
        int[] intArray49 = period48.getValues();
        try {
            int[] intArray51 = offsetDateTimeField15.add(readablePartial37, 4, intArray49, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800086L + "'", long19 == 62135596800086L);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "era" + "'", str30.equals("era"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "97" + "'", str36.equals("97"));
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(days46);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(intArray49);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = lenientChronology6.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(10, (int) '#', 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long10 = dateTimeZone7.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        org.joda.time.Chronology chronology12 = iSOChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone11);
        org.joda.time.Chronology chronology13 = iSOChronology1.withUTC();
        org.joda.time.ReadablePartial readablePartial14 = null;
        try {
            int[] intArray16 = iSOChronology1.get(readablePartial14, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(104, 800001000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 800001000");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.halfdayOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        try {
            int[] intArray11 = lenientChronology6.get(readablePeriod9, (long) 800000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("PT-0.001S", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField11 = new org.joda.time.field.DividedDateTimeField(dateTimeField8, dateTimeFieldType9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, 10L, chronology6);
        int int8 = period7.getDays();
        org.joda.time.Days days9 = period7.toStandardDays();
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period11 = period7.normalizedStandard(periodType10);
        int[] intArray14 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L, 34L);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.monthOfYear();
        int int16 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField17 = gregorianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str1.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(days9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("97");
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, dateTimeFieldType16, 640000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName((long) 36000000, locale6);
        int int9 = fixedDateTimeZone4.getOffsetFromLocal(34L);
        int int11 = fixedDateTimeZone4.getStandardOffset((-33L));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        long long18 = fixedDateTimeZone16.previousTransition((long) 8);
        org.joda.time.ReadableInstant readableInstant19 = null;
        int int20 = fixedDateTimeZone16.getOffset(readableInstant19);
        long long22 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone16, (long) 80000);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.001" + "'", str7.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 8L + "'", long18 == 8L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 80000L + "'", long22 == 80000L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getStandardOffset((long) 10000);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField6 = iSOChronology1.years();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) -1, 10L, chronology11);
        int int13 = period12.getDays();
        org.joda.time.Period period15 = period12.withMillis((int) (short) 1);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) (short) 1);
        long long20 = iSOChronology1.add(0L, 8L, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology1.weekOfWeekyear();
        java.lang.String str22 = iSOChronology1.toString();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder23 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder34 = dateTimeZoneBuilder23.addRecurringSavings("GregorianChronology[America/Los_Angeles]", (int) (short) 10, 0, (int) (byte) -1, 'a', (int) 'a', 10, 0, true, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone37 = dateTimeZoneBuilder34.toDateTimeZone("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported", true);
        org.joda.time.Chronology chronology38 = iSOChronology1.withZone(dateTimeZone37);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[-00:00:00.001]" + "'", str22.equals("ISOChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder34);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(chronology38);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("-00:00:00.001");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"-00:00:00.001/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long6 = iSOChronology2.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.Chronology chronology9 = iSOChronology2.withZone(dateTimeZone8);
        org.joda.time.DurationField durationField10 = iSOChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField14 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType12, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-65L) + "'", long6 == (-65L));
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("");
        illegalFieldValueException2.prependMessage("PeriodType[DayTime]");
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException2.getSuppressed();
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException11.prependMessage("");
        java.lang.String str14 = illegalFieldValueException11.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = illegalFieldValueException11.getDateTimeFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException11);
        java.lang.Throwable[] throwableArray17 = illegalFieldValueException2.getSuppressed();
        java.lang.String str18 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported" + "'", str14.equals("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported"));
        org.junit.Assert.assertNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.year();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology1.dayOfWeek();
        java.lang.String str10 = iSOChronology1.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[-00:00:00.001]" + "'", str10.equals("ISOChronology[-00:00:00.001]"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(97L, "org.joda.time.IllegalFieldValueException: Value 100 for -00:00:00.001 must be in the range [0,10]");
        java.lang.String str3 = illegalInstantException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.097 (org.joda.time.IllegalFieldValueException: Value 100 for -00:00:00.001 must be in the range [0,10])" + "'", str3.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.097 (org.joda.time.IllegalFieldValueException: Value 100 for -00:00:00.001 must be in the range [0,10])"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        long long5 = gregorianChronology0.add((long) 34, (long) 8, 640000);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 5120034L + "'", long5 == 5120034L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        int int21 = offsetDateTimeField15.getLeapAmount((long) (byte) 0);
        try {
            long long24 = offsetDateTimeField15.add(970L, (-62135596799999L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800086L + "'", long19 == 62135596800086L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = null;
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) 0);
        org.joda.time.Period period3 = period1.plusHours(34);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("");
        illegalFieldValueException2.prependMessage("PeriodType[DayTime]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException9.prependMessage("");
        illegalFieldValueException9.prependMessage("PeriodType[DayTime]");
        java.lang.Throwable[] throwableArray14 = illegalFieldValueException9.getSuppressed();
        boolean boolean15 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException18.prependMessage("");
        java.lang.String str21 = illegalFieldValueException18.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = illegalFieldValueException18.getDateTimeFieldType();
        illegalFieldValueException9.addSuppressed((java.lang.Throwable) illegalFieldValueException18);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException18);
        java.lang.Throwable[] throwableArray25 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported" + "'", str21.equals("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported"));
        org.junit.Assert.assertNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(throwableArray25);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "21");
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        int int21 = offsetDateTimeField15.getLeapAmount((long) (byte) 0);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField15.getAsText((int) (short) -1, locale23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval30 = null;
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) 'a', (long) 0, periodType29, chronology31);
        int[] intArray33 = period32.getValues();
        java.util.Locale locale35 = null;
        try {
            int[] intArray36 = offsetDateTimeField15.set(readablePartial25, (int) 'a', intArray33, "era", locale35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"era\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800086L + "'", long19 == 62135596800086L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "-1" + "'", str24.equals("-1"));
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.dayOfMonth();
        org.joda.time.DurationField durationField8 = iSOChronology1.years();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long4 = dateTimeZone1.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone6 = cachedDateTimeZone5.getUncachedZone();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        long long13 = lenientChronology6.getDateTimeMillis((long) 4, (int) (short) 1, 0, 10000, (int) '#');
        org.joda.time.DateTimeField dateTimeField14 = lenientChronology6.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField15 = lenientChronology6.yearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 13600036L + "'", long13 == 13600036L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        org.joda.time.DurationField durationField8 = lenientChronology6.hours();
        long long11 = durationField8.subtract((-65L), 100);
        long long14 = durationField8.subtract(0L, (int) (short) 0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-360000065L) + "'", long11 == (-360000065L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (byte) 0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long4 = dateTimeZone1.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        boolean boolean8 = cachedDateTimeZone5.equals((java.lang.Object) readableInterval6);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        java.lang.String str7 = lenientChronology6.toString();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.centuryOfEra();
        org.joda.time.PeriodType periodType9 = null;
        try {
            org.joda.time.Period period10 = new org.joda.time.Period((java.lang.Object) lenientChronology6, periodType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.LenientChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "LenientChronology[ISOChronology[-00:00:00.001]]" + "'", str7.equals("LenientChronology[ISOChronology[-00:00:00.001]]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) '4');
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, 10L, chronology6);
        int int8 = period7.getDays();
        org.joda.time.Period period10 = period7.withMillis((int) (short) 1);
        org.joda.time.Period period12 = period10.plusSeconds((int) (short) 10);
        org.joda.time.Period period13 = period1.plus((org.joda.time.ReadablePeriod) period10);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) 'a', (long) 0, periodType16, chronology18);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval23 = null;
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval23);
        org.joda.time.Period period25 = new org.joda.time.Period((long) 'a', (long) 0, periodType22, chronology24);
        org.joda.time.Period period26 = period19.withPeriodType(periodType22);
        org.joda.time.format.PeriodFormatter periodFormatter27 = null;
        java.lang.String str28 = period26.toString(periodFormatter27);
        int int29 = period26.getYears();
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.seconds();
        int int31 = periodType30.size();
        org.joda.time.PeriodType periodType32 = periodType30.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType34 = periodType30.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(durationFieldType34, "PT0.011S");
        org.joda.time.Period period38 = period26.withField(durationFieldType34, (int) '4');
        int int39 = period13.indexOf(durationFieldType34);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "PT-0.097S" + "'", str28.equals("PT-0.097S"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 0, (int) (byte) -1, (-34), 2);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, 10L, chronology6);
        int int8 = period7.getDays();
        org.joda.time.Days days9 = period7.toStandardDays();
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period11 = period7.normalizedStandard(periodType10);
        int[] intArray14 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L, 34L);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField16 = gregorianChronology0.months();
        org.joda.time.DurationField durationField17 = gregorianChronology0.months();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str1.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(days9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) 0);
        org.joda.time.Period period3 = period1.multipliedBy((int) (byte) 1);
        int int4 = period1.getSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, 10L, chronology6);
        int int8 = period7.getDays();
        org.joda.time.Days days9 = period7.toStandardDays();
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period11 = period7.normalizedStandard(periodType10);
        int[] intArray14 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L, 34L);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.monthOfYear();
        int int16 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.seconds();
        org.joda.time.DurationFieldType durationFieldType18 = null;
        boolean boolean19 = periodType17.isSupported(durationFieldType18);
        org.joda.time.PeriodType periodType20 = org.joda.time.DateTimeUtils.getPeriodType(periodType17);
        boolean boolean21 = gregorianChronology0.equals((java.lang.Object) periodType17);
        org.joda.time.PeriodType periodType22 = periodType17.withWeeksRemoved();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str1.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(days9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(periodType22);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
        boolean boolean22 = offsetDateTimeField15.isSupported();
        long long24 = offsetDateTimeField15.roundFloor(62135596800086L);
        try {
            long long27 = offsetDateTimeField15.getDifferenceAsLong(97L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800086L + "'", long19 == 62135596800086L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9223372036854775808L) + "'", long21 == (-9223372036854775808L));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62135596799999L) + "'", long24 == (-62135596799999L));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
        int int22 = offsetDateTimeField15.getMaximumValue();
        java.lang.String str23 = offsetDateTimeField15.toString();
        java.lang.String str25 = offsetDateTimeField15.getAsText(970L);
        long long27 = offsetDateTimeField15.remainder(62135596800086L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800086L + "'", long19 == 62135596800086L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9223372036854775808L) + "'", long21 == (-9223372036854775808L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 21 + "'", int22 == 21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "DateTimeField[era]" + "'", str23.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "21" + "'", str25.equals("21"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 124271193600085L + "'", long27 == 124271193600085L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.DurationField durationField4 = iSOChronology2.hours();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        long long10 = iSOChronology6.add((long) '4', 0L, (int) (byte) 100);
        org.joda.time.DurationField durationField11 = iSOChronology6.hours();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField12 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField4, durationField11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-360000065L), (long) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-360000065) + "'", int2 == (-360000065));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("-01:00");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"-01:00/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, 10L, chronology17);
        org.joda.time.Period period20 = period18.plusMonths(0);
        org.joda.time.Period period22 = period20.minusSeconds((int) (byte) 10);
        org.joda.time.Period period23 = period12.withFields((org.joda.time.ReadablePeriod) period20);
        int int24 = period20.getWeeks();
        org.joda.time.Days days25 = period20.toStandardDays();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(days25);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.Period period8 = new org.joda.time.Period(800001000, 0, 0, 104, 10000, 20, (int) (short) 0, 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.DurationField durationField6 = iSOChronology1.days();
        java.lang.String str7 = iSOChronology1.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[-00:00:00.001]" + "'", str7.equals("ISOChronology[-00:00:00.001]"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant22, readableInstant23);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (-1), chronology24);
        org.joda.time.Period period27 = period25.withDays(0);
        int[] intArray28 = period27.getValues();
        int int29 = offsetDateTimeField15.getMinimumValue(readablePartial20, intArray28);
        boolean boolean31 = offsetDateTimeField15.isLeap((-62135596799999L));
        java.util.Locale locale34 = null;
        try {
            long long35 = offsetDateTimeField15.set((long) (byte) 1, "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported\")", locale34);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported\")\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800086L + "'", long19 == 62135596800086L);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.plusMillis((int) '#');
        org.joda.time.Period period6 = period4.withMinutes((-360000065));
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.Period period4 = new org.joda.time.Period(10, 7, 32000, 10000);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long4 = dateTimeZone1.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone6 = cachedDateTimeZone5.getUncachedZone();
        java.lang.String str8 = cachedDateTimeZone5.getName(97L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-00:00:00.001" + "'", str8.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.Period period1 = org.joda.time.Period.years(20);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        int int2 = periodType1.size();
        org.joda.time.PeriodType periodType3 = periodType1.withMinutesRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.monthOfYear();
        org.joda.time.Period period6 = new org.joda.time.Period(0L, periodType3, (org.joda.time.Chronology) gregorianChronology4);
        int int7 = periodType3.size();
        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("-00:00:00.001", (java.lang.Number) 100, (java.lang.Number) 0, (java.lang.Number) (short) 10);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long8 = cachedDateTimeZone4.convertLocalToUTC((long) 10, true, (long) (short) 10);
        java.lang.String str10 = cachedDateTimeZone4.getShortName(32L);
        java.util.TimeZone timeZone11 = cachedDateTimeZone4.toTimeZone();
        java.util.TimeZone timeZone12 = cachedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 11L + "'", long8 == 11L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-00:00:00.001" + "'", str10.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.halfdayOfDay();
        org.joda.time.DurationField durationField9 = lenientChronology6.weeks();
        org.joda.time.DateTimeField dateTimeField10 = lenientChronology6.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        try {
            long long22 = offsetDateTimeField15.add((-115199990L), 62135596800086L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800086L + "'", long19 == 62135596800086L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant6, readableDuration7);
        long long11 = iSOChronology1.add((org.joda.time.ReadablePeriod) period8, (long) 1, (int) ' ');
        org.joda.time.Chronology chronology12 = iSOChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.dayOfYear();
        long long17 = iSOChronology1.add(100L, 34L, 36000000);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.yearOfEra();
        boolean boolean23 = iSOChronology1.equals((java.lang.Object) dateTimeField22);
        org.joda.time.ReadablePartial readablePartial24 = null;
        try {
            int[] intArray26 = iSOChronology1.get(readablePartial24, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1224000100L + "'", long17 == 1224000100L);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        int int4 = periodType3.size();
        org.joda.time.PeriodType periodType5 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType7 = periodType3.getFieldType(0);
        int int8 = periodType0.indexOf(durationFieldType7);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) (short) -1);
        int int13 = preciseDurationField10.getDifference(0L, (long) 1);
        long long16 = preciseDurationField10.getMillis(640000, (-6652800000L));
        java.lang.String str17 = preciseDurationField10.getName();
        org.joda.time.DurationField durationField18 = null;
        try {
            int int19 = preciseDurationField10.compareTo(durationField18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-640000L) + "'", long16 == (-640000L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "seconds" + "'", str17.equals("seconds"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType6 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType7 = periodType2.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        java.lang.String str7 = lenientChronology6.toString();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.centuryOfEra();
        java.lang.String str9 = lenientChronology6.toString();
        org.joda.time.DurationField durationField10 = lenientChronology6.seconds();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "LenientChronology[ISOChronology[-00:00:00.001]]" + "'", str7.equals("LenientChronology[ISOChronology[-00:00:00.001]]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LenientChronology[ISOChronology[-00:00:00.001]]" + "'", str9.equals("LenientChronology[ISOChronology[-00:00:00.001]]"));
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "100");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (-1), chronology3);
        org.joda.time.Period period6 = period4.withDays(0);
        org.joda.time.Period period8 = period6.minusWeeks(0);
        org.joda.time.Period period10 = period8.plusMinutes((int) 'a');
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "org.joda.time.IllegalFieldValueException: Value -1 for PT-0.097S must not be smaller than 1");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period4 = new org.joda.time.Period(11L, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.Chronology chronology5 = gregorianChronology3.withUTC();
        org.joda.time.Period period6 = new org.joda.time.Period(62135596800086L, (long) '4', (org.joda.time.Chronology) gregorianChronology3);
        java.lang.String str7 = gregorianChronology3.toString();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str7.equals("GregorianChronology[-00:00:00.001]"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant6, readableDuration7);
        long long11 = iSOChronology1.add((org.joda.time.ReadablePeriod) period8, (long) 1, (int) ' ');
        org.joda.time.DurationField durationField12 = iSOChronology1.months();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField14 = iSOChronology1.hours();
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant16, readableInstant17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) (-1), chronology18);
        org.joda.time.Period period21 = period19.withDays(0);
        int[] intArray22 = period21.getValues();
        boolean boolean23 = iSOChronology1.equals((java.lang.Object) period21);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) 0, periodType5, chronology7);
        org.joda.time.PeriodType periodType9 = periodType5.withYearsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType9);
        org.joda.time.PeriodType periodType11 = periodType9.withHoursRemoved();
        org.joda.time.Period period12 = new org.joda.time.Period(10L, periodType9);
        org.joda.time.PeriodType periodType13 = periodType9.withHoursRemoved();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.standard();
        boolean boolean15 = periodType9.equals((java.lang.Object) periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.seconds();
        int int17 = periodType16.size();
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.seconds();
        int int20 = periodType19.size();
        org.joda.time.PeriodType periodType21 = periodType19.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = periodType16.indexOf(durationFieldType23);
        int int25 = periodType9.indexOf(durationFieldType23);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType23, 0L);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType23, 0L);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        long long35 = iSOChronology31.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField36 = iSOChronology31.years();
        java.lang.Class<?> wildcardClass37 = iSOChronology31.getClass();
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology31.halfdayOfDay();
        org.joda.time.DurationField durationField39 = iSOChronology31.halfdays();
        int int40 = preciseDurationField29.compareTo(durationField39);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-65L) + "'", long35 == (-65L));
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField6 = iSOChronology1.years();
        org.joda.time.ReadablePartial readablePartial7 = null;
        try {
            long long9 = iSOChronology1.set(readablePartial7, 52L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Standard", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Standard/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
        boolean boolean22 = offsetDateTimeField15.isSupported();
        long long24 = offsetDateTimeField15.roundFloor(62135596800086L);
        java.lang.String str26 = offsetDateTimeField15.getAsShortText((-33L));
        try {
            long long29 = offsetDateTimeField15.getDifferenceAsLong(97L, (long) 20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800086L + "'", long19 == 62135596800086L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9223372036854775808L) + "'", long21 == (-9223372036854775808L));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62135596799999L) + "'", long24 == (-62135596799999L));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "21" + "'", str26.equals("21"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        int int4 = periodType3.size();
        org.joda.time.PeriodType periodType5 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType7 = periodType3.getFieldType(0);
        int int8 = periodType0.indexOf(durationFieldType7);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) (short) -1);
        boolean boolean11 = preciseDurationField10.isSupported();
        long long14 = preciseDurationField10.getDifferenceAsLong((long) 36000000, (-210858120000000L));
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-210858156000000L) + "'", long14 == (-210858156000000L));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        org.joda.time.DurationField durationField18 = offsetDateTimeField15.getLeapDurationField();
        try {
            int int21 = offsetDateTimeField15.getDifference(0L, (long) 10000);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(durationField18);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.Period period1 = new org.joda.time.Period(13600036L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long4 = gregorianChronology0.add(0L, (long) 'a', (int) (byte) 0);
        org.joda.time.DurationField durationField5 = gregorianChronology0.seconds();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis((int) 'a', (-1), (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Seconds");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Seconds/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        java.util.Locale locale18 = null;
        int int19 = offsetDateTimeField15.getMaximumTextLength(locale18);
        long long21 = offsetDateTimeField15.roundHalfFloor(383999999990L);
        try {
            long long24 = offsetDateTimeField15.getDifferenceAsLong((long) (short) 10, (-1560628303091L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62135596799999L) + "'", long21 == (-62135596799999L));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.weeks();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        try {
            int int4 = period2.getValue((-360000065));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.secondOfMinute();
        java.lang.String str9 = lenientChronology6.toString();
        java.lang.String str10 = lenientChronology6.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LenientChronology[ISOChronology[-00:00:00.001]]" + "'", str9.equals("LenientChronology[ISOChronology[-00:00:00.001]]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "LenientChronology[ISOChronology[-00:00:00.001]]" + "'", str10.equals("LenientChronology[ISOChronology[-00:00:00.001]]"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(608003, 608003);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1216006 + "'", int2 == 1216006);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (byte) 0, periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        int int4 = periodType3.size();
        org.joda.time.PeriodType periodType5 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType7 = periodType3.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(durationFieldType7, "PT0.011S");
        org.joda.time.Period period11 = period2.withFieldAdded(durationFieldType7, 7);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        int int19 = offsetDateTimeField15.getLeapAmount((-141746760000000L));
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        long long28 = iSOChronology24.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology24.era();
        org.joda.time.Period period30 = new org.joda.time.Period((long) 'a', (-65L), (org.joda.time.Chronology) iSOChronology24);
        org.joda.time.DurationField durationField31 = iSOChronology24.months();
        org.joda.time.Period period33 = org.joda.time.Period.minutes(8);
        int[] intArray36 = iSOChronology24.get((org.joda.time.ReadablePeriod) period33, (long) 100, 0L);
        int int37 = offsetDateTimeField15.getMaximumValue(readablePartial20, intArray36);
        long long39 = offsetDateTimeField15.roundHalfCeiling(52L);
        org.joda.time.ReadablePartial readablePartial40 = null;
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
        long long49 = iSOChronology45.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology50 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology45);
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology45.year();
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology45.minuteOfHour();
        org.joda.time.Period period53 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology45);
        org.joda.time.DurationField durationField54 = iSOChronology45.minutes();
        org.joda.time.DateTimeField dateTimeField55 = iSOChronology45.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, 20);
        int int59 = offsetDateTimeField57.getLeapAmount(1560628303058L);
        int int61 = offsetDateTimeField57.getLeapAmount((-141746760000000L));
        org.joda.time.ReadablePartial readablePartial62 = null;
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone65);
        long long70 = iSOChronology66.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField71 = iSOChronology66.era();
        org.joda.time.Period period72 = new org.joda.time.Period((long) 'a', (-65L), (org.joda.time.Chronology) iSOChronology66);
        org.joda.time.DurationField durationField73 = iSOChronology66.months();
        org.joda.time.Period period75 = org.joda.time.Period.minutes(8);
        int[] intArray78 = iSOChronology66.get((org.joda.time.ReadablePeriod) period75, (long) 100, 0L);
        int int79 = offsetDateTimeField57.getMaximumValue(readablePartial62, intArray78);
        try {
            int[] intArray81 = offsetDateTimeField15.addWrapPartial(readablePartial40, 608003, intArray78, 800001000);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 608003");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 32L + "'", long28 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 21 + "'", int37 == 21);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-62135596799999L) + "'", long39 == (-62135596799999L));
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-65L) + "'", long49 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(iSOChronology66);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 32L + "'", long70 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField73);
        org.junit.Assert.assertNotNull(period75);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 21 + "'", int79 == 21);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.withYears((int) (byte) 0);
        org.joda.time.Period period6 = period2.plusDays((int) ' ');
        int int7 = period6.getDays();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-799900L), (long) 104);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-83189600) + "'", int2 == (-83189600));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-1560628303091L), (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-49940105698912L) + "'", long2 == (-49940105698912L));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getOffset(97L);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long13 = iSOChronology9.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology14 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 0, (org.joda.time.Chronology) iSOChronology9);
        int int16 = period15.getYears();
        org.joda.time.Period period18 = period15.withYears((int) 'a');
        org.joda.time.Period period20 = period15.plusHours((int) (short) 1);
        boolean boolean21 = fixedDateTimeZone4.equals((java.lang.Object) period15);
        org.joda.time.Period period23 = period15.withMonths((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(period23);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long13 = iSOChronology9.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) 'a', (long) 0, periodType16, chronology18);
        org.joda.time.PeriodType periodType20 = periodType16.withWeeksRemoved();
        boolean boolean21 = iSOChronology9.equals((java.lang.Object) periodType20);
        try {
            org.joda.time.Period period22 = new org.joda.time.Period(0, 6, 2, (int) (short) 10, 33, 21, (int) '4', 32000, periodType20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-65L) + "'", long13 == (-65L));
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.minusYears((int) 'a');
        org.joda.time.Period period10 = period5.multipliedBy(0);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant22, readableInstant23);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (-1), chronology24);
        org.joda.time.Period period27 = period25.withDays(0);
        int[] intArray28 = period27.getValues();
        int int29 = offsetDateTimeField15.getMinimumValue(readablePartial20, intArray28);
        boolean boolean31 = offsetDateTimeField15.isLeap((-62135596799999L));
        org.joda.time.DurationField durationField32 = offsetDateTimeField15.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800086L + "'", long19 == 62135596800086L);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(durationField32);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported");
        org.joda.time.Period period10 = new org.joda.time.Period((int) (short) 1, (int) (byte) 0, (int) (short) 10, 100, 10, 0, (int) (short) -1, (int) '#');
        boolean boolean11 = jodaTimePermission1.equals((java.lang.Object) 10);
        java.security.PermissionCollection permissionCollection12 = jodaTimePermission1.newPermissionCollection();
        java.security.PermissionCollection permissionCollection13 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(permissionCollection12);
        org.junit.Assert.assertNotNull(permissionCollection13);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        long long17 = offsetDateTimeField15.roundHalfEven(97L);
        java.lang.String str19 = offsetDateTimeField15.getAsText((long) 'a');
        int int21 = offsetDateTimeField15.getLeapAmount(34L);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int[] intArray24 = null;
        java.util.Locale locale26 = null;
        try {
            int[] intArray27 = offsetDateTimeField15.set(readablePartial22, 1216006, intArray24, "hi!", locale26);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135596799999L) + "'", long17 == (-62135596799999L));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "21" + "'", str19.equals("21"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, 10L, chronology6);
        int int8 = period7.getDays();
        org.joda.time.Period period10 = period7.withMillis((int) (short) 1);
        java.lang.Object obj11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) 'a', (long) 0, periodType16, chronology18);
        org.joda.time.PeriodType periodType20 = periodType16.withYearsRemoved();
        org.joda.time.Period period21 = new org.joda.time.Period(readableDuration12, readableInstant13, periodType20);
        java.lang.String str22 = periodType20.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period24 = new org.joda.time.Period(obj11, periodType20, (org.joda.time.Chronology) gregorianChronology23);
        org.joda.time.PeriodType periodType25 = periodType20.withHoursRemoved();
        org.joda.time.Period period26 = period7.withPeriodType(periodType25);
        org.joda.time.PeriodType periodType27 = org.joda.time.DateTimeUtils.getPeriodType(periodType25);
        org.joda.time.PeriodType periodType28 = org.joda.time.DateTimeUtils.getPeriodType(periodType27);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str30 = gregorianChronology29.toString();
        org.joda.time.DurationField durationField31 = gregorianChronology29.weekyears();
        org.joda.time.DurationField durationField32 = gregorianChronology29.centuries();
        org.joda.time.Chronology chronology33 = gregorianChronology29.withUTC();
        org.joda.time.chrono.LenientChronology lenientChronology34 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology29);
        org.joda.time.DurationField durationField35 = lenientChronology34.hours();
        org.joda.time.Chronology chronology36 = lenientChronology34.withUTC();
        org.joda.time.Period period37 = new org.joda.time.Period(52L, (long) 1, periodType28, (org.joda.time.Chronology) lenientChronology34);
        try {
            org.joda.time.Period period39 = period37.withWeeks((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PeriodType[DayTime]" + "'", str22.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str30.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(lenientChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(chronology36);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.Period period1 = new org.joda.time.Period((long) ' ');
        org.joda.time.Period period3 = period1.minusSeconds((int) (short) -1);
        org.joda.time.PeriodType periodType4 = period1.getPeriodType();
        org.joda.time.Period period6 = org.joda.time.Period.days((int) (short) 0);
        org.joda.time.Period period8 = period6.multipliedBy((int) (byte) 1);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.seconds();
        int int10 = periodType9.size();
        org.joda.time.PeriodType periodType11 = periodType9.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType13 = periodType9.getFieldType(0);
        java.lang.Number number14 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(durationFieldType13, number14, (java.lang.Number) (-863999999900L), (java.lang.Number) 2440587.5000011576d);
        int int18 = period8.indexOf(durationFieldType13);
        int int19 = periodType4.indexOf(durationFieldType13);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        long long17 = offsetDateTimeField15.roundHalfEven(97L);
        java.lang.String str19 = offsetDateTimeField15.getAsText((long) 'a');
        java.util.Locale locale20 = null;
        int int21 = offsetDateTimeField15.getMaximumShortTextLength(locale20);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135596799999L) + "'", long17 == (-62135596799999L));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "21" + "'", str19.equals("21"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.Period period1 = org.joda.time.Period.hours(0);
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period3 = period1.normalizedStandard(periodType2);
        org.joda.time.PeriodType periodType4 = periodType2.withMonthsRemoved();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-360000065));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        java.lang.String str7 = lenientChronology6.toString();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.centuryOfEra();
        org.joda.time.Chronology chronology9 = lenientChronology6.withUTC();
        org.joda.time.DurationField durationField10 = lenientChronology6.months();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "LenientChronology[ISOChronology[-00:00:00.001]]" + "'", str7.equals("LenientChronology[ISOChronology[-00:00:00.001]]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weekyears();
        org.joda.time.DurationField durationField3 = gregorianChronology0.centuries();
        org.joda.time.Chronology chronology4 = gregorianChronology0.withUTC();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology5.dayOfYear();
        org.joda.time.Chronology chronology7 = lenientChronology5.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str1.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField6 = iSOChronology1.years();
        java.lang.Class<?> wildcardClass7 = iSOChronology1.getClass();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology1.halfdayOfDay();
        org.joda.time.DurationField durationField9 = iSOChronology1.halfdays();
        java.lang.String str10 = iSOChronology1.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[-00:00:00.001]" + "'", str10.equals("ISOChronology[-00:00:00.001]"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        org.joda.time.DurationField durationField16 = offsetDateTimeField15.getRangeDurationField();
        boolean boolean18 = offsetDateTimeField15.isLeap((long) (short) 100);
        int int19 = offsetDateTimeField15.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        int int4 = periodType3.size();
        org.joda.time.PeriodType periodType5 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType7 = periodType3.getFieldType(0);
        int int8 = periodType0.indexOf(durationFieldType7);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) (short) -1);
        int int13 = preciseDurationField10.getDifference(0L, (long) 1);
        int int16 = preciseDurationField10.getValue((long) 34, 618L);
        long long18 = preciseDurationField10.getMillis(3245547120001L);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-34) + "'", int16 == (-34));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3245547120001L) + "'", long18 == (-3245547120001L));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis((long) 7, 800000, 800000, 8, 21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 0, 7, 800001000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 32, 6, 80000);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forID("-00:00:00.001");
        org.joda.time.Chronology chronology10 = lenientChronology6.withZone(dateTimeZone9);
        java.lang.Object obj11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) 'a', (long) 0, periodType16, chronology18);
        org.joda.time.PeriodType periodType20 = periodType16.withYearsRemoved();
        org.joda.time.Period period21 = new org.joda.time.Period(readableDuration12, readableInstant13, periodType20);
        java.lang.String str22 = periodType20.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period24 = new org.joda.time.Period(obj11, periodType20, (org.joda.time.Chronology) gregorianChronology23);
        boolean boolean25 = lenientChronology6.equals(obj11);
        org.joda.time.DurationField durationField26 = lenientChronology6.weeks();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PeriodType[DayTime]" + "'", str22.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(durationField26);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[America/Los_Angeles]", (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder3.setStandardOffset(0);
        java.io.OutputStream outputStream7 = null;
        try {
            dateTimeZoneBuilder5.writeTo("PT-0.097S", outputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        int int18 = offsetDateTimeField15.getOffset();
        int int19 = offsetDateTimeField15.getMinimumValue();
        long long21 = offsetDateTimeField15.roundHalfCeiling(3L);
        try {
            int int24 = offsetDateTimeField15.getDifference((long) 3, (-863999999900L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 20 + "'", int18 == 20);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62135596799999L) + "'", long21 == (-62135596799999L));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        long long17 = offsetDateTimeField15.roundHalfEven(97L);
        java.lang.String str19 = offsetDateTimeField15.getAsText((long) 'a');
        int int21 = offsetDateTimeField15.getLeapAmount(34L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        long long27 = iSOChronology23.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableDuration readableDuration29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant28, readableDuration29);
        long long33 = iSOChronology23.add((org.joda.time.ReadablePeriod) period30, (long) 1, (int) ' ');
        org.joda.time.DurationField durationField34 = iSOChronology23.months();
        try {
            org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) 34L, (org.joda.time.Chronology) iSOChronology23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135596799999L) + "'", long17 == (-62135596799999L));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "21" + "'", str19.equals("21"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-65L) + "'", long27 == (-65L));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1L + "'", long33 == 1L);
        org.junit.Assert.assertNotNull(durationField34);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        int int4 = periodType3.size();
        org.joda.time.PeriodType periodType5 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType7 = periodType3.getFieldType(0);
        int int8 = periodType0.indexOf(durationFieldType7);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) (short) -1);
        int int13 = preciseDurationField10.getDifference(0L, (long) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = gregorianChronology14.withZone(dateTimeZone16);
        boolean boolean18 = preciseDurationField10.equals((java.lang.Object) gregorianChronology14);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant23, readableInstant24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) -1, 10L, chronology25);
        int int27 = period26.getDays();
        org.joda.time.Period period29 = period26.withMillis((int) (short) 1);
        java.lang.Object obj30 = null;
        org.joda.time.ReadableDuration readableDuration31 = null;
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval36 = null;
        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
        org.joda.time.Period period38 = new org.joda.time.Period((long) 'a', (long) 0, periodType35, chronology37);
        org.joda.time.PeriodType periodType39 = periodType35.withYearsRemoved();
        org.joda.time.Period period40 = new org.joda.time.Period(readableDuration31, readableInstant32, periodType39);
        java.lang.String str41 = periodType39.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period43 = new org.joda.time.Period(obj30, periodType39, (org.joda.time.Chronology) gregorianChronology42);
        org.joda.time.PeriodType periodType44 = periodType39.withHoursRemoved();
        org.joda.time.Period period45 = period26.withPeriodType(periodType44);
        org.joda.time.PeriodType periodType46 = org.joda.time.DateTimeUtils.getPeriodType(periodType44);
        org.joda.time.Period period47 = new org.joda.time.Period(readableInstant19, readableInstant20, periodType46);
        int[] intArray50 = gregorianChronology14.get((org.joda.time.ReadablePeriod) period47, (-210865982400000L), (long) '4');
        org.joda.time.Days days51 = period47.toStandardDays();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PeriodType[DayTime]" + "'", str41.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(periodType46);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(days51);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (-1), chronology3);
        org.joda.time.Period period6 = period4.withMonths((int) (short) 10);
        org.joda.time.Weeks weeks7 = period4.toStandardWeeks();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(weeks7);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        java.lang.Object obj13 = null;
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period12, obj13);
        java.lang.Class<?> wildcardClass15 = period12.getClass();
        org.joda.time.Period period17 = period12.plusMillis(21);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType10 = periodType9.withSecondsRemoved();
        org.joda.time.PeriodType periodType11 = periodType9.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        long long17 = iSOChronology13.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        long long23 = iSOChronology13.add((org.joda.time.ReadablePeriod) period20, (long) 1, (int) ' ');
        org.joda.time.DurationField durationField24 = iSOChronology13.months();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology13.monthOfYear();
        org.joda.time.DurationField durationField26 = iSOChronology13.hours();
        org.joda.time.Period period27 = new org.joda.time.Period((-1L), periodType9, (org.joda.time.Chronology) iSOChronology13);
        try {
            org.joda.time.Period period28 = new org.joda.time.Period(4, 100, (-83189600), 800000, (-83189600), 0, 1, (int) (short) 100, periodType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-65L) + "'", long17 == (-65L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.withMillis((int) (short) 1);
        org.joda.time.Period period10 = period5.withMillis((int) (short) 1);
        org.joda.time.Period period12 = period5.plusHours(21);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        int int3 = periodType2.size();
        org.joda.time.PeriodType periodType4 = periodType2.withMinutesRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType4);
        java.lang.String str6 = periodType4.getName();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Seconds" + "'", str6.equals("Seconds"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.era();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        int int2 = periodType1.size();
        org.joda.time.PeriodType periodType3 = periodType1.withMonthsRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        int int5 = periodType4.size();
        org.joda.time.PeriodType periodType6 = periodType4.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType8 = periodType4.getFieldType(0);
        int int9 = periodType1.indexOf(durationFieldType8);
        org.joda.time.field.PreciseDurationField preciseDurationField11 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (short) -1);
        boolean boolean12 = preciseDurationField11.isSupported();
        org.joda.time.DurationField durationField13 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long16 = durationField13.subtract(100L, 800000);
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField17 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, (org.joda.time.DurationField) preciseDurationField11, durationField13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-799900L) + "'", long16 == (-799900L));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(800000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-800000) + "'", int1 == (-800000));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getOffset(97L);
        int int8 = fixedDateTimeZone4.getOffset(0L);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal(320L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.Period period8 = new org.joda.time.Period(640000, 2, 20, 608003, 36000000, 608003, (int) (byte) 0, 0);
        int int9 = period8.getWeeks();
        org.joda.time.Period period11 = period8.minusYears((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
        java.lang.String str23 = offsetDateTimeField15.getAsShortText((-115199968L));
        try {
            long long26 = offsetDateTimeField15.add(2704L, 1216006);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800086L + "'", long19 == 62135596800086L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9223372036854775808L) + "'", long21 == (-9223372036854775808L));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "21" + "'", str23.equals("21"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 100, (int) (short) 10, (int) 'a', (int) '4', (int) (short) 100, (int) '4', 0, (int) (byte) 1);
        org.joda.time.Period period10 = period8.multipliedBy(0);
        org.joda.time.Period period12 = period8.plusSeconds(800001000);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        java.lang.Object obj13 = null;
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period12, obj13);
        java.lang.Class<?> wildcardClass15 = period12.getClass();
        int int16 = period12.getWeeks();
        int int17 = period12.getSeconds();
        org.joda.time.Period period19 = period12.minusSeconds(10);
        org.joda.time.Period period21 = period12.withDays((int) 'a');
        try {
            org.joda.time.Period period23 = period21.plusYears(32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-7) + "'", int1 == (-7));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long4 = durationField1.subtract(100L, 800000);
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField5 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-799900L) + "'", long4 == (-799900L));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(2704L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2704L + "'", long2 == 2704L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getOffset(97L);
        int int8 = fixedDateTimeZone4.getOffset(0L);
        int int10 = fixedDateTimeZone4.getOffset((long) 10);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) 'a', (long) 0, periodType15, chronology17);
        org.joda.time.PeriodType periodType19 = periodType15.withYearsRemoved();
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration11, readableInstant12, periodType19);
        org.joda.time.PeriodType periodType21 = periodType19.withDaysRemoved();
        org.joda.time.PeriodType periodType22 = periodType19.withYearsRemoved();
        org.joda.time.PeriodType periodType23 = periodType22.withHoursRemoved();
        boolean boolean24 = fixedDateTimeZone4.equals((java.lang.Object) periodType22);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) 0, periodType5, chronology7);
        org.joda.time.PeriodType periodType9 = periodType5.withYearsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType9);
        org.joda.time.PeriodType periodType11 = periodType9.withHoursRemoved();
        org.joda.time.Period period12 = new org.joda.time.Period(10L, periodType9);
        org.joda.time.PeriodType periodType13 = periodType9.withHoursRemoved();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.standard();
        boolean boolean15 = periodType9.equals((java.lang.Object) periodType14);
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval22 = null;
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval22);
        org.joda.time.Period period24 = new org.joda.time.Period((long) 'a', (long) 0, periodType21, chronology23);
        org.joda.time.PeriodType periodType25 = periodType21.withYearsRemoved();
        org.joda.time.Period period26 = new org.joda.time.Period(readableDuration17, readableInstant18, periodType25);
        org.joda.time.PeriodType periodType27 = periodType25.withHoursRemoved();
        org.joda.time.Period period28 = new org.joda.time.Period(10L, periodType25);
        org.joda.time.PeriodType periodType29 = periodType25.withHoursRemoved();
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.standard();
        boolean boolean31 = periodType25.equals((java.lang.Object) periodType30);
        org.joda.time.PeriodType periodType32 = org.joda.time.PeriodType.seconds();
        int int33 = periodType32.size();
        org.joda.time.PeriodType periodType34 = periodType32.withMonthsRemoved();
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.seconds();
        int int36 = periodType35.size();
        org.joda.time.PeriodType periodType37 = periodType35.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType39 = periodType35.getFieldType(0);
        int int40 = periodType32.indexOf(durationFieldType39);
        int int41 = periodType25.indexOf(durationFieldType39);
        org.joda.time.field.PreciseDurationField preciseDurationField43 = new org.joda.time.field.PreciseDurationField(durationFieldType39, 0L);
        org.joda.time.field.PreciseDurationField preciseDurationField45 = new org.joda.time.field.PreciseDurationField(durationFieldType39, 0L);
        int int46 = periodType14.indexOf(durationFieldType39);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 3 + "'", int41 == 3);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) 0, periodType5, chronology7);
        org.joda.time.PeriodType periodType9 = periodType5.withYearsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType9);
        org.joda.time.PeriodType periodType11 = periodType9.withHoursRemoved();
        org.joda.time.Period period12 = new org.joda.time.Period(10L, periodType9);
        org.joda.time.PeriodType periodType13 = periodType9.withHoursRemoved();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.standard();
        boolean boolean15 = periodType9.equals((java.lang.Object) periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.seconds();
        int int17 = periodType16.size();
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.seconds();
        int int20 = periodType19.size();
        org.joda.time.PeriodType periodType21 = periodType19.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = periodType16.indexOf(durationFieldType23);
        int int25 = periodType9.indexOf(durationFieldType23);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType23, 0L);
        boolean boolean28 = preciseDurationField27.isPrecise();
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval35 = null;
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval35);
        org.joda.time.Period period37 = new org.joda.time.Period((long) 'a', (long) 0, periodType34, chronology36);
        org.joda.time.PeriodType periodType38 = periodType34.withYearsRemoved();
        org.joda.time.Period period39 = new org.joda.time.Period(readableDuration30, readableInstant31, periodType38);
        org.joda.time.PeriodType periodType40 = periodType38.withHoursRemoved();
        org.joda.time.Period period41 = new org.joda.time.Period(10L, periodType38);
        org.joda.time.PeriodType periodType42 = periodType38.withHoursRemoved();
        org.joda.time.PeriodType periodType43 = org.joda.time.PeriodType.standard();
        boolean boolean44 = periodType38.equals((java.lang.Object) periodType43);
        org.joda.time.PeriodType periodType45 = org.joda.time.PeriodType.seconds();
        int int46 = periodType45.size();
        org.joda.time.PeriodType periodType47 = periodType45.withMonthsRemoved();
        org.joda.time.PeriodType periodType48 = org.joda.time.PeriodType.seconds();
        int int49 = periodType48.size();
        org.joda.time.PeriodType periodType50 = periodType48.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType52 = periodType48.getFieldType(0);
        int int53 = periodType45.indexOf(durationFieldType52);
        int int54 = periodType38.indexOf(durationFieldType52);
        org.joda.time.field.PreciseDurationField preciseDurationField56 = new org.joda.time.field.PreciseDurationField(durationFieldType52, 0L);
        boolean boolean57 = preciseDurationField56.isPrecise();
        int int58 = preciseDurationField27.compareTo((org.joda.time.DurationField) preciseDurationField56);
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.chrono.ISOChronology iSOChronology60 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone59);
        long long64 = iSOChronology60.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField65 = iSOChronology60.years();
        long long69 = iSOChronology60.add((long) 0, 32L, (int) (byte) 10);
        org.joda.time.DurationField durationField70 = iSOChronology60.halfdays();
        int int71 = preciseDurationField27.compareTo(durationField70);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(periodType42);
        org.junit.Assert.assertNotNull(periodType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(periodType48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(periodType50);
        org.junit.Assert.assertNotNull(durationFieldType52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 3 + "'", int54 == 3);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(iSOChronology60);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-65L) + "'", long64 == (-65L));
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 320L + "'", long69 == 320L);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
    }
}

