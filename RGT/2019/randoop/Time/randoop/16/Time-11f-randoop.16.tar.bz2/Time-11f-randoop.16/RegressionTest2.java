import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(12800035L, 618L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7910421630L + "'", long2 == 7910421630L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        int int18 = offsetDateTimeField15.getOffset();
        org.joda.time.DurationField durationField19 = offsetDateTimeField15.getLeapDurationField();
        try {
            long long22 = offsetDateTimeField15.add((-33L), (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 20 + "'", int18 == 20);
        org.junit.Assert.assertNull(durationField19);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test003");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
//        org.joda.time.DurationField durationField37 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        long long39 = zeroIsMaxDateTimeField34.remainder((long) 4);
//        long long41 = zeroIsMaxDateTimeField34.roundFloor((long) 800001000);
//        org.joda.time.DurationField durationField42 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        org.joda.time.DurationField durationField43 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        long long45 = zeroIsMaxDateTimeField34.roundHalfFloor(124271193600085L);
//        java.lang.String str47 = zeroIsMaxDateTimeField34.getAsText(0L);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 800001000L + "'", long41 == 800001000L);
//        org.junit.Assert.assertNull(durationField42);
//        org.junit.Assert.assertNull(durationField43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 124271193600085L + "'", long45 == 124271193600085L);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1" + "'", str47.equals("1"));
//    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test004");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        java.lang.String str7 = lenientChronology6.toString();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.centuryOfEra();
//        java.lang.String str9 = lenientChronology6.toString();
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
//        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) -1, 10L, chronology14);
//        int int16 = period15.getDays();
//        org.joda.time.Period period18 = period15.withMillis((int) (short) 1);
//        org.joda.time.format.PeriodFormatter periodFormatter19 = null;
//        java.lang.String str20 = period15.toString(periodFormatter19);
//        int[] intArray22 = lenientChronology6.get((org.joda.time.ReadablePeriod) period15, (-210865982400000L));
//        java.lang.String str23 = lenientChronology6.toString();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "LenientChronology[ISOChronology[]]" + "'", str7.equals("LenientChronology[ISOChronology[]]"));
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LenientChronology[ISOChronology[]]" + "'", str9.equals("LenientChronology[ISOChronology[]]"));
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PT0.011S" + "'", str20.equals("PT0.011S"));
//        org.junit.Assert.assertNotNull(intArray22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "LenientChronology[ISOChronology[]]" + "'", str23.equals("LenientChronology[ISOChronology[]]"));
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        long long8 = fixedDateTimeZone6.previousTransition(1L);
        long long10 = fixedDateTimeZone6.nextTransition((long) (byte) 1);
        int int12 = fixedDateTimeZone6.getStandardOffset((long) 36000000);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology13.getZone();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant17 = null;
        int int18 = dateTimeZone16.getOffset(readableInstant17);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        long long23 = cachedDateTimeZone19.convertLocalToUTC((long) 10, true, (long) (short) 10);
        boolean boolean24 = cachedDateTimeZone19.isFixed();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        long long31 = fixedDateTimeZone29.previousTransition((long) 8);
        java.util.TimeZone timeZone32 = fixedDateTimeZone29.toTimeZone();
        java.util.TimeZone timeZone33 = fixedDateTimeZone29.toTimeZone();
        int int35 = fixedDateTimeZone29.getOffset(34L);
        boolean boolean36 = cachedDateTimeZone19.equals((java.lang.Object) fixedDateTimeZone29);
        java.util.TimeZone timeZone37 = fixedDateTimeZone29.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone29);
        org.joda.time.Chronology chronology39 = zonedChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone29);
        try {
            long long45 = zonedChronology13.getDateTimeMillis((long) 33, 3, 800001000, 1, 1216006);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 800001000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 11L + "'", long23 == 11L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 8L + "'", long31 == 8L);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(chronology39);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test006");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        org.joda.time.ReadablePartial readablePartial20 = null;
//        org.joda.time.ReadableInstant readableInstant22 = null;
//        org.joda.time.ReadableInstant readableInstant23 = null;
//        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant22, readableInstant23);
//        org.joda.time.Period period25 = new org.joda.time.Period((long) (-1), chronology24);
//        org.joda.time.Period period27 = period25.withDays(0);
//        int[] intArray28 = period27.getValues();
//        int int29 = offsetDateTimeField15.getMinimumValue(readablePartial20, intArray28);
//        int int31 = offsetDateTimeField15.getLeapAmount(11L);
//        java.util.Locale locale32 = null;
//        int int33 = offsetDateTimeField15.getMaximumTextLength(locale32);
//        long long35 = offsetDateTimeField15.roundHalfFloor(8000010L);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62135596800001L) + "'", long35 == (-62135596800001L));
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long8 = cachedDateTimeZone4.convertLocalToUTC((long) 10, true, (long) (short) 10);
        boolean boolean9 = cachedDateTimeZone4.isFixed();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        long long16 = fixedDateTimeZone14.previousTransition((long) 8);
        java.util.TimeZone timeZone17 = fixedDateTimeZone14.toTimeZone();
        java.util.TimeZone timeZone18 = fixedDateTimeZone14.toTimeZone();
        int int20 = fixedDateTimeZone14.getOffset(34L);
        boolean boolean21 = cachedDateTimeZone4.equals((java.lang.Object) fixedDateTimeZone14);
        org.joda.time.ReadableInstant readableInstant22 = null;
        int int23 = cachedDateTimeZone4.getOffset(readableInstant22);
        org.joda.time.DateTimeZone dateTimeZone24 = cachedDateTimeZone4.getUncachedZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 11L + "'", long8 == 11L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 8L + "'", long16 == 8L);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone24);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long11 = dateTimeZone8.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.Chronology chronology13 = iSOChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology1.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.Period period2 = new org.joda.time.Period((long) '4', (long) (-1));
        org.joda.time.Period period4 = period2.minusMonths(1216006);
        org.joda.time.MutablePeriod mutablePeriod5 = period2.toMutablePeriod();
        org.joda.time.Period period7 = period2.minusDays((-1));
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(mutablePeriod5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.Period period11 = new org.joda.time.Period((int) (short) 1, (int) (byte) 0, (int) (short) 10, 100, 10, 0, (int) (short) -1, (int) '#');
        org.joda.time.Period period13 = period11.plusHours((-1));
        org.joda.time.Period period15 = period13.plusSeconds((int) (byte) -1);
        org.joda.time.Period period17 = period13.plusMonths(36000000);
        long long20 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period13, (-97L), 1);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 46256398938L + "'", long20 == 46256398938L);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.lang.Object obj0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) 0, periodType5, chronology7);
        org.joda.time.PeriodType periodType9 = periodType5.withYearsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType9);
        java.lang.String str11 = periodType9.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period13 = new org.joda.time.Period(obj0, periodType9, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.Chronology chronology17 = gregorianChronology12.withZone(dateTimeZone16);
        java.lang.String str18 = gregorianChronology12.toString();
        java.lang.Object obj19 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval25 = null;
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval25);
        org.joda.time.Period period27 = new org.joda.time.Period((long) 'a', (long) 0, periodType24, chronology26);
        org.joda.time.PeriodType periodType28 = periodType24.withYearsRemoved();
        org.joda.time.Period period29 = new org.joda.time.Period(readableDuration20, readableInstant21, periodType28);
        java.lang.String str30 = periodType28.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period32 = new org.joda.time.Period(obj19, periodType28, (org.joda.time.Chronology) gregorianChronology31);
        boolean boolean34 = periodType28.equals((java.lang.Object) "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported");
        org.joda.time.PeriodType periodType35 = periodType28.withWeeksRemoved();
        org.joda.time.PeriodType periodType36 = periodType28.withMonthsRemoved();
        boolean boolean37 = gregorianChronology12.equals((java.lang.Object) periodType36);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PeriodType[DayTime]" + "'", str11.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "GregorianChronology[UTC]" + "'", str18.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PeriodType[DayTime]" + "'", str30.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test012");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        long long36 = zeroIsMaxDateTimeField34.roundHalfCeiling((long) (byte) 100);
//        long long38 = zeroIsMaxDateTimeField34.roundHalfFloor(32L);
//        int int40 = zeroIsMaxDateTimeField34.getLeapAmount(100L);
//        int int42 = zeroIsMaxDateTimeField34.getMinimumValue(0L);
//        int int44 = zeroIsMaxDateTimeField34.getLeapAmount(9953277235200000L);
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone48);
//        long long53 = iSOChronology49.add(0L, (long) 1, (int) ' ');
//        org.joda.time.chrono.LenientChronology lenientChronology54 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology49);
//        org.joda.time.Period period55 = new org.joda.time.Period((long) (short) 0, (org.joda.time.Chronology) iSOChronology49);
//        int int56 = period55.getYears();
//        org.joda.time.Period period58 = period55.withYears((int) 'a');
//        int[] intArray59 = period55.getValues();
//        try {
//            int[] intArray61 = zeroIsMaxDateTimeField34.add(readablePartial45, 79966, intArray59, (-1224000100));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 79966");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 32L + "'", long38 == 32L);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 32L + "'", long53 == 32L);
//        org.junit.Assert.assertNotNull(lenientChronology54);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertNotNull(period58);
//        org.junit.Assert.assertNotNull(intArray59);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) -1, 10, 104, 799900);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 799806 + "'", int4 == 799806);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test014");
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
//        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, 10L, chronology6);
//        int int8 = period7.getDays();
//        org.joda.time.Period period10 = period7.withMillis((int) (short) 1);
//        java.lang.Object obj11 = null;
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.ReadableInterval readableInterval17 = null;
//        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
//        org.joda.time.Period period19 = new org.joda.time.Period((long) 'a', (long) 0, periodType16, chronology18);
//        org.joda.time.PeriodType periodType20 = periodType16.withYearsRemoved();
//        org.joda.time.Period period21 = new org.joda.time.Period(readableDuration12, readableInstant13, periodType20);
//        java.lang.String str22 = periodType20.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Period period24 = new org.joda.time.Period(obj11, periodType20, (org.joda.time.Chronology) gregorianChronology23);
//        org.joda.time.PeriodType periodType25 = periodType20.withHoursRemoved();
//        org.joda.time.Period period26 = period7.withPeriodType(periodType25);
//        org.joda.time.PeriodType periodType27 = org.joda.time.DateTimeUtils.getPeriodType(periodType25);
//        org.joda.time.PeriodType periodType28 = org.joda.time.DateTimeUtils.getPeriodType(periodType27);
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str30 = gregorianChronology29.toString();
//        org.joda.time.DurationField durationField31 = gregorianChronology29.weekyears();
//        org.joda.time.DurationField durationField32 = gregorianChronology29.centuries();
//        org.joda.time.Chronology chronology33 = gregorianChronology29.withUTC();
//        org.joda.time.chrono.LenientChronology lenientChronology34 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology29);
//        org.joda.time.DurationField durationField35 = lenientChronology34.hours();
//        org.joda.time.Chronology chronology36 = lenientChronology34.withUTC();
//        org.joda.time.Period period37 = new org.joda.time.Period(52L, (long) 1, periodType28, (org.joda.time.Chronology) lenientChronology34);
//        org.joda.time.DateTimeField dateTimeField38 = lenientChronology34.year();
//        long long43 = lenientChronology34.getDateTimeMillis((-100), 1, (-100), 800000);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PeriodType[DayTime]" + "'", str22.equals("PeriodType[DayTime]"));
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(periodType25);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(periodType27);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "GregorianChronology[]" + "'", str30.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertNotNull(lenientChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-65331618400001L) + "'", long43 == (-65331618400001L));
//    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test015");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        long long17 = offsetDateTimeField15.roundHalfEven(97L);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField15.getAsShortText((int) (byte) -1, locale19);
//        org.joda.time.ReadablePartial readablePartial21 = null;
//        java.util.Locale locale22 = null;
//        try {
//            java.lang.String str23 = offsetDateTimeField15.getAsShortText(readablePartial21, locale22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135596800001L) + "'", long17 == (-62135596800001L));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-1" + "'", str20.equals("-1"));
//    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test016");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
//        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str26 = gregorianChronology25.toString();
//        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
//        java.lang.String str29 = unsupportedDateTimeField28.toString();
//        java.util.Locale locale30 = null;
//        try {
//            int int31 = unsupportedDateTimeField28.getMaximumTextLength(locale30);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775806L + "'", long21 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800001L) + "'", long23 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[]" + "'", str26.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDateTimeField" + "'", str29.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) 0, periodType5, chronology7);
        org.joda.time.PeriodType periodType9 = periodType5.withYearsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType9);
        org.joda.time.PeriodType periodType11 = periodType9.withHoursRemoved();
        org.joda.time.Period period12 = new org.joda.time.Period(10L, periodType9);
        org.joda.time.PeriodType periodType13 = periodType9.withHoursRemoved();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.standard();
        boolean boolean15 = periodType9.equals((java.lang.Object) periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.seconds();
        int int17 = periodType16.size();
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.seconds();
        int int20 = periodType19.size();
        org.joda.time.PeriodType periodType21 = periodType19.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = periodType16.indexOf(durationFieldType23);
        int int25 = periodType9.indexOf(durationFieldType23);
        org.joda.time.field.PreciseDurationField preciseDurationField27 = new org.joda.time.field.PreciseDurationField(durationFieldType23, 0L);
        long long30 = preciseDurationField27.subtract((long) 1216006, (int) (byte) 1);
        try {
            int int32 = preciseDurationField27.getValue((-9223372036854775807L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1216006L + "'", long30 == 1216006L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) 'a', (long) 0, periodType6, chronology8);
        org.joda.time.PeriodType periodType10 = periodType6.withYearsRemoved();
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration2, readableInstant3, periodType10);
        java.lang.String str12 = periodType10.toString();
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType10);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PeriodType[DayTime]" + "'", str12.equals("PeriodType[DayTime]"));
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test019");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
//        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str26 = gregorianChronology25.toString();
//        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
//        long long31 = unsupportedDateTimeField28.getDifferenceAsLong((long) (-7), 9223372036854775806L);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getRangeDurationField();
//        boolean boolean33 = unsupportedDateTimeField28.isLenient();
//        org.joda.time.ReadablePartial readablePartial34 = null;
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
//        long long42 = iSOChronology38.add(0L, (long) 1, (int) ' ');
//        org.joda.time.DateTimeField dateTimeField43 = iSOChronology38.era();
//        org.joda.time.Period period44 = new org.joda.time.Period((long) 'a', (-65L), (org.joda.time.Chronology) iSOChronology38);
//        org.joda.time.DurationField durationField45 = iSOChronology38.months();
//        org.joda.time.Period period47 = org.joda.time.Period.minutes(8);
//        int[] intArray50 = iSOChronology38.get((org.joda.time.ReadablePeriod) period47, (long) 100, 0L);
//        try {
//            int int51 = unsupportedDateTimeField28.getMinimumValue(readablePartial34, intArray50);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775806L + "'", long21 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800001L) + "'", long23 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[]" + "'", str26.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 292277025L + "'", long31 == 292277025L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 32L + "'", long42 == 32L);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertNotNull(period47);
//        org.junit.Assert.assertNotNull(intArray50);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.withYears((int) (byte) 0);
        org.joda.time.Period period6 = period2.plusDays((int) ' ');
        org.joda.time.Period period8 = period2.withSeconds(20);
        org.joda.time.MutablePeriod mutablePeriod9 = period8.toMutablePeriod();
        org.joda.time.Period period11 = period8.minusSeconds(640000);
        org.joda.time.Period period13 = period8.multipliedBy(640000);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(mutablePeriod9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) '4');
        org.joda.time.Days days2 = period1.toStandardDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(days2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("Standard");
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test023");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.weekyears();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.centuries();
//        org.joda.time.Chronology chronology4 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.halfdayOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test024");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
//        org.joda.time.DurationField durationField37 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        long long39 = zeroIsMaxDateTimeField34.remainder((long) 4);
//        long long41 = zeroIsMaxDateTimeField34.roundFloor((long) 800001000);
//        org.joda.time.DurationField durationField42 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
//        long long48 = iSOChronology44.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology49 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology44);
//        org.joda.time.DateTimeField dateTimeField50 = lenientChronology49.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField51 = lenientChronology49.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone54);
//        long long59 = iSOChronology55.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology60 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology55);
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology55.year();
//        org.joda.time.DateTimeField dateTimeField62 = iSOChronology55.minuteOfHour();
//        org.joda.time.Period period63 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology55);
//        org.joda.time.DurationField durationField64 = iSOChronology55.minutes();
//        org.joda.time.DateTimeField dateTimeField65 = iSOChronology55.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 20);
//        int int69 = offsetDateTimeField67.getLeapAmount(1560628303058L);
//        long long71 = offsetDateTimeField67.remainder(87L);
//        long long73 = offsetDateTimeField67.roundHalfCeiling((-62135596799999L));
//        long long75 = offsetDateTimeField67.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = offsetDateTimeField67.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField77 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField51, dateTimeFieldType76);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField81 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField34, dateTimeFieldType76, (int) 'a', 0, (-83189600));
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 800001000L + "'", long41 == 800001000L);
//        org.junit.Assert.assertNull(durationField42);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-65L) + "'", long48 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(iSOChronology55);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-65L) + "'", long59 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertNotNull(durationField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 62135596800088L + "'", long71 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 9223372036854775806L + "'", long73 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-62135596800001L) + "'", long75 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType76);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        try {
            org.joda.time.Period period14 = period5.withWeeks(608003);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test026");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        long long17 = offsetDateTimeField15.roundHalfEven(97L);
//        java.lang.String str19 = offsetDateTimeField15.getAsText((long) 'a');
//        try {
//            long long22 = offsetDateTimeField15.add((long) (-800000), (long) 4);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135596800001L) + "'", long17 == (-62135596800001L));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "21" + "'", str19.equals("21"));
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long4 = dateTimeZone1.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str7 = cachedDateTimeZone5.getName(8L);
        org.joda.time.LocalDateTime localDateTime8 = null;
        boolean boolean9 = cachedDateTimeZone5.isLocalDateTimeGap(localDateTime8);
        int int11 = cachedDateTimeZone5.getStandardOffset((long) 8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-00:00:00.001" + "'", str7.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.era();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.Period period4 = new org.joda.time.Period(34, 0, 104, 79966);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) -1, 608003);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 608002 + "'", int2 == 608002);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getStandardOffset((long) 10000);
        long long8 = fixedDateTimeZone4.nextTransition(27L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone4.getShortName(640000L, locale10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 27L + "'", long8 == 27L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "ISOChronology[-00:00:00.001]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getStandardOffset((long) 10000);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str9 = fixedDateTimeZone4.getNameKey(0L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PT0.011S" + "'", str9.equals("PT0.011S"));
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test034");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
//        long long40 = iSOChronology36.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.DurationField durationField41 = iSOChronology36.years();
//        org.joda.time.DurationField durationField42 = iSOChronology36.days();
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
//        long long48 = iSOChronology44.add(0L, (long) 1, (int) ' ');
//        org.joda.time.chrono.LenientChronology lenientChronology49 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology44);
//        org.joda.time.DateTimeField dateTimeField50 = lenientChronology49.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField51 = lenientChronology49.halfdayOfDay();
//        org.joda.time.DurationField durationField52 = lenientChronology49.weeks();
//        long long55 = durationField52.subtract(0L, 11L);
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField56 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType33, durationField42, durationField52);
//        long long58 = preciseDateTimeField56.roundCeiling((-141746760000000L));
//        org.joda.time.DurationField durationField59 = preciseDateTimeField56.getDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-65L) + "'", long40 == (-65L));
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 32L + "'", long48 == 32L);
//        org.junit.Assert.assertNotNull(lenientChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-6652800000L) + "'", long55 == (-6652800000L));
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-141746716800000L) + "'", long58 == (-141746716800000L));
//        org.junit.Assert.assertNotNull(durationField59);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withMonthsRemoved();
        java.lang.String str2 = periodType0.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PeriodType[Seconds]" + "'", str2.equals("PeriodType[Seconds]"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getStandardOffset((long) 10000);
        long long8 = fixedDateTimeZone4.nextTransition(27L);
        long long10 = fixedDateTimeZone4.previousTransition(0L);
        int int12 = fixedDateTimeZone4.getOffsetFromLocal((long) (-32));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 27L + "'", long8 == 27L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test037");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        int int21 = offsetDateTimeField15.getLeapAmount((long) (byte) 0);
//        org.joda.time.ReadablePartial readablePartial22 = null;
//        int int23 = offsetDateTimeField15.getMinimumValue(readablePartial22);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 20 + "'", int23 == 20);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test038");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        int int19 = offsetDateTimeField15.getLeapAmount((-141746760000000L));
//        org.joda.time.ReadablePartial readablePartial20 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
//        long long28 = iSOChronology24.add(0L, (long) 1, (int) ' ');
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology24.era();
//        org.joda.time.Period period30 = new org.joda.time.Period((long) 'a', (-65L), (org.joda.time.Chronology) iSOChronology24);
//        org.joda.time.DurationField durationField31 = iSOChronology24.months();
//        org.joda.time.Period period33 = org.joda.time.Period.minutes(8);
//        int[] intArray36 = iSOChronology24.get((org.joda.time.ReadablePeriod) period33, (long) 100, 0L);
//        int int37 = offsetDateTimeField15.getMaximumValue(readablePartial20, intArray36);
//        long long39 = offsetDateTimeField15.roundHalfCeiling(52L);
//        int int41 = offsetDateTimeField15.getMaximumValue((long) (byte) 1);
//        org.joda.time.DurationField durationField42 = offsetDateTimeField15.getLeapDurationField();
//        long long44 = offsetDateTimeField15.roundHalfFloor((long) (-1224000100));
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 32L + "'", long28 == 32L);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(intArray36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 21 + "'", int37 == 21);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-62135596800001L) + "'", long39 == (-62135596800001L));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 21 + "'", int41 == 21);
//        org.junit.Assert.assertNull(durationField42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 9223372036854775806L + "'", long44 == 9223372036854775806L);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("");
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException2.getSuppressed();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException2.getSuppressed();
        java.lang.Number number7 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long7 = dateTimeZone3.convertLocalToUTC((long) (-1), true, 9L);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        long long10 = dateTimeZone3.convertUTCToLocal((-148210560000034L));
        boolean boolean11 = jodaTimePermission1.equals((java.lang.Object) long10);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-148210560000035L) + "'", long10 == (-148210560000035L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfSecond();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long6 = iSOChronology2.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.Chronology chronology9 = iSOChronology2.withZone(dateTimeZone8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        org.joda.time.ReadableInterval readableInterval12 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval11);
        boolean boolean13 = iSOChronology2.equals((java.lang.Object) readableInterval12);
        org.joda.time.ReadableInterval readableInterval14 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval12);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-65L) + "'", long6 == (-65L));
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(readableInterval11);
        org.junit.Assert.assertNotNull(readableInterval12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(readableInterval14);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test043");
//        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
//        int int1 = periodType0.size();
//        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
//        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
//        int int4 = periodType3.size();
//        org.joda.time.PeriodType periodType5 = periodType3.withMonthsRemoved();
//        org.joda.time.DurationFieldType durationFieldType7 = periodType3.getFieldType(0);
//        int int8 = periodType0.indexOf(durationFieldType7);
//        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) (short) -1);
//        int int13 = preciseDurationField10.getDifference(0L, (long) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str15 = gregorianChronology14.toString();
//        org.joda.time.DurationField durationField16 = gregorianChronology14.weekyears();
//        org.joda.time.DurationField durationField17 = gregorianChronology14.centuries();
//        org.joda.time.Chronology chronology18 = gregorianChronology14.withUTC();
//        org.joda.time.chrono.LenientChronology lenientChronology19 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.DurationField durationField20 = lenientChronology19.hours();
//        int int21 = preciseDurationField10.compareTo(durationField20);
//        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.ReadableInterval readableInterval25 = null;
//        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval25);
//        org.joda.time.Period period27 = new org.joda.time.Period((long) 'a', (long) 0, periodType24, chronology26);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.ReadableInterval readableInterval31 = null;
//        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval31);
//        org.joda.time.Period period33 = new org.joda.time.Period((long) 'a', (long) 0, periodType30, chronology32);
//        org.joda.time.Period period34 = period27.withPeriodType(periodType30);
//        java.lang.Object obj35 = null;
//        boolean boolean36 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period34, obj35);
//        java.lang.Class<?> wildcardClass37 = period34.getClass();
//        org.joda.time.Period period39 = period34.multipliedBy(10);
//        org.joda.time.Days days40 = period39.toStandardDays();
//        org.joda.time.ReadableDuration readableDuration41 = null;
//        org.joda.time.ReadableInstant readableInstant42 = null;
//        org.joda.time.PeriodType periodType45 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.ReadableInterval readableInterval46 = null;
//        org.joda.time.Chronology chronology47 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval46);
//        org.joda.time.Period period48 = new org.joda.time.Period((long) 'a', (long) 0, periodType45, chronology47);
//        org.joda.time.PeriodType periodType49 = periodType45.withYearsRemoved();
//        org.joda.time.Period period50 = new org.joda.time.Period(readableDuration41, readableInstant42, periodType49);
//        java.lang.String str51 = periodType49.toString();
//        org.joda.time.PeriodType periodType52 = org.joda.time.PeriodType.seconds();
//        int int53 = periodType52.size();
//        org.joda.time.PeriodType periodType54 = periodType52.withMonthsRemoved();
//        org.joda.time.DurationFieldType durationFieldType56 = periodType52.getFieldType(0);
//        java.lang.Number number57 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException60 = new org.joda.time.IllegalFieldValueException(durationFieldType56, number57, (java.lang.Number) (-863999999900L), (java.lang.Number) 2440587.5000011576d);
//        int int61 = periodType49.indexOf(durationFieldType56);
//        boolean boolean62 = period39.isSupported(durationFieldType56);
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField64 = new org.joda.time.field.ScaledDurationField(durationField20, durationFieldType56, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The scalar must not be 0 or 1");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(periodType5);
//        org.junit.Assert.assertNotNull(durationFieldType7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GregorianChronology[]" + "'", str15.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(lenientChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(periodType24);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(period34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertNotNull(days40);
//        org.junit.Assert.assertNotNull(periodType45);
//        org.junit.Assert.assertNotNull(chronology47);
//        org.junit.Assert.assertNotNull(periodType49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "PeriodType[DayTime]" + "'", str51.equals("PeriodType[DayTime]"));
//        org.junit.Assert.assertNotNull(periodType52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertNotNull(periodType54);
//        org.junit.Assert.assertNotNull(durationFieldType56);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 3 + "'", int61 == 3);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 100, (int) (short) 10, (int) 'a', (int) '4', (int) (short) 100, (int) '4', 0, (int) (byte) 1);
        org.joda.time.Period period10 = period8.minusMillis((int) (byte) 10);
        try {
            org.joda.time.Hours hours11 = period10.toStandardHours();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Hours as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period10);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test045");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        java.lang.String str7 = lenientChronology6.toString();
//        org.joda.time.DurationField durationField8 = lenientChronology6.millis();
//        org.joda.time.DateTimeField dateTimeField9 = lenientChronology6.monthOfYear();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "LenientChronology[ISOChronology[]]" + "'", str7.equals("LenientChronology[ISOChronology[]]"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test046");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
//        java.lang.String str3 = gregorianChronology1.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.Period period14 = period7.withPeriodType(periodType10);
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period14, obj15);
        java.lang.Class<?> wildcardClass17 = period14.getClass();
        org.joda.time.Period period19 = period14.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, periodType25, chronology27);
        org.joda.time.PeriodType periodType29 = periodType25.withYearsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType29);
        org.joda.time.PeriodType periodType31 = periodType29.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(10L, periodType29);
        org.joda.time.PeriodType periodType33 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
        boolean boolean35 = periodType29.equals((java.lang.Object) periodType34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        int int37 = periodType36.size();
        org.joda.time.PeriodType periodType38 = periodType36.withMonthsRemoved();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.seconds();
        int int40 = periodType39.size();
        org.joda.time.PeriodType periodType41 = periodType39.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType(0);
        int int44 = periodType36.indexOf(durationFieldType43);
        int int45 = periodType29.indexOf(durationFieldType43);
        org.joda.time.Period period47 = period14.withField(durationFieldType43, 0);
        int int48 = period1.get(durationFieldType43);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType43);
        try {
            long long52 = unsupportedDurationField49.getMillis((-34), 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: seconds field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((-1));
        org.joda.time.Period period3 = period1.plusWeeks(0);
        org.joda.time.Period period5 = period1.withHours((int) (byte) 0);
        org.joda.time.Period period7 = period5.withYears(104);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test049");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
//        org.joda.time.DurationField durationField37 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        long long39 = zeroIsMaxDateTimeField34.remainder((long) 4);
//        boolean boolean41 = zeroIsMaxDateTimeField34.isLeap(778243840052L);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test050");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
//        long long40 = iSOChronology36.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.DurationField durationField41 = iSOChronology36.years();
//        org.joda.time.DurationField durationField42 = iSOChronology36.days();
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
//        long long48 = iSOChronology44.add(0L, (long) 1, (int) ' ');
//        org.joda.time.chrono.LenientChronology lenientChronology49 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology44);
//        org.joda.time.DateTimeField dateTimeField50 = lenientChronology49.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField51 = lenientChronology49.halfdayOfDay();
//        org.joda.time.DurationField durationField52 = lenientChronology49.weeks();
//        long long55 = durationField52.subtract(0L, 11L);
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField56 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType33, durationField42, durationField52);
//        long long58 = preciseDateTimeField56.roundFloor((-141746716800000L));
//        boolean boolean59 = preciseDateTimeField56.isLenient();
//        long long61 = preciseDateTimeField56.roundFloor(87L);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-65L) + "'", long40 == (-65L));
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 32L + "'", long48 == 32L);
//        org.junit.Assert.assertNotNull(lenientChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-6652800000L) + "'", long55 == (-6652800000L));
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-141746716800000L) + "'", long58 == (-141746716800000L));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("LenientChronology[ISOChronology[]]", "PeriodType[Seconds]", 104, (-799980));
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test052");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
//        org.joda.time.DurationField durationField37 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        long long39 = zeroIsMaxDateTimeField34.remainder((long) 4);
//        long long41 = zeroIsMaxDateTimeField34.roundFloor((long) 800001000);
//        org.joda.time.DurationField durationField42 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        int int43 = zeroIsMaxDateTimeField34.getMaximumValue();
//        int int44 = zeroIsMaxDateTimeField34.getMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 800001000L + "'", long41 == 800001000L);
//        org.junit.Assert.assertNull(durationField42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1000 + "'", int43 == 1000);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-62135596799999L));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 100, (int) (short) 10, (int) 'a', (int) '4', (int) (short) 100, (int) '4', 0, (int) (byte) 1);
        org.joda.time.Period period10 = period8.multipliedBy(0);
        int int11 = period8.getMinutes();
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "DateTimeField[era]", 1216006, (int) '#');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.Period period1 = org.joda.time.Period.hours(21);
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Duration duration3 = period1.toDurationTo(readableInstant2);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant6, readableDuration7);
        long long11 = iSOChronology1.add((org.joda.time.ReadablePeriod) period8, (long) 1, (int) ' ');
        org.joda.time.Chronology chronology12 = iSOChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.dayOfYear();
        long long17 = iSOChronology1.add(100L, 34L, 36000000);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.yearOfEra();
        boolean boolean23 = iSOChronology1.equals((java.lang.Object) dateTimeField22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology1.year();
        try {
            org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) dateTimeField24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1224000100L + "'", long17 == 1224000100L);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test058");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        java.lang.String str7 = lenientChronology6.toString();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.centuryOfEra();
//        org.joda.time.Chronology chronology9 = lenientChronology6.withUTC();
//        org.joda.time.DateTimeField dateTimeField10 = lenientChronology6.dayOfYear();
//        long long14 = lenientChronology6.add(9953277235200000L, (long) 800000, 100);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "LenientChronology[ISOChronology[]]" + "'", str7.equals("LenientChronology[ISOChronology[]]"));
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9953277315200000L + "'", long14 == 9953277315200000L);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        java.util.Locale locale18 = null;
        int int19 = offsetDateTimeField15.getMaximumShortTextLength(locale18);
        boolean boolean20 = offsetDateTimeField15.isLenient();
        int int21 = offsetDateTimeField15.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 20 + "'", int21 == 20);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("");
        illegalFieldValueException2.prependMessage("PeriodType[DayTime]");
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException2.getSuppressed();
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.String str9 = illegalFieldValueException2.toString();
        java.lang.String str10 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.joda.time.IllegalFieldValueException: PeriodType[DayTime]: : Value \"\" for hi! is not supported" + "'", str9.equals("org.joda.time.IllegalFieldValueException: PeriodType[DayTime]: : Value \"\" for hi! is not supported"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.File file4 = null;
        java.io.File file5 = null;
        java.io.File[] fileArray6 = new java.io.File[] { file5 };
        try {
            java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = zoneInfoCompiler0.compile(file4, fileArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(fileArray6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long10 = dateTimeZone7.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        org.joda.time.Chronology chronology12 = iSOChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone11);
        long long14 = cachedDateTimeZone11.previousTransition((long) 0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-360000065));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        org.joda.time.DurationField durationField8 = lenientChronology6.hours();
        boolean boolean10 = lenientChronology6.equals((java.lang.Object) (short) -1);
        org.joda.time.DurationField durationField11 = lenientChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField12 = lenientChronology6.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test065");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.halfdayOfDay();
//        java.lang.String str9 = lenientChronology6.toString();
//        org.joda.time.DateTimeField dateTimeField10 = lenientChronology6.clockhourOfDay();
//        org.joda.time.DurationField durationField11 = lenientChronology6.millis();
//        org.joda.time.DateTimeField dateTimeField12 = lenientChronology6.era();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LenientChronology[ISOChronology[]]" + "'", str9.equals("LenientChronology[ISOChronology[]]"));
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test066");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
//        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str26 = gregorianChronology25.toString();
//        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
//        long long31 = unsupportedDateTimeField28.getDifferenceAsLong((long) (-7), 9223372036854775806L);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getRangeDurationField();
//        long long35 = unsupportedDateTimeField28.add(616007L, (long) (-800000));
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
//        long long43 = iSOChronology39.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology44 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology39);
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology39.year();
//        org.joda.time.DateTimeField dateTimeField46 = iSOChronology39.minuteOfHour();
//        org.joda.time.Period period47 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology39);
//        org.joda.time.DurationField durationField48 = iSOChronology39.minutes();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology39.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, 20);
//        int int53 = offsetDateTimeField51.getLeapAmount(1560628303058L);
//        long long55 = offsetDateTimeField51.remainder(87L);
//        long long57 = offsetDateTimeField51.roundHalfCeiling((-62135596799999L));
//        long long59 = offsetDateTimeField51.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = offsetDateTimeField51.getType();
//        java.lang.Number number61 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType60, number61, (java.lang.Number) 62135596800086L, (java.lang.Number) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException67 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType60, (java.lang.Number) (-56940685192995L), "PeriodType[YearMonthDayTime]");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException69 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType60, "org.joda.time.IllegalFieldValueException: Value 100 for -00:00:00.001 must be in the range [0,10]");
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField70 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) unsupportedDateTimeField28, dateTimeFieldType60);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775806L + "'", long21 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800001L) + "'", long23 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[]" + "'", str26.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 292277025L + "'", long31 == 292277025L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-25245561599383993L) + "'", long35 == (-25245561599383993L));
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-65L) + "'", long43 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 62135596800088L + "'", long55 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 9223372036854775806L + "'", long57 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-62135596800001L) + "'", long59 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType60);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long13 = iSOChronology9.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField14 = iSOChronology9.years();
        long long18 = iSOChronology9.add((long) 0, 32L, (int) (byte) 10);
        boolean boolean19 = lenientChronology6.equals((java.lang.Object) 32L);
        org.joda.time.DateTimeField dateTimeField20 = lenientChronology6.dayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-65L) + "'", long13 == (-65L));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 320L + "'", long18 == 320L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test068");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        long long6 = iSOChronology2.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology7 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology7.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField9 = lenientChronology7.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        long long17 = iSOChronology13.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology18 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.year();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology13.minuteOfHour();
//        org.joda.time.Period period21 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.DurationField durationField22 = iSOChronology13.minutes();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology13.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, 20);
//        int int27 = offsetDateTimeField25.getLeapAmount(1560628303058L);
//        long long29 = offsetDateTimeField25.remainder(87L);
//        long long31 = offsetDateTimeField25.roundHalfCeiling((-62135596799999L));
//        long long33 = offsetDateTimeField25.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = offsetDateTimeField25.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType34);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-65L) + "'", long6 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-65L) + "'", long17 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 62135596800088L + "'", long29 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775806L + "'", long31 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62135596800001L) + "'", long33 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        java.lang.Object obj13 = null;
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period12, obj13);
        java.lang.Class<?> wildcardClass15 = period12.getClass();
        org.joda.time.Period period17 = period12.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) 'a', (long) 0, periodType23, chronology25);
        org.joda.time.PeriodType periodType27 = periodType23.withYearsRemoved();
        org.joda.time.Period period28 = new org.joda.time.Period(readableDuration19, readableInstant20, periodType27);
        org.joda.time.PeriodType periodType29 = periodType27.withHoursRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(10L, periodType27);
        org.joda.time.PeriodType periodType31 = periodType27.withHoursRemoved();
        org.joda.time.PeriodType periodType32 = org.joda.time.PeriodType.standard();
        boolean boolean33 = periodType27.equals((java.lang.Object) periodType32);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.seconds();
        int int35 = periodType34.size();
        org.joda.time.PeriodType periodType36 = periodType34.withMonthsRemoved();
        org.joda.time.PeriodType periodType37 = org.joda.time.PeriodType.seconds();
        int int38 = periodType37.size();
        org.joda.time.PeriodType periodType39 = periodType37.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType41 = periodType37.getFieldType(0);
        int int42 = periodType34.indexOf(durationFieldType41);
        int int43 = periodType27.indexOf(durationFieldType41);
        org.joda.time.Period period45 = period12.withField(durationFieldType41, 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(durationFieldType41, (java.lang.Number) (-9223372036854775807L), (java.lang.Number) 10L, (java.lang.Number) 292277025L);
        java.lang.String str50 = illegalFieldValueException49.getFieldName();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(durationFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 3 + "'", int43 == 3);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "seconds" + "'", str50.equals("seconds"));
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test070");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        org.joda.time.ReadablePartial readablePartial20 = null;
//        org.joda.time.ReadableInstant readableInstant22 = null;
//        org.joda.time.ReadableInstant readableInstant23 = null;
//        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant22, readableInstant23);
//        org.joda.time.Period period25 = new org.joda.time.Period((long) (-1), chronology24);
//        org.joda.time.Period period27 = period25.withDays(0);
//        int[] intArray28 = period27.getValues();
//        int int29 = offsetDateTimeField15.getMinimumValue(readablePartial20, intArray28);
//        int int31 = offsetDateTimeField15.getLeapAmount(11L);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField15.getLeapDurationField();
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField15.getAsText(0, locale34);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test071");
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
//        int int2 = periodType1.size();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        long long8 = iSOChronology4.add(0L, (long) 1, (int) ' ');
//        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
//        org.joda.time.DateTimeField dateTimeField10 = lenientChronology9.yearOfEra();
//        long long16 = lenientChronology9.getDateTimeMillis((long) 4, (int) (short) 1, 0, 10000, (int) '#');
//        org.joda.time.DurationField durationField17 = lenientChronology9.centuries();
//        org.joda.time.Period period18 = new org.joda.time.Period((-800001L), periodType1, (org.joda.time.Chronology) lenientChronology9);
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
//        org.junit.Assert.assertNotNull(lenientChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 13600034L + "'", long16 == 13600034L);
//        org.junit.Assert.assertNotNull(durationField17);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("Seconds");
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("PT-0.001S");
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalInstantException3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (-1), chronology3);
        int int5 = period4.getHours();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test074");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
//        org.joda.time.DurationField durationField37 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        long long39 = zeroIsMaxDateTimeField34.remainder((long) 4);
//        long long41 = zeroIsMaxDateTimeField34.roundFloor((long) 800001000);
//        org.joda.time.DurationField durationField42 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        org.joda.time.DurationField durationField43 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        long long45 = zeroIsMaxDateTimeField34.roundHalfCeiling((long) 1000);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 800001000L + "'", long41 == 800001000L);
//        org.junit.Assert.assertNull(durationField42);
//        org.junit.Assert.assertNull(durationField43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1000L + "'", long45 == 1000L);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.Period period2 = new org.joda.time.Period(0L, (long) 10);
        org.joda.time.Period period3 = period2.toPeriod();
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.withMillis((int) (short) 1);
        org.joda.time.Period period10 = period5.plusWeeks(4);
        org.joda.time.Minutes minutes11 = period10.toStandardMinutes();
        org.joda.time.Period period13 = period10.plusMinutes(1);
        org.joda.time.Period period15 = period13.minusDays((int) ' ');
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.seconds();
        int int17 = periodType16.size();
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.seconds();
        int int20 = periodType19.size();
        org.joda.time.PeriodType periodType21 = periodType19.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = periodType16.indexOf(durationFieldType23);
        org.joda.time.field.PreciseDurationField preciseDurationField26 = new org.joda.time.field.PreciseDurationField(durationFieldType23, (long) (short) -1);
        org.joda.time.Period period28 = period15.withField(durationFieldType23, 2);
        org.joda.time.Period period30 = period15.plusWeeks((int) (short) 100);
        java.lang.Class<?> wildcardClass31 = period30.getClass();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(minutes11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test077");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
//        long long40 = iSOChronology36.add(0L, (long) 1, (int) ' ');
//        org.joda.time.chrono.LenientChronology lenientChronology41 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology36);
//        org.joda.time.DateTimeField dateTimeField42 = lenientChronology41.yearOfEra();
//        long long48 = lenientChronology41.getDateTimeMillis((long) 4, (int) (short) 1, 0, 10000, (int) '#');
//        org.joda.time.DurationField durationField49 = lenientChronology41.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField49);
//        try {
//            int int52 = unsupportedDateTimeField50.getLeapAmount((long) 79966);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 32L + "'", long40 == 32L);
//        org.junit.Assert.assertNotNull(lenientChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 13600034L + "'", long48 == 13600034L);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("GregorianChronology[America/Los_Angeles]", (int) (short) 10, 0, (int) (byte) -1, 'a', (int) 'a', 10, 0, true, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder0.toDateTimeZone("era", false);
        java.io.DataOutput dataOutput16 = null;
        try {
            dateTimeZoneBuilder0.writeTo("ISOChronology[-00:00:00.001]", dataOutput16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.Period period14 = period7.withPeriodType(periodType10);
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period14, obj15);
        java.lang.Class<?> wildcardClass17 = period14.getClass();
        org.joda.time.Period period19 = period14.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, periodType25, chronology27);
        org.joda.time.PeriodType periodType29 = periodType25.withYearsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType29);
        org.joda.time.PeriodType periodType31 = periodType29.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(10L, periodType29);
        org.joda.time.PeriodType periodType33 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
        boolean boolean35 = periodType29.equals((java.lang.Object) periodType34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        int int37 = periodType36.size();
        org.joda.time.PeriodType periodType38 = periodType36.withMonthsRemoved();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.seconds();
        int int40 = periodType39.size();
        org.joda.time.PeriodType periodType41 = periodType39.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType(0);
        int int44 = periodType36.indexOf(durationFieldType43);
        int int45 = periodType29.indexOf(durationFieldType43);
        org.joda.time.Period period47 = period14.withField(durationFieldType43, 0);
        int int48 = period1.get(durationFieldType43);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType43);
        try {
            long long52 = unsupportedDurationField49.add((long) 2, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: seconds field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException5.prependMessage("");
        java.lang.String str8 = illegalFieldValueException5.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException5.getDurationFieldType();
        java.lang.Number number10 = illegalFieldValueException5.getUpperBound();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNull(durationFieldType9);
        org.junit.Assert.assertNull(number10);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test081");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
//        org.joda.time.DurationField durationField37 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        long long39 = zeroIsMaxDateTimeField34.remainder((long) 4);
//        int int42 = zeroIsMaxDateTimeField34.getDifference((long) 0, 1224000100L);
//        org.joda.time.ReadablePartial readablePartial43 = null;
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone47);
//        long long52 = iSOChronology48.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology53 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology48);
//        org.joda.time.DateTimeField dateTimeField54 = iSOChronology48.year();
//        org.joda.time.DateTimeField dateTimeField55 = iSOChronology48.minuteOfHour();
//        org.joda.time.Period period56 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology48);
//        org.joda.time.DurationField durationField57 = iSOChronology48.minutes();
//        org.joda.time.DateTimeField dateTimeField58 = iSOChronology48.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField(dateTimeField58, 20);
//        int int62 = offsetDateTimeField60.getLeapAmount(1560628303058L);
//        int int63 = offsetDateTimeField60.getOffset();
//        org.joda.time.ReadablePartial readablePartial64 = null;
//        org.joda.time.ReadableInstant readableInstant66 = null;
//        org.joda.time.ReadableInstant readableInstant67 = null;
//        org.joda.time.Chronology chronology68 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant66, readableInstant67);
//        org.joda.time.Period period69 = new org.joda.time.Period((long) (-1), chronology68);
//        org.joda.time.Period period71 = period69.withDays(0);
//        int[] intArray72 = period71.getValues();
//        int int73 = offsetDateTimeField60.getMaximumValue(readablePartial64, intArray72);
//        try {
//            int[] intArray75 = zeroIsMaxDateTimeField34.addWrapField(readablePartial43, (int) (short) 1, intArray72, 21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1224000100) + "'", int42 == (-1224000100));
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-65L) + "'", long52 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 20 + "'", int63 == 20);
//        org.junit.Assert.assertNotNull(chronology68);
//        org.junit.Assert.assertNotNull(period71);
//        org.junit.Assert.assertNotNull(intArray72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 21 + "'", int73 == 21);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long4 = dateTimeZone1.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str7 = cachedDateTimeZone5.getName(8L);
        long long10 = cachedDateTimeZone5.convertLocalToUTC((-800001L), true);
        long long12 = cachedDateTimeZone5.previousTransition(1216007L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-00:00:00.001" + "'", str7.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-800000L) + "'", long10 == (-800000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1216007L + "'", long12 == 1216007L);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test083");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported");
//        org.joda.time.Period period10 = new org.joda.time.Period((int) (short) 1, (int) (byte) 0, (int) (short) 10, 100, 10, 0, (int) (short) -1, (int) '#');
//        boolean boolean11 = jodaTimePermission1.equals((java.lang.Object) 10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        long long17 = iSOChronology13.add(0L, (long) 1, (int) ' ');
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.ReadableInterval readableInterval21 = null;
//        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval21);
//        org.joda.time.Period period23 = new org.joda.time.Period((long) 'a', (long) 0, periodType20, chronology22);
//        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.ReadableInterval readableInterval27 = null;
//        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval27);
//        org.joda.time.Period period29 = new org.joda.time.Period((long) 'a', (long) 0, periodType26, chronology28);
//        org.joda.time.Period period30 = period23.withPeriodType(periodType26);
//        org.joda.time.format.PeriodFormatter periodFormatter31 = null;
//        java.lang.String str32 = period30.toString(periodFormatter31);
//        org.joda.time.Seconds seconds33 = period30.toStandardSeconds();
//        long long36 = iSOChronology13.add((org.joda.time.ReadablePeriod) period30, (long) (short) -1, (int) (short) 0);
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology13.minuteOfHour();
//        boolean boolean38 = jodaTimePermission1.equals((java.lang.Object) dateTimeField37);
//        org.joda.time.ReadableInstant readableInstant43 = null;
//        org.joda.time.ReadableInstant readableInstant44 = null;
//        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant43, readableInstant44);
//        org.joda.time.Period period46 = new org.joda.time.Period((long) (short) -1, 10L, chronology45);
//        int int47 = period46.getDays();
//        org.joda.time.Period period49 = period46.withMillis((int) (short) 1);
//        java.lang.Object obj50 = null;
//        org.joda.time.ReadableDuration readableDuration51 = null;
//        org.joda.time.ReadableInstant readableInstant52 = null;
//        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.dayTime();
//        org.joda.time.ReadableInterval readableInterval56 = null;
//        org.joda.time.Chronology chronology57 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval56);
//        org.joda.time.Period period58 = new org.joda.time.Period((long) 'a', (long) 0, periodType55, chronology57);
//        org.joda.time.PeriodType periodType59 = periodType55.withYearsRemoved();
//        org.joda.time.Period period60 = new org.joda.time.Period(readableDuration51, readableInstant52, periodType59);
//        java.lang.String str61 = periodType59.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Period period63 = new org.joda.time.Period(obj50, periodType59, (org.joda.time.Chronology) gregorianChronology62);
//        org.joda.time.PeriodType periodType64 = periodType59.withHoursRemoved();
//        org.joda.time.Period period65 = period46.withPeriodType(periodType64);
//        org.joda.time.PeriodType periodType66 = org.joda.time.DateTimeUtils.getPeriodType(periodType64);
//        org.joda.time.PeriodType periodType67 = org.joda.time.DateTimeUtils.getPeriodType(periodType66);
//        org.joda.time.chrono.GregorianChronology gregorianChronology68 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str69 = gregorianChronology68.toString();
//        org.joda.time.DurationField durationField70 = gregorianChronology68.weekyears();
//        org.joda.time.DurationField durationField71 = gregorianChronology68.centuries();
//        org.joda.time.Chronology chronology72 = gregorianChronology68.withUTC();
//        org.joda.time.chrono.LenientChronology lenientChronology73 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology68);
//        org.joda.time.DurationField durationField74 = lenientChronology73.hours();
//        org.joda.time.Chronology chronology75 = lenientChronology73.withUTC();
//        org.joda.time.Period period76 = new org.joda.time.Period(52L, (long) 1, periodType67, (org.joda.time.Chronology) lenientChronology73);
//        org.joda.time.chrono.GregorianChronology gregorianChronology77 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone78 = gregorianChronology77.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone79 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone78);
//        boolean boolean80 = lenientChronology73.equals((java.lang.Object) cachedDateTimeZone79);
//        java.util.TimeZone timeZone81 = cachedDateTimeZone79.toTimeZone();
//        boolean boolean82 = jodaTimePermission1.equals((java.lang.Object) timeZone81);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 32L + "'", long17 == 32L);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(periodType26);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PT-0.097S" + "'", str32.equals("PT-0.097S"));
//        org.junit.Assert.assertNotNull(seconds33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1L) + "'", long36 == (-1L));
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(period49);
//        org.junit.Assert.assertNotNull(periodType55);
//        org.junit.Assert.assertNotNull(chronology57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PeriodType[DayTime]" + "'", str61.equals("PeriodType[DayTime]"));
//        org.junit.Assert.assertNotNull(gregorianChronology62);
//        org.junit.Assert.assertNotNull(periodType64);
//        org.junit.Assert.assertNotNull(period65);
//        org.junit.Assert.assertNotNull(periodType66);
//        org.junit.Assert.assertNotNull(periodType67);
//        org.junit.Assert.assertNotNull(gregorianChronology68);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "GregorianChronology[]" + "'", str69.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(durationField70);
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertNotNull(chronology72);
//        org.junit.Assert.assertNotNull(lenientChronology73);
//        org.junit.Assert.assertNotNull(durationField74);
//        org.junit.Assert.assertNotNull(chronology75);
//        org.junit.Assert.assertNotNull(gregorianChronology77);
//        org.junit.Assert.assertNotNull(dateTimeZone78);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone79);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(timeZone81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("");
        illegalFieldValueException2.prependMessage("PeriodType[DayTime]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException9.prependMessage("");
        illegalFieldValueException9.prependMessage("PeriodType[DayTime]");
        java.lang.Throwable[] throwableArray14 = illegalFieldValueException9.getSuppressed();
        boolean boolean15 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException18.prependMessage("");
        java.lang.String str21 = illegalFieldValueException18.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = illegalFieldValueException18.getDateTimeFieldType();
        illegalFieldValueException9.addSuppressed((java.lang.Throwable) illegalFieldValueException18);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException18);
        java.lang.Number number25 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported" + "'", str21.equals("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported"));
        org.junit.Assert.assertNull(dateTimeFieldType22);
        org.junit.Assert.assertNull(number25);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("UnsupportedDateTimeField", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"UnsupportedDateTimeField/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test086");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        long long17 = offsetDateTimeField15.roundHalfEven(97L);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField15.getAsShortText((int) (byte) -1, locale19);
//        int int22 = offsetDateTimeField15.getMaximumValue((long) 10000);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone27);
//        long long32 = iSOChronology28.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology33 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology28);
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology28.year();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology28.minuteOfHour();
//        org.joda.time.Period period36 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology28);
//        org.joda.time.DurationField durationField37 = iSOChronology28.minutes();
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology28.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, 20);
//        long long42 = offsetDateTimeField40.roundHalfEven(97L);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = offsetDateTimeField40.getAsShortText((int) (byte) -1, locale44);
//        long long48 = offsetDateTimeField40.addWrapField((-34L), 2);
//        java.util.Locale locale49 = null;
//        int int50 = offsetDateTimeField40.getMaximumShortTextLength(locale49);
//        org.joda.time.ReadablePartial readablePartial51 = null;
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
//        long long57 = iSOChronology53.add(0L, (long) 1, (int) ' ');
//        org.joda.time.chrono.LenientChronology lenientChronology58 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology53);
//        java.lang.String str59 = lenientChronology58.toString();
//        org.joda.time.DateTimeField dateTimeField60 = lenientChronology58.centuryOfEra();
//        java.lang.String str61 = lenientChronology58.toString();
//        org.joda.time.ReadableInstant readableInstant64 = null;
//        org.joda.time.ReadableInstant readableInstant65 = null;
//        org.joda.time.Chronology chronology66 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant64, readableInstant65);
//        org.joda.time.Period period67 = new org.joda.time.Period((long) (short) -1, 10L, chronology66);
//        int int68 = period67.getDays();
//        org.joda.time.Period period70 = period67.withMillis((int) (short) 1);
//        org.joda.time.format.PeriodFormatter periodFormatter71 = null;
//        java.lang.String str72 = period67.toString(periodFormatter71);
//        int[] intArray74 = lenientChronology58.get((org.joda.time.ReadablePeriod) period67, (-210865982400000L));
//        int int75 = offsetDateTimeField40.getMaximumValue(readablePartial51, intArray74);
//        try {
//            int[] intArray77 = offsetDateTimeField15.add(readablePartial23, 36000000, intArray74, 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 36000000");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135596800001L) + "'", long17 == (-62135596800001L));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-1" + "'", str20.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 21 + "'", int22 == 21);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-65L) + "'", long32 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-62135596800001L) + "'", long42 == (-62135596800001L));
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "-1" + "'", str45.equals("-1"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-34L) + "'", long48 == (-34L));
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
//        org.junit.Assert.assertNotNull(iSOChronology53);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 32L + "'", long57 == 32L);
//        org.junit.Assert.assertNotNull(lenientChronology58);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "LenientChronology[ISOChronology[]]" + "'", str59.equals("LenientChronology[ISOChronology[]]"));
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "LenientChronology[ISOChronology[]]" + "'", str61.equals("LenientChronology[ISOChronology[]]"));
//        org.junit.Assert.assertNotNull(chronology66);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//        org.junit.Assert.assertNotNull(period70);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "PT0.011S" + "'", str72.equals("PT0.011S"));
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 21 + "'", int75 == 21);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '4', 0L, (int) (byte) 100);
        org.joda.time.DurationField durationField6 = iSOChronology1.hours();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.millisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long6 = iSOChronology2.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        int int11 = dateTimeZone9.getOffset(readableInstant10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        long long16 = cachedDateTimeZone12.convertLocalToUTC((long) 10, true, (long) (short) 10);
        java.lang.String str18 = cachedDateTimeZone12.getShortName(32L);
        java.util.TimeZone timeZone19 = cachedDateTimeZone12.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, (org.joda.time.DateTimeZone) cachedDateTimeZone12);
        try {
            long long26 = zonedChronology21.getDateTimeMillis(27, 8, (-34), 1000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -34 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-65L) + "'", long6 == (-65L));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 11L + "'", long16 == 11L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-00:00:00.001" + "'", str18.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(zonedChronology21);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long8 = cachedDateTimeZone4.convertLocalToUTC((long) 10, true, (long) (short) 10);
        boolean boolean9 = cachedDateTimeZone4.isFixed();
        long long11 = cachedDateTimeZone4.convertUTCToLocal(1216007L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 11L + "'", long8 == 11L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1216006L + "'", long11 == 1216006L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long13 = dateTimeZone10.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone15 = cachedDateTimeZone14.getUncachedZone();
        java.lang.String str17 = cachedDateTimeZone14.getName(97L);
        org.joda.time.Chronology chronology18 = lenientChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone14);
        boolean boolean20 = cachedDateTimeZone14.isStandardOffset((long) 20);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-00:00:00.001" + "'", str17.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test091");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
//        int int22 = offsetDateTimeField15.getMaximumValue();
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = offsetDateTimeField15.getAsShortText(readablePartial23, 32000, locale25);
//        long long28 = offsetDateTimeField15.roundCeiling(97L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, dateTimeFieldType29, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775806L + "'", long21 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 21 + "'", int22 == 21);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "32000" + "'", str26.equals("32000"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775806L + "'", long28 == 9223372036854775806L);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        int int4 = periodType3.size();
        org.joda.time.PeriodType periodType5 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType7 = periodType3.getFieldType(0);
        int int8 = periodType0.indexOf(durationFieldType7);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) (short) -1);
        int int13 = preciseDurationField10.getDifference(0L, (long) 1);
        long long15 = preciseDurationField10.getMillis(34);
        long long17 = preciseDurationField10.getValueAsLong((long) 800000);
        long long20 = preciseDurationField10.subtract((long) (-83189600), (int) 'a');
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-34L) + "'", long15 == (-34L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-800000L) + "'", long17 == (-800000L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-83189503L) + "'", long20 == (-83189503L));
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test093");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
//        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, 10L, chronology6);
//        int int8 = period7.getDays();
//        org.joda.time.Days days9 = period7.toStandardDays();
//        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.seconds();
//        org.joda.time.Period period11 = period7.normalizedStandard(periodType10);
//        int[] intArray14 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L, 34L);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology0.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(days9);
//        org.junit.Assert.assertNotNull(periodType10);
//        org.junit.Assert.assertNotNull(period11);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getOffset(97L);
        int int8 = fixedDateTimeZone4.getOffset(0L);
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone4.getName(1L, locale11);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.001" + "'", str12.equals("+00:00:00.001"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant6, readableDuration7);
        long long11 = iSOChronology1.add((org.joda.time.ReadablePeriod) period8, (long) 1, (int) ' ');
        org.joda.time.Period period13 = period8.withSeconds(36000000);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        java.lang.Object obj1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) 'a', (long) 0, periodType6, chronology8);
        org.joda.time.PeriodType periodType10 = periodType6.withYearsRemoved();
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration2, readableInstant3, periodType10);
        java.lang.String str12 = periodType10.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period14 = new org.joda.time.Period(obj1, periodType10, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.hourOfDay();
        org.joda.time.Period period16 = new org.joda.time.Period((-863999999900L), (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationFieldType[] durationFieldTypeArray17 = period16.getFieldTypes();
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PeriodType[DayTime]" + "'", str12.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationFieldTypeArray17);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.Period period14 = period7.withPeriodType(periodType10);
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period14, obj15);
        java.lang.Class<?> wildcardClass17 = period14.getClass();
        org.joda.time.Period period19 = period14.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, periodType25, chronology27);
        org.joda.time.PeriodType periodType29 = periodType25.withYearsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType29);
        org.joda.time.PeriodType periodType31 = periodType29.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(10L, periodType29);
        org.joda.time.PeriodType periodType33 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
        boolean boolean35 = periodType29.equals((java.lang.Object) periodType34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        int int37 = periodType36.size();
        org.joda.time.PeriodType periodType38 = periodType36.withMonthsRemoved();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.seconds();
        int int40 = periodType39.size();
        org.joda.time.PeriodType periodType41 = periodType39.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType(0);
        int int44 = periodType36.indexOf(durationFieldType43);
        int int45 = periodType29.indexOf(durationFieldType43);
        org.joda.time.Period period47 = period14.withField(durationFieldType43, 0);
        int int48 = period1.get(durationFieldType43);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType43);
        try {
            int int52 = unsupportedDurationField49.getDifference((long) 3, (long) (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: seconds field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.Object obj0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(obj0, chronology1);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test099");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        int int18 = offsetDateTimeField15.getOffset();
//        int int19 = offsetDateTimeField15.getMinimumValue();
//        long long21 = offsetDateTimeField15.roundHalfCeiling(3L);
//        int int22 = offsetDateTimeField15.getOffset();
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 20 + "'", int18 == 20);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62135596800001L) + "'", long21 == (-62135596800001L));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.Period period1 = org.joda.time.Period.days(800000);
        org.joda.time.Hours hours2 = period1.toStandardHours();
        org.joda.time.Period period4 = period1.minusMillis((-360000065));
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) 'a', (long) 0, periodType11, chronology13);
        org.joda.time.PeriodType periodType15 = periodType11.withYearsRemoved();
        org.joda.time.Period period16 = new org.joda.time.Period(readableDuration7, readableInstant8, periodType15);
        org.joda.time.PeriodType periodType17 = periodType15.withDaysRemoved();
        org.joda.time.PeriodType periodType18 = periodType15.withYearsRemoved();
        org.joda.time.PeriodType periodType19 = periodType18.withHoursRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withMinutesRemoved();
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant5, readableDuration6, periodType20);
        org.joda.time.Period period23 = period21.withMillis(32000);
        org.joda.time.Period period24 = period4.withFields((org.joda.time.ReadablePeriod) period21);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(hours2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, 0);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, 10000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test102");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        int int21 = offsetDateTimeField15.getLeapAmount((long) (byte) 0);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField15.getAsText((int) (short) -1, locale23);
//        boolean boolean25 = offsetDateTimeField15.isLenient();
//        long long27 = offsetDateTimeField15.roundHalfCeiling((long) 1000);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "-1" + "'", str24.equals("-1"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62135596800001L) + "'", long27 == (-62135596800001L));
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test103");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
//        org.joda.time.DurationField durationField37 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        long long39 = zeroIsMaxDateTimeField34.remainder((long) 4);
//        int int42 = zeroIsMaxDateTimeField34.getDifference((long) 0, 1224000100L);
//        long long44 = zeroIsMaxDateTimeField34.roundCeiling(0L);
//        long long46 = zeroIsMaxDateTimeField34.remainder(97L);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1224000100) + "'", int42 == (-1224000100));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        long long8 = fixedDateTimeZone6.previousTransition(1L);
        long long10 = fixedDateTimeZone6.nextTransition((long) (byte) 1);
        int int12 = fixedDateTimeZone6.getStandardOffset((long) 36000000);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology13.getZone();
        try {
            long long20 = zonedChronology13.getDateTimeMillis((long) 20, (int) (short) 10, 0, 799900, 20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 799900 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.year();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology1.dayOfWeek();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("LenientChronology[ISOChronology[America/Los_Angeles]]");
        boolean boolean3 = jodaTimePermission1.equals((java.lang.Object) 8000010L);
        java.lang.String str4 = jodaTimePermission1.getName();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType7 = periodType6.withSecondsRemoved();
        org.joda.time.PeriodType periodType8 = periodType6.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        long long14 = iSOChronology10.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        long long20 = iSOChronology10.add((org.joda.time.ReadablePeriod) period17, (long) 1, (int) ' ');
        org.joda.time.DurationField durationField21 = iSOChronology10.months();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology10.monthOfYear();
        org.joda.time.DurationField durationField23 = iSOChronology10.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((-1L), periodType6, (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology10.millisOfDay();
        boolean boolean26 = jodaTimePermission1.equals((java.lang.Object) iSOChronology10);
        java.security.PermissionCollection permissionCollection27 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LenientChronology[ISOChronology[America/Los_Angeles]]" + "'", str4.equals("LenientChronology[ISOChronology[America/Los_Angeles]]"));
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-65L) + "'", long14 == (-65L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(permissionCollection27);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        boolean boolean2 = periodType0.isSupported(durationFieldType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType4 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType5 = periodType0.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "era");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test109");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        long long17 = offsetDateTimeField15.roundHalfEven(97L);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField15.getAsShortText((int) (byte) -1, locale19);
//        org.joda.time.DurationField durationField21 = offsetDateTimeField15.getRangeDurationField();
//        int int23 = offsetDateTimeField15.getMaximumValue(1100L);
//        long long25 = offsetDateTimeField15.roundHalfEven(320L);
//        org.joda.time.ReadablePartial readablePartial26 = null;
//        int[] intArray27 = null;
//        int int28 = offsetDateTimeField15.getMinimumValue(readablePartial26, intArray27);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135596800001L) + "'", long17 == (-62135596800001L));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-1" + "'", str20.equals("-1"));
//        org.junit.Assert.assertNull(durationField21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 21 + "'", int23 == 21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-62135596800001L) + "'", long25 == (-62135596800001L));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.withMillis((int) (short) 1);
        org.joda.time.Period period10 = period5.withMillis((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType12 = period5.getFieldType(4);
        org.joda.time.field.PreciseDurationField preciseDurationField14 = new org.joda.time.field.PreciseDurationField(durationFieldType12, (long) (-799980));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldType12);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        boolean boolean2 = periodType0.isSupported(durationFieldType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType4 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType5 = periodType0.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test112");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
//        long long39 = zeroIsMaxDateTimeField34.addWrapField((long) 80000, 640000);
//        org.joda.time.DurationField durationField40 = zeroIsMaxDateTimeField34.getDurationField();
//        org.joda.time.ReadablePartial readablePartial41 = null;
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
//        long long49 = iSOChronology45.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology50 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology45);
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology45.year();
//        org.joda.time.DateTimeField dateTimeField52 = iSOChronology45.minuteOfHour();
//        org.joda.time.Period period53 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology45);
//        org.joda.time.DurationField durationField54 = iSOChronology45.minutes();
//        org.joda.time.DateTimeField dateTimeField55 = iSOChronology45.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, 20);
//        int int59 = offsetDateTimeField57.getLeapAmount(1560628303058L);
//        int int60 = offsetDateTimeField57.getOffset();
//        org.joda.time.ReadablePartial readablePartial61 = null;
//        org.joda.time.ReadableInstant readableInstant63 = null;
//        org.joda.time.ReadableInstant readableInstant64 = null;
//        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant63, readableInstant64);
//        org.joda.time.Period period66 = new org.joda.time.Period((long) (-1), chronology65);
//        org.joda.time.Period period68 = period66.withDays(0);
//        int[] intArray69 = period68.getValues();
//        int int70 = offsetDateTimeField57.getMaximumValue(readablePartial61, intArray69);
//        int int71 = zeroIsMaxDateTimeField34.getMinimumValue(readablePartial41, intArray69);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 80000L + "'", long39 == 80000L);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-65L) + "'", long49 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(durationField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 20 + "'", int60 == 20);
//        org.junit.Assert.assertNotNull(chronology65);
//        org.junit.Assert.assertNotNull(period68);
//        org.junit.Assert.assertNotNull(intArray69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 21 + "'", int70 == 21);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.lang.Object obj1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) 'a', (long) 0, periodType6, chronology8);
        org.joda.time.PeriodType periodType10 = periodType6.withYearsRemoved();
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration2, readableInstant3, periodType10);
        java.lang.String str12 = periodType10.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period14 = new org.joda.time.Period(obj1, periodType10, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.PeriodType periodType15 = periodType10.withHoursRemoved();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        long long21 = iSOChronology17.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        long long27 = iSOChronology17.add((org.joda.time.ReadablePeriod) period24, (long) 1, (int) ' ');
        org.joda.time.Chronology chronology28 = iSOChronology17.withUTC();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology17.dayOfYear();
        long long33 = iSOChronology17.add(100L, 34L, 36000000);
        org.joda.time.Period period34 = new org.joda.time.Period((long) 104, periodType15, (org.joda.time.Chronology) iSOChronology17);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PeriodType[DayTime]" + "'", str12.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-65L) + "'", long21 == (-65L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1224000100L + "'", long33 == 1224000100L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[America/Los_Angeles]", (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[America/Los_Angeles]", (int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeZoneBuilder0.toDateTimeZone("GregorianChronology[-00:00:00.001]", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder0.setFixedSavings("ISOChronology[UTC]", (int) (byte) 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder12.setStandardOffset(0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder17 = dateTimeZoneBuilder12.setFixedSavings("", (int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder12);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder17);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period2 = new org.joda.time.Period(0L, periodType1);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "PeriodType[DayTime]", "LenientChronology[ISOChronology[-00:00:00.001]]");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "PT0.011S", "hi!");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "", "P100WT-0.001S");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("");
        illegalFieldValueException2.prependMessage("PeriodType[DayTime]");
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException2.getSuppressed();
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException11.prependMessage("");
        java.lang.String str14 = illegalFieldValueException11.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = illegalFieldValueException11.getDateTimeFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException11);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str18 = illegalFieldValueException2.getFieldName();
        org.joda.time.DurationFieldType durationFieldType19 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported" + "'", str14.equals("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported"));
        org.junit.Assert.assertNull(dateTimeFieldType15);
        org.junit.Assert.assertNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNull(durationFieldType19);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.Period period14 = period7.withPeriodType(periodType10);
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period14, obj15);
        java.lang.Class<?> wildcardClass17 = period14.getClass();
        org.joda.time.Period period19 = period14.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, periodType25, chronology27);
        org.joda.time.PeriodType periodType29 = periodType25.withYearsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType29);
        org.joda.time.PeriodType periodType31 = periodType29.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(10L, periodType29);
        org.joda.time.PeriodType periodType33 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
        boolean boolean35 = periodType29.equals((java.lang.Object) periodType34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        int int37 = periodType36.size();
        org.joda.time.PeriodType periodType38 = periodType36.withMonthsRemoved();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.seconds();
        int int40 = periodType39.size();
        org.joda.time.PeriodType periodType41 = periodType39.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType(0);
        int int44 = periodType36.indexOf(durationFieldType43);
        int int45 = periodType29.indexOf(durationFieldType43);
        org.joda.time.Period period47 = period14.withField(durationFieldType43, 0);
        int int48 = period1.get(durationFieldType43);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType43);
        boolean boolean50 = unsupportedDurationField49.isPrecise();
        try {
            long long52 = unsupportedDurationField49.getMillis(1216006L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: seconds field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.Period period8 = new org.joda.time.Period(640000, 2, 20, 608003, 36000000, 608003, (int) (byte) 0, 0);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period8.toDurationFrom(readableInstant10);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(duration11);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test120");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str5 = gregorianChronology4.toString();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        int int9 = dateTimeZone7.getOffset(readableInstant8);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        org.joda.time.Chronology chronology11 = gregorianChronology4.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) cachedDateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.monthOfYear();
//        try {
//            long long21 = zonedChronology12.getDateTimeMillis((-20), (int) (byte) -1, (int) 'a', 4, 0, 0, (-20));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -20 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[]" + "'", str5.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.Period period14 = period7.withPeriodType(periodType10);
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period14, obj15);
        java.lang.Class<?> wildcardClass17 = period14.getClass();
        org.joda.time.Period period19 = period14.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, periodType25, chronology27);
        org.joda.time.PeriodType periodType29 = periodType25.withYearsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType29);
        org.joda.time.PeriodType periodType31 = periodType29.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(10L, periodType29);
        org.joda.time.PeriodType periodType33 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
        boolean boolean35 = periodType29.equals((java.lang.Object) periodType34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        int int37 = periodType36.size();
        org.joda.time.PeriodType periodType38 = periodType36.withMonthsRemoved();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.seconds();
        int int40 = periodType39.size();
        org.joda.time.PeriodType periodType41 = periodType39.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType(0);
        int int44 = periodType36.indexOf(durationFieldType43);
        int int45 = periodType29.indexOf(durationFieldType43);
        org.joda.time.Period period47 = period14.withField(durationFieldType43, 0);
        int int48 = period1.get(durationFieldType43);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType43);
        boolean boolean50 = unsupportedDurationField49.isPrecise();
        org.joda.time.DurationFieldType durationFieldType51 = unsupportedDurationField49.getType();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(durationFieldType51);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test122");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
//        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str26 = gregorianChronology25.toString();
//        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
//        long long31 = unsupportedDateTimeField28.getDifferenceAsLong((long) (-7), 9223372036854775806L);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getRangeDurationField();
//        long long35 = unsupportedDateTimeField28.add(616007L, (long) (-800000));
//        try {
//            long long37 = unsupportedDateTimeField28.roundHalfFloor(11L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775806L + "'", long21 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800001L) + "'", long23 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[]" + "'", str26.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 292277025L + "'", long31 == 292277025L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-25245561599383993L) + "'", long35 == (-25245561599383993L));
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.Period period1 = org.joda.time.Period.millis((-360000065));
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test124");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        long long17 = offsetDateTimeField15.roundHalfEven(97L);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField15.getAsShortText((int) (byte) -1, locale19);
//        long long23 = offsetDateTimeField15.addWrapField((-34L), 2);
//        boolean boolean24 = offsetDateTimeField15.isSupported();
//        int int26 = offsetDateTimeField15.getMinimumValue(148210560000034L);
//        long long29 = offsetDateTimeField15.addWrapField(36L, (int) (short) 10);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135596800001L) + "'", long17 == (-62135596800001L));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-1" + "'", str20.equals("-1"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-34L) + "'", long23 == (-34L));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 36L + "'", long29 == 36L);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(100);
        org.joda.time.PeriodType periodType2 = period1.getPeriodType();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        long long8 = iSOChronology4.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.Period period9 = new org.joda.time.Period((long) '#', (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology4.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology4.weekyear();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology4.halfdayOfDay();
        try {
            org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) 32000, periodType1, (org.joda.time.Chronology) iSOChronology4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-65L) + "'", long8 == (-65L));
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test127");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
//        org.joda.time.DurationField durationField37 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        long long39 = zeroIsMaxDateTimeField34.remainder((long) 4);
//        long long41 = zeroIsMaxDateTimeField34.roundFloor((long) 800001000);
//        org.joda.time.DurationField durationField42 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        org.joda.time.DurationField durationField43 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        long long45 = zeroIsMaxDateTimeField34.roundHalfFloor(124271193600085L);
//        java.lang.String str46 = zeroIsMaxDateTimeField34.getName();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 800001000L + "'", long41 == 800001000L);
//        org.junit.Assert.assertNull(durationField42);
//        org.junit.Assert.assertNull(durationField43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 124271193600085L + "'", long45 == 124271193600085L);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "era" + "'", str46.equals("era"));
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withMinutesRemoved();
        java.lang.String str3 = periodType2.getName();
        org.joda.time.PeriodType periodType4 = periodType2.withYearsRemoved();
        java.lang.String str5 = periodType4.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Seconds" + "'", str3.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Seconds" + "'", str5.equals("Seconds"));
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test129");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
//        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str26 = gregorianChronology25.toString();
//        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
//        long long31 = unsupportedDateTimeField28.getDifferenceAsLong((long) (-7), 9223372036854775806L);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getRangeDurationField();
//        boolean boolean33 = unsupportedDateTimeField28.isLenient();
//        try {
//            long long36 = unsupportedDateTimeField28.set((long) 36000000, (int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775806L + "'", long21 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800001L) + "'", long23 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[]" + "'", str26.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 292277025L + "'", long31 == 292277025L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) (short) 1, locale17);
        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField15.getWrappedField();
        int int20 = offsetDateTimeField15.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "21" + "'", str18.equals("21"));
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 20 + "'", int20 == 20);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-21));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 21 + "'", int1 == 21);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.joda.time.Period period1 = org.joda.time.Period.hours(1);
        org.joda.time.Period period3 = period1.minusMinutes((int) (short) -1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test133");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
//        try {
//            long long39 = zeroIsMaxDateTimeField34.set((-48077599992L), (-1224000100));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1224000100 for era must be in the range [1,1000]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        java.lang.Object obj13 = null;
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period12, obj13);
        java.lang.Class<?> wildcardClass15 = period12.getClass();
        org.joda.time.Period period17 = period12.multipliedBy(10);
        org.joda.time.Days days18 = period17.toStandardDays();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) 'a', (long) 0, periodType23, chronology25);
        org.joda.time.PeriodType periodType27 = periodType23.withYearsRemoved();
        org.joda.time.Period period28 = new org.joda.time.Period(readableDuration19, readableInstant20, periodType27);
        java.lang.String str29 = periodType27.toString();
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.seconds();
        int int31 = periodType30.size();
        org.joda.time.PeriodType periodType32 = periodType30.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType34 = periodType30.getFieldType(0);
        java.lang.Number number35 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException38 = new org.joda.time.IllegalFieldValueException(durationFieldType34, number35, (java.lang.Number) (-863999999900L), (java.lang.Number) 2440587.5000011576d);
        int int39 = periodType27.indexOf(durationFieldType34);
        boolean boolean40 = period17.isSupported(durationFieldType34);
        org.joda.time.PeriodType periodType43 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval44 = null;
        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval44);
        org.joda.time.Period period46 = new org.joda.time.Period((long) 'a', (long) 0, periodType43, chronology45);
        org.joda.time.PeriodType periodType49 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval50);
        org.joda.time.Period period52 = new org.joda.time.Period((long) 'a', (long) 0, periodType49, chronology51);
        org.joda.time.Period period53 = period46.withPeriodType(periodType49);
        java.lang.Object obj54 = null;
        boolean boolean55 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period53, obj54);
        java.lang.Class<?> wildcardClass56 = period53.getClass();
        org.joda.time.Period period58 = period53.multipliedBy(10);
        org.joda.time.Days days59 = period58.toStandardDays();
        org.joda.time.ReadableDuration readableDuration60 = null;
        org.joda.time.ReadableInstant readableInstant61 = null;
        org.joda.time.PeriodType periodType64 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval65 = null;
        org.joda.time.Chronology chronology66 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval65);
        org.joda.time.Period period67 = new org.joda.time.Period((long) 'a', (long) 0, periodType64, chronology66);
        org.joda.time.PeriodType periodType68 = periodType64.withYearsRemoved();
        org.joda.time.Period period69 = new org.joda.time.Period(readableDuration60, readableInstant61, periodType68);
        java.lang.String str70 = periodType68.toString();
        org.joda.time.PeriodType periodType71 = org.joda.time.PeriodType.seconds();
        int int72 = periodType71.size();
        org.joda.time.PeriodType periodType73 = periodType71.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType75 = periodType71.getFieldType(0);
        java.lang.Number number76 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException79 = new org.joda.time.IllegalFieldValueException(durationFieldType75, number76, (java.lang.Number) (-863999999900L), (java.lang.Number) 2440587.5000011576d);
        int int80 = periodType68.indexOf(durationFieldType75);
        boolean boolean81 = period58.isSupported(durationFieldType75);
        boolean boolean82 = period17.isSupported(durationFieldType75);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(days18);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PeriodType[DayTime]" + "'", str29.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 3 + "'", int39 == 3);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(periodType43);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(periodType49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(days59);
        org.junit.Assert.assertNotNull(periodType64);
        org.junit.Assert.assertNotNull(chronology66);
        org.junit.Assert.assertNotNull(periodType68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "PeriodType[DayTime]" + "'", str70.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(periodType71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(periodType73);
        org.junit.Assert.assertNotNull(durationFieldType75);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 3 + "'", int80 == 3);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[-00:00:00.001]", "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.097 (hi!)", 0, (int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        long long10 = iSOChronology6.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology6.era();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long16 = dateTimeZone13.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
        org.joda.time.Chronology chronology18 = iSOChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
        long long22 = cachedDateTimeZone17.convertLocalToUTC((long) 10, true, (long) (short) 0);
        long long24 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone17, 148210585201011L);
        long long26 = fixedDateTimeZone4.convertUTCToLocal((long) 640000);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 11L + "'", long22 == 11L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 148210585201012L + "'", long24 == 148210585201012L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 640000L + "'", long26 == 640000L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getOffset(97L);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gregorianChronology9);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test137");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
//        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str26 = gregorianChronology25.toString();
//        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
//        long long31 = unsupportedDateTimeField28.getDifferenceAsLong((long) (-7), 9223372036854775806L);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getRangeDurationField();
//        boolean boolean33 = unsupportedDateTimeField28.isLenient();
//        try {
//            long long36 = unsupportedDateTimeField28.set(0L, "");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775806L + "'", long21 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800001L) + "'", long23 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[]" + "'", str26.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 292277025L + "'", long31 == 292277025L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long8 = cachedDateTimeZone4.convertLocalToUTC((long) 10, true, (long) (short) 10);
        int int10 = cachedDateTimeZone4.getOffsetFromLocal(100L);
        boolean boolean12 = cachedDateTimeZone4.isStandardOffset(320L);
        java.lang.String str14 = cachedDateTimeZone4.getNameKey((long) 27);
        long long17 = cachedDateTimeZone4.adjustOffset(4L, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 11L + "'", long8 == 11L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4L + "'", long17 == 4L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[America/Los_Angeles]", (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder3.setStandardOffset(0);
        java.io.OutputStream outputStream7 = null;
        try {
            dateTimeZoneBuilder3.writeTo("PeriodType[YearMonthDayTime]", outputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test140");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
//        boolean boolean22 = offsetDateTimeField15.isSupported();
//        long long24 = offsetDateTimeField15.roundFloor(62135596800086L);
//        long long26 = offsetDateTimeField15.roundCeiling(0L);
//        long long28 = offsetDateTimeField15.roundHalfFloor(13600036L);
//        long long31 = offsetDateTimeField15.addWrapField(1100L, 3);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775806L + "'", long21 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62135596800001L) + "'", long24 == (-62135596800001L));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775806L + "'", long26 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62135596800001L) + "'", long28 == (-62135596800001L));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-124334351998900L) + "'", long31 == (-124334351998900L));
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (-21), (-59334459011L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-59334459032L) + "'", long2 == (-59334459032L));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        org.joda.time.Period period7 = period5.plusMonths(0);
        int int8 = period7.getMillis();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getOffset(97L);
        java.lang.String str8 = fixedDateTimeZone4.getShortName((-1L));
        java.lang.String str10 = fixedDateTimeZone4.getNameKey((long) 33);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT0.011S" + "'", str10.equals("PT0.011S"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long9 = dateTimeZone6.convertLocalToUTC(0L, true);
        org.joda.time.ReadableInstant readableInstant10 = null;
        int int11 = dateTimeZone6.getOffset(readableInstant10);
        long long13 = cachedDateTimeZone4.getMillisKeepLocal(dateTimeZone6, (long) (short) 100);
        long long16 = dateTimeZone6.adjustOffset((long) (short) 0, true);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone6.getShortName(148210585201011L, locale18);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test145");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.year();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        long long11 = iSOChronology7.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology7);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.year();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology7.minuteOfHour();
//        org.joda.time.Period period15 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology7);
//        org.joda.time.DurationField durationField16 = iSOChronology7.minutes();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology7.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 20);
//        int int21 = offsetDateTimeField19.getLeapAmount(1560628303058L);
//        long long23 = offsetDateTimeField19.remainder(87L);
//        long long25 = offsetDateTimeField19.roundHalfCeiling((-62135596799999L));
//        long long27 = offsetDateTimeField19.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField19.getType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str30 = gregorianChronology29.toString();
//        org.joda.time.DurationField durationField31 = gregorianChronology29.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField31);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType28, (int) (short) 10, 2, 27);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType28, 79966);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-65L) + "'", long11 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 62135596800088L + "'", long23 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775806L + "'", long25 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62135596800001L) + "'", long27 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "GregorianChronology[]" + "'", str30.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long13 = dateTimeZone10.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone15 = cachedDateTimeZone14.getUncachedZone();
        java.lang.String str17 = cachedDateTimeZone14.getName(97L);
        org.joda.time.Chronology chronology18 = lenientChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone14);
        long long21 = cachedDateTimeZone14.adjustOffset((long) (-7), true);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-00:00:00.001" + "'", str17.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-7L) + "'", long21 == (-7L));
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test147");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
//        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, 10L, chronology6);
//        int int8 = period7.getDays();
//        org.joda.time.Days days9 = period7.toStandardDays();
//        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.seconds();
//        org.joda.time.Period period11 = period7.normalizedStandard(periodType10);
//        int[] intArray14 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L, 34L);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.monthOfYear();
//        org.joda.time.DurationField durationField16 = gregorianChronology0.months();
//        long long19 = durationField16.subtract((long) (-1224000100), 608002);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(days9);
//        org.junit.Assert.assertNotNull(periodType10);
//        org.junit.Assert.assertNotNull(period11);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1598891976000100L) + "'", long19 == (-1598891976000100L));
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.joda.time.Period period1 = new org.joda.time.Period(124271193600118L);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test149");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        long long6 = iSOChronology2.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology7 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology7.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField9 = lenientChronology7.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        long long17 = iSOChronology13.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology18 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.year();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology13.minuteOfHour();
//        org.joda.time.Period period21 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.DurationField durationField22 = iSOChronology13.minutes();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology13.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, 20);
//        int int27 = offsetDateTimeField25.getLeapAmount(1560628303058L);
//        long long29 = offsetDateTimeField25.remainder(87L);
//        long long31 = offsetDateTimeField25.roundHalfCeiling((-62135596799999L));
//        long long33 = offsetDateTimeField25.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = offsetDateTimeField25.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType34);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
//        long long41 = iSOChronology37.add(0L, (long) 1, (int) ' ');
//        org.joda.time.chrono.LenientChronology lenientChronology42 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology37);
//        org.joda.time.DateTimeField dateTimeField43 = lenientChronology42.yearOfEra();
//        long long49 = lenientChronology42.getDateTimeMillis((long) 4, (int) (short) 1, 0, 10000, (int) '#');
//        org.joda.time.DurationField durationField50 = lenientChronology42.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField51 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType34, durationField50);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField52 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-65L) + "'", long6 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-65L) + "'", long17 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 62135596800088L + "'", long29 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775806L + "'", long31 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62135596800001L) + "'", long33 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 32L + "'", long41 == 32L);
//        org.junit.Assert.assertNotNull(lenientChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 13600034L + "'", long49 == 13600034L);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField51);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test150");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
//        long long40 = iSOChronology36.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.DurationField durationField41 = iSOChronology36.years();
//        org.joda.time.DurationField durationField42 = iSOChronology36.days();
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
//        long long48 = iSOChronology44.add(0L, (long) 1, (int) ' ');
//        org.joda.time.chrono.LenientChronology lenientChronology49 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology44);
//        org.joda.time.DateTimeField dateTimeField50 = lenientChronology49.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField51 = lenientChronology49.halfdayOfDay();
//        org.joda.time.DurationField durationField52 = lenientChronology49.weeks();
//        long long55 = durationField52.subtract(0L, 11L);
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField56 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType33, durationField42, durationField52);
//        long long58 = preciseDateTimeField56.roundCeiling((-141746760000000L));
//        boolean boolean59 = preciseDateTimeField56.isLenient();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-65L) + "'", long40 == (-65L));
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 32L + "'", long48 == 32L);
//        org.junit.Assert.assertNotNull(lenientChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-6652800000L) + "'", long55 == (-6652800000L));
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-141746716800000L) + "'", long58 == (-141746716800000L));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test151");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.halfdayOfDay();
//        java.lang.String str9 = lenientChronology6.toString();
//        org.joda.time.DateTimeField dateTimeField10 = lenientChronology6.minuteOfHour();
//        java.lang.String str11 = lenientChronology6.toString();
//        long long17 = lenientChronology6.getDateTimeMillis(3600027L, 27, (-21), (-1), (-360000065));
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LenientChronology[ISOChronology[]]" + "'", str9.equals("LenientChronology[ISOChronology[]]"));
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "LenientChronology[ISOChronology[]]" + "'", str11.equals("LenientChronology[ISOChronology[]]"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-264061066L) + "'", long17 == (-264061066L));
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("org.joda.time.IllegalFieldValueException: Value -1 for PT-0.097S must not be smaller than 1", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"org.joda.time.IllegalFieldValueException: Value -1 for PT-0.097S must not be smaller than 1/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        int int4 = periodType3.size();
        org.joda.time.PeriodType periodType5 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType7 = periodType3.getFieldType(0);
        int int8 = periodType0.indexOf(durationFieldType7);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) (short) -1);
        int int13 = preciseDurationField10.getDifference(0L, (long) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = gregorianChronology14.withZone(dateTimeZone16);
        boolean boolean18 = preciseDurationField10.equals((java.lang.Object) gregorianChronology14);
        int int21 = preciseDurationField10.getValue((long) 21, (-210858120000000L));
        long long24 = preciseDurationField10.add((-210866760000000L), (-799980));
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-21) + "'", int21 == (-21));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-210866759200020L) + "'", long24 == (-210866759200020L));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Days days7 = period5.toStandardDays();
        org.joda.time.Period period9 = period5.withHours(0);
        org.joda.time.Period period11 = period9.plusMillis((int) (byte) 1);
        java.lang.String str12 = period11.toString();
        org.joda.time.Period period14 = org.joda.time.Period.days((int) (short) 0);
        org.joda.time.Period period16 = period14.multipliedBy((int) (byte) 1);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.seconds();
        int int18 = periodType17.size();
        org.joda.time.PeriodType periodType19 = periodType17.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType21 = periodType17.getFieldType(0);
        java.lang.Number number22 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(durationFieldType21, number22, (java.lang.Number) (-863999999900L), (java.lang.Number) 2440587.5000011576d);
        int int26 = period16.indexOf(durationFieldType21);
        int int27 = period11.get(durationFieldType21);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(days7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PT0.012S" + "'", str12.equals("PT0.012S"));
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test155");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
//        boolean boolean22 = offsetDateTimeField15.isSupported();
//        long long24 = offsetDateTimeField15.roundFloor(62135596800086L);
//        java.lang.String str25 = offsetDateTimeField15.getName();
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775806L + "'", long21 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62135596800001L) + "'", long24 == (-62135596800001L));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "era" + "'", str25.equals("era"));
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        int int3 = periodType2.size();
        org.joda.time.PeriodType periodType4 = periodType2.withMonthsRemoved();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder5.setFixedSavings("GregorianChronology[America/Los_Angeles]", (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder5.setFixedSavings("GregorianChronology[America/Los_Angeles]", (int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder5.toDateTimeZone("GregorianChronology[-00:00:00.001]", true);
        boolean boolean15 = periodType4.equals((java.lang.Object) dateTimeZone14);
        try {
            org.joda.time.Period period16 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.withMillis((int) (short) 1);
        org.joda.time.Period period10 = period8.plusSeconds((int) (short) 10);
        org.joda.time.Period period12 = org.joda.time.Period.minutes((-1));
        int int13 = period12.getHours();
        org.joda.time.Period period15 = period12.withHours((int) (byte) 1);
        org.joda.time.Period period16 = period8.minus((org.joda.time.ReadablePeriod) period12);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test158");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
//        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str26 = gregorianChronology25.toString();
//        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
//        long long31 = unsupportedDateTimeField28.getDifferenceAsLong((long) (-7), 9223372036854775806L);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getRangeDurationField();
//        boolean boolean33 = unsupportedDateTimeField28.isLenient();
//        org.joda.time.ReadablePartial readablePartial34 = null;
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
//        long long41 = iSOChronology37.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.Period period42 = new org.joda.time.Period((long) '#', (org.joda.time.Chronology) iSOChronology37);
//        org.joda.time.Period period44 = period42.plusMonths((int) (short) -1);
//        int[] intArray45 = period42.getValues();
//        try {
//            int int46 = unsupportedDateTimeField28.getMaximumValue(readablePartial34, intArray45);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775806L + "'", long21 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800001L) + "'", long23 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[]" + "'", str26.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 292277025L + "'", long31 == 292277025L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-65L) + "'", long41 == (-65L));
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertNotNull(intArray45);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(4L, (long) 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.era();
        org.joda.time.DurationField durationField7 = iSOChronology1.weeks();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long6 = iSOChronology2.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.Chronology chronology9 = iSOChronology2.withZone(dateTimeZone8);
        org.joda.time.DurationField durationField10 = iSOChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology2.hourOfDay();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField11, 640000, 67, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 640000 for hourOfDay must be in the range [67,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-65L) + "'", long6 == (-65L));
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test162");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        int int21 = offsetDateTimeField15.getLeapAmount((long) (byte) 0);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField15.getAsText((int) (short) -1, locale23);
//        java.util.Locale locale25 = null;
//        int int26 = offsetDateTimeField15.getMaximumTextLength(locale25);
//        long long28 = offsetDateTimeField15.roundFloor((long) 104);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "-1" + "'", str24.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62135596800001L) + "'", long28 == (-62135596800001L));
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test163");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        int int5 = dateTimeZone3.getOffset(readableInstant4);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology0.getZone();
//        org.joda.time.DurationField durationField9 = gregorianChronology0.months();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(durationField9);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Seconds seconds15 = period12.toStandardSeconds();
        org.joda.time.Period period17 = period12.minusDays((int) (byte) 100);
        org.joda.time.DurationFieldType durationFieldType18 = null;
        int int19 = period12.indexOf(durationFieldType18);
        try {
            org.joda.time.Period period21 = period12.withYears(2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT-0.097S" + "'", str14.equals("PT-0.097S"));
        org.junit.Assert.assertNotNull(seconds15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        long long9 = iSOChronology5.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField11 = lenientChronology10.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = lenientChronology10.millisOfSecond();
        boolean boolean13 = jodaTimePermission1.equals((java.lang.Object) lenientChronology10);
        org.joda.time.DateTimeField dateTimeField14 = lenientChronology10.secondOfMinute();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-65L) + "'", long9 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test166");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
//        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str26 = gregorianChronology25.toString();
//        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
//        java.lang.String str29 = unsupportedDateTimeField28.toString();
//        try {
//            long long31 = unsupportedDateTimeField28.roundHalfEven((-48077599992L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775806L + "'", long21 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800001L) + "'", long23 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[]" + "'", str26.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDateTimeField" + "'", str29.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-34));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210869697600000L) + "'", long1 == (-210869697600000L));
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test168");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
//        org.joda.time.DurationField durationField37 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        long long39 = zeroIsMaxDateTimeField34.remainder((long) 4);
//        org.joda.time.DateTimeField dateTimeField40 = zeroIsMaxDateTimeField34.getWrappedField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, dateTimeFieldType41, 0, (-21), 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test169");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
//        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
//        java.lang.Number number25 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, number25, (java.lang.Number) 62135596800086L, (java.lang.Number) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) (-56940685192995L), "PeriodType[YearMonthDayTime]");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, "org.joda.time.IllegalFieldValueException: Value 100 for -00:00:00.001 must be in the range [0,10]");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, "Weeks");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, "PeriodType[YearMonthDayTime]");
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775806L + "'", long21 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800001L) + "'", long23 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.Period period14 = period7.withPeriodType(periodType10);
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period14, obj15);
        java.lang.Class<?> wildcardClass17 = period14.getClass();
        org.joda.time.Period period19 = period14.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, periodType25, chronology27);
        org.joda.time.PeriodType periodType29 = periodType25.withYearsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType29);
        org.joda.time.PeriodType periodType31 = periodType29.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(10L, periodType29);
        org.joda.time.PeriodType periodType33 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
        boolean boolean35 = periodType29.equals((java.lang.Object) periodType34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        int int37 = periodType36.size();
        org.joda.time.PeriodType periodType38 = periodType36.withMonthsRemoved();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.seconds();
        int int40 = periodType39.size();
        org.joda.time.PeriodType periodType41 = periodType39.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType(0);
        int int44 = periodType36.indexOf(durationFieldType43);
        int int45 = periodType29.indexOf(durationFieldType43);
        org.joda.time.Period period47 = period14.withField(durationFieldType43, 0);
        int int48 = period1.get(durationFieldType43);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType43);
        java.lang.String str50 = unsupportedDurationField49.toString();
        try {
            long long53 = unsupportedDurationField49.add(34L, (-10L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: seconds field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "UnsupportedDurationField[seconds]" + "'", str50.equals("UnsupportedDurationField[seconds]"));
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test171");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
//        long long40 = iSOChronology36.add(0L, (long) 1, (int) ' ');
//        org.joda.time.chrono.LenientChronology lenientChronology41 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology36);
//        org.joda.time.DateTimeField dateTimeField42 = lenientChronology41.yearOfEra();
//        long long48 = lenientChronology41.getDateTimeMillis((long) 4, (int) (short) 1, 0, 10000, (int) '#');
//        org.joda.time.DurationField durationField49 = lenientChronology41.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField49);
//        try {
//            long long52 = unsupportedDateTimeField50.roundHalfFloor((long) 79966);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 32L + "'", long40 == 32L);
//        org.junit.Assert.assertNotNull(lenientChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 13600034L + "'", long48 == 13600034L);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long6 = iSOChronology2.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        int int11 = dateTimeZone9.getOffset(readableInstant10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        long long16 = cachedDateTimeZone12.convertLocalToUTC((long) 10, true, (long) (short) 10);
        java.lang.String str18 = cachedDateTimeZone12.getShortName(32L);
        java.util.TimeZone timeZone19 = cachedDateTimeZone12.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, (org.joda.time.DateTimeZone) cachedDateTimeZone12);
        boolean boolean23 = zonedChronology21.equals((java.lang.Object) 3L);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        org.joda.time.Chronology chronology28 = zonedChronology21.withZone(dateTimeZone25);
        org.joda.time.ReadableInstant readableInstant29 = null;
        int int30 = dateTimeZone25.getOffset(readableInstant29);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-65L) + "'", long6 == (-65L));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 11L + "'", long16 == 11L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-00:00:00.001" + "'", str18.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        long long8 = iSOChronology4.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Chronology chronology10 = lenientChronology9.withUTC();
        org.joda.time.Period period11 = new org.joda.time.Period((long) 32000, (-10L), periodType2, (org.joda.time.Chronology) lenientChronology9);
        org.joda.time.Period period20 = new org.joda.time.Period((int) (byte) -1, 0, (-1), (-1), 100, (int) (byte) 10, 100, (int) (byte) 1);
        try {
            org.joda.time.Period period21 = period11.withFields((org.joda.time.ReadablePeriod) period20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'weeks'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) 0, periodType3, chronology5);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) 'a', (long) 0, periodType9, chronology11);
        org.joda.time.Period period13 = period6.withPeriodType(periodType9);
        org.joda.time.Period period14 = period6.normalizedStandard();
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period14.toDurationTo(readableInstant15);
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration16);
        long long18 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration16);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval25 = null;
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval25);
        org.joda.time.Period period27 = new org.joda.time.Period((long) 'a', (long) 0, periodType24, chronology26);
        org.joda.time.PeriodType periodType28 = periodType24.withYearsRemoved();
        org.joda.time.Period period29 = new org.joda.time.Period(readableDuration20, readableInstant21, periodType28);
        java.lang.String str30 = periodType28.toString();
        java.lang.String str31 = periodType28.toString();
        org.joda.time.DurationField durationField32 = org.joda.time.field.MillisDurationField.INSTANCE;
        boolean boolean33 = periodType28.equals((java.lang.Object) durationField32);
        org.joda.time.PeriodType periodType34 = periodType28.withDaysRemoved();
        org.joda.time.Period period35 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant19, periodType28);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-97L) + "'", long18 == (-97L));
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PeriodType[DayTime]" + "'", str30.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "PeriodType[DayTime]" + "'", str31.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(periodType34);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        long long9 = iSOChronology5.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.era();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long15 = dateTimeZone12.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        org.joda.time.Chronology chronology17 = iSOChronology5.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone16);
        long long21 = cachedDateTimeZone16.convertLocalToUTC((long) 10, true, (long) (short) 0);
        long long23 = cachedDateTimeZone16.previousTransition(1L);
        java.util.Locale locale25 = null;
        java.lang.String str26 = cachedDateTimeZone16.getShortName(87L, locale25);
        org.joda.time.Chronology chronology27 = iSOChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 11L + "'", long21 == 11L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "-00:00:00.001" + "'", str26.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology27);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.Period period14 = period7.withPeriodType(periodType10);
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period14, obj15);
        java.lang.Class<?> wildcardClass17 = period14.getClass();
        org.joda.time.Period period19 = period14.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, periodType25, chronology27);
        org.joda.time.PeriodType periodType29 = periodType25.withYearsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType29);
        org.joda.time.PeriodType periodType31 = periodType29.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(10L, periodType29);
        org.joda.time.PeriodType periodType33 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
        boolean boolean35 = periodType29.equals((java.lang.Object) periodType34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        int int37 = periodType36.size();
        org.joda.time.PeriodType periodType38 = periodType36.withMonthsRemoved();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.seconds();
        int int40 = periodType39.size();
        org.joda.time.PeriodType periodType41 = periodType39.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType(0);
        int int44 = periodType36.indexOf(durationFieldType43);
        int int45 = periodType29.indexOf(durationFieldType43);
        org.joda.time.Period period47 = period14.withField(durationFieldType43, 0);
        int int48 = period1.get(durationFieldType43);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType43);
        try {
            long long52 = unsupportedDurationField49.getMillis((long) (byte) -1, (-49940105698912L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: seconds field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test177");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
//        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str26 = gregorianChronology25.toString();
//        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
//        org.joda.time.ReadablePartial readablePartial29 = null;
//        int[] intArray31 = null;
//        try {
//            int[] intArray33 = unsupportedDateTimeField28.addWrapField(readablePartial29, 34, intArray31, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775806L + "'", long21 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800001L) + "'", long23 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[]" + "'", str26.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        int int4 = periodType3.size();
        org.joda.time.PeriodType periodType5 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType7 = periodType3.getFieldType(0);
        int int8 = periodType0.indexOf(durationFieldType7);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) (short) -1);
        long long11 = preciseDurationField10.getUnitMillis();
        long long13 = preciseDurationField10.getMillis(0L);
        java.lang.Object obj14 = null;
        boolean boolean15 = preciseDurationField10.equals(obj14);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test179");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
//        boolean boolean22 = offsetDateTimeField15.isSupported();
//        int int24 = offsetDateTimeField15.getLeapAmount((-210858120000000L));
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
//        long long34 = iSOChronology30.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology35 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology30);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology30.year();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology30.minuteOfHour();
//        org.joda.time.Period period38 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology30);
//        org.joda.time.DurationField durationField39 = iSOChronology30.minutes();
//        org.joda.time.DateTimeField dateTimeField40 = iSOChronology30.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, 20);
//        int int44 = offsetDateTimeField42.getLeapAmount(1560628303058L);
//        long long46 = offsetDateTimeField42.remainder(87L);
//        org.joda.time.ReadablePartial readablePartial47 = null;
//        org.joda.time.ReadableInstant readableInstant49 = null;
//        org.joda.time.ReadableInstant readableInstant50 = null;
//        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
//        org.joda.time.Period period52 = new org.joda.time.Period((long) (-1), chronology51);
//        org.joda.time.Period period54 = period52.withDays(0);
//        int[] intArray55 = period54.getValues();
//        int int56 = offsetDateTimeField42.getMinimumValue(readablePartial47, intArray55);
//        try {
//            int[] intArray58 = offsetDateTimeField15.addWrapField(readablePartial25, (int) (short) 0, intArray55, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775806L + "'", long21 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-65L) + "'", long34 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 62135596800088L + "'", long46 == 62135596800088L);
//        org.junit.Assert.assertNotNull(chronology51);
//        org.junit.Assert.assertNotNull(period54);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 20 + "'", int56 == 20);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        org.joda.time.Period period13 = period5.normalizedStandard();
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period13.toDurationTo(readableInstant14);
        org.joda.time.Period period17 = period13.minusMinutes(10);
        org.joda.time.Period period19 = period13.plusYears(27);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test181");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
//        org.joda.time.DurationField durationField37 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        long long39 = zeroIsMaxDateTimeField34.remainder((long) 4);
//        long long41 = zeroIsMaxDateTimeField34.roundFloor((long) 800001000);
//        org.joda.time.DurationField durationField42 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        int int43 = zeroIsMaxDateTimeField34.getMaximumValue();
//        long long46 = zeroIsMaxDateTimeField34.getDifferenceAsLong(124271193600085L, (-33L));
//        int int47 = zeroIsMaxDateTimeField34.getMaximumValue();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 800001000L + "'", long41 == 800001000L);
//        org.junit.Assert.assertNull(durationField42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1000 + "'", int43 == 1000);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 124271193600118L + "'", long46 == 124271193600118L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1000 + "'", int47 == 1000);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test182");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long4 = gregorianChronology0.add(10L, (long) 800000, (int) (short) 10);
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
//        java.lang.String str6 = gregorianChronology0.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 8000010L + "'", long4 == 8000010L);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[]" + "'", str6.equals("GregorianChronology[]"));
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        long long15 = durationField12.subtract(383999999990L, (int) (short) -1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 384000059990L + "'", long15 == 384000059990L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getOffset(97L);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long13 = dateTimeZone10.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        boolean boolean15 = cachedDateTimeZone14.isFixed();
        org.joda.time.Chronology chronology16 = iSOChronology3.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.Period period17 = new org.joda.time.Period((long) 800000, (long) 1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period17.toDurationTo(readableInstant18);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(duration19);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test186");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
//        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
//        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
//        long long28 = offsetDateTimeField24.remainder(87L);
//        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
//        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
//        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
//        org.joda.time.DurationField durationField37 = zeroIsMaxDateTimeField34.getLeapDurationField();
//        long long39 = zeroIsMaxDateTimeField34.remainder((long) 4);
//        int int42 = zeroIsMaxDateTimeField34.getDifference((long) 0, 1224000100L);
//        int int44 = zeroIsMaxDateTimeField34.getMaximumValue(12L);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800088L + "'", long28 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775806L + "'", long30 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800001L) + "'", long32 == (-62135596800001L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1224000100) + "'", int42 == (-1224000100));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1000 + "'", int44 == 1000);
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test187");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
//        int int22 = offsetDateTimeField15.getMaximumValue();
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = offsetDateTimeField15.getAsShortText(readablePartial23, 32000, locale25);
//        long long28 = offsetDateTimeField15.roundCeiling(97L);
//        org.joda.time.ReadablePartial readablePartial29 = null;
//        int int30 = offsetDateTimeField15.getMinimumValue(readablePartial29);
//        java.util.Locale locale31 = null;
//        int int32 = offsetDateTimeField15.getMaximumTextLength(locale31);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775806L + "'", long21 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 21 + "'", int22 == 21);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "32000" + "'", str26.equals("32000"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775806L + "'", long28 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 20 + "'", int30 == 20);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test188");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        long long17 = offsetDateTimeField15.roundHalfEven(97L);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField15.getAsShortText((int) (byte) -1, locale19);
//        java.lang.String str21 = offsetDateTimeField15.getName();
//        org.joda.time.ReadablePartial readablePartial22 = null;
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableInstant readableInstant27 = null;
//        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant26, readableInstant27);
//        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) -1, 10L, chronology28);
//        int int30 = period29.getDays();
//        org.joda.time.Days days31 = period29.toStandardDays();
//        org.joda.time.PeriodType periodType32 = org.joda.time.PeriodType.seconds();
//        org.joda.time.Period period33 = period29.normalizedStandard(periodType32);
//        int[] intArray34 = period33.getValues();
//        try {
//            int[] intArray36 = offsetDateTimeField15.addWrapField(readablePartial22, 32000, intArray34, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32000");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135596800001L) + "'", long17 == (-62135596800001L));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-1" + "'", str20.equals("-1"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "era" + "'", str21.equals("era"));
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(days31);
//        org.junit.Assert.assertNotNull(periodType32);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(intArray34);
//    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test189");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
//        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
//        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
//        long long19 = offsetDateTimeField15.remainder(87L);
//        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
//        java.lang.String str23 = offsetDateTimeField15.getAsShortText((-115199968L));
//        long long25 = offsetDateTimeField15.roundHalfEven((long) 8);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800088L + "'", long19 == 62135596800088L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775806L + "'", long21 == 9223372036854775806L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "21" + "'", str23.equals("21"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-62135596800001L) + "'", long25 == (-62135596800001L));
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.withMillis((int) (short) 1);
        org.joda.time.Period period10 = period5.withMillis((int) (short) 1);
        org.joda.time.Period period12 = period10.minusMillis((int) (byte) 1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "LenientChronology[ISOChronology[America/Los_Angeles]]", "GregorianChronology[-00:00:00.001]");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "DateTimeField[era]", "-1");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.withYears((int) (byte) 0);
        org.joda.time.Period period6 = period4.plusWeeks((int) (byte) 1);
        org.joda.time.Period period8 = period4.withHours(800001000);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period8.toDurationTo(readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant11);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        long long5 = dateTimeZone1.convertLocalToUTC((-56940685192995L), false, 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-56940685192995L) + "'", long5 == (-56940685192995L));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long6 = iSOChronology2.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology7 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 0, (org.joda.time.Chronology) iSOChronology2);
        int int9 = period8.getYears();
        org.joda.time.Period period11 = period8.withYears((int) 'a');
        org.joda.time.Period period13 = period8.plusHours((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period16 = new org.joda.time.Period(11L, (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.Period period17 = period13.plus((org.joda.time.ReadablePeriod) period16);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.Period period14 = period7.withPeriodType(periodType10);
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period14, obj15);
        java.lang.Class<?> wildcardClass17 = period14.getClass();
        org.joda.time.Period period19 = period14.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, periodType25, chronology27);
        org.joda.time.PeriodType periodType29 = periodType25.withYearsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType29);
        org.joda.time.PeriodType periodType31 = periodType29.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(10L, periodType29);
        org.joda.time.PeriodType periodType33 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
        boolean boolean35 = periodType29.equals((java.lang.Object) periodType34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        int int37 = periodType36.size();
        org.joda.time.PeriodType periodType38 = periodType36.withMonthsRemoved();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.seconds();
        int int40 = periodType39.size();
        org.joda.time.PeriodType periodType41 = periodType39.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType(0);
        int int44 = periodType36.indexOf(durationFieldType43);
        int int45 = periodType29.indexOf(durationFieldType43);
        org.joda.time.Period period47 = period14.withField(durationFieldType43, 0);
        int int48 = period1.get(durationFieldType43);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType43);
        boolean boolean50 = unsupportedDurationField49.isPrecise();
        try {
            long long53 = unsupportedDurationField49.add((long) (short) -1, (long) 1000);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: seconds field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long6 = iSOChronology2.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        int int11 = dateTimeZone9.getOffset(readableInstant10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        long long16 = cachedDateTimeZone12.convertLocalToUTC((long) 10, true, (long) (short) 10);
        java.lang.String str18 = cachedDateTimeZone12.getShortName(32L);
        java.util.TimeZone timeZone19 = cachedDateTimeZone12.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, (org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval25 = null;
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval25);
        org.joda.time.Period period27 = new org.joda.time.Period((long) 'a', (long) 0, periodType24, chronology26);
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval31);
        org.joda.time.Period period33 = new org.joda.time.Period((long) 'a', (long) 0, periodType30, chronology32);
        org.joda.time.Period period34 = period27.withPeriodType(periodType30);
        java.lang.Object obj35 = null;
        boolean boolean36 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period34, obj35);
        java.lang.Class<?> wildcardClass37 = period34.getClass();
        org.joda.time.Period period39 = period34.multipliedBy(10);
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.Duration duration41 = period39.toDurationTo(readableInstant40);
        boolean boolean42 = iSOChronology2.equals((java.lang.Object) period39);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-65L) + "'", long6 == (-65L));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 11L + "'", long16 == 11L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-00:00:00.001" + "'", str18.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(duration41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        long long17 = offsetDateTimeField15.roundHalfEven(97L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField15.getAsShortText((int) (byte) -1, locale19);
        long long23 = offsetDateTimeField15.addWrapField((-34L), 2);
        boolean boolean24 = offsetDateTimeField15.isSupported();
        java.lang.String str26 = offsetDateTimeField15.getAsText(0L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135596800000L) + "'", long17 == (-62135596800000L));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-1" + "'", str20.equals("-1"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-34L) + "'", long23 == (-34L));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "21" + "'", str26.equals("21"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getOffset(97L);
        java.lang.String str8 = fixedDateTimeZone4.getShortName((-1L));
        long long10 = fixedDateTimeZone4.nextTransition((long) 1000);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1000L + "'", long10 == 1000L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant6, readableDuration7);
        long long11 = iSOChronology1.add((org.joda.time.ReadablePeriod) period8, (long) 1, (int) ' ');
        org.joda.time.DurationField durationField12 = iSOChronology1.months();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone16 = iSOChronology1.getZone();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        long long17 = offsetDateTimeField15.roundHalfEven(97L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField15.getAsShortText((int) (byte) -1, locale19);
        org.joda.time.DurationField durationField21 = offsetDateTimeField15.getRangeDurationField();
        int int23 = offsetDateTimeField15.getMaximumValue(1100L);
        boolean boolean25 = offsetDateTimeField15.isLeap(0L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135596800000L) + "'", long17 == (-62135596800000L));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-1" + "'", str20.equals("-1"));
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 21 + "'", int23 == 21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.year();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.withYears((int) (byte) 0);
        org.joda.time.Period period6 = period4.plusWeeks((int) (byte) 1);
        org.joda.time.Period period8 = period4.plusHours((int) '#');
        org.joda.time.Period period10 = period4.plusMonths(21);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) 0, periodType5, chronology7);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) 'a', (long) 0, periodType11, chronology13);
        org.joda.time.Period period15 = period8.withPeriodType(periodType11);
        java.lang.Object obj16 = null;
        boolean boolean17 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period15, obj16);
        org.joda.time.Period period19 = org.joda.time.Period.days(0);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval23 = null;
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval23);
        org.joda.time.Period period25 = new org.joda.time.Period((long) 'a', (long) 0, periodType22, chronology24);
        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval29 = null;
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval29);
        org.joda.time.Period period31 = new org.joda.time.Period((long) 'a', (long) 0, periodType28, chronology30);
        org.joda.time.Period period32 = period25.withPeriodType(periodType28);
        java.lang.Object obj33 = null;
        boolean boolean34 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period32, obj33);
        java.lang.Class<?> wildcardClass35 = period32.getClass();
        org.joda.time.Period period37 = period32.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.PeriodType periodType43 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval44 = null;
        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval44);
        org.joda.time.Period period46 = new org.joda.time.Period((long) 'a', (long) 0, periodType43, chronology45);
        org.joda.time.PeriodType periodType47 = periodType43.withYearsRemoved();
        org.joda.time.Period period48 = new org.joda.time.Period(readableDuration39, readableInstant40, periodType47);
        org.joda.time.PeriodType periodType49 = periodType47.withHoursRemoved();
        org.joda.time.Period period50 = new org.joda.time.Period(10L, periodType47);
        org.joda.time.PeriodType periodType51 = periodType47.withHoursRemoved();
        org.joda.time.PeriodType periodType52 = org.joda.time.PeriodType.standard();
        boolean boolean53 = periodType47.equals((java.lang.Object) periodType52);
        org.joda.time.PeriodType periodType54 = org.joda.time.PeriodType.seconds();
        int int55 = periodType54.size();
        org.joda.time.PeriodType periodType56 = periodType54.withMonthsRemoved();
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.seconds();
        int int58 = periodType57.size();
        org.joda.time.PeriodType periodType59 = periodType57.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType61 = periodType57.getFieldType(0);
        int int62 = periodType54.indexOf(durationFieldType61);
        int int63 = periodType47.indexOf(durationFieldType61);
        org.joda.time.Period period65 = period32.withField(durationFieldType61, 0);
        int int66 = period19.get(durationFieldType61);
        int int67 = period15.get(durationFieldType61);
        boolean boolean68 = periodType2.isSupported(durationFieldType61);
        org.joda.time.Period period69 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(periodType43);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(periodType49);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(periodType56);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(periodType59);
        org.junit.Assert.assertNotNull(durationFieldType61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 3 + "'", int63 == 3);
        org.junit.Assert.assertNotNull(period65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("GregorianChronology[America/Los_Angeles]", (int) (short) 10, 0, (int) (byte) -1, 'a', (int) 'a', 10, 0, true, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder11.toDateTimeZone("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder25 = dateTimeZoneBuilder11.addRecurringSavings("seconds", (int) (byte) 10, 100, 10, ' ', 80000, 0, 34, true, (int) (short) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder33 = dateTimeZoneBuilder11.addCutover((-1224000100), 'a', 0, (-100), (-34), false, 8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder25);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder33);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, 10L, chronology6);
        int int8 = period7.getDays();
        org.joda.time.Days days9 = period7.toStandardDays();
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period11 = period7.normalizedStandard(periodType10);
        int[] intArray14 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L, 34L);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.monthOfYear();
        int int16 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField17 = gregorianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(days9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str26 = gregorianChronology25.toString();
        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
        long long31 = unsupportedDateTimeField28.getDifferenceAsLong((long) (-7), 9223372036854775806L);
        org.joda.time.ReadablePartial readablePartial32 = null;
        try {
            int int33 = unsupportedDateTimeField28.getMinimumValue(readablePartial32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800087L + "'", long19 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800000L) + "'", long23 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[UTC]" + "'", str26.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 292277025L + "'", long31 == 292277025L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
        long long28 = offsetDateTimeField24.remainder(87L);
        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        long long40 = iSOChronology36.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField41 = iSOChronology36.years();
        org.joda.time.DurationField durationField42 = iSOChronology36.days();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
        long long48 = iSOChronology44.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology49 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology44);
        org.joda.time.DateTimeField dateTimeField50 = lenientChronology49.yearOfEra();
        org.joda.time.DateTimeField dateTimeField51 = lenientChronology49.halfdayOfDay();
        org.joda.time.DurationField durationField52 = lenientChronology49.weeks();
        long long55 = durationField52.subtract(0L, 11L);
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField56 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType33, durationField42, durationField52);
        long long58 = preciseDateTimeField56.roundCeiling((-141746760000000L));
        long long59 = preciseDateTimeField56.getUnitMillis();
        long long61 = preciseDateTimeField56.roundCeiling((-1560628303091L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800087L + "'", long28 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800000L) + "'", long32 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-65L) + "'", long40 == (-65L));
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 32L + "'", long48 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-6652800000L) + "'", long55 == (-6652800000L));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-141746716800000L) + "'", long58 == (-141746716800000L));
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 86400000L + "'", long59 == 86400000L);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-1560556800000L) + "'", long61 == (-1560556800000L));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long13 = iSOChronology9.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField14 = iSOChronology9.years();
        long long18 = iSOChronology9.add((long) 0, 32L, (int) (byte) 10);
        boolean boolean19 = lenientChronology6.equals((java.lang.Object) 32L);
        org.joda.time.ReadablePartial readablePartial20 = null;
        try {
            long long22 = lenientChronology6.set(readablePartial20, (-7L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-65L) + "'", long13 == (-65L));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 320L + "'", long18 == 320L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.Period period14 = period7.withPeriodType(periodType10);
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period14, obj15);
        java.lang.Class<?> wildcardClass17 = period14.getClass();
        org.joda.time.Period period19 = period14.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, periodType25, chronology27);
        org.joda.time.PeriodType periodType29 = periodType25.withYearsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType29);
        org.joda.time.PeriodType periodType31 = periodType29.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(10L, periodType29);
        org.joda.time.PeriodType periodType33 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
        boolean boolean35 = periodType29.equals((java.lang.Object) periodType34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        int int37 = periodType36.size();
        org.joda.time.PeriodType periodType38 = periodType36.withMonthsRemoved();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.seconds();
        int int40 = periodType39.size();
        org.joda.time.PeriodType periodType41 = periodType39.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType(0);
        int int44 = periodType36.indexOf(durationFieldType43);
        int int45 = periodType29.indexOf(durationFieldType43);
        org.joda.time.Period period47 = period14.withField(durationFieldType43, 0);
        int int48 = period1.get(durationFieldType43);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType43);
        java.lang.String str50 = unsupportedDurationField49.toString();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        long long57 = iSOChronology53.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.Period period58 = new org.joda.time.Period((long) '#', (org.joda.time.Chronology) iSOChronology53);
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant61 = null;
        int int62 = dateTimeZone60.getOffset(readableInstant61);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone63 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone60);
        long long67 = cachedDateTimeZone63.convertLocalToUTC((long) 10, true, (long) (short) 10);
        java.lang.String str69 = cachedDateTimeZone63.getShortName(32L);
        java.util.TimeZone timeZone70 = cachedDateTimeZone63.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology71 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone63);
        org.joda.time.chrono.ZonedChronology zonedChronology72 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology53, (org.joda.time.DateTimeZone) cachedDateTimeZone63);
        org.joda.time.Period period74 = org.joda.time.Period.days((int) (byte) 10);
        org.joda.time.format.PeriodFormatter periodFormatter75 = null;
        java.lang.String str76 = period74.toString(periodFormatter75);
        org.joda.time.Hours hours77 = period74.toStandardHours();
        boolean boolean78 = zonedChronology72.equals((java.lang.Object) hours77);
        boolean boolean79 = unsupportedDurationField49.equals((java.lang.Object) boolean78);
        long long80 = unsupportedDurationField49.getUnitMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "UnsupportedDurationField[seconds]" + "'", str50.equals("UnsupportedDurationField[seconds]"));
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-65L) + "'", long57 == (-65L));
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone63);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 11L + "'", long67 == 11L);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "-00:00:00.001" + "'", str69.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNotNull(iSOChronology71);
        org.junit.Assert.assertNotNull(zonedChronology72);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "P10D" + "'", str76.equals("P10D"));
        org.junit.Assert.assertNotNull(hours77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 0L + "'", long80 == 0L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("P100WT-0.001S");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"P100WT-0.001S/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) -1, 0L, chronology4);
        org.joda.time.Hours hours6 = period5.toStandardHours();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(hours6);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.Period period14 = period7.withPeriodType(periodType10);
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period14, obj15);
        java.lang.Class<?> wildcardClass17 = period14.getClass();
        org.joda.time.Period period19 = period14.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, periodType25, chronology27);
        org.joda.time.PeriodType periodType29 = periodType25.withYearsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType29);
        org.joda.time.PeriodType periodType31 = periodType29.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(10L, periodType29);
        org.joda.time.PeriodType periodType33 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
        boolean boolean35 = periodType29.equals((java.lang.Object) periodType34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        int int37 = periodType36.size();
        org.joda.time.PeriodType periodType38 = periodType36.withMonthsRemoved();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.seconds();
        int int40 = periodType39.size();
        org.joda.time.PeriodType periodType41 = periodType39.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType(0);
        int int44 = periodType36.indexOf(durationFieldType43);
        int int45 = periodType29.indexOf(durationFieldType43);
        org.joda.time.Period period47 = period14.withField(durationFieldType43, 0);
        int int48 = period1.get(durationFieldType43);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType43);
        boolean boolean50 = unsupportedDurationField49.isPrecise();
        try {
            long long53 = unsupportedDurationField49.add(124271193600085L, 32000);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: seconds field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.Period period14 = period7.withPeriodType(periodType10);
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period14, obj15);
        java.lang.Class<?> wildcardClass17 = period14.getClass();
        org.joda.time.Period period19 = period14.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, periodType25, chronology27);
        org.joda.time.PeriodType periodType29 = periodType25.withYearsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType29);
        org.joda.time.PeriodType periodType31 = periodType29.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(10L, periodType29);
        org.joda.time.PeriodType periodType33 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
        boolean boolean35 = periodType29.equals((java.lang.Object) periodType34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        int int37 = periodType36.size();
        org.joda.time.PeriodType periodType38 = periodType36.withMonthsRemoved();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.seconds();
        int int40 = periodType39.size();
        org.joda.time.PeriodType periodType41 = periodType39.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType(0);
        int int44 = periodType36.indexOf(durationFieldType43);
        int int45 = periodType29.indexOf(durationFieldType43);
        org.joda.time.Period period47 = period14.withField(durationFieldType43, 0);
        int int48 = period1.get(durationFieldType43);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType43);
        java.lang.String str50 = unsupportedDurationField49.toString();
        try {
            long long53 = unsupportedDurationField49.getValueAsLong((-9223372036854775807L), 99L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: seconds field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "UnsupportedDurationField[seconds]" + "'", str50.equals("UnsupportedDurationField[seconds]"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
        long long28 = offsetDateTimeField24.remainder(87L);
        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
        long long39 = zeroIsMaxDateTimeField34.addWrapField((long) 80000, 640000);
        org.joda.time.DurationField durationField40 = zeroIsMaxDateTimeField34.getDurationField();
        int int42 = zeroIsMaxDateTimeField34.getMinimumValue((-49940105698912L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800087L + "'", long28 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800000L) + "'", long32 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 80000L + "'", long39 == 80000L);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology3.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (short) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
        int int22 = offsetDateTimeField15.getMaximumValue();
        java.lang.String str23 = offsetDateTimeField15.toString();
        int int25 = offsetDateTimeField15.get(0L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800087L + "'", long19 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 21 + "'", int22 == 21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "DateTimeField[era]" + "'", str23.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 21 + "'", int25 == 21);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "GregorianChronology[America/Los_Angeles]", "PeriodType[DayTime]");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str26 = gregorianChronology25.toString();
        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
        long long31 = unsupportedDateTimeField28.getDifferenceAsLong((long) (-7), 9223372036854775806L);
        org.joda.time.ReadablePartial readablePartial32 = null;
        java.util.Locale locale34 = null;
        try {
            java.lang.String str35 = unsupportedDateTimeField28.getAsShortText(readablePartial32, 27, locale34);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800087L + "'", long19 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800000L) + "'", long23 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[UTC]" + "'", str26.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 292277025L + "'", long31 == 292277025L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        org.joda.time.Period period13 = period5.normalizedStandard();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType16 = periodType14.withDaysRemoved();
        org.joda.time.Period period17 = period13.withPeriodType(periodType16);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.seconds();
        int int19 = periodType18.size();
        org.joda.time.PeriodType periodType20 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        int int22 = periodType21.size();
        org.joda.time.PeriodType periodType23 = periodType21.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType25 = periodType21.getFieldType(0);
        int int26 = periodType18.indexOf(durationFieldType25);
        org.joda.time.field.PreciseDurationField preciseDurationField28 = new org.joda.time.field.PreciseDurationField(durationFieldType25, (long) (short) -1);
        int int31 = preciseDurationField28.getDifference(0L, (long) 1);
        int int34 = preciseDurationField28.getValue((long) 34, 618L);
        int int36 = preciseDurationField28.getValue((long) (short) -1);
        org.joda.time.DurationFieldType durationFieldType37 = preciseDurationField28.getType();
        int int38 = period17.indexOf(durationFieldType37);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-34) + "'", int34 == (-34));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(durationFieldType37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 5 + "'", int38 == 5);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology3.era();
        org.joda.time.Period period9 = new org.joda.time.Period((long) 'a', (-65L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField10 = iSOChronology3.months();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, 10L, chronology17);
        int int19 = period18.getDays();
        org.joda.time.Period period21 = period18.withMillis((int) (short) 1);
        java.lang.Object obj22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) 'a', (long) 0, periodType27, chronology29);
        org.joda.time.PeriodType periodType31 = periodType27.withYearsRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(readableDuration23, readableInstant24, periodType31);
        java.lang.String str33 = periodType31.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period35 = new org.joda.time.Period(obj22, periodType31, (org.joda.time.Chronology) gregorianChronology34);
        org.joda.time.PeriodType periodType36 = periodType31.withHoursRemoved();
        org.joda.time.Period period37 = period18.withPeriodType(periodType36);
        org.joda.time.PeriodType periodType38 = org.joda.time.DateTimeUtils.getPeriodType(periodType36);
        org.joda.time.Period period39 = new org.joda.time.Period(readableInstant11, readableInstant12, periodType38);
        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.seconds();
        int int41 = periodType40.size();
        org.joda.time.PeriodType periodType42 = periodType40.withMonthsRemoved();
        org.joda.time.PeriodType periodType43 = org.joda.time.PeriodType.seconds();
        int int44 = periodType43.size();
        org.joda.time.PeriodType periodType45 = periodType43.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType47 = periodType43.getFieldType(0);
        int int48 = periodType40.indexOf(durationFieldType47);
        org.joda.time.field.PreciseDurationField preciseDurationField50 = new org.joda.time.field.PreciseDurationField(durationFieldType47, (long) (short) -1);
        org.joda.time.DurationFieldType durationFieldType51 = preciseDurationField50.getType();
        int int52 = periodType38.indexOf(durationFieldType51);
        org.joda.time.field.DecoratedDurationField decoratedDurationField53 = new org.joda.time.field.DecoratedDurationField(durationField10, durationFieldType51);
        org.joda.time.ReadableDuration readableDuration55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval60 = null;
        org.joda.time.Chronology chronology61 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval60);
        org.joda.time.Period period62 = new org.joda.time.Period((long) 'a', (long) 0, periodType59, chronology61);
        org.joda.time.PeriodType periodType63 = periodType59.withYearsRemoved();
        org.joda.time.Period period64 = new org.joda.time.Period(readableDuration55, readableInstant56, periodType63);
        org.joda.time.PeriodType periodType65 = periodType63.withHoursRemoved();
        org.joda.time.Period period66 = new org.joda.time.Period(10L, periodType63);
        org.joda.time.PeriodType periodType67 = periodType63.withHoursRemoved();
        org.joda.time.PeriodType periodType68 = org.joda.time.PeriodType.standard();
        boolean boolean69 = periodType63.equals((java.lang.Object) periodType68);
        org.joda.time.PeriodType periodType70 = org.joda.time.PeriodType.seconds();
        int int71 = periodType70.size();
        org.joda.time.PeriodType periodType72 = periodType70.withMonthsRemoved();
        org.joda.time.PeriodType periodType73 = org.joda.time.PeriodType.seconds();
        int int74 = periodType73.size();
        org.joda.time.PeriodType periodType75 = periodType73.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType77 = periodType73.getFieldType(0);
        int int78 = periodType70.indexOf(durationFieldType77);
        int int79 = periodType63.indexOf(durationFieldType77);
        org.joda.time.field.PreciseDurationField preciseDurationField81 = new org.joda.time.field.PreciseDurationField(durationFieldType77, 0L);
        int int82 = decoratedDurationField53.compareTo((org.joda.time.DurationField) preciseDurationField81);
        org.joda.time.DurationField durationField83 = decoratedDurationField53.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PeriodType[DayTime]" + "'", str33.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(periodType42);
        org.junit.Assert.assertNotNull(periodType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(durationFieldType47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(durationFieldType51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertNotNull(periodType59);
        org.junit.Assert.assertNotNull(chronology61);
        org.junit.Assert.assertNotNull(periodType63);
        org.junit.Assert.assertNotNull(periodType65);
        org.junit.Assert.assertNotNull(periodType67);
        org.junit.Assert.assertNotNull(periodType68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(periodType70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNotNull(periodType72);
        org.junit.Assert.assertNotNull(periodType73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(periodType75);
        org.junit.Assert.assertNotNull(durationFieldType77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 3 + "'", int79 == 3);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
        org.junit.Assert.assertNotNull(durationField83);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField6 = iSOChronology1.years();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) -1, 10L, chronology11);
        int int13 = period12.getDays();
        org.joda.time.Period period15 = period12.withMillis((int) (short) 1);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) (short) 1);
        long long20 = iSOChronology1.add(0L, 8L, (int) (short) 0);
        org.joda.time.DurationField durationField21 = iSOChronology1.days();
        long long24 = durationField21.subtract((long) 100, 10000);
        long long27 = durationField21.subtract(5120034L, 0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-863999999900L) + "'", long24 == (-863999999900L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 5120034L + "'", long27 == 5120034L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        int int4 = periodType3.size();
        org.joda.time.PeriodType periodType5 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType7 = periodType3.getFieldType(0);
        int int8 = periodType0.indexOf(durationFieldType7);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) (short) -1);
        int int13 = preciseDurationField10.getDifference(0L, (long) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = gregorianChronology14.withZone(dateTimeZone16);
        boolean boolean18 = preciseDurationField10.equals((java.lang.Object) gregorianChronology14);
        try {
            long long23 = gregorianChronology14.getDateTimeMillis(0, 100, (int) (short) 1, (-21));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -21 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str26 = gregorianChronology25.toString();
        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
        long long31 = unsupportedDateTimeField28.getDifferenceAsLong((long) (-7), 9223372036854775806L);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial33 = null;
        try {
            int int34 = unsupportedDateTimeField28.getMaximumValue(readablePartial33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800087L + "'", long19 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800000L) + "'", long23 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[UTC]" + "'", str26.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 292277025L + "'", long31 == 292277025L);
        org.junit.Assert.assertNull(durationField32);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
        long long28 = offsetDateTimeField24.remainder(87L);
        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        long long40 = iSOChronology36.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField41 = iSOChronology36.years();
        org.joda.time.DurationField durationField42 = iSOChronology36.days();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
        long long48 = iSOChronology44.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology49 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology44);
        org.joda.time.DateTimeField dateTimeField50 = lenientChronology49.yearOfEra();
        org.joda.time.DateTimeField dateTimeField51 = lenientChronology49.halfdayOfDay();
        org.joda.time.DurationField durationField52 = lenientChronology49.weeks();
        long long55 = durationField52.subtract(0L, 11L);
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField56 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType33, durationField42, durationField52);
        org.joda.time.DurationField durationField57 = preciseDateTimeField56.getDurationField();
        int int58 = preciseDateTimeField56.getRange();
        long long60 = preciseDateTimeField56.remainder((-210869697600000L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800087L + "'", long28 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800000L) + "'", long32 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-65L) + "'", long40 == (-65L));
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 32L + "'", long48 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-6652800000L) + "'", long55 == (-6652800000L));
        org.junit.Assert.assertNotNull(durationField57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 7 + "'", int58 == 7);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 43200000L + "'", long60 == 43200000L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        java.lang.Object obj13 = null;
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period12, obj13);
        java.lang.Class<?> wildcardClass15 = period12.getClass();
        org.joda.time.Period period17 = period12.minusSeconds((int) (byte) 10);
        org.joda.time.Period period19 = period12.minusHours(1);
        org.joda.time.Period period21 = period12.withSeconds(608003);
        org.joda.time.Period period23 = period21.withMillis(799900);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long6 = iSOChronology2.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        int int11 = dateTimeZone9.getOffset(readableInstant10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        long long16 = cachedDateTimeZone12.convertLocalToUTC((long) 10, true, (long) (short) 10);
        java.lang.String str18 = cachedDateTimeZone12.getShortName(32L);
        java.util.TimeZone timeZone19 = cachedDateTimeZone12.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, (org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.joda.time.Chronology chronology22 = zonedChronology21.withUTC();
        org.joda.time.DateTimeField dateTimeField23 = zonedChronology21.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone24 = zonedChronology21.getZone();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-65L) + "'", long6 == (-65L));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 11L + "'", long16 == 11L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-00:00:00.001" + "'", str18.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(0);
        org.joda.time.Period period2 = period1.negated();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.secondOfMinute();
        java.lang.String str9 = lenientChronology6.toString();
        org.joda.time.Chronology chronology10 = lenientChronology6.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str9.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = periodType0.withDaysRemoved();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = periodType2.indexOf(durationFieldType3);
        org.joda.time.PeriodType periodType5 = periodType2.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
        long long28 = offsetDateTimeField24.remainder(87L);
        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
        long long36 = zeroIsMaxDateTimeField34.roundHalfCeiling((long) (byte) 100);
        long long38 = zeroIsMaxDateTimeField34.roundHalfFloor(32L);
        int int40 = zeroIsMaxDateTimeField34.getLeapAmount(100L);
        int int42 = zeroIsMaxDateTimeField34.getMinimumValue(0L);
        int int44 = zeroIsMaxDateTimeField34.getLeapAmount((long) '4');
        java.util.Locale locale47 = null;
        try {
            long long48 = zeroIsMaxDateTimeField34.set(0L, "org.joda.time.IllegalFieldValueException: Value -1 for PT-0.097S must not be smaller than 1", locale47);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value -1 for PT-0.097S must not be smaller than 1\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800087L + "'", long28 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800000L) + "'", long32 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 32L + "'", long38 == 32L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str26 = gregorianChronology25.toString();
        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
        long long31 = unsupportedDateTimeField28.getDifferenceAsLong((long) (-7), 9223372036854775806L);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getRangeDurationField();
        long long35 = unsupportedDateTimeField28.add(616007L, (long) (-800000));
        java.util.Locale locale36 = null;
        try {
            int int37 = unsupportedDateTimeField28.getMaximumTextLength(locale36);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800087L + "'", long19 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800000L) + "'", long23 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[UTC]" + "'", str26.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 292277025L + "'", long31 == 292277025L);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-25245561599383993L) + "'", long35 == (-25245561599383993L));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant22, readableInstant23);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (-1), chronology24);
        org.joda.time.Period period27 = period25.withDays(0);
        int[] intArray28 = period27.getValues();
        int int29 = offsetDateTimeField15.getMinimumValue(readablePartial20, intArray28);
        int int31 = offsetDateTimeField15.getLeapAmount(11L);
        org.joda.time.DurationField durationField32 = offsetDateTimeField15.getLeapDurationField();
        long long34 = offsetDateTimeField15.roundHalfFloor(34L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800087L + "'", long19 == 62135596800087L);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-62135596800000L) + "'", long34 == (-62135596800000L));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "DateTimeField[era]", 1216006, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (-1), chronology3);
        org.joda.time.Period period6 = period4.plusWeeks((int) (byte) 100);
        org.joda.time.Period period8 = period6.withSeconds(34);
        org.joda.time.Period period10 = period6.minusMinutes(0);
        org.joda.time.Period period12 = period6.plusDays(800000);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period12.toDurationTo(readableInstant13);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration14);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract(100L, 800000);
        long long6 = durationField0.subtract(9223372036854775807L, 33);
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-799900L) + "'", long3 == (-799900L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775774L + "'", long6 == 9223372036854775774L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long4 = dateTimeZone1.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTimeZone1.getName((long) 800001000, locale7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-00:00:00.001" + "'", str8.equals("-00:00:00.001"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period2 = new org.joda.time.Period(11L, (org.joda.time.Chronology) gregorianChronology1);
        try {
            int int4 = period2.getValue((-20));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("GregorianChronology[America/Los_Angeles]", (int) (short) 10, 0, (int) (byte) -1, 'a', (int) 'a', 10, 0, true, (int) '#');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("ISOChronology[-00:00:00.001]", 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder17 = dateTimeZoneBuilder11.setFixedSavings("seconds", (-799980));
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder17);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.withMillis((int) (short) 1);
        java.lang.Object obj9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) 'a', (long) 0, periodType14, chronology16);
        org.joda.time.PeriodType periodType18 = periodType14.withYearsRemoved();
        org.joda.time.Period period19 = new org.joda.time.Period(readableDuration10, readableInstant11, periodType18);
        java.lang.String str20 = periodType18.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period22 = new org.joda.time.Period(obj9, periodType18, (org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.PeriodType periodType23 = periodType18.withHoursRemoved();
        org.joda.time.Period period24 = period5.withPeriodType(periodType23);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant27, readableInstant28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) (short) -1, 10L, chronology29);
        int int31 = period30.getDays();
        org.joda.time.Period period33 = period30.withMillis((int) (short) 1);
        org.joda.time.Period period35 = period30.withMillis((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType37 = period30.getFieldType(4);
        int int38 = period5.indexOf(durationFieldType37);
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(durationFieldType37, (java.lang.Number) 100.0f, (java.lang.Number) 6, (java.lang.Number) 8000010L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(durationFieldType37, "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported");
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PeriodType[DayTime]" + "'", str20.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(durationFieldType37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (short) 0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) 0, periodType5, chronology7);
        org.joda.time.PeriodType periodType9 = periodType5.withYearsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType9);
        org.joda.time.PeriodType periodType11 = periodType9.withHoursRemoved();
        org.joda.time.Period period12 = new org.joda.time.Period(10L, periodType9);
        org.joda.time.PeriodType periodType13 = periodType9.withHoursRemoved();
        org.joda.time.PeriodType periodType14 = periodType13.withMinutesRemoved();
        org.joda.time.PeriodType periodType15 = periodType14.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long11 = dateTimeZone8.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        boolean boolean13 = cachedDateTimeZone12.isFixed();
        org.joda.time.Chronology chronology14 = iSOChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        long long16 = cachedDateTimeZone12.previousTransition((long) (short) 0);
        int int18 = cachedDateTimeZone12.getOffset(99L);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long23 = dateTimeZone20.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone20);
        java.lang.String str26 = cachedDateTimeZone24.getName(8L);
        org.joda.time.LocalDateTime localDateTime27 = null;
        boolean boolean28 = cachedDateTimeZone24.isLocalDateTimeGap(localDateTime27);
        long long30 = cachedDateTimeZone12.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone24, 1224000100L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "-00:00:00.001" + "'", str26.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1224000100L + "'", long30 == 1224000100L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
        long long28 = offsetDateTimeField24.remainder(87L);
        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
        org.joda.time.DurationField durationField37 = zeroIsMaxDateTimeField34.getLeapDurationField();
        long long39 = zeroIsMaxDateTimeField34.remainder((long) 4);
        long long41 = zeroIsMaxDateTimeField34.roundFloor((long) 800001000);
        org.joda.time.DurationField durationField42 = zeroIsMaxDateTimeField34.getLeapDurationField();
        org.joda.time.DurationField durationField43 = zeroIsMaxDateTimeField34.getLeapDurationField();
        long long45 = zeroIsMaxDateTimeField34.roundHalfFloor(124271193600085L);
        java.lang.String str47 = zeroIsMaxDateTimeField34.getAsText(34L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800087L + "'", long28 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800000L) + "'", long32 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNull(durationField37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 800001000L + "'", long41 == 800001000L);
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertNull(durationField43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 124271193600085L + "'", long45 == 124271193600085L);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "34" + "'", str47.equals("34"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str26 = gregorianChronology25.toString();
        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
        long long31 = unsupportedDateTimeField28.getDifferenceAsLong((long) (-7), 9223372036854775806L);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getRangeDurationField();
        long long35 = unsupportedDateTimeField28.add(616007L, (long) (-800000));
        int int38 = unsupportedDateTimeField28.getDifference((long) 20, (long) 'a');
        int int41 = unsupportedDateTimeField28.getDifference((-115199990L), 1560628303058L);
        try {
            long long43 = unsupportedDateTimeField28.remainder((-33L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800087L + "'", long19 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800000L) + "'", long23 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[UTC]" + "'", str26.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 292277025L + "'", long31 == 292277025L);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-25245561599383993L) + "'", long35 == (-25245561599383993L));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-49) + "'", int41 == (-49));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long8 = cachedDateTimeZone4.convertLocalToUTC((long) 10, true, (long) (short) 10);
        int int10 = cachedDateTimeZone4.getOffsetFromLocal(100L);
        boolean boolean12 = cachedDateTimeZone4.isStandardOffset(320L);
        long long14 = cachedDateTimeZone4.nextTransition((long) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 11L + "'", long8 == 11L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long6 = iSOChronology2.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology7 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 0, (org.joda.time.Chronology) iSOChronology2);
        int int9 = period8.getYears();
        org.joda.time.Period period11 = period8.withYears((int) 'a');
        org.joda.time.Period period13 = period8.plusHours((int) (short) 1);
        org.joda.time.Period period15 = period13.plusMinutes(104);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        org.joda.time.Period period1 = org.joda.time.Period.days(800000);
        org.joda.time.Hours hours2 = period1.toStandardHours();
        org.joda.time.Period period4 = period1.minusMillis((-360000065));
        org.joda.time.Period period6 = period4.plusHours(10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(hours2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.Period period14 = period7.withPeriodType(periodType10);
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period14, obj15);
        java.lang.Class<?> wildcardClass17 = period14.getClass();
        org.joda.time.Period period19 = period14.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, periodType25, chronology27);
        org.joda.time.PeriodType periodType29 = periodType25.withYearsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType29);
        org.joda.time.PeriodType periodType31 = periodType29.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(10L, periodType29);
        org.joda.time.PeriodType periodType33 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
        boolean boolean35 = periodType29.equals((java.lang.Object) periodType34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        int int37 = periodType36.size();
        org.joda.time.PeriodType periodType38 = periodType36.withMonthsRemoved();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.seconds();
        int int40 = periodType39.size();
        org.joda.time.PeriodType periodType41 = periodType39.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType(0);
        int int44 = periodType36.indexOf(durationFieldType43);
        int int45 = periodType29.indexOf(durationFieldType43);
        org.joda.time.Period period47 = period14.withField(durationFieldType43, 0);
        int int48 = period1.get(durationFieldType43);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType43);
        try {
            long long52 = unsupportedDurationField49.subtract((-360000065L), (long) 608003);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: seconds field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long9 = dateTimeZone6.convertLocalToUTC(0L, true);
        org.joda.time.ReadableInstant readableInstant10 = null;
        int int11 = dateTimeZone6.getOffset(readableInstant10);
        long long13 = cachedDateTimeZone4.getMillisKeepLocal(dateTimeZone6, (long) (short) 100);
        int int15 = cachedDateTimeZone4.getStandardOffset(34L);
        int int17 = cachedDateTimeZone4.getStandardOffset(4L);
        java.lang.String str18 = cachedDateTimeZone4.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-00:00:00.001" + "'", str18.equals("-00:00:00.001"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        org.joda.time.ReadableInstant readableInstant0 = null;
        java.lang.Object obj1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) 'a', (long) 0, periodType6, chronology8);
        org.joda.time.PeriodType periodType10 = periodType6.withYearsRemoved();
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration2, readableInstant3, periodType10);
        java.lang.String str12 = periodType10.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period14 = new org.joda.time.Period(obj1, periodType10, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period14.toDurationFrom(readableInstant15);
        long long17 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration16);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval23 = null;
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval23);
        org.joda.time.Period period25 = new org.joda.time.Period((long) 'a', (long) 0, periodType22, chronology24);
        org.joda.time.PeriodType periodType26 = periodType22.withYearsRemoved();
        org.joda.time.Period period27 = new org.joda.time.Period(readableDuration18, readableInstant19, periodType26);
        org.joda.time.PeriodType periodType28 = periodType26.withDaysRemoved();
        org.joda.time.PeriodType periodType29 = periodType26.withYearsRemoved();
        org.joda.time.PeriodType periodType30 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType31 = periodType30.withMinutesRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration16, periodType30);
        org.joda.time.Period period34 = period32.multipliedBy(0);
        org.joda.time.Seconds seconds35 = period32.toStandardSeconds();
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PeriodType[DayTime]" + "'", str12.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(seconds35);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        java.lang.String str3 = dateTimeZone2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported");
        org.joda.time.Period period10 = new org.joda.time.Period((int) (short) 1, (int) (byte) 0, (int) (short) 10, 100, 10, 0, (int) (short) -1, (int) '#');
        boolean boolean11 = jodaTimePermission1.equals((java.lang.Object) 10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        long long17 = iSOChronology13.add(0L, (long) 1, (int) ' ');
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval21);
        org.joda.time.Period period23 = new org.joda.time.Period((long) 'a', (long) 0, periodType20, chronology22);
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval27 = null;
        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval27);
        org.joda.time.Period period29 = new org.joda.time.Period((long) 'a', (long) 0, periodType26, chronology28);
        org.joda.time.Period period30 = period23.withPeriodType(periodType26);
        org.joda.time.format.PeriodFormatter periodFormatter31 = null;
        java.lang.String str32 = period30.toString(periodFormatter31);
        org.joda.time.Seconds seconds33 = period30.toStandardSeconds();
        long long36 = iSOChronology13.add((org.joda.time.ReadablePeriod) period30, (long) (short) -1, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology13.minuteOfHour();
        boolean boolean38 = jodaTimePermission1.equals((java.lang.Object) dateTimeField37);
        java.lang.String str39 = jodaTimePermission1.getActions();
        java.security.PermissionCollection permissionCollection40 = jodaTimePermission1.newPermissionCollection();
        try {
            org.joda.time.Period period41 = new org.joda.time.Period((java.lang.Object) jodaTimePermission1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.JodaTimePermission");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 32L + "'", long17 == 32L);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PT-0.097S" + "'", str32.equals("PT-0.097S"));
        org.junit.Assert.assertNotNull(seconds33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1L) + "'", long36 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertNotNull(permissionCollection40);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField6 = iSOChronology1.minutes();
        try {
            org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) durationField6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDurationField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', (long) 0, periodType2, chronology4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) 0, periodType8, chronology10);
        org.joda.time.Period period12 = period5.withPeriodType(periodType8);
        java.lang.Object obj13 = null;
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period12, obj13);
        java.lang.Class<?> wildcardClass15 = period12.getClass();
        int int16 = period12.getWeeks();
        int int17 = period12.getSeconds();
        org.joda.time.Period period19 = period12.minusSeconds(10);
        org.joda.time.Period period21 = period12.withDays((int) 'a');
        int int22 = period12.getDays();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Days days7 = period5.toStandardDays();
        org.joda.time.Period period9 = period5.withHours(0);
        org.joda.time.Period period11 = period9.plusMinutes((-100));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(days7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("ISOChronology[]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        int int2 = periodType1.size();
        org.joda.time.PeriodType periodType3 = periodType1.withMinutesRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.monthOfYear();
        org.joda.time.Period period6 = new org.joda.time.Period(0L, periodType3, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationField durationField7 = gregorianChronology4.weekyears();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
        long long28 = offsetDateTimeField24.remainder(87L);
        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
        long long39 = zeroIsMaxDateTimeField34.add(0L, 800000);
        long long41 = zeroIsMaxDateTimeField34.remainder((-800000L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800087L + "'", long28 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800000L) + "'", long32 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 800000L + "'", long39 == 800000L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.DurationField durationField6 = iSOChronology1.days();
        try {
            long long12 = iSOChronology1.getDateTimeMillis(9223372036854775806L, 27, (-1), (int) (byte) 1, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 27 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        org.joda.time.DurationField durationField8 = lenientChronology6.hours();
        boolean boolean10 = lenientChronology6.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTimeField dateTimeField11 = lenientChronology6.millisOfSecond();
        org.joda.time.Period period13 = org.joda.time.Period.minutes(8);
        org.joda.time.Period period14 = period13.toPeriod();
        long long17 = lenientChronology6.add((org.joda.time.ReadablePeriod) period13, 618L, 800001000);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval22 = null;
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval22);
        org.joda.time.Period period24 = new org.joda.time.Period((long) 'a', (long) 0, periodType21, chronology23);
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) 'a', (long) 0, periodType27, chronology29);
        org.joda.time.Period period31 = period24.withPeriodType(periodType27);
        org.joda.time.Period period32 = period24.normalizedStandard();
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Duration duration34 = period32.toDurationTo(readableInstant33);
        org.joda.time.Period period35 = new org.joda.time.Period(readableInstant18, (org.joda.time.ReadableDuration) duration34);
        org.joda.time.Period period37 = period35.multipliedBy((int) (short) 100);
        int[] intArray39 = lenientChronology6.get((org.joda.time.ReadablePeriod) period37, 148210560000034L);
        org.joda.time.DurationField durationField40 = lenientChronology6.weeks();
        org.joda.time.DateTimeField dateTimeField41 = lenientChronology6.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 384000480000618L + "'", long17 == 384000480000618L);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(duration34);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', (long) 0, periodType3, chronology5);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) 'a', (long) 0, periodType9, chronology11);
        org.joda.time.Period period13 = period6.withPeriodType(periodType9);
        java.lang.Object obj14 = null;
        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period13, obj14);
        java.lang.Class<?> wildcardClass16 = period13.getClass();
        org.joda.time.Period period18 = period13.multipliedBy(10);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period18.toDurationTo(readableInstant19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType22 = org.joda.time.DateTimeUtils.getPeriodType(periodType21);
        org.joda.time.PeriodType periodType23 = periodType21.withDaysRemoved();
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration20, periodType23);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str26 = gregorianChronology25.toString();
        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
        org.joda.time.DurationField durationField28 = gregorianChronology25.centuries();
        org.joda.time.Chronology chronology29 = gregorianChronology25.withUTC();
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DurationField durationField31 = lenientChronology30.hours();
        org.joda.time.Chronology chronology32 = lenientChronology30.withUTC();
        org.joda.time.DateTimeField dateTimeField33 = lenientChronology30.year();
        org.joda.time.Period period34 = new org.joda.time.Period((java.lang.Object) duration20, (org.joda.time.Chronology) lenientChronology30);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[UTC]" + "'", str26.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology3.era();
        org.joda.time.Period period9 = new org.joda.time.Period((long) 'a', (-65L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField10 = iSOChronology3.months();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, 10L, chronology17);
        int int19 = period18.getDays();
        org.joda.time.Period period21 = period18.withMillis((int) (short) 1);
        java.lang.Object obj22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) 'a', (long) 0, periodType27, chronology29);
        org.joda.time.PeriodType periodType31 = periodType27.withYearsRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(readableDuration23, readableInstant24, periodType31);
        java.lang.String str33 = periodType31.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period35 = new org.joda.time.Period(obj22, periodType31, (org.joda.time.Chronology) gregorianChronology34);
        org.joda.time.PeriodType periodType36 = periodType31.withHoursRemoved();
        org.joda.time.Period period37 = period18.withPeriodType(periodType36);
        org.joda.time.PeriodType periodType38 = org.joda.time.DateTimeUtils.getPeriodType(periodType36);
        org.joda.time.Period period39 = new org.joda.time.Period(readableInstant11, readableInstant12, periodType38);
        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.seconds();
        int int41 = periodType40.size();
        org.joda.time.PeriodType periodType42 = periodType40.withMonthsRemoved();
        org.joda.time.PeriodType periodType43 = org.joda.time.PeriodType.seconds();
        int int44 = periodType43.size();
        org.joda.time.PeriodType periodType45 = periodType43.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType47 = periodType43.getFieldType(0);
        int int48 = periodType40.indexOf(durationFieldType47);
        org.joda.time.field.PreciseDurationField preciseDurationField50 = new org.joda.time.field.PreciseDurationField(durationFieldType47, (long) (short) -1);
        org.joda.time.DurationFieldType durationFieldType51 = preciseDurationField50.getType();
        int int52 = periodType38.indexOf(durationFieldType51);
        org.joda.time.field.DecoratedDurationField decoratedDurationField53 = new org.joda.time.field.DecoratedDurationField(durationField10, durationFieldType51);
        long long54 = decoratedDurationField53.getUnitMillis();
        long long55 = decoratedDurationField53.getUnitMillis();
        org.joda.time.DurationField durationField56 = decoratedDurationField53.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PeriodType[DayTime]" + "'", str33.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(periodType42);
        org.junit.Assert.assertNotNull(periodType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(durationFieldType47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(durationFieldType51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2629746000L + "'", long54 == 2629746000L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2629746000L + "'", long55 == 2629746000L);
        org.junit.Assert.assertNotNull(durationField56);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant6, readableDuration7);
        long long11 = iSOChronology1.add((org.joda.time.ReadablePeriod) period8, (long) 1, (int) ' ');
        org.joda.time.DurationField durationField12 = iSOChronology1.months();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField14 = iSOChronology1.weeks();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-65331618400001L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-9223372036854775808L) + "'", long1 == (-9223372036854775808L));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[America/Los_Angeles]", (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("PT-0.097S", 8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        int int5 = periodType4.size();
        org.joda.time.PeriodType periodType6 = periodType4.withMinutesRemoved();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withMinutesRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType6);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
        long long28 = offsetDateTimeField24.remainder(87L);
        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
        long long37 = zeroIsMaxDateTimeField34.getDifferenceAsLong(384000480000618L, (-799900L));
        boolean boolean39 = zeroIsMaxDateTimeField34.isLeap(52L);
        java.util.Locale locale41 = null;
        java.lang.String str42 = zeroIsMaxDateTimeField34.getAsText(0L, locale41);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800087L + "'", long28 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800000L) + "'", long32 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 384000480800518L + "'", long37 == 384000480800518L);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1000" + "'", str42.equals("1000"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str26 = gregorianChronology25.toString();
        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
        java.lang.String str29 = unsupportedDateTimeField28.toString();
        java.util.Locale locale31 = null;
        try {
            java.lang.String str32 = unsupportedDateTimeField28.getAsText((int) (short) 100, locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800087L + "'", long19 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800000L) + "'", long23 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[UTC]" + "'", str26.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDateTimeField" + "'", str29.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("LenientChronology[ISOChronology[America/Los_Angeles]]");
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        long long9 = iSOChronology5.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology5.year();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology5.minuteOfHour();
        org.joda.time.Period period13 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DurationField durationField14 = iSOChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology5.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 20);
        int int19 = offsetDateTimeField17.getLeapAmount(1560628303058L);
        long long21 = offsetDateTimeField17.remainder(87L);
        long long23 = offsetDateTimeField17.roundHalfCeiling((-62135596799999L));
        boolean boolean24 = offsetDateTimeField17.isSupported();
        long long26 = offsetDateTimeField17.roundFloor(62135596800086L);
        java.lang.String str28 = offsetDateTimeField17.getAsShortText((-33L));
        boolean boolean29 = jodaTimePermission1.equals((java.lang.Object) str28);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-65L) + "'", long9 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 62135596800087L + "'", long21 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-62135596800000L) + "'", long26 == (-62135596800000L));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "21" + "'", str28.equals("21"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getOffset(97L);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long13 = iSOChronology9.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology14 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 0, (org.joda.time.Chronology) iSOChronology9);
        int int16 = period15.getYears();
        org.joda.time.Period period18 = period15.withYears((int) 'a');
        org.joda.time.Period period20 = period15.plusHours((int) (short) 1);
        boolean boolean21 = fixedDateTimeZone4.equals((java.lang.Object) period15);
        long long23 = fixedDateTimeZone4.previousTransition(616007L);
        java.util.TimeZone timeZone24 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 616007L + "'", long23 == 616007L);
        org.junit.Assert.assertNotNull(timeZone24);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1", (java.lang.Number) (-97L), (java.lang.Number) (-20), (java.lang.Number) (-56940685192995L));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.halfdayOfDay();
        java.lang.String str9 = lenientChronology6.toString();
        org.joda.time.DurationField durationField10 = lenientChronology6.eras();
        long long15 = lenientChronology6.getDateTimeMillis(0, 80000, (int) (short) 10, 33);
        org.joda.time.DateTimeField dateTimeField16 = lenientChronology6.dayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str9.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 148210560000033L + "'", long15 == 148210560000033L);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str26 = gregorianChronology25.toString();
        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
        long long31 = unsupportedDateTimeField28.getDifferenceAsLong((long) (-7), 9223372036854775806L);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial33 = null;
        try {
            int int34 = unsupportedDateTimeField28.getMinimumValue(readablePartial33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800087L + "'", long19 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800000L) + "'", long23 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[UTC]" + "'", str26.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 292277025L + "'", long31 == 292277025L);
        org.junit.Assert.assertNull(durationField32);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((-1));
        org.joda.time.Period period3 = period1.plusWeeks(0);
        org.joda.time.Period period5 = org.joda.time.Period.seconds((-1));
        org.joda.time.Period period7 = period5.minusSeconds((int) (byte) 1);
        org.joda.time.Period period8 = period1.plus((org.joda.time.ReadablePeriod) period5);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Period period10 = period8.plus(readablePeriod9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period10.toDurationTo(readableInstant11);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration12);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("");
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException2.getSuppressed();
        java.lang.String str6 = illegalFieldValueException2.toString();
        java.lang.Number number7 = illegalFieldValueException2.getUpperBound();
        java.lang.Number number8 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported" + "'", str6.equals("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported"));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        java.lang.Object obj0 = null;
        org.joda.time.Period period1 = new org.joda.time.Period(obj0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        int int18 = offsetDateTimeField15.getOffset();
        int int19 = offsetDateTimeField15.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField15.getAsText(readablePartial20, (-1), locale22);
        java.lang.String str25 = offsetDateTimeField15.getAsShortText(7910421630L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 20 + "'", int18 == 20);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "-1" + "'", str23.equals("-1"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "21" + "'", str25.equals("21"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
        long long28 = offsetDateTimeField24.remainder(87L);
        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        long long40 = iSOChronology36.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField41 = iSOChronology36.years();
        org.joda.time.DurationField durationField42 = iSOChronology36.days();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
        long long48 = iSOChronology44.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology49 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology44);
        org.joda.time.DateTimeField dateTimeField50 = lenientChronology49.yearOfEra();
        org.joda.time.DateTimeField dateTimeField51 = lenientChronology49.halfdayOfDay();
        org.joda.time.DurationField durationField52 = lenientChronology49.weeks();
        long long55 = durationField52.subtract(0L, 11L);
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField56 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType33, durationField42, durationField52);
        long long58 = preciseDateTimeField56.roundCeiling((-141746760000000L));
        long long59 = preciseDateTimeField56.getUnitMillis();
        long long61 = preciseDateTimeField56.roundFloor(43200000L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800087L + "'", long28 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800000L) + "'", long32 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-65L) + "'", long40 == (-65L));
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 32L + "'", long48 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-6652800000L) + "'", long55 == (-6652800000L));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-141746716800000L) + "'", long58 == (-141746716800000L));
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 86400000L + "'", long59 == 86400000L);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.year();
        org.joda.time.ReadablePartial readablePartial4 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        long long12 = iSOChronology8.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology13 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology8.year();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology8.minuteOfHour();
        org.joda.time.Period period16 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DurationField durationField17 = iSOChronology8.minutes();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology8.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 20);
        int int22 = offsetDateTimeField20.getLeapAmount(1560628303058L);
        int int23 = offsetDateTimeField20.getOffset();
        org.joda.time.ReadablePartial readablePartial24 = null;
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant26, readableInstant27);
        org.joda.time.Period period29 = new org.joda.time.Period((long) (-1), chronology28);
        org.joda.time.Period period31 = period29.withDays(0);
        int[] intArray32 = period31.getValues();
        int int33 = offsetDateTimeField20.getMaximumValue(readablePartial24, intArray32);
        try {
            iSOChronology1.validate(readablePartial4, intArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-65L) + "'", long12 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 20 + "'", int23 == 20);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 21 + "'", int33 == 21);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, 10L, chronology6);
        int int8 = period7.getDays();
        org.joda.time.Days days9 = period7.toStandardDays();
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period11 = period7.normalizedStandard(periodType10);
        int[] intArray14 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L, 34L);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.monthOfYear();
        int int16 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology17 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField18 = gregorianChronology0.days();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(days9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        int int2 = periodType1.size();
        org.joda.time.PeriodType periodType3 = periodType1.withMonthsRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        int int5 = periodType4.size();
        org.joda.time.PeriodType periodType6 = periodType4.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType8 = periodType4.getFieldType(0);
        int int9 = periodType1.indexOf(durationFieldType8);
        org.joda.time.field.PreciseDurationField preciseDurationField11 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (long) (short) -1);
        org.joda.time.DurationFieldType durationFieldType12 = preciseDurationField11.getType();
        boolean boolean13 = periodType0.isSupported(durationFieldType12);
        int int14 = periodType0.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(608003, 52, (int) '4', (-83189600));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        java.lang.Object obj1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) 'a', (long) 0, periodType6, chronology8);
        org.joda.time.PeriodType periodType10 = periodType6.withYearsRemoved();
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration2, readableInstant3, periodType10);
        java.lang.String str12 = periodType10.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period14 = new org.joda.time.Period(obj1, periodType10, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.hourOfDay();
        org.joda.time.Period period16 = new org.joda.time.Period((-863999999900L), (org.joda.time.Chronology) gregorianChronology13);
        java.lang.String str17 = gregorianChronology13.toString();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology13.secondOfDay();
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PeriodType[DayTime]" + "'", str12.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[UTC]" + "'", str17.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException(durationFieldType4, "PT0.011S");
        java.lang.String str7 = illegalFieldValueException6.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0.011S" + "'", str7.equals("PT0.011S"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str26 = gregorianChronology25.toString();
        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
        long long31 = unsupportedDateTimeField28.getDifferenceAsLong((long) (-7), 9223372036854775806L);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField28.getRangeDurationField();
        long long35 = unsupportedDateTimeField28.add(616007L, (long) (-800000));
        int int38 = unsupportedDateTimeField28.getDifference((long) 20, (long) 'a');
        int int41 = unsupportedDateTimeField28.getDifference((-115199990L), 1560628303058L);
        try {
            long long43 = unsupportedDateTimeField28.roundHalfEven(86400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800087L + "'", long19 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800000L) + "'", long23 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[UTC]" + "'", str26.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 292277025L + "'", long31 == 292277025L);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-25245561599383993L) + "'", long35 == (-25245561599383993L));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-49) + "'", int41 == (-49));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        long long9 = iSOChronology5.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField11 = lenientChronology10.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = lenientChronology10.millisOfSecond();
        boolean boolean13 = jodaTimePermission1.equals((java.lang.Object) lenientChronology10);
        long long19 = lenientChronology10.getDateTimeMillis(0L, 608003, (-7), 0, 0);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-65L) + "'", long9 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2188810380000L + "'", long19 == 2188810380000L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, 10L, chronology6);
        int int8 = period7.getDays();
        org.joda.time.Days days9 = period7.toStandardDays();
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period11 = period7.normalizedStandard(periodType10);
        int[] intArray14 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period7, 0L, 34L);
        org.joda.time.DurationField durationField15 = gregorianChronology0.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(days9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
        long long28 = offsetDateTimeField24.remainder(87L);
        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        long long40 = iSOChronology36.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField41 = iSOChronology36.years();
        org.joda.time.DurationField durationField42 = iSOChronology36.days();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
        long long48 = iSOChronology44.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology49 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology44);
        org.joda.time.DateTimeField dateTimeField50 = lenientChronology49.yearOfEra();
        org.joda.time.DateTimeField dateTimeField51 = lenientChronology49.halfdayOfDay();
        org.joda.time.DurationField durationField52 = lenientChronology49.weeks();
        long long55 = durationField52.subtract(0L, 11L);
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField56 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType33, durationField42, durationField52);
        long long57 = preciseDateTimeField56.getUnitMillis();
        org.joda.time.DurationField durationField58 = preciseDateTimeField56.getRangeDurationField();
        boolean boolean59 = preciseDateTimeField56.isLenient();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800087L + "'", long28 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800000L) + "'", long32 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-65L) + "'", long40 == (-65L));
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 32L + "'", long48 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-6652800000L) + "'", long55 == (-6652800000L));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 86400000L + "'", long57 == 86400000L);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.Period period14 = period7.withPeriodType(periodType10);
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period14, obj15);
        java.lang.Class<?> wildcardClass17 = period14.getClass();
        org.joda.time.Period period19 = period14.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, periodType25, chronology27);
        org.joda.time.PeriodType periodType29 = periodType25.withYearsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType29);
        org.joda.time.PeriodType periodType31 = periodType29.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(10L, periodType29);
        org.joda.time.PeriodType periodType33 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
        boolean boolean35 = periodType29.equals((java.lang.Object) periodType34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        int int37 = periodType36.size();
        org.joda.time.PeriodType periodType38 = periodType36.withMonthsRemoved();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.seconds();
        int int40 = periodType39.size();
        org.joda.time.PeriodType periodType41 = periodType39.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType(0);
        int int44 = periodType36.indexOf(durationFieldType43);
        int int45 = periodType29.indexOf(durationFieldType43);
        org.joda.time.Period period47 = period14.withField(durationFieldType43, 0);
        int int48 = period1.get(durationFieldType43);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType43);
        boolean boolean50 = unsupportedDurationField49.isPrecise();
        try {
            long long52 = unsupportedDurationField49.getMillis((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: seconds field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffset((long) (byte) 0);
        java.lang.String str7 = cachedDateTimeZone4.getID();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant8);
        boolean boolean10 = cachedDateTimeZone4.equals((java.lang.Object) readableInstant8);
        boolean boolean11 = cachedDateTimeZone4.isFixed();
        boolean boolean12 = cachedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-00:00:00.001" + "'", str7.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(1224000100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440601.666667824d + "'", double1 == 2440601.666667824d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        org.joda.time.DurationField durationField18 = offsetDateTimeField15.getLeapDurationField();
        java.lang.String str19 = offsetDateTimeField15.toString();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[era]" + "'", str19.equals("DateTimeField[era]"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period2 = new org.joda.time.Period(11L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Chronology chronology3 = gregorianChronology1.withUTC();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = dateTimeZoneBuilder4.addRecurringSavings("GregorianChronology[America/Los_Angeles]", (int) (short) 10, 0, (int) (byte) -1, 'a', (int) 'a', 10, 0, true, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone18 = dateTimeZoneBuilder15.toDateTimeZone("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported", true);
        boolean boolean19 = gregorianChronology1.equals((java.lang.Object) dateTimeZoneBuilder15);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long11 = dateTimeZone8.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.Chronology chronology13 = iSOChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        long long17 = cachedDateTimeZone12.convertLocalToUTC((long) 10, true, (long) (short) 0);
        long long19 = cachedDateTimeZone12.previousTransition(1L);
        java.util.Locale locale21 = null;
        java.lang.String str22 = cachedDateTimeZone12.getShortName(87L, locale21);
        java.lang.String str23 = cachedDateTimeZone12.getID();
        boolean boolean24 = cachedDateTimeZone12.isFixed();
        java.util.Locale locale26 = null;
        java.lang.String str27 = cachedDateTimeZone12.getShortName(11L, locale26);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 11L + "'", long17 == 11L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-00:00:00.001" + "'", str22.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "-00:00:00.001" + "'", str23.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-00:00:00.001" + "'", str27.equals("-00:00:00.001"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long4 = dateTimeZone1.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone6 = cachedDateTimeZone5.getUncachedZone();
        java.lang.String str8 = cachedDateTimeZone5.getName(97L);
        long long10 = cachedDateTimeZone5.previousTransition(2704L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-00:00:00.001" + "'", str8.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2704L + "'", long10 == 2704L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, 80000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80000 + "'", int2 == 80000);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.withMillis((int) (short) 1);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period5.toString(periodFormatter9);
        org.joda.time.Period period12 = period5.minusSeconds((-799980));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT0.011S" + "'", str10.equals("PT0.011S"));
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
        long long28 = offsetDateTimeField24.remainder(87L);
        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
        long long36 = zeroIsMaxDateTimeField34.roundHalfCeiling((long) (byte) 100);
        long long38 = zeroIsMaxDateTimeField34.roundHalfFloor(32L);
        int int41 = zeroIsMaxDateTimeField34.getDifference(1224000100L, 0L);
        long long43 = zeroIsMaxDateTimeField34.roundCeiling((-264061066L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800087L + "'", long28 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800000L) + "'", long32 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 32L + "'", long38 == 32L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1224000100 + "'", int41 == 1224000100);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-264061066L) + "'", long43 == (-264061066L));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long6 = iSOChronology2.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant7, readableDuration8);
        long long12 = iSOChronology2.add((org.joda.time.ReadablePeriod) period9, (long) 1, (int) ' ');
        org.joda.time.Chronology chronology13 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology2.dayOfYear();
        try {
            org.joda.time.Period period15 = new org.joda.time.Period((-9223372036854775808L), (org.joda.time.Chronology) iSOChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -15250284452");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-65L) + "'", long6 == (-65L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
        long long28 = offsetDateTimeField24.remainder(87L);
        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
        boolean boolean38 = zeroIsMaxDateTimeField34.isLeap((-62135596799999L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800087L + "'", long28 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800000L) + "'", long32 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        long long8 = iSOChronology4.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology4.year();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology4.minuteOfHour();
        org.joda.time.Period period12 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField13 = iSOChronology4.minutes();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology4.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 20);
        int int18 = offsetDateTimeField16.getLeapAmount(1560628303058L);
        long long20 = offsetDateTimeField16.remainder(87L);
        long long22 = offsetDateTimeField16.roundHalfCeiling((-62135596799999L));
        long long24 = offsetDateTimeField16.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField16.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str27 = gregorianChronology26.toString();
        org.joda.time.DurationField durationField28 = gregorianChronology26.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField29 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField28);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType25, (int) (short) 10, 2, 27);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-65L) + "'", long8 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 62135596800087L + "'", long20 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62135596800000L) + "'", long24 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "GregorianChronology[UTC]" + "'", str27.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField29);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(9953277315200000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1764055642592593E8d + "'", double1 == 1.1764055642592593E8d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withMinutesRemoved();
        org.joda.time.PeriodType periodType3 = periodType0.withMillisRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        java.security.PermissionCollection permissionCollection4 = jodaTimePermission1.newPermissionCollection();
        jodaTimePermission1.checkGuard((java.lang.Object) (-360000065L));
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported");
        boolean boolean10 = jodaTimePermission8.equals((java.lang.Object) 10);
        org.joda.time.JodaTimePermission jodaTimePermission12 = new org.joda.time.JodaTimePermission("LenientChronology[ISOChronology[America/Los_Angeles]]");
        boolean boolean14 = jodaTimePermission12.equals((java.lang.Object) 8000010L);
        java.lang.String str15 = jodaTimePermission12.getName();
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType18 = periodType17.withSecondsRemoved();
        org.joda.time.PeriodType periodType19 = periodType17.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        long long25 = iSOChronology21.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        long long31 = iSOChronology21.add((org.joda.time.ReadablePeriod) period28, (long) 1, (int) ' ');
        org.joda.time.DurationField durationField32 = iSOChronology21.months();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology21.monthOfYear();
        org.joda.time.DurationField durationField34 = iSOChronology21.hours();
        org.joda.time.Period period35 = new org.joda.time.Period((-1L), periodType17, (org.joda.time.Chronology) iSOChronology21);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology21.millisOfDay();
        boolean boolean37 = jodaTimePermission12.equals((java.lang.Object) iSOChronology21);
        boolean boolean38 = jodaTimePermission8.implies((java.security.Permission) jodaTimePermission12);
        boolean boolean39 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission8);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertNotNull(permissionCollection4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "LenientChronology[ISOChronology[America/Los_Angeles]]" + "'", str15.equals("LenientChronology[ISOChronology[America/Los_Angeles]]"));
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-65L) + "'", long25 == (-65L));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        org.joda.time.Period period1 = org.joda.time.Period.hours(0);
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period3 = period1.normalizedStandard(periodType2);
        int int4 = period1.getMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, 27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.011S", 1, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getOffset(97L);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.seconds();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        boolean boolean7 = periodType5.isSupported(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = periodType5.indexOf(durationFieldType8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology11 = iSOChronology10.withUTC();
        org.joda.time.Period period12 = new org.joda.time.Period(0L, periodType5, chronology11);
        int[] intArray15 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period12, (-33L), (long) 0);
        try {
            long long23 = gregorianChronology0.getDateTimeMillis(799806, (int) (byte) -1, 36000000, 0, 79966, 11, (-1224000100));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79966 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        int int21 = offsetDateTimeField15.getLeapAmount((long) (byte) 0);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField15.getAsText((int) (short) -1, locale23);
        int int26 = offsetDateTimeField15.getMaximumValue(0L);
        long long28 = offsetDateTimeField15.roundHalfEven(9223372036854775774L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800087L + "'", long19 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "-1" + "'", str24.equals("-1"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 21 + "'", int26 == 21);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62135596800000L) + "'", long28 == (-62135596800000L));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str5 = gregorianChronology4.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant8 = null;
        int int9 = dateTimeZone7.getOffset(readableInstant8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        org.joda.time.Chronology chronology11 = gregorianChronology4.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = zonedChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = zonedChronology12.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[UTC]" + "'", str5.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("");
        illegalFieldValueException2.prependMessage("PeriodType[DayTime]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException9.prependMessage("");
        illegalFieldValueException9.prependMessage("PeriodType[DayTime]");
        java.lang.Throwable[] throwableArray14 = illegalFieldValueException9.getSuppressed();
        boolean boolean15 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException18.prependMessage("");
        java.lang.String str21 = illegalFieldValueException18.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = illegalFieldValueException18.getDateTimeFieldType();
        illegalFieldValueException9.addSuppressed((java.lang.Throwable) illegalFieldValueException18);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException18);
        java.lang.Number number25 = illegalFieldValueException18.getUpperBound();
        java.lang.Number number26 = illegalFieldValueException18.getUpperBound();
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported" + "'", str21.equals("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported"));
        org.junit.Assert.assertNull(dateTimeFieldType22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(number26);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period2 = new org.joda.time.Period(11L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Chronology chronology3 = gregorianChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
        long long7 = dateTimeZone4.convertLocalToUTC((long) (-360000065), false);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-360000065L) + "'", long7 == (-360000065L));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 10, 1224000100, (int) (byte) 10, (-21));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        int int2 = periodType1.size();
        org.joda.time.PeriodType periodType3 = periodType1.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long4 = gregorianChronology0.add(0L, (long) 'a', (int) (byte) 0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant7, readableInstant8);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) -1, 10L, chronology9);
        int int11 = period10.getDays();
        org.joda.time.Days days12 = period10.toStandardDays();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period14 = period10.normalizedStandard(periodType13);
        long long17 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period14, 0L, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology0.getZone();
        org.joda.time.ReadablePartial readablePartial19 = null;
        try {
            int[] intArray21 = gregorianChronology0.get(readablePartial19, (-59334459011L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(days12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, 10L, chronology4);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.withMillis((int) (short) 1);
        org.joda.time.Period period10 = period5.plusWeeks(4);
        org.joda.time.Minutes minutes11 = period10.toStandardMinutes();
        org.joda.time.Period period13 = period10.plusMinutes(1);
        org.joda.time.Period period15 = period13.minusDays((int) ' ');
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.seconds();
        int int17 = periodType16.size();
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.seconds();
        int int20 = periodType19.size();
        org.joda.time.PeriodType periodType21 = periodType19.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType(0);
        int int24 = periodType16.indexOf(durationFieldType23);
        org.joda.time.field.PreciseDurationField preciseDurationField26 = new org.joda.time.field.PreciseDurationField(durationFieldType23, (long) (short) -1);
        org.joda.time.Period period28 = period15.withField(durationFieldType23, 2);
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(durationFieldType23, "LenientChronology[ISOChronology[-00:00:00.001]]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 28L, (java.lang.Number) 2440588L, (java.lang.Number) 34);
        org.joda.time.IllegalFieldValueException illegalFieldValueException38 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) (-3245547120001L), (java.lang.Number) 33, (java.lang.Number) (-21));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(minutes11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(period28);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant22, readableInstant23);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (-1), chronology24);
        org.joda.time.Period period27 = period25.withDays(0);
        int[] intArray28 = period27.getValues();
        int int29 = offsetDateTimeField15.getMinimumValue(readablePartial20, intArray28);
        org.joda.time.ReadablePartial readablePartial30 = null;
        int[] intArray31 = null;
        int int32 = offsetDateTimeField15.getMinimumValue(readablePartial30, intArray31);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800087L + "'", long19 == 62135596800087L);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 20 + "'", int32 == 20);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        long long17 = offsetDateTimeField15.roundHalfEven(97L);
        java.lang.String str19 = offsetDateTimeField15.getAsText((long) (short) 100);
        int int21 = offsetDateTimeField15.getMaximumValue((long) (byte) 0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135596800000L) + "'", long17 == (-62135596800000L));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "21" + "'", str19.equals("21"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 21 + "'", int21 == 21);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        illegalFieldValueException2.prependMessage("");
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException2.getSuppressed();
        java.lang.String str6 = illegalFieldValueException2.toString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 100 for -00:00:00.001 must be in the range [0,10]", (java.lang.Number) (-10L), (java.lang.Number) 33, (java.lang.Number) (-58885142400000L));
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException11);
        java.lang.String str13 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported" + "'", str6.equals("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str5 = gregorianChronology4.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant8 = null;
        int int9 = dateTimeZone7.getOffset(readableInstant8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        org.joda.time.Chronology chronology11 = gregorianChronology4.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology12.getZone();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[UTC]" + "'", str5.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.Period period14 = period7.withPeriodType(periodType10);
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period14, obj15);
        java.lang.Class<?> wildcardClass17 = period14.getClass();
        org.joda.time.Period period19 = period14.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, periodType25, chronology27);
        org.joda.time.PeriodType periodType29 = periodType25.withYearsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType29);
        org.joda.time.PeriodType periodType31 = periodType29.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(10L, periodType29);
        org.joda.time.PeriodType periodType33 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
        boolean boolean35 = periodType29.equals((java.lang.Object) periodType34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        int int37 = periodType36.size();
        org.joda.time.PeriodType periodType38 = periodType36.withMonthsRemoved();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.seconds();
        int int40 = periodType39.size();
        org.joda.time.PeriodType periodType41 = periodType39.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType(0);
        int int44 = periodType36.indexOf(durationFieldType43);
        int int45 = periodType29.indexOf(durationFieldType43);
        org.joda.time.Period period47 = period14.withField(durationFieldType43, 0);
        int int48 = period1.get(durationFieldType43);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType43);
        java.lang.String str50 = unsupportedDurationField49.toString();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        long long57 = iSOChronology53.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.Period period58 = new org.joda.time.Period((long) '#', (org.joda.time.Chronology) iSOChronology53);
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant61 = null;
        int int62 = dateTimeZone60.getOffset(readableInstant61);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone63 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone60);
        long long67 = cachedDateTimeZone63.convertLocalToUTC((long) 10, true, (long) (short) 10);
        java.lang.String str69 = cachedDateTimeZone63.getShortName(32L);
        java.util.TimeZone timeZone70 = cachedDateTimeZone63.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology71 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone63);
        org.joda.time.chrono.ZonedChronology zonedChronology72 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology53, (org.joda.time.DateTimeZone) cachedDateTimeZone63);
        org.joda.time.Period period74 = org.joda.time.Period.days((int) (byte) 10);
        org.joda.time.format.PeriodFormatter periodFormatter75 = null;
        java.lang.String str76 = period74.toString(periodFormatter75);
        org.joda.time.Hours hours77 = period74.toStandardHours();
        boolean boolean78 = zonedChronology72.equals((java.lang.Object) hours77);
        boolean boolean79 = unsupportedDurationField49.equals((java.lang.Object) boolean78);
        try {
            long long81 = unsupportedDurationField49.getMillis((-799900L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: seconds field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "UnsupportedDurationField[seconds]" + "'", str50.equals("UnsupportedDurationField[seconds]"));
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-65L) + "'", long57 == (-65L));
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone63);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 11L + "'", long67 == 11L);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "-00:00:00.001" + "'", str69.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNotNull(iSOChronology71);
        org.junit.Assert.assertNotNull(zonedChronology72);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "P10D" + "'", str76.equals("P10D"));
        org.junit.Assert.assertNotNull(hours77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
        long long28 = offsetDateTimeField24.remainder(87L);
        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        long long40 = iSOChronology36.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology41 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology36);
        org.joda.time.DateTimeField dateTimeField42 = lenientChronology41.yearOfEra();
        long long48 = lenientChronology41.getDateTimeMillis((long) 4, (int) (short) 1, 0, 10000, (int) '#');
        org.joda.time.DurationField durationField49 = lenientChronology41.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField49);
        try {
            long long52 = unsupportedDateTimeField50.remainder((long) 608002);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800087L + "'", long28 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800000L) + "'", long32 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 32L + "'", long40 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 13600035L + "'", long48 == 13600035L);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        java.security.PermissionCollection permissionCollection4 = jodaTimePermission1.newPermissionCollection();
        jodaTimePermission1.checkGuard((java.lang.Object) (-360000065L));
        java.lang.Object obj7 = null;
        jodaTimePermission1.checkGuard(obj7);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertNotNull(permissionCollection4);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
        long long28 = offsetDateTimeField24.remainder(87L);
        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        long long40 = iSOChronology36.add(0L, (long) 1, (int) ' ');
        org.joda.time.chrono.LenientChronology lenientChronology41 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology36);
        org.joda.time.DateTimeField dateTimeField42 = lenientChronology41.yearOfEra();
        long long48 = lenientChronology41.getDateTimeMillis((long) 4, (int) (short) 1, 0, 10000, (int) '#');
        org.joda.time.DurationField durationField49 = lenientChronology41.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField49);
        org.joda.time.ReadablePartial readablePartial51 = null;
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone54);
        long long59 = iSOChronology55.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology55.era();
        org.joda.time.Period period61 = new org.joda.time.Period((long) 'a', (-65L), (org.joda.time.Chronology) iSOChronology55);
        org.joda.time.DurationField durationField62 = iSOChronology55.months();
        org.joda.time.Period period64 = org.joda.time.Period.minutes(8);
        int[] intArray67 = iSOChronology55.get((org.joda.time.ReadablePeriod) period64, (long) 100, 0L);
        int[] intArray68 = period64.getValues();
        try {
            int int69 = unsupportedDateTimeField50.getMinimumValue(readablePartial51, intArray68);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800087L + "'", long28 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800000L) + "'", long32 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 32L + "'", long40 == 32L);
        org.junit.Assert.assertNotNull(lenientChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 13600035L + "'", long48 == 13600035L);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertNotNull(iSOChronology55);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 32L + "'", long59 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(period64);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray68);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology3.era();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        long long13 = dateTimeZone10.convertLocalToUTC(0L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        org.joda.time.Chronology chronology15 = iSOChronology3.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone14);
        long long19 = cachedDateTimeZone14.convertLocalToUTC((long) 10, true, (long) (short) 0);
        org.joda.time.Period period21 = org.joda.time.Period.minutes(1);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        boolean boolean23 = cachedDateTimeZone14.equals((java.lang.Object) periodType22);
        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
        java.lang.Object obj25 = null;
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval31);
        org.joda.time.Period period33 = new org.joda.time.Period((long) 'a', (long) 0, periodType30, chronology32);
        org.joda.time.PeriodType periodType34 = periodType30.withYearsRemoved();
        org.joda.time.Period period35 = new org.joda.time.Period(readableDuration26, readableInstant27, periodType34);
        java.lang.String str36 = periodType34.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period38 = new org.joda.time.Period(obj25, periodType34, (org.joda.time.Chronology) gregorianChronology37);
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.Chronology chronology42 = gregorianChronology37.withZone(dateTimeZone41);
        org.joda.time.DateTimeZone dateTimeZone43 = gregorianChronology37.getZone();
        org.joda.time.Chronology chronology44 = zonedChronology24.withZone(dateTimeZone43);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 11L + "'", long19 == 11L);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(zonedChronology24);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "PeriodType[DayTime]" + "'", str36.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(chronology44);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
        long long28 = offsetDateTimeField24.remainder(87L);
        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
        int int36 = zeroIsMaxDateTimeField34.getMinimumValue((long) 800001000);
        long long38 = zeroIsMaxDateTimeField34.roundHalfFloor((long) (-34));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800087L + "'", long28 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800000L) + "'", long32 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-34L) + "'", long38 == (-34L));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported", "");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported");
        org.joda.time.Period period10 = new org.joda.time.Period((int) (short) 1, (int) (byte) 0, (int) (short) 10, 100, 10, 0, (int) (short) -1, (int) '#');
        boolean boolean11 = jodaTimePermission1.equals((java.lang.Object) 10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        long long17 = iSOChronology13.add(0L, (long) 1, (int) ' ');
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval21);
        org.joda.time.Period period23 = new org.joda.time.Period((long) 'a', (long) 0, periodType20, chronology22);
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval27 = null;
        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval27);
        org.joda.time.Period period29 = new org.joda.time.Period((long) 'a', (long) 0, periodType26, chronology28);
        org.joda.time.Period period30 = period23.withPeriodType(periodType26);
        org.joda.time.format.PeriodFormatter periodFormatter31 = null;
        java.lang.String str32 = period30.toString(periodFormatter31);
        org.joda.time.Seconds seconds33 = period30.toStandardSeconds();
        long long36 = iSOChronology13.add((org.joda.time.ReadablePeriod) period30, (long) (short) -1, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology13.minuteOfHour();
        boolean boolean38 = jodaTimePermission1.equals((java.lang.Object) dateTimeField37);
        java.lang.String str39 = jodaTimePermission1.getActions();
        java.lang.String str40 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 32L + "'", long17 == 32L);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PT-0.097S" + "'", str32.equals("PT-0.097S"));
        org.junit.Assert.assertNotNull(seconds33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1L) + "'", long36 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported\")" + "'", str40.equals("(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: : Value \"\" for hi! is not supported\")"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.Period period14 = period7.withPeriodType(periodType10);
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period14, obj15);
        java.lang.Class<?> wildcardClass17 = period14.getClass();
        org.joda.time.Period period19 = period14.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, periodType25, chronology27);
        org.joda.time.PeriodType periodType29 = periodType25.withYearsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType29);
        org.joda.time.PeriodType periodType31 = periodType29.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(10L, periodType29);
        org.joda.time.PeriodType periodType33 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
        boolean boolean35 = periodType29.equals((java.lang.Object) periodType34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        int int37 = periodType36.size();
        org.joda.time.PeriodType periodType38 = periodType36.withMonthsRemoved();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.seconds();
        int int40 = periodType39.size();
        org.joda.time.PeriodType periodType41 = periodType39.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType(0);
        int int44 = periodType36.indexOf(durationFieldType43);
        int int45 = periodType29.indexOf(durationFieldType43);
        org.joda.time.Period period47 = period14.withField(durationFieldType43, 0);
        int int48 = period1.get(durationFieldType43);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType43);
        try {
            long long51 = unsupportedDurationField49.getMillis(383999999990L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: seconds field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        int int3 = periodType2.size();
        org.joda.time.PeriodType periodType4 = periodType2.withMonthsRemoved();
        try {
            org.joda.time.Period period5 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant22, readableInstant23);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (-1), chronology24);
        org.joda.time.Period period27 = period25.withDays(0);
        int[] intArray28 = period27.getValues();
        int int29 = offsetDateTimeField15.getMinimumValue(readablePartial20, intArray28);
        java.lang.String str30 = offsetDateTimeField15.getName();
        boolean boolean32 = offsetDateTimeField15.isLeap((long) ' ');
        org.joda.time.ReadablePartial readablePartial33 = null;
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField15.getAsShortText(readablePartial33, (int) 'a', locale35);
        org.joda.time.ReadablePartial readablePartial37 = null;
        int int38 = offsetDateTimeField15.getMinimumValue(readablePartial37);
        long long40 = offsetDateTimeField15.roundHalfFloor(0L);
        long long42 = offsetDateTimeField15.roundHalfCeiling((long) (-1));
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800087L + "'", long19 == 62135596800087L);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "era" + "'", str30.equals("era"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "97" + "'", str36.equals("97"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 20 + "'", int38 == 20);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62135596800000L) + "'", long40 == (-62135596800000L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
        int int26 = offsetDateTimeField15.getMinimumValue((long) 1224000100);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800087L + "'", long19 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800000L) + "'", long23 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str26 = gregorianChronology25.toString();
        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
        java.lang.String str29 = unsupportedDateTimeField28.toString();
        java.util.Locale locale32 = null;
        try {
            long long33 = unsupportedDateTimeField28.set(3245547120001L, "DurationField[seconds]", locale32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800087L + "'", long19 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800000L) + "'", long23 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[UTC]" + "'", str26.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDateTimeField" + "'", str29.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', (long) 0, periodType4, chronology6);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) 'a', (long) 0, periodType10, chronology12);
        org.joda.time.Period period14 = period7.withPeriodType(periodType10);
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period14, obj15);
        java.lang.Class<?> wildcardClass17 = period14.getClass();
        org.joda.time.Period period19 = period14.minusSeconds((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', (long) 0, periodType25, chronology27);
        org.joda.time.PeriodType periodType29 = periodType25.withYearsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType29);
        org.joda.time.PeriodType periodType31 = periodType29.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(10L, periodType29);
        org.joda.time.PeriodType periodType33 = periodType29.withHoursRemoved();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.standard();
        boolean boolean35 = periodType29.equals((java.lang.Object) periodType34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        int int37 = periodType36.size();
        org.joda.time.PeriodType periodType38 = periodType36.withMonthsRemoved();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.seconds();
        int int40 = periodType39.size();
        org.joda.time.PeriodType periodType41 = periodType39.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType(0);
        int int44 = periodType36.indexOf(durationFieldType43);
        int int45 = periodType29.indexOf(durationFieldType43);
        org.joda.time.Period period47 = period14.withField(durationFieldType43, 0);
        int int48 = period1.get(durationFieldType43);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType43);
        try {
            int int52 = unsupportedDurationField49.getValue((-360000065L), 148210585201012L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: seconds field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.year();
        org.joda.time.DurationField durationField4 = gregorianChronology1.eras();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale3 = null;
        java.lang.String str6 = defaultNameProvider0.getName(locale3, "PT-0.001S", "PeriodType[DayTime]");
        java.util.Locale locale7 = null;
        java.lang.String str10 = defaultNameProvider0.getShortName(locale7, "79966", "");
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long16 = iSOChronology12.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.year();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology12.minuteOfHour();
        org.joda.time.Period period20 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DurationField durationField21 = iSOChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology12.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 20);
        int int26 = offsetDateTimeField24.getLeapAmount(1560628303058L);
        long long28 = offsetDateTimeField24.remainder(87L);
        long long30 = offsetDateTimeField24.roundHalfCeiling((-62135596799999L));
        long long32 = offsetDateTimeField24.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType33);
        long long36 = zeroIsMaxDateTimeField34.roundHalfCeiling((long) (byte) 100);
        long long38 = zeroIsMaxDateTimeField34.roundHalfFloor(32L);
        long long40 = zeroIsMaxDateTimeField34.roundHalfEven((-3245547120001L));
        java.lang.String str42 = zeroIsMaxDateTimeField34.getAsShortText(1100L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-65L) + "'", long16 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 62135596800087L + "'", long28 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62135596800000L) + "'", long32 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 32L + "'", long38 == 32L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-3245547120001L) + "'", long40 == (-3245547120001L));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "100" + "'", str42.equals("100"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        int int17 = offsetDateTimeField15.getLeapAmount(1560628303058L);
        long long19 = offsetDateTimeField15.remainder(87L);
        long long21 = offsetDateTimeField15.roundHalfCeiling((-62135596799999L));
        long long23 = offsetDateTimeField15.roundFloor((long) 36000000);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str26 = gregorianChronology25.toString();
        org.joda.time.DurationField durationField27 = gregorianChronology25.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
        long long31 = unsupportedDateTimeField28.getDifferenceAsLong((long) (-7), 9223372036854775806L);
        try {
            java.lang.String str33 = unsupportedDateTimeField28.getAsShortText(11L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62135596800087L + "'", long19 == 62135596800087L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135596800000L) + "'", long23 == (-62135596800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[UTC]" + "'", str26.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 292277025L + "'", long31 == 292277025L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(2, (-20));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -20");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField12 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 20);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) (short) 1, locale17);
        java.lang.String str19 = offsetDateTimeField15.toString();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-65L) + "'", long7 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "21" + "'", str18.equals("21"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[era]" + "'", str19.equals("DateTimeField[era]"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long6 = iSOChronology2.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (org.joda.time.Chronology) iSOChronology2);
        int int8 = period7.getYears();
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period7.toString(periodFormatter9);
        org.joda.time.Period period12 = period7.withSeconds(0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-65L) + "'", long6 == (-65L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT0.035S" + "'", str10.equals("PT0.035S"));
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        org.joda.time.Period period1 = new org.joda.time.Period((long) ' ');
        org.joda.time.Period period3 = period1.minusSeconds((int) (short) -1);
        org.joda.time.PeriodType periodType4 = period1.getPeriodType();
        org.joda.time.PeriodType periodType5 = periodType4.withMonthsRemoved();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        int int4 = periodType3.size();
        org.joda.time.PeriodType periodType5 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType7 = periodType3.getFieldType(0);
        int int8 = periodType0.indexOf(durationFieldType7);
        org.joda.time.field.PreciseDurationField preciseDurationField10 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) (short) -1);
        int int13 = preciseDurationField10.getDifference(0L, (long) 1);
        long long16 = preciseDurationField10.getMillis(0L, 383999999990L);
        java.lang.String str17 = preciseDurationField10.toString();
        org.joda.time.DurationFieldType durationFieldType18 = preciseDurationField10.getType();
        int int20 = preciseDurationField10.getValue((long) 20);
        long long23 = preciseDurationField10.getValueAsLong((long) (byte) 100, (-1L));
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DurationField[seconds]" + "'", str17.equals("DurationField[seconds]"));
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-20) + "'", int20 == (-20));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-100L) + "'", long23 == (-100L));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, 10L, chronology6);
        int int8 = period7.getDays();
        org.joda.time.Period period10 = period7.withMillis((int) (short) 1);
        java.lang.Object obj11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) 'a', (long) 0, periodType16, chronology18);
        org.joda.time.PeriodType periodType20 = periodType16.withYearsRemoved();
        org.joda.time.Period period21 = new org.joda.time.Period(readableDuration12, readableInstant13, periodType20);
        java.lang.String str22 = periodType20.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period24 = new org.joda.time.Period(obj11, periodType20, (org.joda.time.Chronology) gregorianChronology23);
        org.joda.time.PeriodType periodType25 = periodType20.withHoursRemoved();
        org.joda.time.Period period26 = period7.withPeriodType(periodType25);
        org.joda.time.PeriodType periodType27 = org.joda.time.DateTimeUtils.getPeriodType(periodType25);
        org.joda.time.PeriodType periodType28 = org.joda.time.DateTimeUtils.getPeriodType(periodType27);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str30 = gregorianChronology29.toString();
        org.joda.time.DurationField durationField31 = gregorianChronology29.weekyears();
        org.joda.time.DurationField durationField32 = gregorianChronology29.centuries();
        org.joda.time.Chronology chronology33 = gregorianChronology29.withUTC();
        org.joda.time.chrono.LenientChronology lenientChronology34 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology29);
        org.joda.time.DurationField durationField35 = lenientChronology34.hours();
        org.joda.time.Chronology chronology36 = lenientChronology34.withUTC();
        org.joda.time.Period period37 = new org.joda.time.Period(52L, (long) 1, periodType28, (org.joda.time.Chronology) lenientChronology34);
        org.joda.time.PeriodType periodType38 = periodType28.withSecondsRemoved();
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PeriodType[DayTime]" + "'", str22.equals("PeriodType[DayTime]"));
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "GregorianChronology[UTC]" + "'", str30.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(lenientChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(periodType38);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.DurationField durationField6 = iSOChronology1.years();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) -1, 10L, chronology11);
        int int13 = period12.getDays();
        org.joda.time.Period period15 = period12.withMillis((int) (short) 1);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) (short) 1);
        long long20 = iSOChronology1.add(0L, 8L, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.DurationField durationField22 = iSOChronology1.centuries();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        long long28 = iSOChronology24.add((long) '#', (long) (-1), (int) (byte) 100);
        org.joda.time.chrono.LenientChronology lenientChronology29 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology24);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology24.year();
        org.joda.time.DurationField durationField31 = iSOChronology24.centuries();
        boolean boolean32 = iSOChronology1.equals((java.lang.Object) durationField31);
        org.joda.time.DateTimeZone dateTimeZone33 = iSOChronology1.getZone();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-65L) + "'", long5 == (-65L));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-65L) + "'", long28 == (-65L));
        org.junit.Assert.assertNotNull(lenientChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTimeZone33);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("GregorianChronology[]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'GregorianChronology[]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("P1DT-0.097S");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'P1DT-0.097S' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long7 = iSOChronology3.add(0L, (long) 1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology3.era();
        org.joda.time.Period period9 = new org.joda.time.Period((long) 'a', (-65L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology3.dayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.dayTime();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', (long) 0, periodType5, chronology7);
        org.joda.time.PeriodType periodType9 = periodType5.withYearsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType9);
        org.joda.time.PeriodType periodType11 = periodType9.withHoursRemoved();
        org.joda.time.Period period12 = new org.joda.time.Period(10L, periodType9);
        org.joda.time.PeriodType periodType13 = periodType9.withHoursRemoved();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.standard();
        boolean boolean15 = periodType9.equals((java.lang.Object) periodType14);
        org.joda.time.PeriodType periodType16 = periodType9.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(periodType16);
    }
}

