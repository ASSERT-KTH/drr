import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, (int) 'a', 0, 100);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) '#', 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) 'a', (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-97) + "'", int2 == (-97));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (-97));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.Throwable throwable0 = null;
        try {
            boolean boolean1 = org.joda.time.IllegalInstantException.isIllegalInstant(throwable0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (-100), (int) (byte) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) -1, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) (-1), chronology2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.Period period6 = period3.withField(durationFieldType4, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        java.lang.String str1 = periodType0.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PeriodType[YearMonthDayTime]" + "'", str1.equals("PeriodType[YearMonthDayTime]"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) (-1), chronology2);
        org.joda.time.Minutes minutes4 = period3.toStandardMinutes();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(minutes4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period3 = period1.withWeeks((int) '#');
        org.joda.time.Period period5 = period1.minusYears((int) (short) 100);
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (-1), chronology10);
        org.joda.time.Period period12 = new org.joda.time.Period((-1L), (long) (byte) 0, chronology10);
        try {
            org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) (short) 100, chronology10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test023");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone1.getShortName((long) 100, locale5);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period3 = period1.withWeeks((int) '#');
        int int4 = period3.getYears();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 0L + "'", long0 == 0L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (-1), chronology4);
        org.joda.time.Period period6 = new org.joda.time.Period((-1L), (long) (byte) 0, chronology4);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology(chronology4);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 0, periodType9, chronology10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.Period period13 = period11.minus(readablePeriod12);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period15 = period11.normalizedStandard(periodType14);
        try {
            org.joda.time.Period period16 = new org.joda.time.Period((int) (short) 100, (-10), (int) '#', (int) ' ', (int) (short) 10, (-10), (-1), 0, periodType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(10, (-97), (int) '4', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Period period5 = period3.minus(readablePeriod4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period7 = period3.normalizedStandard(periodType6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.Period period10 = period7.withFieldAdded(durationFieldType8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "", "YearDay");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("hi!", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1L), (java.lang.Number) (short) 1, (java.lang.Number) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        long long6 = iSOChronology0.add((org.joda.time.ReadablePeriod) period2, (long) (byte) 100, (int) (byte) 100);
        try {
            long long12 = iSOChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 1, 10, (int) (byte) 100, (-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(minutes3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Pacific Standard Time\" is malformed at \"acific Standard Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) 'a', 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        long long3 = dateTimeZone1.convertUTCToLocal((long) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-28799900L) + "'", long3 == (-28799900L));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) -1, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (-10));
        boolean boolean5 = dateTimeZone1.isStandardOffset((long) (-28800000));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period3 = period1.withSeconds((-1));
        try {
            org.joda.time.DurationFieldType durationFieldType5 = period3.getFieldType((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
//        org.joda.time.Period period5 = period3.withMinutes(0);
//        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.millis();
//        org.joda.time.PeriodType periodType7 = periodType6.withDaysRemoved();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean10 = iSOChronology8.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.secondOfMinute();
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getName((long) (byte) 0, locale15);
//        org.joda.time.ReadableInstant readableInstant17 = null;
//        int int18 = dateTimeZone13.getOffset(readableInstant17);
//        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology8, dateTimeZone13);
//        java.util.TimeZone timeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
//        java.lang.String str22 = dateTimeZone21.getID();
//        org.joda.time.Chronology chronology23 = zonedChronology19.withZone(dateTimeZone21);
//        try {
//            org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) 0, periodType6, (org.joda.time.Chronology) zonedChronology19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(periodType6);
//        org.junit.Assert.assertNotNull(periodType7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pacific Standard Time" + "'", str16.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800000) + "'", int18 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "America/Los_Angeles" + "'", str22.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology23);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) -1, (int) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-97L) + "'", long2 == (-97L));
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        int[] intArray15 = new int[] { (byte) 10 };
//        try {
//            zonedChronology11.validate(readablePartial13, intArray15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(intArray15);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            org.joda.time.Period period1 = new org.joda.time.Period((java.lang.Object) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = period1.normalizedStandard(periodType2);
        org.joda.time.Period period5 = period1.minusSeconds(0);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.Period period8 = period5.withField(durationFieldType6, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology11.getZone();
//        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.millis();
//        java.lang.String str16 = periodType15.getName();
//        org.joda.time.PeriodType periodType17 = periodType15.withWeeksRemoved();
//        org.joda.time.PeriodType periodType18 = periodType17.withHoursRemoved();
//        try {
//            org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) dateTimeZone14, periodType18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.CachedDateTimeZone");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Millis" + "'", str16.equals("Millis"));
//        org.junit.Assert.assertNotNull(periodType17);
//        org.junit.Assert.assertNotNull(periodType18);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        long long6 = iSOChronology0.add((org.joda.time.ReadablePeriod) period2, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.clockhourOfHalfday();
        try {
            long long12 = iSOChronology0.getDateTimeMillis((int) (short) -1, (int) (short) 0, 2, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(minutes3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes4 = period3.toStandardMinutes();
        long long7 = iSOChronology1.add((org.joda.time.ReadablePeriod) period3, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.DurationField durationField8 = iSOChronology1.weeks();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(minutes4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(durationField8);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.time();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period3 = period1.withWeeks((int) '#');
        org.joda.time.Period period5 = period1.minusYears((int) (short) 100);
        try {
            org.joda.time.Seconds seconds6 = period5.toStandardSeconds();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Seconds as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) '4', "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.035 ()");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = period1.normalizedStandard(periodType2);
        org.joda.time.Period period5 = period1.minusSeconds(0);
        org.joda.time.Period period7 = period1.multipliedBy((-1));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        java.lang.Class<?> wildcardClass2 = dateTimeField1.getClass();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1, "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period3 = period1.withSeconds((-1));
        org.joda.time.Days days4 = period1.toStandardDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(days4);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, 10, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 0.0d, (java.lang.Number) 1L, (java.lang.Number) (-1009411200001L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(2440587L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5282475348d + "'", double1 == 2440587.5282475348d);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        try {
//            org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) durationField12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDurationField");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.50000037d + "'", double1 == 2440587.50000037d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.Period period1 = org.joda.time.Period.millis((-1));
        org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(minutes2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) -1, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-100) + "'", int2 == (-100));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period5 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        org.joda.time.Period period8 = period5.negated();
        org.joda.time.Period period9 = period3.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.DurationFieldType[] durationFieldTypeArray10 = period9.getFieldTypes();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(durationFieldTypeArray10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) -1, (long) (-28800000));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28800000L + "'", long2 == 28800000L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (-10), (-28800000), (int) 'a');
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.lang.String str4 = iSOChronology0.toString();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getShortName((long) 0, locale11);
//        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology0.weekOfWeekyear();
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField15, (int) (short) 100, (-28800000), (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [-28800000,32]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("ISOChronology[UTC]");
        boolean boolean2 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) (-1), chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period(2440587L, chronology5);
        org.joda.time.Period period8 = new org.joda.time.Period((-28799900L), (long) (-97), chronology5);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (byte) 0);
        java.lang.String str2 = period1.toString();
        int int3 = period1.getMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PT0S" + "'", str2.equals("PT0S"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset(0L);
//        java.lang.String str4 = dateTimeZone1.toString();
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone1.getName((long) (-10), locale7);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) -1, (int) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-52L) + "'", long2 == (-52L));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1.0d), (java.lang.Number) 8, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone13 = zonedChronology11.getZone();
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        try {
//            int[] intArray16 = zonedChronology11.get(readablePartial14, (long) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("PST", (int) (short) 10);
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder3.writeTo("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.035 ()", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField2 = iSOChronology0.months();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField5 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType3, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, (-10), (int) '#', 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withMinutes(0);
        org.joda.time.Period period7 = period3.withSeconds((-100));
        org.joda.time.Period period9 = period3.plusHours(10);
        org.joda.time.Period period11 = period9.plusMonths((int) (short) 0);
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 0, periodType13, chronology14);
        org.joda.time.Period period17 = period15.withMinutes(0);
        org.joda.time.Period period19 = period15.withSeconds((-100));
        org.joda.time.Period period21 = period15.plusHours(10);
        org.joda.time.Period period23 = period21.plusMonths((int) (short) 0);
        org.joda.time.Period period24 = period9.plus((org.joda.time.ReadablePeriod) period23);
        org.joda.time.Period period26 = period9.withMonths(10);
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.yearMonthDay();
        try {
            org.joda.time.Period period28 = period26.withPeriodType(periodType27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'hours'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        org.joda.time.format.PeriodFormatter periodFormatter4 = null;
        java.lang.String str5 = period3.toString(periodFormatter4);
        try {
            org.joda.time.Period period7 = period3.withWeeks((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0S" + "'", str5.equals("PT0S"));
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        long long9 = gregorianChronology4.getDateTimeMillis((-28800000), (int) (byte) 10, 1, (int) (short) 10);
//        try {
//            long long14 = gregorianChronology4.getDateTimeMillis((int) (short) 1, (int) (short) 0, (-97), (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-908902361117221990L) + "'", long9 == (-908902361117221990L));
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        java.lang.String str14 = dateTimeZone13.getID();
//        org.joda.time.Chronology chronology15 = zonedChronology11.withZone(dateTimeZone13);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Period period18 = org.joda.time.Period.days((int) (byte) 0);
//        org.joda.time.Minutes minutes19 = period18.toStandardMinutes();
//        long long22 = iSOChronology16.add((org.joda.time.ReadablePeriod) period18, (long) (byte) 100, (int) (byte) 100);
//        org.joda.time.Period period24 = period18.withDays((-1));
//        boolean boolean25 = zonedChronology11.equals((java.lang.Object) (-1));
//        org.joda.time.DateTimeField dateTimeField26 = zonedChronology11.halfdayOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "America/Los_Angeles" + "'", str14.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertNotNull(minutes19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = period1.normalizedStandard(periodType2);
        org.joda.time.Period period4 = period1.negated();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.millis();
        boolean boolean6 = period4.equals((java.lang.Object) periodType5);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 0, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 10, (-908902361117221990L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 908902361117222000L + "'", long2 == 908902361117222000L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("PST", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean3 = iSOChronology1.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        org.joda.time.ReadableInstant readableInstant10 = null;
//        int int11 = dateTimeZone6.getOffset(readableInstant10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone6);
//        org.joda.time.DurationField durationField13 = zonedChronology12.weekyears();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean16 = iSOChronology14.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.secondOfMinute();
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone19.getName((long) (byte) 0, locale21);
//        org.joda.time.ReadableInstant readableInstant23 = null;
//        int int24 = dateTimeZone19.getOffset(readableInstant23);
//        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, dateTimeZone19);
//        org.joda.time.DurationField durationField26 = zonedChronology25.weekyears();
//        org.joda.time.DurationField durationField27 = zonedChronology25.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone28 = zonedChronology25.getZone();
//        org.joda.time.DurationField durationField29 = zonedChronology25.days();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField30 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField13, durationField29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Pacific Standard Time" + "'", str22.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(durationField29);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866846400000L) + "'", long1 == (-210866846400000L));
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.joda.time.Chronology chronology0 = null;
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.ReadableInstant readableInstant6 = null;
//        int int7 = dateTimeZone2.getOffset(readableInstant6);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        int int9 = dateTimeZone2.getOffset(readableInstant8);
//        try {
//            org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28800000) + "'", int7 == (-28800000));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (-97));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.4999988773d + "'", double1 == 2440587.4999988773d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        boolean boolean2 = periodType0.isSupported(durationFieldType1);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (byte) 10);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 0, periodType9, chronology10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.Period period13 = period11.minus(readablePeriod12);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period15 = period11.normalizedStandard(periodType14);
        int[] intArray16 = period11.getValues();
        java.util.Locale locale18 = null;
        try {
            int[] intArray19 = offsetDateTimeField3.set(readablePartial6, (-1), intArray16, "", locale18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-52L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) -1, 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8L) + "'", long2 == (-8L));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean3 = iSOChronology1.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        org.joda.time.ReadableInstant readableInstant10 = null;
//        int int11 = dateTimeZone6.getOffset(readableInstant10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone6);
//        org.joda.time.DurationField durationField13 = zonedChronology12.weekyears();
//        org.joda.time.DateTimeField dateTimeField14 = zonedChronology12.clockhourOfDay();
//        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 2440588L, (java.lang.Object) zonedChronology12);
//        org.joda.time.DurationField durationField16 = zonedChronology12.weekyears();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-25200000) + "'", int11 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(durationField16);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("hi!");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-28799900L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.166667824d + "'", double1 == 2440587.166667824d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(28800032L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        boolean boolean17 = dateTimeZone15.isStandardOffset(0L);
//        org.joda.time.Chronology chronology18 = zonedChronology11.withZone(dateTimeZone15);
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        int[] intArray25 = new int[] { (-28800000), (-10), (short) 1, (-97), 4 };
//        try {
//            zonedChronology11.validate(readablePartial19, intArray25);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(intArray25);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withMinutes(0);
        org.joda.time.Period period7 = period3.withSeconds((-100));
        org.joda.time.Period period9 = period3.plusHours(10);
        org.joda.time.Period period11 = period9.plusMonths((int) (short) 0);
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 0, periodType13, chronology14);
        org.joda.time.Period period17 = period15.withMinutes(0);
        org.joda.time.Period period19 = period15.withSeconds((-100));
        org.joda.time.Period period21 = period15.plusHours(10);
        org.joda.time.Period period23 = period21.plusMonths((int) (short) 0);
        org.joda.time.Period period24 = period9.plus((org.joda.time.ReadablePeriod) period23);
        org.joda.time.Period period26 = period9.multipliedBy((-100));
        org.joda.time.Minutes minutes27 = period26.toStandardMinutes();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(minutes27);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology11.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        long long17 = cachedDateTimeZone15.previousTransition((long) (-100));
//        int int19 = cachedDateTimeZone15.getStandardOffset(0L);
//        java.lang.String str20 = cachedDateTimeZone15.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-5756400001L) + "'", long17 == (-5756400001L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "America/Los_Angeles" + "'", str20.equals("America/Los_Angeles"));
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes4 = period3.toStandardMinutes();
        long long7 = iSOChronology1.add((org.joda.time.ReadablePeriod) period3, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.Duration duration8 = period3.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType10);
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8);
        long long13 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(minutes4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = period1.normalizedStandard(periodType2);
        org.joda.time.Period period5 = period3.withWeeks((-10));
        org.joda.time.Period period7 = period5.multipliedBy((int) (byte) 10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        long long6 = iSOChronology0.add((org.joda.time.ReadablePeriod) period2, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.Period period8 = period2.multipliedBy(0);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.Period period11 = period2.withFieldAdded(durationFieldType9, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(minutes3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) (-1), chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period(2440587L, (long) (short) 1, periodType2, chronology5);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        org.joda.time.ReadablePartial readablePartial4 = null;
        int[] intArray8 = new int[] { (byte) -1, (byte) 10 };
        try {
            int[] intArray10 = offsetDateTimeField3.addWrapPartial(readablePartial4, (int) (byte) 10, intArray8, (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "Millis");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("PST", (int) (short) 10);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("PST", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 0, periodType9, chronology10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.Period period13 = period11.minus(readablePeriod12);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period15 = period11.normalizedStandard(periodType14);
        int[] intArray16 = period11.getValues();
        try {
            int[] intArray18 = offsetDateTimeField3.addWrapField(readablePartial6, (int) (byte) 0, intArray16, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        long long6 = iSOChronology0.add((org.joda.time.ReadablePeriod) period2, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.Duration duration7 = period2.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period10 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant8, periodType9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant11);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(minutes3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(2, (-25200000), (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-25199998) + "'", int3 == (-25199998));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withMinutes(0);
        org.joda.time.Period period7 = period3.withSeconds((-100));
        org.joda.time.Period period9 = period3.plusHours(10);
        org.joda.time.Period period11 = period9.plusMonths((int) (short) 0);
        org.joda.time.Period period13 = period9.plusHours((int) (short) 100);
        org.joda.time.Period period15 = period9.plusMonths((int) (short) 1);
        org.joda.time.Minutes minutes16 = period9.toStandardMinutes();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(minutes16);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes4 = period3.toStandardMinutes();
        long long7 = iSOChronology1.add((org.joda.time.ReadablePeriod) period3, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.Duration duration8 = period3.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType10);
        try {
            org.joda.time.Period period12 = new org.joda.time.Period(908902361117222000L, periodType10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 252472878088");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(minutes4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType10);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.clockhourOfDay();
//        org.joda.time.DurationField durationField14 = zonedChronology11.millis();
//        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType16 = periodType15.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType18 = periodType16.getFieldType(0);
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField20 = new org.joda.time.field.ScaledDurationField(durationField14, durationFieldType18, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The scalar must not be 0 or 1");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertNotNull(durationFieldType18);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        long long6 = iSOChronology0.add((org.joda.time.ReadablePeriod) period2, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(minutes3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(1L, (long) (short) 1, periodType2);
        org.joda.time.Period period5 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period7 = period5.withSeconds((-1));
        int int8 = period7.getYears();
        boolean boolean9 = periodType2.equals((java.lang.Object) period7);
        int int10 = period7.getMinutes();
        org.joda.time.Period period12 = period7.minusSeconds(0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDayTime]", (java.lang.Number) 100.0d, (java.lang.Number) (-97), (java.lang.Number) 10.0d);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        java.lang.String str6 = illegalFieldValueException4.getFieldName();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PeriodType[YearMonthDayTime]" + "'", str5.equals("PeriodType[YearMonthDayTime]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PeriodType[YearMonthDayTime]" + "'", str6.equals("PeriodType[YearMonthDayTime]"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0d + "'", number7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-97) + "'", number8.equals((-97)));
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = zonedChronology11.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = zonedChronology11.era();
//        try {
//            long long23 = zonedChronology11.getDateTimeMillis((-1), (int) (short) 10, 0, (-97), (-1), (int) (byte) 10, 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -97 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationField durationField2 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withMinutes(0);
        org.joda.time.Period period7 = period3.withSeconds((-100));
        org.joda.time.Period period9 = period3.plusHours(10);
        org.joda.time.Period period11 = period9.plusMonths((int) (short) 0);
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 0, periodType13, chronology14);
        org.joda.time.Period period17 = period15.withMinutes(0);
        org.joda.time.Period period19 = period15.withSeconds((-100));
        org.joda.time.Period period21 = period15.plusHours(10);
        org.joda.time.Period period23 = period21.plusMonths((int) (short) 0);
        org.joda.time.Period period24 = period9.plus((org.joda.time.ReadablePeriod) period23);
        org.joda.time.Period period26 = period9.multipliedBy((-100));
        int int27 = period9.getMonths();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        boolean boolean5 = offsetDateTimeField3.isLeap((long) 0);
//        long long8 = offsetDateTimeField3.addWrapField((long) (short) 10, (-25200000));
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean14 = iSOChronology12.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.secondOfMinute();
//        java.util.TimeZone timeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.ReadableInstant readableInstant21 = null;
//        int int22 = dateTimeZone17.getOffset(readableInstant21);
//        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology12, dateTimeZone17);
//        org.joda.time.DurationField durationField24 = zonedChronology23.weekyears();
//        org.joda.time.DateTimeField dateTimeField25 = zonedChronology23.clockhourOfDay();
//        boolean boolean26 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 2440588L, (java.lang.Object) zonedChronology23);
//        org.joda.time.Period period28 = org.joda.time.Period.days((int) '4');
//        org.joda.time.Period period30 = period28.withWeeks((int) '#');
//        org.joda.time.Period period32 = period28.minusYears((int) (short) 100);
//        int[] intArray34 = zonedChronology23.get((org.joda.time.ReadablePeriod) period28, (-1L));
//        try {
//            int[] intArray36 = offsetDateTimeField3.addWrapField(readablePartial9, (int) 'a', intArray34, (-28800000));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pacific Standard Time" + "'", str20.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-25200000) + "'", int22 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(intArray34);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withMinutes(0);
        org.joda.time.Period period7 = period3.withSeconds((-100));
        org.joda.time.Period period9 = period3.plusHours(10);
        org.joda.time.Period period11 = period9.plusMonths((int) (short) 0);
        org.joda.time.Period period13 = period9.plusHours((int) (short) 100);
        org.joda.time.Period period15 = period13.plusMillis((int) (byte) -1);
        java.lang.Class<?> wildcardClass16 = period15.getClass();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        long long7 = offsetDateTimeField3.roundFloor((long) (short) 100);
        java.util.Locale locale10 = null;
        try {
            long long11 = offsetDateTimeField3.set((long) ' ', "PeriodType[YearDay]", locale10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PeriodType[YearDay]\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.lang.String str4 = iSOChronology0.toString();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getShortName((long) 0, locale11);
//        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.hourOfDay();
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField16, (int) (short) 1, 1, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for hourOfDay must be in the range [1,-1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long28 = durationField12.subtract(100L, 0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.lang.String str4 = iSOChronology0.toString();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getShortName((long) 0, locale11);
//        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField20 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType18, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
//        org.joda.time.Period period10 = new org.joda.time.Period((-10), (int) (short) -1, (-10), (int) (short) 0);
//        org.joda.time.Days days11 = period10.toStandardDays();
//        boolean boolean12 = gregorianChronology4.equals((java.lang.Object) period10);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        try {
//            int[] intArray15 = gregorianChronology4.get(readablePartial13, (long) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(days11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withMinutes(0);
        org.joda.time.Period period7 = period3.withSeconds((-100));
        org.joda.time.Period period9 = period3.plusHours(10);
        org.joda.time.Period period11 = period9.plusMonths((int) (short) 0);
        org.joda.time.Period period13 = period9.plusHours((int) (short) 100);
        org.joda.time.Period period15 = period9.plusSeconds(0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) (-1), chronology2);
        org.joda.time.Period period5 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period7 = period5.withWeeks((int) '#');
        org.joda.time.Period period9 = period5.minusYears((int) (short) 100);
        org.joda.time.PeriodType periodType10 = period5.getPeriodType();
        org.joda.time.Period period11 = period3.normalizedStandard(periodType10);
        org.joda.time.Period period13 = period3.withMinutes((-1));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.Chronology chronology0 = null;
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) (-10));
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
        long long8 = dateTimeZone2.getMillisKeepLocal(dateTimeZone6, 28800000L);
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) '4', 0, (int) (short) 0, 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfHalfday();
        try {
            long long6 = iSOChronology0.getDateTimeMillis((-10), 0, (-10), (-25199998));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25199998 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Period period5 = period3.minus(readablePeriod4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period7 = period3.normalizedStandard(periodType6);
        int[] intArray8 = period3.getValues();
        org.joda.time.Period period10 = period3.minusYears((int) (byte) 100);
        org.joda.time.Period period12 = period10.multipliedBy((int) (short) 1);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Period period5 = period3.minus(readablePeriod4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period7 = period3.normalizedStandard(periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withMonthsRemoved();
        java.lang.String str9 = periodType8.getName();
        org.joda.time.PeriodType periodType10 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
        org.joda.time.PeriodType periodType11 = periodType8.withMonthsRemoved();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "YearDay" + "'", str9.equals("YearDay"));
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-210866846400000L));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        long long6 = iSOChronology0.add((org.joda.time.ReadablePeriod) period2, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.Period period8 = period2.multipliedBy(0);
        org.joda.time.Period period10 = period2.minusMinutes(0);
        org.joda.time.PeriodType periodType11 = period2.getPeriodType();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(minutes3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        long long7 = dateTimeZone1.adjustOffset(2678400000L, true);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2678400000L + "'", long7 == 2678400000L);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long27 = scaledDurationField25.getMillis((-25200000));
//        long long29 = scaledDurationField25.getValueAsLong((-210866846400000L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28378000) + "'", int10 == (-28378000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 795235190400000000L + "'", long27 == 795235190400000000L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 6682L + "'", long29 == 6682L);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        boolean boolean5 = offsetDateTimeField3.isLeap((long) 0);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 10, (-25200000));
        try {
            long long11 = offsetDateTimeField3.set(908902361117222000L, "YearDay");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"YearDay\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        long long6 = iSOChronology0.add((org.joda.time.ReadablePeriod) period2, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray15 = new int[] { (-10), (short) -1, 'a', (short) 10, 10, (byte) 0 };
        try {
            iSOChronology0.validate(readablePartial8, intArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(minutes3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDayTime]", (java.lang.Number) 100.0d, (java.lang.Number) (-97), (java.lang.Number) 10.0d);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number9 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType10 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-97) + "'", number5.equals((-97)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-97) + "'", number8.equals((-97)));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-97) + "'", number9.equals((-97)));
        org.junit.Assert.assertNull(durationFieldType10);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.035 ()");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalInstantExce...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
//        org.joda.time.Period period10 = new org.joda.time.Period((-10), (int) (short) -1, (-10), (int) (short) 0);
//        org.joda.time.Days days11 = period10.toStandardDays();
//        boolean boolean12 = gregorianChronology4.equals((java.lang.Object) period10);
//        try {
//            long long20 = gregorianChronology4.getDateTimeMillis((int) (byte) -1, 16, 4, (int) (short) 100, (int) 'a', 0, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(days11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.PeriodType periodType3 = period2.getPeriodType();
        org.joda.time.MutablePeriod mutablePeriod4 = period2.toMutablePeriod();
        org.joda.time.format.PeriodFormatter periodFormatter5 = null;
        java.lang.String str6 = period2.toString(periodFormatter5);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0S" + "'", str6.equals("PT0S"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        long long7 = offsetDateTimeField3.roundCeiling((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = offsetDateTimeField3.getMaximumValue(readablePartial8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial10, locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2678400000L + "'", long7 == 2678400000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean3 = iSOChronology1.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        org.joda.time.ReadableInstant readableInstant10 = null;
//        int int11 = dateTimeZone6.getOffset(readableInstant10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone6);
//        org.joda.time.DurationField durationField13 = zonedChronology12.weekyears();
//        org.joda.time.DurationField durationField14 = zonedChronology12.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology12.getZone();
//        org.joda.time.DurationField durationField16 = zonedChronology12.days();
//        org.joda.time.DurationField durationField17 = zonedChronology12.minutes();
//        org.joda.time.DurationField durationField18 = org.joda.time.field.MillisDurationField.INSTANCE;
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField19 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField17, durationField18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28378000) + "'", int11 == (-28378000));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(durationField18);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        boolean boolean5 = offsetDateTimeField3.isLeap((long) 0);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 10, (-25200000));
        long long10 = offsetDateTimeField3.roundHalfFloor((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType11, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-210866760000000L));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]", (-28800000), (int) (byte) 0, 10, '#', (-28378000), 5, (int) (short) 100, false, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
//        org.joda.time.Period period10 = new org.joda.time.Period((-10), (int) (short) -1, (-10), (int) (short) 0);
//        org.joda.time.Days days11 = period10.toStandardDays();
//        boolean boolean12 = gregorianChronology4.equals((java.lang.Object) period10);
//        try {
//            long long17 = gregorianChronology4.getDateTimeMillis(100, (int) ' ', (-25199998), (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(days11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        long long6 = iSOChronology0.add((org.joda.time.ReadablePeriod) period2, (long) (byte) 100, (int) (byte) 100);
        long long10 = iSOChronology0.add(0L, (long) '4', (-28800000));
        try {
            long long15 = iSOChronology0.getDateTimeMillis((int) (byte) -1, (int) '#', (-25199998), 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(minutes3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1497600000L) + "'", long10 == (-1497600000L));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) '#', (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean3 = iSOChronology1.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        org.joda.time.ReadableInstant readableInstant10 = null;
//        int int11 = dateTimeZone6.getOffset(readableInstant10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone6);
//        org.joda.time.DurationField durationField13 = zonedChronology12.weekyears();
//        org.joda.time.DurationField durationField14 = zonedChronology12.weekyears();
//        long long17 = durationField14.subtract((-1L), (int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean20 = iSOChronology18.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology18.secondOfMinute();
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone23.getName((long) (byte) 0, locale25);
//        org.joda.time.ReadableInstant readableInstant27 = null;
//        int int28 = dateTimeZone23.getOffset(readableInstant27);
//        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology18, dateTimeZone23);
//        org.joda.time.DurationField durationField30 = zonedChronology29.weekyears();
//        org.joda.time.Period period32 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType33 = null;
//        org.joda.time.Period period34 = period32.normalizedStandard(periodType33);
//        org.joda.time.Period period36 = period32.minusSeconds(0);
//        boolean boolean37 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField30, (java.lang.Object) period32);
//        org.joda.time.PeriodType periodType38 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType39 = periodType38.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField43 = new org.joda.time.field.ScaledDurationField(durationField30, durationFieldType41, (-1));
//        long long46 = scaledDurationField43.getDifferenceAsLong((long) '4', (long) (byte) 100);
//        long long49 = scaledDurationField43.getValueAsLong((long) 1, 0L);
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField50 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField14, (org.joda.time.DurationField) scaledDurationField43);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28378000) + "'", int11 == (-28378000));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1009411200001L) + "'", long17 == (-1009411200001L));
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pacific Standard Time" + "'", str26.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-28378000) + "'", int28 == (-28378000));
//        org.junit.Assert.assertNotNull(zonedChronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(period34);
//        org.junit.Assert.assertNotNull(period36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(periodType38);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(durationFieldType41);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "+00:00:00.004");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) -1);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean3 = iSOChronology1.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
//        java.lang.String str5 = iSOChronology1.toString();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName((long) (byte) 0, locale9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone7.getShortName((long) 0, locale12);
//        org.joda.time.Chronology chronology14 = iSOChronology1.withZone(dateTimeZone7);
//        try {
//            org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) provider0, (org.joda.time.Chronology) iSOChronology1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.ZoneInfoProvider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(provider0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pacific Standard Time" + "'", str10.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PST" + "'", str13.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology14);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-1497600000L));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 5, (java.lang.Number) 100.0d, (java.lang.Number) (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        java.lang.String str14 = dateTimeZone13.getID();
//        org.joda.time.Chronology chronology15 = zonedChronology11.withZone(dateTimeZone13);
//        org.joda.time.DurationField durationField16 = zonedChronology11.minutes();
//        try {
//            long long22 = zonedChronology11.getDateTimeMillis((long) '4', (-10), (int) 'a', (int) (byte) 10, (-28800000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "America/Los_Angeles" + "'", str14.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) (byte) 0, locale3);
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        int int6 = dateTimeZone1.getOffset(readableInstant5);
//        long long9 = dateTimeZone1.convertLocalToUTC((-10094112000L), false);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28800000) + "'", int6 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-10068912000L) + "'", long9 == (-10068912000L));
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        java.lang.String str14 = zonedChronology11.toString();
//        org.joda.time.DateTimeField dateTimeField15 = zonedChronology11.millisOfDay();
//        try {
//            org.joda.time.Period period16 = new org.joda.time.Period((java.lang.Object) dateTimeField15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        java.lang.Number number28 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number28);
//        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType23, (long) 100);
//        int int33 = preciseDurationField31.getValue((long) (byte) 10);
//        boolean boolean34 = preciseDurationField31.isSupported();
//        long long35 = preciseDurationField31.getUnitMillis();
//        long long38 = preciseDurationField31.getMillis(0L, 0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long28 = scaledDurationField25.getDifferenceAsLong((long) '4', (long) (byte) 100);
//        long long30 = scaledDurationField25.getValueAsLong((-908902361117221990L));
//        long long33 = scaledDurationField25.getValueAsLong((-4L), 2678400000L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28801969L + "'", long30 == 28801969L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDayTime]", (java.lang.Number) 100.0d, (java.lang.Number) (-97), (java.lang.Number) 10.0d);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        java.lang.String str6 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PeriodType[YearMonthDayTime]" + "'", str5.equals("PeriodType[YearMonthDayTime]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period11 = new org.joda.time.Period(1L, (long) (short) 1, periodType10);
        org.joda.time.Period period13 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period15 = period13.withSeconds((-1));
        int int16 = period15.getYears();
        boolean boolean17 = periodType10.equals((java.lang.Object) period15);
        org.joda.time.PeriodType periodType18 = periodType10.withSecondsRemoved();
        try {
            org.joda.time.Period period19 = new org.joda.time.Period(10, 0, 0, (-97), (int) (short) 100, 10, (int) (short) -1, (-1), periodType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(periodType18);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (-1), (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((-1L), periodType1, chronology2);
        org.joda.time.Period period5 = period3.minusMonths((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationFrom(readableInstant6);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.Period period21 = period14.minusMinutes(16);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(period21);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withMinutes(0);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.millis();
        java.lang.String str7 = periodType6.getName();
        org.joda.time.PeriodType periodType8 = periodType6.withWeeksRemoved();
        org.joda.time.Period period9 = period3.normalizedStandard(periodType8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Millis" + "'", str7.equals("Millis"));
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("DurationField[years]", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'ISOChronology[UTC]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        java.lang.String str14 = zonedChronology11.toString();
//        org.joda.time.DateTimeField dateTimeField15 = zonedChronology11.millisOfDay();
//        try {
//            long long21 = zonedChronology11.getDateTimeMillis((long) 100, (int) (byte) 1, (int) (byte) 1, (-28800000), (-28800000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period2 = new org.joda.time.Period(0L, (org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Period period5 = period3.minus(readablePeriod4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period7 = period3.normalizedStandard(periodType6);
        org.joda.time.Period period9 = period3.multipliedBy((-1));
        int int10 = period9.getYears();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology11.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        org.joda.time.LocalDateTime localDateTime16 = null;
//        try {
//            boolean boolean17 = cachedDateTimeZone15.isLocalDateTimeGap(localDateTime16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        boolean boolean5 = offsetDateTimeField3.isLeap((long) 0);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 10, (-25200000));
        java.lang.String str10 = offsetDateTimeField3.getAsShortText((long) (byte) -1);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = offsetDateTimeField3.getAsText(readablePartial11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "16" + "'", str10.equals("16"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        long long6 = iSOChronology0.add((org.joda.time.ReadablePeriod) period2, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.year();
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 0, periodType9, chronology10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.Period period13 = period11.minus(readablePeriod12);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period15 = period11.normalizedStandard(periodType14);
        boolean boolean16 = iSOChronology0.equals((java.lang.Object) period15);
        java.lang.String str17 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(minutes3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period3 = period1.withWeeks((int) '#');
        org.joda.time.Period period5 = period1.minusYears((int) (short) 100);
        org.joda.time.Period period7 = period1.minusMinutes((-28378000));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        boolean boolean5 = offsetDateTimeField3.isLeap((long) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField7 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withMinutes(0);
        org.joda.time.Period period7 = period3.withSeconds((-100));
        org.joda.time.Period period9 = period3.plusHours(10);
        org.joda.time.Period period11 = period9.plusMonths((int) (short) 0);
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 0, periodType13, chronology14);
        org.joda.time.Period period17 = period15.withMinutes(0);
        org.joda.time.Period period19 = period15.withSeconds((-100));
        org.joda.time.Period period21 = period15.plusHours(10);
        org.joda.time.Period period23 = period21.plusMonths((int) (short) 0);
        org.joda.time.Period period24 = period9.plus((org.joda.time.ReadablePeriod) period23);
        org.joda.time.Period period26 = period9.withMonths(10);
        org.joda.time.MutablePeriod mutablePeriod27 = period26.toMutablePeriod();
        try {
            int int29 = mutablePeriod27.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(mutablePeriod27);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        long long6 = iSOChronology0.add((org.joda.time.ReadablePeriod) period2, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.Period period8 = period2.withDays((-1));
        org.joda.time.Period period10 = period2.minusSeconds((int) (byte) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(minutes3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = period1.normalizedStandard(periodType2);
        org.joda.time.Period period4 = period1.negated();
        org.joda.time.Period period6 = period1.minusSeconds((-100));
        org.joda.time.Period period8 = period6.minusMonths((int) (byte) 0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, periodType2, chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.Period period6 = period4.minus(readablePeriod5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period8 = period4.normalizedStandard(periodType7);
        org.joda.time.PeriodType periodType9 = periodType7.withMonthsRemoved();
        java.lang.String str10 = periodType9.getName();
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) (-1), chronology15);
        org.joda.time.Period period17 = new org.joda.time.Period((-1L), (long) (byte) 0, chronology15);
        org.joda.time.Period period18 = new org.joda.time.Period(obj0, periodType9, chronology15);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "YearDay" + "'", str10.equals("YearDay"));
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        long long5 = offsetDateTimeField3.roundFloor((long) (short) -1);
        int int7 = offsetDateTimeField3.getLeapAmount(0L);
        java.util.Locale locale10 = null;
        try {
            long long11 = offsetDateTimeField3.set((long) (-1), "100.0", locale10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"100.0\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2678400000L) + "'", long5 == (-2678400000L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        boolean boolean17 = dateTimeZone15.isStandardOffset(0L);
//        org.joda.time.Chronology chronology18 = zonedChronology11.withZone(dateTimeZone15);
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        try {
//            long long21 = zonedChronology11.set(readablePartial19, (long) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(chronology18);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("PST", (int) (short) 10);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover(8, ' ', (int) ' ', (-25199998), (int) (short) 0, false, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        java.lang.String str14 = dateTimeZone13.getID();
//        org.joda.time.Chronology chronology15 = zonedChronology11.withZone(dateTimeZone13);
//        org.joda.time.DurationField durationField16 = zonedChronology11.hours();
//        java.util.TimeZone timeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        java.lang.String str20 = dateTimeZone18.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.Chronology chronology22 = zonedChronology11.withZone(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology11.getZone();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "America/Los_Angeles" + "'", str14.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period3 = period1.withWeeks((int) '#');
        int[] intArray4 = period1.getValues();
        org.joda.time.Period period6 = period1.multipliedBy((-25199998));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType1 = periodType0.withDaysRemoved();
        org.joda.time.DurationFieldType durationFieldType3 = periodType1.getFieldType(0);
        org.joda.time.PeriodType periodType4 = periodType1.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(durationFieldType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
        try {
            long long8 = iSOChronology0.getDateTimeMillis((int) (short) -1, (-10), (int) (short) 100, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(28799999L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Period period5 = period3.minus(readablePeriod4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period7 = period3.normalizedStandard(periodType6);
        org.joda.time.Period period9 = period3.multipliedBy((-1));
        try {
            org.joda.time.Period period10 = new org.joda.time.Period((java.lang.Object) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) -1, (java.lang.Number) 100L, (java.lang.Number) (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.Period period1 = org.joda.time.Period.months(1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int7 = offsetDateTimeField3.getDifference((long) 4, (long) '#');
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray12 = new int[] { (byte) 100, 4, ' ' };
        int int13 = offsetDateTimeField3.getMinimumValue(readablePartial8, intArray12);
        long long16 = offsetDateTimeField3.add(2440588L, (int) (byte) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2440588L + "'", long16 == 2440588L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.Period period2 = new org.joda.time.Period((-1L), (long) (-97));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.lang.String str4 = iSOChronology0.toString();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getShortName((long) 0, locale11);
//        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType15, 4, (int) (short) 100, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long28 = scaledDurationField25.getDifferenceAsLong((long) '4', (long) (byte) 100);
//        long long31 = scaledDurationField25.subtract((long) 0, (long) (-28800000));
//        org.joda.time.DurationField durationField32 = scaledDurationField25.getWrappedField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-908840217600422000L) + "'", long31 == (-908840217600422000L));
//        org.junit.Assert.assertNotNull(durationField32);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
        try {
            long long11 = iSOChronology0.getDateTimeMillis((int) (byte) 100, (int) (byte) 1, (int) (byte) 1, 0, 0, 0, (-25199998));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25199998 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((-10));
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) (byte) 0, locale3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone1.getShortName((long) 5, locale6);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "Pacific Standard Time");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "", "+00:00:00.004");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getShortName(locale9, "DurationField[years]", "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.035 ()");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-28800000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28800000 + "'", int1 == 28800000);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
//        java.lang.String str5 = periodType4.getName();
//        org.joda.time.PeriodType periodType6 = periodType4.withWeeksRemoved();
//        org.joda.time.PeriodType periodType7 = periodType6.withHoursRemoved();
//        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType6);
//        boolean boolean10 = periodType6.equals((java.lang.Object) 10L);
//        org.joda.time.Period period11 = period1.normalizedStandard(periodType6);
//        org.joda.time.PeriodType periodType13 = null;
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.Period period15 = new org.joda.time.Period((-1L), periodType13, chronology14);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Period period18 = org.joda.time.Period.days((int) (byte) 0);
//        org.joda.time.Minutes minutes19 = period18.toStandardMinutes();
//        long long22 = iSOChronology16.add((org.joda.time.ReadablePeriod) period18, (long) (byte) 100, (int) (byte) 100);
//        org.joda.time.Period period24 = period18.withDays((-1));
//        org.joda.time.Period period25 = period15.plus((org.joda.time.ReadablePeriod) period18);
//        java.lang.Object obj26 = null;
//        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period28 = new org.joda.time.Period(obj26, periodType27);
//        org.joda.time.Period period29 = period15.normalizedStandard(periodType27);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean32 = iSOChronology30.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology30.secondOfMinute();
//        java.util.TimeZone timeZone34 = null;
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = dateTimeZone35.getName((long) (byte) 0, locale37);
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        int int40 = dateTimeZone35.getOffset(readableInstant39);
//        org.joda.time.chrono.ZonedChronology zonedChronology41 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology30, dateTimeZone35);
//        org.joda.time.DurationField durationField42 = zonedChronology41.weekyears();
//        org.joda.time.Period period44 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType45 = null;
//        org.joda.time.Period period46 = period44.normalizedStandard(periodType45);
//        org.joda.time.Period period48 = period44.minusSeconds(0);
//        boolean boolean49 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField42, (java.lang.Object) period44);
//        org.joda.time.PeriodType periodType50 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType51 = periodType50.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType53 = periodType51.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField55 = new org.joda.time.field.ScaledDurationField(durationField42, durationFieldType53, (-1));
//        java.lang.Number number58 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException59 = new org.joda.time.IllegalFieldValueException(durationFieldType53, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number58);
//        org.joda.time.field.PreciseDurationField preciseDurationField61 = new org.joda.time.field.PreciseDurationField(durationFieldType53, (long) 100);
//        boolean boolean62 = periodType27.isSupported(durationFieldType53);
//        try {
//            org.joda.time.Period period64 = period11.withField(durationFieldType53, 4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(period1);
//        org.junit.Assert.assertNotNull(periodType4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Millis" + "'", str5.equals("Millis"));
//        org.junit.Assert.assertNotNull(periodType6);
//        org.junit.Assert.assertNotNull(periodType7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(period11);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertNotNull(minutes19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period25);
//        org.junit.Assert.assertNotNull(periodType27);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Pacific Standard Time" + "'", str38.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-28800000) + "'", int40 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertNotNull(period46);
//        org.junit.Assert.assertNotNull(period48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(periodType50);
//        org.junit.Assert.assertNotNull(periodType51);
//        org.junit.Assert.assertNotNull(durationFieldType53);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-10));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withMinutes(0);
        org.joda.time.Period period7 = period3.withSeconds((-100));
        int int8 = period3.getMillis();
        int int9 = period3.size();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getShortName((long) 0, locale11);
//        java.lang.String str14 = dateTimeZone6.getName(0L);
//        java.lang.String str15 = dateTimeZone6.getID();
//        long long18 = dateTimeZone6.adjustOffset((long) (-1), true);
//        org.joda.time.Chronology chronology19 = gregorianChronology4.withZone(dateTimeZone6);
//        java.util.TimeZone timeZone20 = dateTimeZone6.toTimeZone();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone6.getName((long) 100, locale22);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Pacific Standard Time" + "'", str14.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "America/Los_Angeles" + "'", str15.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Pacific Standard Time" + "'", str23.equals("Pacific Standard Time"));
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDay();
        java.lang.String str3 = periodType2.toString();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int5 = period4.getMonths();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[YearDay]" + "'", str3.equals("PeriodType[YearDay]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        int int7 = offsetDateTimeField3.getLeapAmount(100L);
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField3.getAsShortText((long) (short) 100, locale9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "5" + "'", str10.equals("5"));
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) (byte) 0, locale3);
//        boolean boolean6 = dateTimeZone1.isStandardOffset((long) ' ');
//        java.lang.String str7 = dateTimeZone1.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "America/Los_Angeles" + "'", str7.equals("America/Los_Angeles"));
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-10068912000L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440471L + "'", long1 == 2440471L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-100L) + "'", long2 == (-100L));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((-1L), periodType1, chronology2);
        org.joda.time.Period period5 = period3.minusMonths((int) (byte) 100);
        org.joda.time.Period period7 = period5.withWeeks((-28800000));
        int int8 = period7.getMinutes();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Period period5 = period3.minus(readablePeriod4);
        int int6 = period5.getYears();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 4);
        long long12 = offsetDateTimeField10.roundHalfCeiling((-1009411200001L));
        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) int6, (java.lang.Object) long12);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1009843200000L) + "'", long12 == (-1009843200000L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        long long6 = iSOChronology0.add((org.joda.time.ReadablePeriod) period2, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.Duration duration7 = period2.toStandardDuration();
        long long8 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration7);
        long long9 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration7);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType12 = periodType11.withDaysRemoved();
        org.joda.time.PeriodType periodType13 = org.joda.time.DateTimeUtils.getPeriodType(periodType12);
        org.joda.time.Period period14 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant10, periodType13);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(minutes3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        boolean boolean5 = offsetDateTimeField3.isLeap((long) 0);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 10, (-25200000));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = offsetDateTimeField3.getAsShortText(readablePartial11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean3 = iSOChronology1.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        org.joda.time.ReadableInstant readableInstant10 = null;
//        int int11 = dateTimeZone6.getOffset(readableInstant10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone6);
//        org.joda.time.DurationField durationField13 = zonedChronology12.weekyears();
//        org.joda.time.DateTimeField dateTimeField14 = zonedChronology12.clockhourOfDay();
//        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 2440588L, (java.lang.Object) zonedChronology12);
//        java.util.TimeZone timeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone17.getShortName((long) 0, locale22);
//        java.lang.String str25 = dateTimeZone17.getName(0L);
//        java.lang.String str26 = dateTimeZone17.getID();
//        long long29 = dateTimeZone17.adjustOffset((long) (-1), true);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone17);
//        java.util.TimeZone timeZone31 = dateTimeZone17.toTimeZone();
//        org.joda.time.Chronology chronology32 = zonedChronology12.withZone(dateTimeZone17);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pacific Standard Time" + "'", str20.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PST" + "'", str23.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Pacific Standard Time" + "'", str25.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "America/Los_Angeles" + "'", str26.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNotNull(chronology32);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(100);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) (byte) 0, locale3);
//        boolean boolean6 = dateTimeZone1.isStandardOffset((long) ' ');
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone1.getName(28799999L, locale8);
//        java.lang.String str11 = dateTimeZone1.getShortName((long) (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PST" + "'", str11.equals("PST"));
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        try {
//            long long21 = zonedChronology11.getDateTimeMillis((int) ' ', (-28378000), (int) (byte) 0, 0, (int) '#', (int) '4', 8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28378000 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-28378000), (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-113512000L) + "'", long2 == (-113512000L));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.lang.String str4 = iSOChronology0.toString();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        org.joda.time.Chronology chronology10 = iSOChronology0.withZone(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.Period period1 = org.joda.time.Period.days(1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("org.joda.time.IllegalFieldValueException: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        long long6 = dateTimeZone1.convertLocalToUTC((long) ' ', false);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone1.getShortName((-210866846400000L), locale8);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28800032L + "'", long6 == 28800032L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-07:52:58" + "'", str9.equals("-07:52:58"));
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "Pacific Standard Time");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.millis();
        java.lang.String str2 = periodType1.getName();
        org.joda.time.PeriodType periodType3 = periodType1.withWeeksRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(0L, periodType3);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Millis" + "'", str2.equals("Millis"));
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        boolean boolean17 = dateTimeZone15.isStandardOffset(0L);
//        org.joda.time.Chronology chronology18 = zonedChronology11.withZone(dateTimeZone15);
//        org.joda.time.DurationField durationField19 = zonedChronology11.centuries();
//        org.joda.time.DateTimeField dateTimeField20 = zonedChronology11.secondOfDay();
//        org.joda.time.Chronology chronology21 = zonedChronology11.withUTC();
//        org.joda.time.ReadablePartial readablePartial22 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 4);
//        java.lang.String str27 = offsetDateTimeField26.getName();
//        org.joda.time.ReadablePartial readablePartial28 = null;
//        int[] intArray32 = new int[] { (byte) 10, (-100), (-25200000) };
//        int int33 = offsetDateTimeField26.getMaximumValue(readablePartial28, intArray32);
//        try {
//            zonedChronology11.validate(readablePartial22, intArray32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "monthOfYear" + "'", str27.equals("monthOfYear"));
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 16 + "'", int33 == 16);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.Period period1 = org.joda.time.Period.months(4);
        org.joda.time.Period period3 = period1.plusYears((-97));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        java.lang.Number number28 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number28);
//        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType23, (long) 100);
//        long long34 = preciseDurationField31.getValueAsLong((-1009411200001L), 28799999L);
//        long long37 = preciseDurationField31.getValueAsLong(0L, (long) 8);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-10094112000L) + "'", long34 == (-10094112000L));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) (-1), chronology2);
        org.joda.time.Period period5 = period3.withSeconds((int) '#');
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        long long5 = offsetDateTimeField3.roundFloor((long) (short) -1);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 0, periodType9, chronology10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.Period period13 = period11.minus(readablePeriod12);
        org.joda.time.Period period15 = period13.plusDays((int) (byte) -1);
        int[] intArray16 = period15.getValues();
        try {
            int[] intArray18 = offsetDateTimeField3.addWrapPartial(readablePartial6, (-100), intArray16, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2678400000L) + "'", long5 == (-2678400000L));
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withMinutes(0);
        org.joda.time.Period period7 = period3.withSeconds((-100));
        org.joda.time.Period period9 = period3.plusHours(10);
        org.joda.time.Period period11 = period9.plusMonths((int) (short) 0);
        org.joda.time.Period period13 = period9.plusHours((int) (short) 100);
        org.joda.time.Period period15 = period9.plusMonths((int) (short) 1);
        org.joda.time.Duration duration16 = period9.toStandardDuration();
        org.joda.time.Period period17 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.Period period19 = period17.minusMillis(0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(2);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withMinutes(0);
        org.joda.time.Period period7 = period3.withSeconds((-100));
        org.joda.time.Period period9 = period3.plusHours(10);
        org.joda.time.Period period11 = period9.plusMonths((int) (short) 0);
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 0, periodType13, chronology14);
        org.joda.time.Period period17 = period15.withMinutes(0);
        org.joda.time.Period period19 = period15.withSeconds((-100));
        org.joda.time.Period period21 = period15.plusHours(10);
        org.joda.time.Period period23 = period21.plusMonths((int) (short) 0);
        org.joda.time.Period period24 = period9.plus((org.joda.time.ReadablePeriod) period23);
        org.joda.time.Period period26 = period9.withMonths(10);
        org.joda.time.MutablePeriod mutablePeriod27 = period26.toMutablePeriod();
        java.lang.String str28 = mutablePeriod27.toString();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(mutablePeriod27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "P10MT10H" + "'", str28.equals("P10MT10H"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.format.PeriodFormatter periodFormatter3 = null;
        java.lang.String str4 = period2.toString(periodFormatter3);
        org.joda.time.Period period6 = period2.plusDays(8);
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, periodType8, chronology9);
        org.joda.time.Period period12 = period10.withMinutes(0);
        org.joda.time.Period period14 = period10.withSeconds((-100));
        org.joda.time.Period period16 = period10.plusHours(10);
        org.joda.time.Period period18 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period20 = period18.withWeeks((int) '#');
        org.joda.time.Period period22 = period18.minusYears((int) (short) 100);
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.Period period24 = period22.normalizedStandard(periodType23);
        org.joda.time.MutablePeriod mutablePeriod25 = period22.toMutablePeriod();
        org.joda.time.Period period26 = period10.minus((org.joda.time.ReadablePeriod) period22);
        org.joda.time.Period period27 = period2.plus((org.joda.time.ReadablePeriod) period26);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0S" + "'", str4.equals("PT0S"));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(mutablePeriod25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        boolean boolean17 = dateTimeZone15.isStandardOffset(0L);
//        org.joda.time.Chronology chronology18 = zonedChronology11.withZone(dateTimeZone15);
//        org.joda.time.DurationField durationField19 = zonedChronology11.centuries();
//        org.joda.time.DateTimeField dateTimeField20 = zonedChronology11.dayOfYear();
//        org.joda.time.ReadablePartial readablePartial21 = null;
//        org.joda.time.PeriodType periodType23 = null;
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) 0, periodType23, chronology24);
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.Period period27 = period25.minus(readablePeriod26);
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.Period period29 = period25.normalizedStandard(periodType28);
//        int[] intArray30 = period25.getValues();
//        try {
//            zonedChronology11.validate(readablePartial21, intArray30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(intArray30);
//    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long28 = scaledDurationField25.getDifferenceAsLong((long) '4', (long) (byte) 100);
//        long long30 = scaledDurationField25.getValueAsLong((-908902361117221990L));
//        java.lang.Object obj31 = null;
//        boolean boolean32 = scaledDurationField25.equals(obj31);
//        int int33 = scaledDurationField25.getScalar();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28801969L + "'", long30 == 28801969L);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.weekOfWeekyear();
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 0, periodType15, chronology16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.Period period19 = period17.minus(readablePeriod18);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.Period period21 = period17.normalizedStandard(periodType20);
//        long long24 = zonedChronology11.add((org.joda.time.ReadablePeriod) period21, 28800000L, (int) (short) 1);
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.Period period27 = org.joda.time.Period.days((int) '4');
//        org.joda.time.Period period29 = period27.withWeeks((int) '#');
//        int[] intArray30 = period27.getValues();
//        try {
//            zonedChronology11.validate(readablePartial25, intArray30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28800000L + "'", long24 == 28800000L);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(intArray30);
//    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        java.lang.String str14 = zonedChronology11.toString();
//        org.joda.time.DateTimeField dateTimeField15 = zonedChronology11.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology11.getZone();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) (-1), chronology2);
        org.joda.time.Period period5 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period7 = period5.withWeeks((int) '#');
        org.joda.time.Period period9 = period5.minusYears((int) (short) 100);
        org.joda.time.PeriodType periodType10 = period5.getPeriodType();
        org.joda.time.Period period11 = period3.normalizedStandard(periodType10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period11.toDurationTo(readableInstant12);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(duration13);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Period period5 = period3.minus(readablePeriod4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period7 = period3.normalizedStandard(periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withMonthsRemoved();
        org.joda.time.PeriodType periodType9 = periodType8.withYearsRemoved();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean6 = iSOChronology4.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.secondOfMinute();
//        java.lang.String str8 = iSOChronology4.toString();
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone10.getName((long) (byte) 0, locale12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone10.getShortName((long) 0, locale15);
//        org.joda.time.Chronology chronology17 = iSOChronology4.withZone(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology4.weekyearOfCentury();
//        try {
//            org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) iSOChronology0, (org.joda.time.Chronology) iSOChronology4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[UTC]" + "'", str8.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PST" + "'", str16.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.minuteOfHour();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.lang.String str9 = dateTimeZone7.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        long long15 = gregorianChronology10.getDateTimeMillis((-28800000), (int) (byte) 10, 1, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology10.getZone();
//        boolean boolean17 = gregorianChronology4.equals((java.lang.Object) gregorianChronology10);
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology4.monthOfYear();
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, 4);
//        boolean boolean25 = offsetDateTimeField23.isLeap((long) 0);
//        long long28 = offsetDateTimeField23.addWrapField((long) (short) 10, (-25200000));
//        java.lang.String str30 = offsetDateTimeField23.getAsShortText((long) (byte) -1);
//        org.joda.time.ReadablePartial readablePartial31 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean35 = iSOChronology33.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology33.secondOfMinute();
//        java.util.TimeZone timeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forTimeZone(timeZone37);
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dateTimeZone38.getName((long) (byte) 0, locale40);
//        org.joda.time.ReadableInstant readableInstant42 = null;
//        int int43 = dateTimeZone38.getOffset(readableInstant42);
//        org.joda.time.chrono.ZonedChronology zonedChronology44 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology33, dateTimeZone38);
//        org.joda.time.DurationField durationField45 = zonedChronology44.weekyears();
//        org.joda.time.DateTimeField dateTimeField46 = zonedChronology44.clockhourOfDay();
//        boolean boolean47 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 2440588L, (java.lang.Object) zonedChronology44);
//        org.joda.time.Period period49 = org.joda.time.Period.days((int) '4');
//        org.joda.time.Period period51 = period49.withWeeks((int) '#');
//        org.joda.time.Period period53 = period49.minusYears((int) (short) 100);
//        int[] intArray55 = zonedChronology44.get((org.joda.time.ReadablePeriod) period49, (-1L));
//        int int56 = offsetDateTimeField23.getMaximumValue(readablePartial31, intArray55);
//        try {
//            gregorianChronology4.validate(readablePartial19, intArray55);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-908902361117221990L) + "'", long15 == (-908902361117221990L));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "16" + "'", str30.equals("16"));
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Pacific Standard Time" + "'", str41.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-28800000) + "'", int43 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology44);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(period49);
//        org.junit.Assert.assertNotNull(period51);
//        org.junit.Assert.assertNotNull(period53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 16 + "'", int56 == 16);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        long long6 = iSOChronology0.add((org.joda.time.ReadablePeriod) period2, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.year();
        org.joda.time.DurationField durationField8 = iSOChronology0.seconds();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(minutes3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = period1.normalizedStandard(periodType2);
        org.joda.time.Period period4 = period1.negated();
        org.joda.time.Period period6 = period1.minusSeconds((-100));
        org.joda.time.Period period8 = period6.minusWeeks(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getShortName((long) 0, locale11);
//        java.lang.String str14 = dateTimeZone6.getName(0L);
//        java.lang.String str15 = dateTimeZone6.getID();
//        long long18 = dateTimeZone6.adjustOffset((long) (-1), true);
//        org.joda.time.Chronology chronology19 = gregorianChronology4.withZone(dateTimeZone6);
//        java.util.TimeZone timeZone20 = dateTimeZone6.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Pacific Standard Time" + "'", str14.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "America/Los_Angeles" + "'", str15.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        java.lang.Number number28 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number28);
//        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType23, (long) 100);
//        int int33 = preciseDurationField31.getValue((long) (byte) 10);
//        long long36 = preciseDurationField31.getDifferenceAsLong((-1009843200000L), 1L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-10098432000L) + "'", long36 == (-10098432000L));
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Period period5 = period3.minus(readablePeriod4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period7 = period3.normalizedStandard(periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withMonthsRemoved();
        java.lang.String str9 = periodType8.getName();
        org.joda.time.PeriodType periodType10 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
        org.joda.time.PeriodType periodType11 = periodType8.withMinutesRemoved();
        org.joda.time.PeriodType periodType12 = periodType8.withDaysRemoved();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "YearDay" + "'", str9.equals("YearDay"));
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        boolean boolean17 = dateTimeZone15.isStandardOffset(0L);
//        org.joda.time.Chronology chronology18 = zonedChronology11.withZone(dateTimeZone15);
//        org.joda.time.DurationField durationField19 = zonedChronology11.centuries();
//        org.joda.time.DateTimeField dateTimeField20 = zonedChronology11.secondOfDay();
//        org.joda.time.Chronology chronology21 = zonedChronology11.withUTC();
//        org.joda.time.DateTimeField dateTimeField22 = zonedChronology11.minuteOfHour();
//        try {
//            long long27 = zonedChronology11.getDateTimeMillis((int) (short) 0, (int) (byte) 1, (-10), (-25199998));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25199998 for millisOfDay must be in the range [0,86399999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = offsetDateTimeField3.getMaximumValue(readablePartial5);
        int int7 = offsetDateTimeField3.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = offsetDateTimeField3.getAsShortText(readablePartial8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        boolean boolean5 = offsetDateTimeField3.isLeap((long) 0);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 10, (-25200000));
        java.lang.String str10 = offsetDateTimeField3.getAsShortText((long) (byte) -1);
        int int13 = offsetDateTimeField3.getDifference(28801969L, 2678400000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "16" + "'", str10.equals("16"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = period1.normalizedStandard(periodType2);
        org.joda.time.Period period5 = period3.withWeeks((-10));
        org.joda.time.Period period7 = period5.minusDays(0);
        org.joda.time.Period period9 = period5.minusYears((-28800000));
        org.joda.time.DurationFieldType[] durationFieldTypeArray10 = period5.getFieldTypes();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.forFields(durationFieldTypeArray10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(durationFieldTypeArray10);
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.Period period2 = period0.plusMonths((int) (short) -1);
        org.joda.time.Period period4 = period0.minusMinutes((int) '#');
        org.joda.time.Period period6 = period0.withWeeks(0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        long long7 = offsetDateTimeField3.roundCeiling((long) (byte) 1);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2678400000L + "'", long7 == 2678400000L);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        java.lang.String str4 = dateTimeZone2.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.minuteOfHour();
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        java.lang.String str10 = dateTimeZone8.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        long long16 = gregorianChronology11.getDateTimeMillis((-28800000), (int) (byte) 10, 1, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology11.getZone();
//        boolean boolean18 = gregorianChronology5.equals((java.lang.Object) gregorianChronology11);
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology5.monthOfYear();
//        org.joda.time.Period period20 = new org.joda.time.Period(28801969L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-908902361117221990L) + "'", long16 == (-908902361117221990L));
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(chronology21);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.Period period1 = new org.joda.time.Period((-100L));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        int int4 = period3.getSeconds();
        org.joda.time.Period period6 = period3.plusMillis(0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        long long5 = offsetDateTimeField3.roundHalfCeiling((-1009411200001L));
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField3.getAsShortText((long) (short) 1, locale7);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1009843200000L) + "'", long5 == (-1009843200000L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5" + "'", str8.equals("5"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        long long6 = iSOChronology0.add((org.joda.time.ReadablePeriod) period2, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.Period period8 = period2.multipliedBy(0);
        org.joda.time.Period period10 = period2.minusMinutes(0);
        org.joda.time.Period period12 = period2.withHours(8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(minutes3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.junit.Assert.assertNotNull(period0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = periodType2.withDaysRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType3);
        org.joda.time.PeriodType periodType5 = periodType3.withDaysRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType7 = periodType3.getFieldType(2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        boolean boolean17 = dateTimeZone15.isStandardOffset(0L);
//        org.joda.time.Chronology chronology18 = zonedChronology11.withZone(dateTimeZone15);
//        org.joda.time.DurationField durationField19 = zonedChronology11.minutes();
//        try {
//            long long27 = zonedChronology11.getDateTimeMillis((int) (short) 10, 0, (int) ' ', 100, (int) '4', 0, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology11.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        long long17 = cachedDateTimeZone15.previousTransition((long) (-100));
//        int int19 = cachedDateTimeZone15.getStandardOffset(0L);
//        int int21 = cachedDateTimeZone15.getOffset(10L);
//        org.joda.time.DateTimeZone dateTimeZone22 = cachedDateTimeZone15.getUncachedZone();
//        int int24 = dateTimeZone22.getOffsetFromLocal((-74626937766000001L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-5756400001L) + "'", long17 == (-5756400001L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28378000) + "'", int24 == (-28378000));
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
        long long4 = dateTimeZone1.adjustOffset((long) (byte) 0, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("100.0", (java.lang.Number) (-25200000), (java.lang.Number) 10, (java.lang.Number) 10.0f);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        long long5 = offsetDateTimeField3.roundFloor((long) (short) -1);
        boolean boolean7 = offsetDateTimeField3.isLeap((-10068912000L));
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2678400000L) + "'", long5 == (-2678400000L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.Period period8 = new org.joda.time.Period((int) ' ', (int) (byte) 0, (int) (byte) 10, 0, 5, (-25200000), (-28378000), (-97));
        try {
            int int10 = period8.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getShortName((long) 0, locale11);
//        java.lang.String str14 = dateTimeZone6.getName(0L);
//        java.lang.String str15 = dateTimeZone6.getID();
//        long long18 = dateTimeZone6.adjustOffset((long) (-1), true);
//        org.joda.time.Chronology chronology19 = gregorianChronology4.withZone(dateTimeZone6);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean22 = iSOChronology20.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology20.secondOfMinute();
//        java.util.TimeZone timeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone25.getName((long) (byte) 0, locale27);
//        org.joda.time.ReadableInstant readableInstant29 = null;
//        int int30 = dateTimeZone25.getOffset(readableInstant29);
//        org.joda.time.chrono.ZonedChronology zonedChronology31 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology20, dateTimeZone25);
//        org.joda.time.DurationField durationField32 = zonedChronology31.weekyears();
//        org.joda.time.DurationField durationField33 = zonedChronology31.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone34 = zonedChronology31.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone35 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone34);
//        long long37 = cachedDateTimeZone35.previousTransition((long) (-100));
//        java.lang.String str39 = cachedDateTimeZone35.getNameKey((long) (short) 10);
//        int int41 = cachedDateTimeZone35.getOffset((-908902361117221990L));
//        org.joda.time.chrono.ZonedChronology zonedChronology42 = org.joda.time.chrono.ZonedChronology.getInstance(chronology19, (org.joda.time.DateTimeZone) cachedDateTimeZone35);
//        long long44 = cachedDateTimeZone35.previousTransition(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Pacific Standard Time" + "'", str14.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "America/Los_Angeles" + "'", str15.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Pacific Standard Time" + "'", str28.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-28800000) + "'", int30 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-5756400001L) + "'", long37 == (-5756400001L));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "PST" + "'", str39.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-28378000) + "'", int41 == (-28378000));
//        org.junit.Assert.assertNotNull(zonedChronology42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-5756400001L) + "'", long44 == (-5756400001L));
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField12 = zonedChronology11.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField13, dateTimeFieldType14, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("DurationField[years]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"DurationField[years]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "-07:52:58");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        java.lang.Number number28 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number28);
//        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType23, (long) 100);
//        int int33 = preciseDurationField31.getValue((long) (byte) 10);
//        boolean boolean34 = preciseDurationField31.isSupported();
//        long long35 = preciseDurationField31.getUnitMillis();
//        long long38 = preciseDurationField31.add((long) (byte) 10, (long) 16);
//        long long41 = preciseDurationField31.getValueAsLong(0L, 28800000L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1610L + "'", long38 == 1610L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int7 = offsetDateTimeField3.getDifference((long) 4, (long) '#');
        long long9 = offsetDateTimeField3.remainder(0L);
        int int11 = offsetDateTimeField3.getLeapAmount((long) 10);
        int int12 = offsetDateTimeField3.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.PeriodType periodType16 = null;
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 0, periodType16, chronology17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.Period period20 = period18.minus(readablePeriod19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period22 = period18.normalizedStandard(periodType21);
        int[] intArray23 = period18.getValues();
        try {
            int[] intArray25 = offsetDateTimeField3.add(readablePartial13, (-7), intArray23, (-25199998));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(intArray23);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getShortName((long) 0, locale11);
//        java.lang.String str14 = dateTimeZone6.getName(0L);
//        java.lang.String str15 = dateTimeZone6.getID();
//        long long18 = dateTimeZone6.adjustOffset((long) (-1), true);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        java.util.TimeZone timeZone20 = dateTimeZone6.toTimeZone();
//        java.lang.String str22 = dateTimeZone6.getName(10L);
//        long long24 = dateTimeZone6.convertUTCToLocal((-2678400000L));
//        org.joda.time.Chronology chronology25 = lenientChronology4.withZone(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(lenientChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Pacific Standard Time" + "'", str14.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "America/Los_Angeles" + "'", str15.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Pacific Standard Time" + "'", str22.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-2707200000L) + "'", long24 == (-2707200000L));
//        org.junit.Assert.assertNotNull(chronology25);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "Millis");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int7 = offsetDateTimeField3.getDifference((long) 4, (long) '#');
        long long9 = offsetDateTimeField3.remainder(0L);
        int int11 = offsetDateTimeField3.getLeapAmount((-28799900L));
        long long13 = offsetDateTimeField3.roundHalfEven((long) '#');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDayTime]", (java.lang.Number) 100.0d, (java.lang.Number) (-97), (java.lang.Number) 10.0d);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number9 = illegalFieldValueException4.getIllegalNumberValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-97) + "'", number5.equals((-97)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-97) + "'", number8.equals((-97)));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100.0d + "'", number9.equals(100.0d));
        org.junit.Assert.assertNull(dateTimeFieldType10);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = period1.normalizedStandard(periodType2);
        org.joda.time.Period period5 = period3.withWeeks((-10));
        org.joda.time.Weeks weeks6 = period5.toStandardWeeks();
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, periodType8, chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.Period period12 = period10.minus(readablePeriod11);
        org.joda.time.Period period14 = period12.plusDays((int) (byte) -1);
        org.joda.time.Period period15 = period5.withFields((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period17 = period12.plusMinutes((-97));
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withDaysRemoved();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType(0);
        boolean boolean22 = period17.isSupported(durationFieldType21);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(weeks6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        java.lang.String str26 = scaledDurationField25.toString();
//        long long29 = scaledDurationField25.getMillis(5, 2440588L);
//        long long31 = scaledDurationField25.getMillis((long) '#');
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DurationField[years]" + "'", str26.equals("DurationField[years]"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-157248000000L) + "'", long29 == (-157248000000L));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1104493320000L) + "'", long31 == (-1104493320000L));
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        long long7 = offsetDateTimeField3.roundCeiling((long) (byte) 1);
        try {
            long long10 = offsetDateTimeField3.set(1610L, "America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2678400000L + "'", long7 == 2678400000L);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        int int5 = gregorianChronology4.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType7, (int) (byte) 0, 5, 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1L, (-100L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-100) + "'", int2 == (-100));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        boolean boolean5 = offsetDateTimeField3.isLeap((long) 0);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 10, (-25200000));
        long long10 = offsetDateTimeField3.roundHalfFloor((-10L));
        long long13 = offsetDateTimeField3.add(2440588L, (long) 0);
        int int14 = offsetDateTimeField3.getMinimumValue();
        long long16 = offsetDateTimeField3.roundHalfCeiling((long) (-10));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2440588L + "'", long13 == 2440588L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-1104493320000L), (long) (-100));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 110449332000000L + "'", long2 == 110449332000000L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Period period5 = period3.minus(readablePeriod4);
        org.joda.time.Period period7 = period3.plusMillis((int) (byte) 100);
        org.joda.time.Period period9 = period7.minusDays((int) '4');
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) -1);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        java.lang.String str14 = dateTimeZone13.getID();
//        org.joda.time.Chronology chronology15 = zonedChronology11.withZone(dateTimeZone13);
//        org.joda.time.DurationField durationField16 = zonedChronology11.hours();
//        org.joda.time.PeriodType periodType18 = null;
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.Period period20 = new org.joda.time.Period((-1L), periodType18, chronology19);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Period period23 = org.joda.time.Period.days((int) (byte) 0);
//        org.joda.time.Minutes minutes24 = period23.toStandardMinutes();
//        long long27 = iSOChronology21.add((org.joda.time.ReadablePeriod) period23, (long) (byte) 100, (int) (byte) 100);
//        org.joda.time.Period period29 = period23.withDays((-1));
//        org.joda.time.Period period30 = period20.plus((org.joda.time.ReadablePeriod) period23);
//        java.lang.Object obj31 = null;
//        org.joda.time.PeriodType periodType32 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period33 = new org.joda.time.Period(obj31, periodType32);
//        org.joda.time.Period period34 = period20.normalizedStandard(periodType32);
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean37 = iSOChronology35.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology35.secondOfMinute();
//        java.util.TimeZone timeZone39 = null;
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forTimeZone(timeZone39);
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = dateTimeZone40.getName((long) (byte) 0, locale42);
//        org.joda.time.ReadableInstant readableInstant44 = null;
//        int int45 = dateTimeZone40.getOffset(readableInstant44);
//        org.joda.time.chrono.ZonedChronology zonedChronology46 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology35, dateTimeZone40);
//        org.joda.time.DurationField durationField47 = zonedChronology46.weekyears();
//        org.joda.time.Period period49 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType50 = null;
//        org.joda.time.Period period51 = period49.normalizedStandard(periodType50);
//        org.joda.time.Period period53 = period49.minusSeconds(0);
//        boolean boolean54 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField47, (java.lang.Object) period49);
//        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType56 = periodType55.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType58 = periodType56.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField60 = new org.joda.time.field.ScaledDurationField(durationField47, durationFieldType58, (-1));
//        java.lang.Number number63 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(durationFieldType58, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number63);
//        org.joda.time.field.PreciseDurationField preciseDurationField66 = new org.joda.time.field.PreciseDurationField(durationFieldType58, (long) 100);
//        boolean boolean67 = periodType32.isSupported(durationFieldType58);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField68 = new org.joda.time.field.DecoratedDurationField(durationField16, durationFieldType58);
//        int int71 = decoratedDurationField68.getDifference((long) (-28378000), (long) (short) 0);
//        java.lang.String str72 = decoratedDurationField68.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "America/Los_Angeles" + "'", str14.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(period23);
//        org.junit.Assert.assertNotNull(minutes24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertNotNull(periodType32);
//        org.junit.Assert.assertNotNull(period34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Pacific Standard Time" + "'", str43.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-28800000) + "'", int45 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(period49);
//        org.junit.Assert.assertNotNull(period51);
//        org.junit.Assert.assertNotNull(period53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(periodType55);
//        org.junit.Assert.assertNotNull(periodType56);
//        org.junit.Assert.assertNotNull(durationFieldType58);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-7) + "'", int71 == (-7));
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "DurationField[years]" + "'", str72.equals("DurationField[years]"));
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        long long7 = offsetDateTimeField3.roundCeiling((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField3.getAsShortText((-10), locale9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2678400000L + "'", long7 == 2678400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-10" + "'", str10.equals("-10"));
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long27 = scaledDurationField25.getValueAsLong((long) 100);
//        boolean boolean28 = scaledDurationField25.isPrecise();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDay();
        java.lang.String str1 = periodType0.toString();
        java.lang.String str2 = periodType0.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PeriodType[YearDay]" + "'", str1.equals("PeriodType[YearDay]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PeriodType[YearDay]" + "'", str2.equals("PeriodType[YearDay]"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 2, "PeriodType[YearDay]");
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(795235190400000000L, 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 795235190400000000L + "'", long2 == 795235190400000000L);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology11.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        long long17 = cachedDateTimeZone15.previousTransition((long) (-100));
//        int int19 = cachedDateTimeZone15.getOffset((long) (byte) 0);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = cachedDateTimeZone15.getShortName((long) (byte) 1, locale21);
//        org.joda.time.DateTimeZone dateTimeZone23 = cachedDateTimeZone15.getUncachedZone();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-5756400001L) + "'", long17 == (-5756400001L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PST" + "'", str22.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "PeriodType[YearMonthDayTime]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.MutablePeriod mutablePeriod2 = period1.toMutablePeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(mutablePeriod2);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.Period period4 = new org.joda.time.Period((-7), (int) (short) 0, 28800000, 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        long long7 = offsetDateTimeField3.roundCeiling((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsText(readablePartial8, (int) (byte) 0, locale10);
        org.joda.time.DurationField durationField12 = offsetDateTimeField3.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2678400000L + "'", long7 == 2678400000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "DateTimeField[monthOfYear]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        long long6 = iSOChronology0.add((org.joda.time.ReadablePeriod) period2, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
        org.joda.time.Period period13 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType14 = null;
        org.joda.time.Period period15 = period13.normalizedStandard(periodType14);
        org.joda.time.Period period16 = period13.negated();
        org.joda.time.Period period17 = period11.withFields((org.joda.time.ReadablePeriod) period16);
        int[] intArray19 = iSOChronology0.get((org.joda.time.ReadablePeriod) period16, 0L);
        org.joda.time.DurationField durationField20 = iSOChronology0.centuries();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(minutes3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(durationField20);
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, periodType2, chronology3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.Period period6 = period4.minus(readablePeriod5);
//        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.Period period8 = period4.normalizedStandard(periodType7);
//        org.joda.time.PeriodType periodType9 = periodType7.withMonthsRemoved();
//        java.lang.String str10 = periodType9.getName();
//        org.joda.time.PeriodType periodType11 = periodType9.withMonthsRemoved();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean14 = iSOChronology12.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.secondOfMinute();
//        java.util.TimeZone timeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.ReadableInstant readableInstant21 = null;
//        int int22 = dateTimeZone17.getOffset(readableInstant21);
//        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology12, dateTimeZone17);
//        org.joda.time.DurationField durationField24 = zonedChronology23.weekyears();
//        org.joda.time.DurationField durationField25 = zonedChronology23.weekyears();
//        java.util.TimeZone timeZone26 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forTimeZone(timeZone26);
//        boolean boolean29 = dateTimeZone27.isStandardOffset(0L);
//        org.joda.time.Chronology chronology30 = zonedChronology23.withZone(dateTimeZone27);
//        org.joda.time.DurationField durationField31 = zonedChronology23.minutes();
//        org.joda.time.Period period32 = new org.joda.time.Period(28801969L, periodType9, (org.joda.time.Chronology) zonedChronology23);
//        try {
//            long long40 = zonedChronology23.getDateTimeMillis((-25200000), 1, (-10), (int) (byte) -1, 0, (-97), 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(periodType7);
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "YearDay" + "'", str10.equals("YearDay"));
//        org.junit.Assert.assertNotNull(periodType11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pacific Standard Time" + "'", str20.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-28800000) + "'", int22 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) (byte) 0, locale3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone1.getShortName((long) 0, locale6);
//        java.lang.String str9 = dateTimeZone1.getName(0L);
//        java.lang.String str10 = dateTimeZone1.getID();
//        long long13 = dateTimeZone1.adjustOffset((long) (-1), true);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
//        java.util.TimeZone timeZone15 = dateTimeZone1.toTimeZone();
//        java.lang.String str17 = dateTimeZone1.getName(10L);
//        java.lang.String str18 = dateTimeZone1.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pacific Standard Time" + "'", str17.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "America/Los_Angeles" + "'", str18.equals("America/Los_Angeles"));
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long27 = scaledDurationField25.getMillis((-25200000));
//        int int29 = scaledDurationField25.getValue((long) 'a');
//        boolean boolean30 = scaledDurationField25.isPrecise();
//        org.joda.time.DurationField durationField31 = scaledDurationField25.getWrappedField();
//        long long34 = scaledDurationField25.getMillis(2440471L, (-10098432000L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 795235190400000000L + "'", long27 == 795235190400000000L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-77013825840000000L) + "'", long34 == (-77013825840000000L));
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Period period5 = period3.minus(readablePeriod4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period7 = period3.normalizedStandard(periodType6);
        int[] intArray8 = period3.getValues();
        org.joda.time.Period period10 = period3.minusYears((int) (byte) 100);
        org.joda.time.Period period11 = period10.negated();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.Period period1 = new org.joda.time.Period((-1L));
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology11.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        long long17 = cachedDateTimeZone15.previousTransition((long) (-100));
//        java.lang.String str19 = cachedDateTimeZone15.getNameKey((long) (short) 10);
//        int int21 = cachedDateTimeZone15.getOffset((-908902361117221990L));
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone15);
//        java.lang.String str23 = cachedDateTimeZone15.getID();
//        int int25 = cachedDateTimeZone15.getOffset((long) (-28378000));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-5756400001L) + "'", long17 == (-5756400001L));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28378000) + "'", int21 == (-28378000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "America/Los_Angeles" + "'", str23.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-28800000) + "'", int25 == (-28800000));
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = period1.normalizedStandard(periodType2);
        org.joda.time.Period period5 = period1.minusSeconds(0);
        org.joda.time.Period period7 = period5.withHours((-25200000));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = period3.getMillis();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period((-1L), periodType1, chronology2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Period period6 = org.joda.time.Period.days((int) (byte) 0);
//        org.joda.time.Minutes minutes7 = period6.toStandardMinutes();
//        long long10 = iSOChronology4.add((org.joda.time.ReadablePeriod) period6, (long) (byte) 100, (int) (byte) 100);
//        org.joda.time.Period period12 = period6.withDays((-1));
//        org.joda.time.Period period13 = period3.plus((org.joda.time.ReadablePeriod) period6);
//        java.lang.Object obj14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period16 = new org.joda.time.Period(obj14, periodType15);
//        org.joda.time.Period period17 = period3.normalizedStandard(periodType15);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean20 = iSOChronology18.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology18.secondOfMinute();
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone23.getName((long) (byte) 0, locale25);
//        org.joda.time.ReadableInstant readableInstant27 = null;
//        int int28 = dateTimeZone23.getOffset(readableInstant27);
//        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology18, dateTimeZone23);
//        org.joda.time.DurationField durationField30 = zonedChronology29.weekyears();
//        org.joda.time.Period period32 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType33 = null;
//        org.joda.time.Period period34 = period32.normalizedStandard(periodType33);
//        org.joda.time.Period period36 = period32.minusSeconds(0);
//        boolean boolean37 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField30, (java.lang.Object) period32);
//        org.joda.time.PeriodType periodType38 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType39 = periodType38.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField43 = new org.joda.time.field.ScaledDurationField(durationField30, durationFieldType41, (-1));
//        java.lang.Number number46 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException47 = new org.joda.time.IllegalFieldValueException(durationFieldType41, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number46);
//        org.joda.time.field.PreciseDurationField preciseDurationField49 = new org.joda.time.field.PreciseDurationField(durationFieldType41, (long) 100);
//        boolean boolean50 = periodType15.isSupported(durationFieldType41);
//        org.joda.time.field.PreciseDurationField preciseDurationField52 = new org.joda.time.field.PreciseDurationField(durationFieldType41, (-52L));
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(minutes7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pacific Standard Time" + "'", str26.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-28800000) + "'", int28 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(period34);
//        org.junit.Assert.assertNotNull(period36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(periodType38);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(durationFieldType41);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.lang.String str4 = iSOChronology0.toString();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getShortName((long) 0, locale11);
//        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone6);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone6.getShortName(1610L, locale15);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PST" + "'", str16.equals("PST"));
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = period1.normalizedStandard(periodType2);
        org.joda.time.Period period5 = period1.minusSeconds(0);
        org.joda.time.Period period7 = period1.minusMonths(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.Period period8 = new org.joda.time.Period((-100), (int) (short) 0, (int) (short) 100, (int) (short) 10, (-10), 5, (-10), (-97));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withMinutes(0);
        org.joda.time.Period period7 = period3.withSeconds((-100));
        org.joda.time.Period period9 = period3.plusHours(10);
        org.joda.time.Period period11 = period9.plusMonths((int) (short) 0);
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 0, periodType13, chronology14);
        org.joda.time.Period period17 = period15.withMinutes(0);
        org.joda.time.Period period19 = period15.withSeconds((-100));
        org.joda.time.Period period21 = period15.plusHours(10);
        org.joda.time.Period period23 = period21.plusMonths((int) (short) 0);
        org.joda.time.Period period24 = period9.plus((org.joda.time.ReadablePeriod) period23);
        org.joda.time.DurationFieldType durationFieldType25 = null;
        boolean boolean26 = period9.isSupported(durationFieldType25);
        org.joda.time.PeriodType periodType28 = null;
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((-1L), periodType28, chronology29);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period33 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes34 = period33.toStandardMinutes();
        long long37 = iSOChronology31.add((org.joda.time.ReadablePeriod) period33, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.Period period39 = period33.withDays((-1));
        org.joda.time.Period period40 = period30.plus((org.joda.time.ReadablePeriod) period33);
        java.lang.Object obj41 = null;
        org.joda.time.PeriodType periodType42 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period43 = new org.joda.time.Period(obj41, periodType42);
        org.joda.time.Period period44 = period30.normalizedStandard(periodType42);
        org.joda.time.Period period45 = period9.plus((org.joda.time.ReadablePeriod) period44);
        org.joda.time.Period period47 = period45.minusWeeks((-1));
        try {
            int int49 = period45.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(minutes34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(periodType42);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.lang.String str4 = iSOChronology0.toString();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getShortName((long) 0, locale11);
//        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone6);
//        org.joda.time.DurationField durationField14 = iSOChronology0.eras();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        int int7 = offsetDateTimeField3.getLeapAmount(100L);
        long long10 = offsetDateTimeField3.add((long) 4, 10L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 4);
        java.lang.String str17 = offsetDateTimeField16.getName();
        org.joda.time.ReadablePartial readablePartial18 = null;
        int[] intArray22 = new int[] { (byte) 10, (-100), (-25200000) };
        int int23 = offsetDateTimeField16.getMaximumValue(readablePartial18, intArray22);
        try {
            int[] intArray25 = offsetDateTimeField3.add(readablePartial11, 1, intArray22, (-7));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 26265600004L + "'", long10 == 26265600004L);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "monthOfYear" + "'", str17.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withMinutes(0);
        org.joda.time.Period period7 = period3.withSeconds((-100));
        org.joda.time.Period period9 = period3.plusHours(10);
        org.joda.time.Period period11 = period9.plusMonths((int) (short) 0);
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 0, periodType13, chronology14);
        org.joda.time.Period period17 = period15.withMinutes(0);
        org.joda.time.Period period19 = period15.withSeconds((-100));
        org.joda.time.Period period21 = period15.plusHours(10);
        org.joda.time.Period period23 = period21.plusMonths((int) (short) 0);
        org.joda.time.Period period24 = period9.plus((org.joda.time.ReadablePeriod) period23);
        org.joda.time.PeriodType periodType25 = period23.getPeriodType();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        java.lang.String str14 = zonedChronology11.toString();
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology11);
//        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology11.getZone();
//        org.joda.time.LocalDateTime localDateTime17 = null;
//        try {
//            boolean boolean18 = dateTimeZone16.isLocalDateTimeGap(localDateTime17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int7 = offsetDateTimeField3.getDifference((long) 4, (long) '#');
        long long9 = offsetDateTimeField3.remainder(0L);
        long long11 = offsetDateTimeField3.roundFloor(2440588L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) '#', 28801969L, chronology4);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-157248000000L), (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 157248000000L + "'", long2 == 157248000000L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes4 = period3.toStandardMinutes();
        long long7 = iSOChronology1.add((org.joda.time.ReadablePeriod) period3, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.Duration duration8 = period3.toStandardDuration();
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 0, periodType10, chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.Period period14 = period12.minus(readablePeriod13);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period16 = period12.normalizedStandard(periodType15);
        org.joda.time.PeriodType periodType17 = periodType15.withMonthsRemoved();
        java.lang.String str18 = periodType17.getName();
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8, periodType17);
        try {
            org.joda.time.DurationFieldType durationFieldType21 = periodType17.getFieldType((-100));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(minutes4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "YearDay" + "'", str18.equals("YearDay"));
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        java.lang.String str4 = dateTimeZone2.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.minuteOfHour();
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        java.lang.String str10 = dateTimeZone8.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        long long16 = gregorianChronology11.getDateTimeMillis((-28800000), (int) (byte) 10, 1, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology11.getZone();
//        boolean boolean18 = gregorianChronology5.equals((java.lang.Object) gregorianChronology11);
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology5.monthOfYear();
//        org.joda.time.Period period20 = new org.joda.time.Period(28801969L, (org.joda.time.Chronology) gregorianChronology5);
//        int int21 = gregorianChronology5.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology5.weekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-908902361117221990L) + "'", long16 == (-908902361117221990L));
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDayTime]", (java.lang.Number) 100.0d, (java.lang.Number) (-97), (java.lang.Number) 10.0d);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        java.lang.String str6 = illegalFieldValueException4.getFieldName();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        java.lang.Number number8 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number9 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PeriodType[YearMonthDayTime]" + "'", str5.equals("PeriodType[YearMonthDayTime]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PeriodType[YearMonthDayTime]" + "'", str6.equals("PeriodType[YearMonthDayTime]"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0d + "'", number7.equals(10.0d));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100.0d + "'", number8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-97) + "'", number9.equals((-97)));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        java.lang.String str3 = periodType2.getName();
        org.joda.time.PeriodType periodType4 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withHoursRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType4);
        boolean boolean8 = periodType4.equals((java.lang.Object) 10L);
        org.joda.time.PeriodType periodType9 = periodType4.withMinutesRemoved();
        org.joda.time.PeriodType periodType10 = periodType4.withMonthsRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Millis" + "'", str3.equals("Millis"));
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long28 = scaledDurationField25.getDifferenceAsLong(2440588L, 0L);
//        long long31 = scaledDurationField25.getMillis(0L, (-908902361117221990L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        boolean boolean5 = offsetDateTimeField3.isLeap((long) 0);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 10, (-25200000));
        long long10 = offsetDateTimeField3.roundHalfFloor((-10L));
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 4);
        java.lang.String str17 = offsetDateTimeField16.getName();
        org.joda.time.ReadablePartial readablePartial18 = null;
        int[] intArray22 = new int[] { (byte) 10, (-100), (-25200000) };
        int int23 = offsetDateTimeField16.getMaximumValue(readablePartial18, intArray22);
        try {
            int[] intArray25 = offsetDateTimeField3.set(readablePartial11, (int) (byte) 100, intArray22, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "monthOfYear" + "'", str17.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        java.lang.String str14 = zonedChronology11.toString();
//        org.joda.time.DateTimeField dateTimeField15 = zonedChronology11.millisOfSecond();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.lang.String str4 = iSOChronology0.toString();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getShortName((long) 0, locale11);
//        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 16);
//        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField18.getWrappedField();
//        long long21 = offsetDateTimeField18.roundHalfCeiling(26784000L);
//        boolean boolean23 = offsetDateTimeField18.isLeap((-2108667600000L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 25200000L + "'", long21 == 25200000L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        boolean boolean5 = offsetDateTimeField3.isLeap((long) 0);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 10, (-25200000));
        long long10 = offsetDateTimeField3.roundHalfFloor((-10L));
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.PeriodType periodType14 = null;
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((long) (short) 0, periodType14, chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.Period period18 = period16.minus(readablePeriod17);
        org.joda.time.Period period20 = period18.plusDays((int) (byte) -1);
        int[] intArray21 = period20.getValues();
        try {
            int[] intArray23 = offsetDateTimeField3.add(readablePartial11, 0, intArray21, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(intArray21);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, periodType2, chronology3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.Period period6 = period4.minus(readablePeriod5);
//        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.Period period8 = period4.normalizedStandard(periodType7);
//        org.joda.time.PeriodType periodType9 = periodType7.withMonthsRemoved();
//        java.lang.String str10 = periodType9.getName();
//        org.joda.time.PeriodType periodType11 = periodType9.withMonthsRemoved();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean14 = iSOChronology12.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.secondOfMinute();
//        java.util.TimeZone timeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.ReadableInstant readableInstant21 = null;
//        int int22 = dateTimeZone17.getOffset(readableInstant21);
//        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology12, dateTimeZone17);
//        org.joda.time.DurationField durationField24 = zonedChronology23.weekyears();
//        org.joda.time.DurationField durationField25 = zonedChronology23.weekyears();
//        java.util.TimeZone timeZone26 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forTimeZone(timeZone26);
//        boolean boolean29 = dateTimeZone27.isStandardOffset(0L);
//        org.joda.time.Chronology chronology30 = zonedChronology23.withZone(dateTimeZone27);
//        org.joda.time.DurationField durationField31 = zonedChronology23.minutes();
//        org.joda.time.Period period32 = new org.joda.time.Period(28801969L, periodType9, (org.joda.time.Chronology) zonedChronology23);
//        org.joda.time.DurationField durationField33 = zonedChronology23.months();
//        try {
//            long long39 = zonedChronology23.getDateTimeMillis((-908902361117221990L), (int) (short) 100, (int) (byte) 1, 0, (-10));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(periodType7);
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "YearDay" + "'", str10.equals("YearDay"));
//        org.junit.Assert.assertNotNull(periodType11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pacific Standard Time" + "'", str20.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-28800000) + "'", int22 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(durationField33);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.Period period2 = new org.joda.time.Period((long) '#', 0L);
        int int3 = period2.size();
        org.joda.time.Period period5 = period2.plusMonths((-1));
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period2.toDurationTo(readableInstant6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = period1.normalizedStandard(periodType2);
        org.joda.time.Period period4 = period1.negated();
        org.joda.time.Period period6 = period1.minusSeconds((-100));
        org.joda.time.Period period8 = period1.withMonths(4);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((long) (-1), chronology2);
        org.joda.time.Period period4 = period3.negated();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-100));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDayTime]", (java.lang.Number) 100.0d, (java.lang.Number) (-97), (java.lang.Number) 10.0d);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        java.lang.String str8 = illegalFieldValueException4.getFieldName();
        illegalFieldValueException4.prependMessage("ISOChronology[UTC]");
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-97) + "'", number5.equals((-97)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PeriodType[YearMonthDayTime]" + "'", str8.equals("PeriodType[YearMonthDayTime]"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        boolean boolean5 = offsetDateTimeField3.isLeap((long) 0);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 10, (-25200000));
        long long10 = offsetDateTimeField3.roundHalfFloor((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType11, 0, (-28800000), 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, periodType2, chronology3);
        org.joda.time.Period period6 = period4.withMinutes(0);
        org.joda.time.Period period8 = period4.withSeconds((-100));
        org.joda.time.Period period10 = period4.plusHours(10);
        org.joda.time.Period period12 = period10.plusMonths((int) (short) 0);
        org.joda.time.Period period14 = period10.plusHours((int) (short) 100);
        org.joda.time.Period period16 = period10.plusMonths((int) (short) 1);
        org.joda.time.Duration duration17 = period10.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18);
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration17);
        org.joda.time.Period period22 = org.joda.time.Period.days((int) (byte) 0);
        java.lang.String str23 = period22.toString();
        org.joda.time.PeriodType periodType24 = period22.getPeriodType();
        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period20, periodType24);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PT0S" + "'", str23.equals("PT0S"));
        org.junit.Assert.assertNotNull(periodType24);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int7 = offsetDateTimeField3.getDifference((long) 4, (long) '#');
//        long long9 = offsetDateTimeField3.roundHalfCeiling((long) (-28800000));
//        int int11 = offsetDateTimeField3.getLeapAmount(28800000L);
//        long long14 = offsetDateTimeField3.add(0L, (int) (byte) 0);
//        org.joda.time.ReadablePartial readablePartial15 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 4);
//        boolean boolean22 = offsetDateTimeField20.isLeap((long) 0);
//        long long25 = offsetDateTimeField20.addWrapField((long) (short) 10, (-25200000));
//        java.lang.String str27 = offsetDateTimeField20.getAsShortText((long) (byte) -1);
//        org.joda.time.ReadablePartial readablePartial28 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean32 = iSOChronology30.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology30.secondOfMinute();
//        java.util.TimeZone timeZone34 = null;
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = dateTimeZone35.getName((long) (byte) 0, locale37);
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        int int40 = dateTimeZone35.getOffset(readableInstant39);
//        org.joda.time.chrono.ZonedChronology zonedChronology41 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology30, dateTimeZone35);
//        org.joda.time.DurationField durationField42 = zonedChronology41.weekyears();
//        org.joda.time.DateTimeField dateTimeField43 = zonedChronology41.clockhourOfDay();
//        boolean boolean44 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 2440588L, (java.lang.Object) zonedChronology41);
//        org.joda.time.Period period46 = org.joda.time.Period.days((int) '4');
//        org.joda.time.Period period48 = period46.withWeeks((int) '#');
//        org.joda.time.Period period50 = period46.minusYears((int) (short) 100);
//        int[] intArray52 = zonedChronology41.get((org.joda.time.ReadablePeriod) period46, (-1L));
//        int int53 = offsetDateTimeField20.getMaximumValue(readablePartial28, intArray52);
//        java.util.Locale locale55 = null;
//        try {
//            int[] intArray56 = offsetDateTimeField3.set(readablePartial15, (-7), intArray52, "org.joda.time.IllegalFieldValueException: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]", locale55);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]\" for monthOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "16" + "'", str27.equals("16"));
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Pacific Standard Time" + "'", str38.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-28800000) + "'", int40 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(period46);
//        org.junit.Assert.assertNotNull(period48);
//        org.junit.Assert.assertNotNull(period50);
//        org.junit.Assert.assertNotNull(intArray52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 16 + "'", int53 == 16);
//    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
//        org.joda.time.Period period5 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType6 = null;
//        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
//        org.joda.time.Period period8 = period5.negated();
//        org.joda.time.Period period9 = period3.withFields((org.joda.time.ReadablePeriod) period8);
//        org.joda.time.Weeks weeks10 = period8.toStandardWeeks();
//        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean14 = iSOChronology12.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.secondOfMinute();
//        java.lang.String str16 = iSOChronology12.toString();
//        java.util.TimeZone timeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) (byte) 0, locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone18.getShortName((long) 0, locale23);
//        org.joda.time.Chronology chronology25 = iSOChronology12.withZone(dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology12.hourOfDay();
//        try {
//            org.joda.time.Period period29 = new org.joda.time.Period((java.lang.Object) weeks10, periodType11, (org.joda.time.Chronology) iSOChronology12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'weeks'");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertNotNull(period9);
//        org.junit.Assert.assertNotNull(weeks10);
//        org.junit.Assert.assertNotNull(periodType11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ISOChronology[UTC]" + "'", str16.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PST" + "'", str24.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        java.lang.Number number28 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number28);
//        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType23, (long) 100);
//        int int33 = preciseDurationField31.getValue((long) (byte) 10);
//        org.joda.time.PeriodType periodType35 = null;
//        org.joda.time.Chronology chronology36 = null;
//        org.joda.time.Period period37 = new org.joda.time.Period((long) (short) 0, periodType35, chronology36);
//        org.joda.time.ReadablePeriod readablePeriod38 = null;
//        org.joda.time.Period period39 = period37.minus(readablePeriod38);
//        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.Period period41 = period37.normalizedStandard(periodType40);
//        org.joda.time.PeriodType periodType42 = periodType40.withMonthsRemoved();
//        java.lang.String str43 = periodType42.getName();
//        try {
//            org.joda.time.Period period44 = new org.joda.time.Period((java.lang.Object) int33, periodType42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertNotNull(periodType40);
//        org.junit.Assert.assertNotNull(period41);
//        org.junit.Assert.assertNotNull(periodType42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "YearDay" + "'", str43.equals("YearDay"));
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("monthOfYear");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.String str5 = jodaTimePermission3.getActions();
        java.lang.String str6 = jodaTimePermission3.getName();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "monthOfYear" + "'", str6.equals("monthOfYear"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType1 = periodType0.withDaysRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Period period5 = period3.minus(readablePeriod4);
        org.joda.time.Period period7 = period5.plusMinutes(100);
        org.joda.time.Period period9 = period5.plusMonths((int) (byte) 100);
        org.joda.time.Period period11 = period9.plusMonths((-10));
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (-1), (-8L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9L) + "'", long2 == (-9L));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("-1");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"-1/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) '4', (long) (-10));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 42L + "'", long2 == 42L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        java.lang.String str14 = dateTimeZone13.getID();
//        org.joda.time.Chronology chronology15 = zonedChronology11.withZone(dateTimeZone13);
//        org.joda.time.DurationField durationField16 = zonedChronology11.hours();
//        java.util.TimeZone timeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        java.lang.String str20 = dateTimeZone18.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.Chronology chronology22 = zonedChronology11.withZone(dateTimeZone18);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        try {
//            long long25 = zonedChronology11.set(readablePartial23, (long) 28800000);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "America/Los_Angeles" + "'", str14.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(chronology22);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period3 = period1.withWeeks((int) '#');
        int int4 = period3.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(1L, (long) (short) 1, periodType2);
        org.joda.time.Period period5 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period7 = period5.withSeconds((-1));
        int int8 = period7.getYears();
        boolean boolean9 = periodType2.equals((java.lang.Object) period7);
        org.joda.time.PeriodType periodType10 = periodType2.withMonthsRemoved();
        org.joda.time.PeriodType periodType11 = periodType2.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        long long9 = gregorianChronology4.getDateTimeMillis((-28800000), (int) (byte) 10, 1, (int) (short) 10);
//        org.joda.time.Chronology chronology10 = gregorianChronology4.withUTC();
//        try {
//            long long18 = gregorianChronology4.getDateTimeMillis((-1), 0, (-28378000), (int) (byte) 1, 0, 0, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-908902361117221990L) + "'", long9 == (-908902361117221990L));
//        org.junit.Assert.assertNotNull(chronology10);
//    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        boolean boolean17 = dateTimeZone15.isStandardOffset(0L);
//        org.joda.time.Chronology chronology18 = zonedChronology11.withZone(dateTimeZone15);
//        try {
//            long long23 = zonedChronology11.getDateTimeMillis(0, (-25199998), (int) '4', (-10));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for millisOfDay must be in the range [0,86399999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(chronology18);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset(0L);
        java.lang.String str4 = dateTimeZone1.toString();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology6 = iSOChronology5.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 8, (-1), (int) ' ');
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        boolean boolean5 = offsetDateTimeField3.isLeap((long) 0);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 10, (-25200000));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(0L);
        org.joda.time.DurationField durationField13 = offsetDateTimeField3.getLeapDurationField();
        try {
            long long16 = offsetDateTimeField3.set((-28799900L), "hi!");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "5" + "'", str12.equals("5"));
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDayTime]", (java.lang.Number) 100.0d, (java.lang.Number) (-97), (java.lang.Number) 10.0d);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number9 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str10 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str11 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-97) + "'", number5.equals((-97)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-97) + "'", number8.equals((-97)));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100.0d + "'", number9.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0" + "'", str10.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0" + "'", str11.equals("100.0"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int7 = offsetDateTimeField3.getDifference((long) 4, (long) '#');
        long long9 = offsetDateTimeField3.remainder(0L);
        int int11 = offsetDateTimeField3.getMinimumValue(3155846401610L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(28800000);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        int int7 = offsetDateTimeField3.getLeapAmount(100L);
        long long10 = offsetDateTimeField3.add((long) 4, 10L);
        org.joda.time.DurationField durationField11 = offsetDateTimeField3.getDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 26265600004L + "'", long10 == 26265600004L);
        org.junit.Assert.assertNotNull(durationField11);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
//        boolean boolean9 = gregorianChronology4.equals((java.lang.Object) (short) 10);
//        int int10 = gregorianChronology4.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology4.dayOfWeek();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int7 = offsetDateTimeField3.getDifference((long) 4, (long) '#');
        long long9 = offsetDateTimeField3.roundHalfCeiling((long) (-28800000));
        int int11 = offsetDateTimeField3.getLeapAmount(28800000L);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField3.getMaximumShortTextLength(locale12);
        java.util.Locale locale14 = null;
        int int15 = offsetDateTimeField3.getMaximumShortTextLength(locale14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType16, 4, (-10), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset(0L);
        java.lang.String str4 = dateTimeZone1.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(4);
        long long8 = dateTimeZone1.getMillisKeepLocal(dateTimeZone6, 28800000L);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-4L) + "'", long8 == (-4L));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (short) -1);
        org.joda.time.Seconds seconds2 = period1.toStandardSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(seconds2);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.lang.String str4 = iSOChronology0.toString();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        org.joda.time.Chronology chronology10 = iSOChronology0.withZone(dateTimeZone6);
//        java.lang.Class<?> wildcardClass11 = dateTimeZone6.getClass();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone6.getName(0L, locale13);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Pacific Standard Time" + "'", str14.equals("Pacific Standard Time"));
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        long long8 = offsetDateTimeField3.add(100L, (-1));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2678399900L) + "'", long8 == (-2678399900L));
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        org.joda.time.ReadablePartial readablePartial4 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
//        boolean boolean11 = offsetDateTimeField9.isLeap((long) 0);
//        long long14 = offsetDateTimeField9.addWrapField((long) (short) 10, (-25200000));
//        java.lang.String str16 = offsetDateTimeField9.getAsShortText((long) (byte) -1);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean21 = iSOChronology19.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.secondOfMinute();
//        java.util.TimeZone timeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone24.getName((long) (byte) 0, locale26);
//        org.joda.time.ReadableInstant readableInstant28 = null;
//        int int29 = dateTimeZone24.getOffset(readableInstant28);
//        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology19, dateTimeZone24);
//        org.joda.time.DurationField durationField31 = zonedChronology30.weekyears();
//        org.joda.time.DateTimeField dateTimeField32 = zonedChronology30.clockhourOfDay();
//        boolean boolean33 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 2440588L, (java.lang.Object) zonedChronology30);
//        org.joda.time.Period period35 = org.joda.time.Period.days((int) '4');
//        org.joda.time.Period period37 = period35.withWeeks((int) '#');
//        org.joda.time.Period period39 = period35.minusYears((int) (short) 100);
//        int[] intArray41 = zonedChronology30.get((org.joda.time.ReadablePeriod) period35, (-1L));
//        int int42 = offsetDateTimeField9.getMaximumValue(readablePartial17, intArray41);
//        java.util.Locale locale44 = null;
//        try {
//            int[] intArray45 = offsetDateTimeField3.set(readablePartial4, 28800000, intArray41, "100", locale44);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [5,16]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "16" + "'", str16.equals("16"));
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(period37);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertNotNull(intArray41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 16 + "'", int42 == 16);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 28800000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.8333333335d + "'", double1 == 2440587.8333333335d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(readableInterval4);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("+00:00:00.004");
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        long long6 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration5);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period4 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes5 = period4.toStandardMinutes();
        long long8 = iSOChronology2.add((org.joda.time.ReadablePeriod) period4, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.year();
        org.joda.time.DurationField durationField10 = iSOChronology2.minutes();
        org.joda.time.Period period11 = new org.joda.time.Period((long) '#', (long) 10, (org.joda.time.Chronology) iSOChronology2);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(minutes5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
//        org.joda.time.Period period10 = new org.joda.time.Period((-10), (int) (short) -1, (-10), (int) (short) 0);
//        org.joda.time.Days days11 = period10.toStandardDays();
//        boolean boolean12 = gregorianChronology4.equals((java.lang.Object) period10);
//        org.joda.time.DurationField durationField13 = gregorianChronology4.hours();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        boolean boolean17 = dateTimeZone15.isStandardOffset(0L);
//        java.lang.String str18 = dateTimeZone15.toString();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis(4);
//        long long22 = dateTimeZone15.getMillisKeepLocal(dateTimeZone20, 28800000L);
//        java.lang.String str24 = dateTimeZone20.getShortName((long) (-97));
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone20.getName((long) (short) 1, locale26);
//        org.joda.time.Chronology chronology28 = gregorianChronology4.withZone(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(days11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "America/Los_Angeles" + "'", str18.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-4L) + "'", long22 == (-4L));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.004" + "'", str24.equals("+00:00:00.004"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00:00.004" + "'", str27.equals("+00:00:00.004"));
//        org.junit.Assert.assertNotNull(chronology28);
//    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology11.getZone();
//        org.joda.time.DateTimeField dateTimeField15 = zonedChronology11.weekyearOfCentury();
//        try {
//            long long23 = zonedChronology11.getDateTimeMillis(0, (-28378000), (int) (byte) -1, (-10), (-100), (-25200000), (int) '#');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period4 = new org.joda.time.Period(1L, (long) (short) 1, periodType3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (-100), periodType3, (org.joda.time.Chronology) iSOChronology5);
        try {
            org.joda.time.DurationFieldType durationFieldType8 = periodType3.getFieldType((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology5);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Period period5 = period3.minus(readablePeriod4);
        org.joda.time.Period period7 = period5.plusMinutes(100);
        org.joda.time.Period period9 = period7.minusWeeks((-100));
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "PST");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDayTime]", (java.lang.Number) 100.0d, (java.lang.Number) (-97), (java.lang.Number) 10.0d);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number9 = illegalFieldValueException4.getIllegalNumberValue();
        illegalFieldValueException4.prependMessage("100.0");
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Number number13 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-97) + "'", number5.equals((-97)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-97) + "'", number8.equals((-97)));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100.0d + "'", number9.equals(100.0d));
        org.junit.Assert.assertNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 100.0d + "'", number13.equals(100.0d));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) ' ', (int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        int int6 = offsetDateTimeField3.getMaximumValue(readablePartial5);
//        java.lang.String str8 = offsetDateTimeField3.getAsText(6682L);
//        long long11 = offsetDateTimeField3.add((-908902361117221990L), 5);
//        org.joda.time.ReadablePartial readablePartial12 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean16 = iSOChronology14.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.secondOfMinute();
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone19.getName((long) (byte) 0, locale21);
//        org.joda.time.ReadableInstant readableInstant23 = null;
//        int int24 = dateTimeZone19.getOffset(readableInstant23);
//        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, dateTimeZone19);
//        org.joda.time.Period period30 = new org.joda.time.Period((-10), (int) (short) -1, (-10), (int) (short) 0);
//        org.joda.time.Days days31 = period30.toStandardDays();
//        long long34 = iSOChronology14.add((org.joda.time.ReadablePeriod) days31, (-1009411200001L), 0);
//        org.joda.time.PeriodType periodType36 = null;
//        org.joda.time.Chronology chronology37 = null;
//        org.joda.time.Period period38 = new org.joda.time.Period((long) (short) 0, periodType36, chronology37);
//        org.joda.time.Period period40 = period38.withMinutes(0);
//        org.joda.time.Period period42 = period38.withSeconds((-100));
//        org.joda.time.Period period44 = period38.plusHours(10);
//        org.joda.time.Period period46 = period44.plusMonths((int) (short) 0);
//        org.joda.time.Period period48 = period44.plusHours((int) (short) 100);
//        org.joda.time.Period period50 = period48.plusMillis((int) (byte) -1);
//        org.joda.time.Period period52 = period48.withMonths((-100));
//        int[] intArray54 = iSOChronology14.get((org.joda.time.ReadablePeriod) period52, 3155846401610L);
//        try {
//            int[] intArray56 = offsetDateTimeField3.addWrapPartial(readablePartial12, (int) ' ', intArray54, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5" + "'", str8.equals("5"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-908902348070821990L) + "'", long11 == (-908902348070821990L));
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Pacific Standard Time" + "'", str22.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology25);
//        org.junit.Assert.assertNotNull(days31);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1009411200001L) + "'", long34 == (-1009411200001L));
//        org.junit.Assert.assertNotNull(period40);
//        org.junit.Assert.assertNotNull(period42);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertNotNull(period46);
//        org.junit.Assert.assertNotNull(period48);
//        org.junit.Assert.assertNotNull(period50);
//        org.junit.Assert.assertNotNull(period52);
//        org.junit.Assert.assertNotNull(intArray54);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-28378000));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2662725960000000L) + "'", long1 == (-2662725960000000L));
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.lang.String str4 = iSOChronology0.toString();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getShortName((long) 0, locale11);
//        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.weekOfWeekyear();
//        long long18 = iSOChronology0.add((long) '4', 110449332000000L, (int) ' ');
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3534378624000052L + "'", long18 == 3534378624000052L);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        long long6 = iSOChronology0.add((org.joda.time.ReadablePeriod) period2, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.DurationField durationField7 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(minutes3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.Period period2 = period0.plusMonths((int) (short) -1);
        try {
            org.joda.time.Weeks weeks3 = period2.toStandardWeeks();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Weeks as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        long long6 = offsetDateTimeField3.roundCeiling(9972000000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10368000000L + "'", long6 == 10368000000L);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean3 = iSOChronology1.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        org.joda.time.ReadableInstant readableInstant10 = null;
//        int int11 = dateTimeZone6.getOffset(readableInstant10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone6);
//        org.joda.time.DurationField durationField13 = zonedChronology12.weekyears();
//        org.joda.time.Period period15 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType16 = null;
//        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
//        org.joda.time.Period period19 = period15.minusSeconds(0);
//        boolean boolean20 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField13, (java.lang.Object) period15);
//        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType22 = periodType21.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType24 = periodType22.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField26 = new org.joda.time.field.ScaledDurationField(durationField13, durationFieldType24, (-1));
//        long long28 = scaledDurationField26.getMillis((-25200000));
//        int int30 = scaledDurationField26.getValue((long) 'a');
//        java.util.TimeZone timeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forTimeZone(timeZone31);
//        java.lang.String str34 = dateTimeZone32.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
//        boolean boolean40 = gregorianChronology35.equals((java.lang.Object) (short) 10);
//        int int41 = gregorianChronology35.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField42 = gregorianChronology35.years();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField43 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, (org.joda.time.DurationField) scaledDurationField26, durationField42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(period15);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(periodType22);
//        org.junit.Assert.assertNotNull(durationFieldType24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 795235190400000000L + "'", long28 == 795235190400000000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PST" + "'", str34.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
//        org.junit.Assert.assertNotNull(durationField42);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-2707200000L));
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.lang.String str4 = iSOChronology0.toString();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getShortName((long) 0, locale11);
//        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 16);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = offsetDateTimeField18.getAsShortText((-25200000), locale20);
//        org.joda.time.ReadablePartial readablePartial22 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Period period26 = org.joda.time.Period.days((int) (byte) 0);
//        org.joda.time.Minutes minutes27 = period26.toStandardMinutes();
//        long long30 = iSOChronology24.add((org.joda.time.ReadablePeriod) period26, (long) (byte) 100, (int) (byte) 100);
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology24.clockhourOfHalfday();
//        org.joda.time.ReadableInstant readableInstant32 = null;
//        org.joda.time.ReadableInstant readableInstant33 = null;
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.yearMonthDay();
//        org.joda.time.Period period35 = new org.joda.time.Period(readableInstant32, readableInstant33, periodType34);
//        org.joda.time.Period period37 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType38 = null;
//        org.joda.time.Period period39 = period37.normalizedStandard(periodType38);
//        org.joda.time.Period period40 = period37.negated();
//        org.joda.time.Period period41 = period35.withFields((org.joda.time.ReadablePeriod) period40);
//        int[] intArray43 = iSOChronology24.get((org.joda.time.ReadablePeriod) period40, 0L);
//        try {
//            int[] intArray45 = offsetDateTimeField18.addWrapPartial(readablePartial22, (int) (byte) 1, intArray43, 28800000);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-25200000" + "'", str21.equals("-25200000"));
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(minutes27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(period37);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertNotNull(period40);
//        org.junit.Assert.assertNotNull(period41);
//        org.junit.Assert.assertNotNull(intArray43);
//    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long27 = scaledDurationField25.getMillis((-25200000));
//        int int29 = scaledDurationField25.getValue((long) 'a');
//        long long32 = scaledDurationField25.getMillis((long) 16, 25200000L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 795235190400000000L + "'", long27 == 795235190400000000L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-504403200000L) + "'", long32 == (-504403200000L));
//    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long28 = scaledDurationField25.getDifferenceAsLong((long) '4', (long) (byte) 100);
//        long long30 = scaledDurationField25.getValueAsLong((-908902361117221990L));
//        java.lang.Object obj31 = null;
//        boolean boolean32 = scaledDurationField25.equals(obj31);
//        boolean boolean34 = scaledDurationField25.equals((java.lang.Object) (byte) 10);
//        long long37 = scaledDurationField25.getValueAsLong((long) (-25199998), 0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28801969L + "'", long30 == 28801969L);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getShortName((long) 0, locale11);
//        java.lang.String str14 = dateTimeZone6.getName(0L);
//        java.lang.String str15 = dateTimeZone6.getID();
//        long long18 = dateTimeZone6.adjustOffset((long) (-1), true);
//        org.joda.time.Chronology chronology19 = gregorianChronology4.withZone(dateTimeZone6);
//        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Pacific Standard Time" + "'", str14.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "America/Los_Angeles" + "'", str15.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(lenientChronology20);
//    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        java.lang.String str14 = dateTimeZone13.getID();
//        org.joda.time.Chronology chronology15 = zonedChronology11.withZone(dateTimeZone13);
//        java.util.TimeZone timeZone16 = dateTimeZone13.toTimeZone();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "America/Los_Angeles" + "'", str14.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(timeZone16);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        int int7 = offsetDateTimeField3.getLeapAmount(100L);
        java.lang.String str8 = offsetDateTimeField3.toString();
        java.lang.String str10 = offsetDateTimeField3.getAsText((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DateTimeField[monthOfYear]" + "'", str8.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "5" + "'", str10.equals("5"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = periodType2.withDaysRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType3);
        org.joda.time.PeriodType periodType5 = periodType3.withDaysRemoved();
        int int6 = periodType3.size();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
//        boolean boolean9 = gregorianChronology4.equals((java.lang.Object) (short) 10);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.yearOfEra();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
//        org.joda.time.Period period5 = period3.withMinutes(0);
//        org.joda.time.Period period7 = period3.withSeconds((-100));
//        org.joda.time.Period period9 = period3.plusHours(10);
//        org.joda.time.Period period11 = period9.plusMonths((int) (short) 0);
//        org.joda.time.Period period13 = period9.plusHours((int) (short) 100);
//        org.joda.time.Period period15 = period9.plusMonths((int) (short) 1);
//        org.joda.time.Duration duration16 = period9.toStandardDuration();
//        org.joda.time.ReadableInstant readableInstant17 = null;
//        org.joda.time.Period period18 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant17);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean21 = iSOChronology19.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.secondOfMinute();
//        java.util.TimeZone timeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone24.getName((long) (byte) 0, locale26);
//        org.joda.time.ReadableInstant readableInstant28 = null;
//        int int29 = dateTimeZone24.getOffset(readableInstant28);
//        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology19, dateTimeZone24);
//        org.joda.time.DurationField durationField31 = zonedChronology30.weekyears();
//        org.joda.time.Period period33 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType34 = null;
//        org.joda.time.Period period35 = period33.normalizedStandard(periodType34);
//        org.joda.time.Period period37 = period33.minusSeconds(0);
//        boolean boolean38 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField31, (java.lang.Object) period33);
//        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType40 = periodType39.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType42 = periodType40.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField44 = new org.joda.time.field.ScaledDurationField(durationField31, durationFieldType42, (-1));
//        boolean boolean45 = period18.isSupported(durationFieldType42);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(durationFieldType42, (java.lang.Number) 2440587.166667824d, (java.lang.Number) 28800032L, (java.lang.Number) (-908840217600422000L));
//        boolean boolean50 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException49);
//        java.lang.String str51 = illegalFieldValueException49.getFieldName();
//        java.lang.Throwable throwable52 = null;
//        try {
//            illegalFieldValueException49.addSuppressed(throwable52);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertNotNull(period9);
//        org.junit.Assert.assertNotNull(period11);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(period15);
//        org.junit.Assert.assertNotNull(duration16);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(period37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(periodType40);
//        org.junit.Assert.assertNotNull(durationFieldType42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "years" + "'", str51.equals("years"));
//    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Period period3 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period5 = period3.withSeconds((-1));
        int int6 = period5.getYears();
        org.joda.time.Period period7 = period1.plus((org.joda.time.ReadablePeriod) period5);
        org.joda.time.Weeks weeks8 = period5.toStandardWeeks();
        org.joda.time.Period period10 = period5.minusMonths(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(weeks8);
        org.junit.Assert.assertNotNull(period10);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology11.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        long long17 = cachedDateTimeZone15.previousTransition((long) (-100));
//        int int19 = cachedDateTimeZone15.getOffset((long) (byte) 0);
//        int int21 = cachedDateTimeZone15.getOffset((-1497600000L));
//        boolean boolean22 = cachedDateTimeZone15.isFixed();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-5756400001L) + "'", long17 == (-5756400001L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("America/Los_Angeles");
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (short) 0, true, (-97L));
//        java.lang.String str7 = dateTimeZone1.getName((long) (short) 0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28800000L + "'", long5 == 28800000L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", 5, 1, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5 for  must be in the range [1,4]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDayTime]", (java.lang.Number) 100.0d, (java.lang.Number) (-97), (java.lang.Number) 10.0d);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-97) + "'", number5.equals((-97)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0d + "'", number6.equals(10.0d));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = period1.normalizedStandard(periodType2);
        org.joda.time.Period period4 = period1.negated();
        org.joda.time.Period period6 = period1.minusSeconds((-100));
        int int7 = period6.getWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        long long9 = gregorianChronology4.getDateTimeMillis((-28800000), (int) (byte) 10, 1, (int) (short) 10);
//        org.joda.time.Chronology chronology10 = gregorianChronology4.withUTC();
//        int int11 = gregorianChronology4.getMinimumDaysInFirstWeek();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-908902361117221990L) + "'", long9 == (-908902361117221990L));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.joda.time.DurationField durationField0 = null;
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, periodType2, chronology3);
//        org.joda.time.Period period6 = period4.withMinutes(0);
//        org.joda.time.Period period8 = period4.withSeconds((-100));
//        org.joda.time.Period period10 = period4.plusHours(10);
//        org.joda.time.Period period12 = period10.plusMonths((int) (short) 0);
//        org.joda.time.Period period14 = period10.plusHours((int) (short) 100);
//        org.joda.time.Period period16 = period10.plusMonths((int) (short) 1);
//        org.joda.time.Duration duration17 = period10.toStandardDuration();
//        org.joda.time.ReadableInstant readableInstant18 = null;
//        org.joda.time.Period period19 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean22 = iSOChronology20.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology20.secondOfMinute();
//        java.util.TimeZone timeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone25.getName((long) (byte) 0, locale27);
//        org.joda.time.ReadableInstant readableInstant29 = null;
//        int int30 = dateTimeZone25.getOffset(readableInstant29);
//        org.joda.time.chrono.ZonedChronology zonedChronology31 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology20, dateTimeZone25);
//        org.joda.time.DurationField durationField32 = zonedChronology31.weekyears();
//        org.joda.time.Period period34 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType35 = null;
//        org.joda.time.Period period36 = period34.normalizedStandard(periodType35);
//        org.joda.time.Period period38 = period34.minusSeconds(0);
//        boolean boolean39 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField32, (java.lang.Object) period34);
//        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType41 = periodType40.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType43 = periodType41.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField45 = new org.joda.time.field.ScaledDurationField(durationField32, durationFieldType43, (-1));
//        boolean boolean46 = period19.isSupported(durationFieldType43);
//        org.joda.time.field.PreciseDurationField preciseDurationField48 = new org.joda.time.field.PreciseDurationField(durationFieldType43, (-1L));
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField50 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType43, 16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(duration17);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Pacific Standard Time" + "'", str28.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-28800000) + "'", int30 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(period34);
//        org.junit.Assert.assertNotNull(period36);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(periodType40);
//        org.junit.Assert.assertNotNull(periodType41);
//        org.junit.Assert.assertNotNull(durationFieldType43);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) -1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(110449332000000L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((-9L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-9) + "'", int1 == (-9));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType3 = periodType2.withDaysRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType3);
        org.joda.time.PeriodType periodType5 = periodType3.withMillisRemoved();
        java.lang.String str6 = periodType3.getName();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "YearDayNoDays" + "'", str6.equals("YearDayNoDays"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period2 = new org.joda.time.Period(obj0, periodType1);
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]");
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("monthOfYear");
        boolean boolean7 = jodaTimePermission4.implies((java.security.Permission) jodaTimePermission6);
        java.lang.Object obj8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period10 = new org.joda.time.Period(obj8, periodType9);
        jodaTimePermission4.checkGuard((java.lang.Object) periodType9);
        org.joda.time.JodaTimePermission jodaTimePermission13 = new org.joda.time.JodaTimePermission("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]");
        org.joda.time.JodaTimePermission jodaTimePermission15 = new org.joda.time.JodaTimePermission("monthOfYear");
        boolean boolean16 = jodaTimePermission13.implies((java.security.Permission) jodaTimePermission15);
        boolean boolean17 = jodaTimePermission4.implies((java.security.Permission) jodaTimePermission13);
        boolean boolean18 = periodType1.equals((java.lang.Object) jodaTimePermission4);
        org.joda.time.PeriodType periodType20 = null;
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period((long) (short) 0, periodType20, chronology21);
        org.joda.time.Period period24 = period22.withMinutes(0);
        org.joda.time.Period period26 = period22.withSeconds((-100));
        org.joda.time.Period period28 = period22.plusHours(10);
        org.joda.time.Period period30 = period28.plusMonths((int) (short) 0);
        org.joda.time.PeriodType periodType32 = null;
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period((long) (short) 0, periodType32, chronology33);
        org.joda.time.Period period36 = period34.withMinutes(0);
        org.joda.time.Period period38 = period34.withSeconds((-100));
        org.joda.time.Period period40 = period34.plusHours(10);
        org.joda.time.Period period42 = period40.plusMonths((int) (short) 0);
        org.joda.time.Period period43 = period28.plus((org.joda.time.ReadablePeriod) period42);
        org.joda.time.Period period45 = period28.withMonths(10);
        org.joda.time.MutablePeriod mutablePeriod46 = period45.toMutablePeriod();
        jodaTimePermission4.checkGuard((java.lang.Object) mutablePeriod46);
        org.joda.time.PeriodType periodType49 = null;
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.Period period51 = new org.joda.time.Period((long) (short) 0, periodType49, chronology50);
        org.joda.time.ReadablePeriod readablePeriod52 = null;
        org.joda.time.Period period53 = period51.minus(readablePeriod52);
        org.joda.time.Period period55 = period51.plusMillis((int) (byte) 100);
        org.joda.time.Period period57 = period55.plusMonths((-25200000));
        jodaTimePermission4.checkGuard((java.lang.Object) (-25200000));
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(mutablePeriod46);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(period57);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period2 = new org.joda.time.Period(obj0, periodType1);
        org.joda.time.PeriodType periodType3 = periodType1.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-210866846400000L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        int int5 = gregorianChronology4.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.minuteOfDay();
//        org.joda.time.DurationField durationField7 = gregorianChronology4.days();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getShortName((long) 0, locale11);
//        java.lang.String str14 = dateTimeZone6.getName(0L);
//        java.lang.String str15 = dateTimeZone6.getID();
//        long long18 = dateTimeZone6.adjustOffset((long) (-1), true);
//        org.joda.time.Chronology chronology19 = gregorianChronology4.withZone(dateTimeZone6);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean22 = iSOChronology20.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology20.secondOfMinute();
//        java.util.TimeZone timeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone25.getName((long) (byte) 0, locale27);
//        org.joda.time.ReadableInstant readableInstant29 = null;
//        int int30 = dateTimeZone25.getOffset(readableInstant29);
//        org.joda.time.chrono.ZonedChronology zonedChronology31 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology20, dateTimeZone25);
//        org.joda.time.DurationField durationField32 = zonedChronology31.weekyears();
//        org.joda.time.DurationField durationField33 = zonedChronology31.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone34 = zonedChronology31.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone35 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone34);
//        long long37 = cachedDateTimeZone35.previousTransition((long) (-100));
//        java.lang.String str39 = cachedDateTimeZone35.getNameKey((long) (short) 10);
//        int int41 = cachedDateTimeZone35.getOffset((-908902361117221990L));
//        org.joda.time.chrono.ZonedChronology zonedChronology42 = org.joda.time.chrono.ZonedChronology.getInstance(chronology19, (org.joda.time.DateTimeZone) cachedDateTimeZone35);
//        java.lang.String str44 = cachedDateTimeZone35.getShortName(77013825840000002L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Pacific Standard Time" + "'", str14.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "America/Los_Angeles" + "'", str15.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Pacific Standard Time" + "'", str28.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-25200000) + "'", int30 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-5756400001L) + "'", long37 == (-5756400001L));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "PST" + "'", str39.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-28378000) + "'", int41 == (-28378000));
//        org.junit.Assert.assertNotNull(zonedChronology42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "PST" + "'", str44.equals("PST"));
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.weekOfWeekyear();
//        try {
//            long long19 = zonedChronology11.getDateTimeMillis(3155846401610L, (int) (short) 1, (int) (short) -1, (int) (byte) 10, 2);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period4 = new org.joda.time.Period(1L, (long) (short) 1, periodType3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (-100), periodType3, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.PeriodType periodType7 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(periodType7);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        boolean boolean17 = dateTimeZone15.isStandardOffset(0L);
//        org.joda.time.Chronology chronology18 = zonedChronology11.withZone(dateTimeZone15);
//        org.joda.time.DurationField durationField19 = zonedChronology11.hours();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long28 = scaledDurationField25.getDifferenceAsLong(2440588L, 0L);
//        long long31 = scaledDurationField25.getValueAsLong((long) (-7), 0L);
//        int int34 = scaledDurationField25.getValue((long) (byte) 1, (long) '#');
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.minuteOfHour();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.lang.String str9 = dateTimeZone7.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        long long15 = gregorianChronology10.getDateTimeMillis((-28800000), (int) (byte) 10, 1, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology10.getZone();
//        boolean boolean17 = gregorianChronology4.equals((java.lang.Object) gregorianChronology10);
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology4.monthOfYear();
//        org.joda.time.DurationField durationField19 = gregorianChronology4.halfdays();
//        try {
//            long long27 = gregorianChronology4.getDateTimeMillis((int) (byte) 0, 5, (int) (short) 100, 5, 28800000, 0, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28800000 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-908902361117221990L) + "'", long15 == (-908902361117221990L));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField19);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.Period period2 = new org.joda.time.Period((long) '#', 0L);
        int int3 = period2.size();
        int int4 = period2.getMonths();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.035 ()", (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d, (java.lang.Number) 10L);
        illegalFieldValueException4.prependMessage("+00:00:00.004");
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.035 ()" + "'", str7.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.035 ()"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period3 = period1.withWeeks((int) '#');
        org.joda.time.Period period5 = period1.minusYears((int) (short) 100);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        boolean boolean7 = period5.isSupported(durationFieldType6);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        boolean boolean5 = offsetDateTimeField3.isLeap((long) 0);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 10, (-25200000));
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(0L);
        org.joda.time.DurationField durationField13 = offsetDateTimeField3.getLeapDurationField();
        try {
            long long16 = offsetDateTimeField3.set((-56999900L), (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [5,16]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "5" + "'", str12.equals("5"));
        org.junit.Assert.assertNotNull(durationField13);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long28 = scaledDurationField25.getDifferenceAsLong((long) '4', (long) (byte) 100);
//        long long30 = scaledDurationField25.getValueAsLong((-908902361117221990L));
//        java.lang.Object obj31 = null;
//        boolean boolean32 = scaledDurationField25.equals(obj31);
//        long long34 = scaledDurationField25.getValueAsLong((-10098432000L));
//        long long37 = scaledDurationField25.add(0L, 2440471L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28801969L + "'", long30 == 28801969L);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-77013825840422000L) + "'", long37 == (-77013825840422000L));
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis((int) ' ', (int) '4', (int) '#', 2, (int) (short) -1, (int) (byte) 1, (-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
//        org.joda.time.PeriodType periodType5 = periodType4.withDaysRemoved();
//        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType5);
//        org.joda.time.PeriodType periodType7 = periodType5.withDaysRemoved();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) 0, (-4L), periodType5, chronology8);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean12 = iSOChronology10.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        int int20 = dateTimeZone15.getOffset(readableInstant19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone15);
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        java.lang.String str24 = dateTimeZone23.getID();
//        org.joda.time.Chronology chronology25 = zonedChronology21.withZone(dateTimeZone23);
//        org.joda.time.DurationField durationField26 = zonedChronology21.hours();
//        org.joda.time.PeriodType periodType28 = null;
//        org.joda.time.Chronology chronology29 = null;
//        org.joda.time.Period period30 = new org.joda.time.Period((-1L), periodType28, chronology29);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Period period33 = org.joda.time.Period.days((int) (byte) 0);
//        org.joda.time.Minutes minutes34 = period33.toStandardMinutes();
//        long long37 = iSOChronology31.add((org.joda.time.ReadablePeriod) period33, (long) (byte) 100, (int) (byte) 100);
//        org.joda.time.Period period39 = period33.withDays((-1));
//        org.joda.time.Period period40 = period30.plus((org.joda.time.ReadablePeriod) period33);
//        java.lang.Object obj41 = null;
//        org.joda.time.PeriodType periodType42 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period43 = new org.joda.time.Period(obj41, periodType42);
//        org.joda.time.Period period44 = period30.normalizedStandard(periodType42);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean47 = iSOChronology45.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField48 = iSOChronology45.secondOfMinute();
//        java.util.TimeZone timeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forTimeZone(timeZone49);
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = dateTimeZone50.getName((long) (byte) 0, locale52);
//        org.joda.time.ReadableInstant readableInstant54 = null;
//        int int55 = dateTimeZone50.getOffset(readableInstant54);
//        org.joda.time.chrono.ZonedChronology zonedChronology56 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology45, dateTimeZone50);
//        org.joda.time.DurationField durationField57 = zonedChronology56.weekyears();
//        org.joda.time.Period period59 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType60 = null;
//        org.joda.time.Period period61 = period59.normalizedStandard(periodType60);
//        org.joda.time.Period period63 = period59.minusSeconds(0);
//        boolean boolean64 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField57, (java.lang.Object) period59);
//        org.joda.time.PeriodType periodType65 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType66 = periodType65.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType68 = periodType66.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField70 = new org.joda.time.field.ScaledDurationField(durationField57, durationFieldType68, (-1));
//        java.lang.Number number73 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException74 = new org.joda.time.IllegalFieldValueException(durationFieldType68, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number73);
//        org.joda.time.field.PreciseDurationField preciseDurationField76 = new org.joda.time.field.PreciseDurationField(durationFieldType68, (long) 100);
//        boolean boolean77 = periodType42.isSupported(durationFieldType68);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField78 = new org.joda.time.field.DecoratedDurationField(durationField26, durationFieldType68);
//        try {
//            org.joda.time.Period period80 = period9.withField(durationFieldType68, 8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType4);
//        org.junit.Assert.assertNotNull(periodType5);
//        org.junit.Assert.assertNotNull(periodType7);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-25200000) + "'", int20 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "America/Los_Angeles" + "'", str24.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(minutes34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertNotNull(period40);
//        org.junit.Assert.assertNotNull(periodType42);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Pacific Standard Time" + "'", str53.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-25200000) + "'", int55 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology56);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(period59);
//        org.junit.Assert.assertNotNull(period61);
//        org.junit.Assert.assertNotNull(period63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(periodType65);
//        org.junit.Assert.assertNotNull(periodType66);
//        org.junit.Assert.assertNotNull(durationFieldType68);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
//    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.weekOfWeekyear();
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 0, periodType15, chronology16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.Period period19 = period17.minus(readablePeriod18);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.Period period21 = period17.normalizedStandard(periodType20);
//        long long24 = zonedChronology11.add((org.joda.time.ReadablePeriod) period21, 28800000L, (int) (short) 1);
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period21.normalizedStandard(periodType25);
//        org.joda.time.MutablePeriod mutablePeriod27 = period21.toMutablePeriod();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28800000L + "'", long24 == 28800000L);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(mutablePeriod27);
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(908902361117222000L, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 908902361117222000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int7 = offsetDateTimeField3.getDifference((long) 4, (long) '#');
        int int8 = offsetDateTimeField3.getMaximumValue();
        long long11 = offsetDateTimeField3.add((-5756400001L), (-28378000));
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType12, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-74626937766000001L) + "'", long11 == (-74626937766000001L));
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long27 = scaledDurationField25.getMillis((-25200000));
//        int int29 = scaledDurationField25.getValue((long) 'a');
//        long long32 = scaledDurationField25.add((-908902361117221990L), 28800000);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 795235190400000000L + "'", long27 == 795235190400000000L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1817742578717221990L) + "'", long32 == (-1817742578717221990L));
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        java.lang.Number number28 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number28);
//        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType23, (long) 100);
//        int int33 = preciseDurationField31.getValue((long) (byte) 10);
//        boolean boolean34 = preciseDurationField31.isSupported();
//        long long35 = preciseDurationField31.getUnitMillis();
//        long long38 = preciseDurationField31.getMillis(110449332000000L, (-210866846400000L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 11044933200000000L + "'", long38 == 11044933200000000L);
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = offsetDateTimeField3.getMaximumValue(readablePartial5);
        java.lang.String str8 = offsetDateTimeField3.getAsText(6682L);
        boolean boolean9 = offsetDateTimeField3.isSupported();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5" + "'", str8.equals("5"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        java.lang.Number number28 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number28);
//        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType23, (long) 100);
//        long long34 = preciseDurationField31.getValueAsLong((-1009411200001L), 28799999L);
//        long long37 = preciseDurationField31.add(100L, (-10L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-10094112000L) + "'", long34 == (-10094112000L));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-900L) + "'", long37 == (-900L));
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDayTime]", (java.lang.Number) 100.0d, (java.lang.Number) (-97), (java.lang.Number) 10.0d);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number9 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number10 = illegalFieldValueException4.getUpperBound();
        java.lang.String str11 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-97) + "'", number5.equals((-97)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-97) + "'", number8.equals((-97)));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100.0d + "'", number9.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10.0d + "'", number10.equals(10.0d));
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-2678399900L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440556.5000011576d + "'", double1 == 2440556.5000011576d);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology11.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        long long17 = cachedDateTimeZone15.previousTransition((long) (-100));
//        int int19 = cachedDateTimeZone15.getStandardOffset(0L);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, 4);
//        boolean boolean24 = cachedDateTimeZone15.equals((java.lang.Object) dateTimeField21);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-5756400001L) + "'", long17 == (-5756400001L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.weekOfWeekyear();
//        try {
//            long long18 = zonedChronology11.getDateTimeMillis((-100), (int) (byte) 1, (int) (byte) 10, (-9));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -9 for millisOfDay must be in the range [0,86399999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int7 = offsetDateTimeField3.getDifference((long) 4, (long) '#');
        long long9 = offsetDateTimeField3.remainder(0L);
        int int11 = offsetDateTimeField3.getLeapAmount((long) 10);
        int int12 = offsetDateTimeField3.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField3.getAsText(readablePartial13, (int) (byte) 10, locale15);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10" + "'", str16.equals("10"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = offsetDateTimeField3.getMaximumValue(readablePartial5);
        java.lang.String str8 = offsetDateTimeField3.getAsText(6682L);
        long long11 = offsetDateTimeField3.add((-908902361117221990L), 5);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField3.getMaximumTextLength(locale12);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5" + "'", str8.equals("5"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-908902348070821990L) + "'", long11 == (-908902348070821990L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology11.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        java.lang.Object obj16 = new java.lang.Object();
//        boolean boolean17 = cachedDateTimeZone15.equals(obj16);
//        long long19 = cachedDateTimeZone15.previousTransition(28800000L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-5756400001L) + "'", long19 == (-5756400001L));
//    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.lang.String str4 = iSOChronology0.toString();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getShortName((long) 0, locale11);
//        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone6);
//        org.joda.time.Chronology chronology14 = iSOChronology0.withUTC();
//        org.joda.time.chrono.LenientChronology lenientChronology15 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.clockhourOfHalfday();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(lenientChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }
//}

