import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test001");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
//        boolean boolean9 = gregorianChronology4.equals((java.lang.Object) (short) 10);
//        int int10 = gregorianChronology4.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology4.year();
//        org.joda.time.DurationField durationField12 = gregorianChronology4.hours();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(durationField12);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period5 = period3.minusWeeks((-28378000));
        int int6 = period5.getMillis();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) ' ');
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test004");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long28 = scaledDurationField25.getDifferenceAsLong(2440588L, 0L);
//        long long31 = scaledDurationField25.getValueAsLong((long) (-7), 0L);
//        try {
//            long long33 = scaledDurationField25.getMillis((-252455616000L));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 252455616000 * 31556952000");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test005");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int5 = offsetDateTimeField3.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 5200L, "");
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean12 = iSOChronology10.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        int int20 = dateTimeZone15.getOffset(readableInstant19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone15);
//        org.joda.time.DurationField durationField22 = zonedChronology21.weekyears();
//        org.joda.time.Period period24 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period24.normalizedStandard(periodType25);
//        org.joda.time.Period period28 = period24.minusSeconds(0);
//        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField22, (java.lang.Object) period24);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType31 = periodType30.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (-1));
//        long long37 = scaledDurationField35.getMillis((long) 'a');
//        int int40 = scaledDurationField35.getDifference(0L, (-31556952000L));
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, (org.joda.time.DurationField) scaledDurationField35);
//        long long44 = unsupportedDateTimeField41.add(2678400001L, (-57601969));
//        try {
//            long long46 = unsupportedDateTimeField41.roundCeiling((long) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28800000) + "'", int20 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3061024344000L) + "'", long37 == (-3061024344000L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1817742573820800001L + "'", long44 == 1817742573820800001L);
//    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test006");
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period((-1L), periodType1, chronology2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Period period6 = org.joda.time.Period.days((int) (byte) 0);
//        org.joda.time.Minutes minutes7 = period6.toStandardMinutes();
//        long long10 = iSOChronology4.add((org.joda.time.ReadablePeriod) period6, (long) (byte) 100, (int) (byte) 100);
//        org.joda.time.Period period12 = period6.withDays((-1));
//        org.joda.time.Period period13 = period3.plus((org.joda.time.ReadablePeriod) period6);
//        java.lang.Object obj14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period16 = new org.joda.time.Period(obj14, periodType15);
//        org.joda.time.Period period17 = period3.normalizedStandard(periodType15);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean20 = iSOChronology18.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology18.secondOfMinute();
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone23.getName((long) (byte) 0, locale25);
//        org.joda.time.ReadableInstant readableInstant27 = null;
//        int int28 = dateTimeZone23.getOffset(readableInstant27);
//        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology18, dateTimeZone23);
//        org.joda.time.DurationField durationField30 = zonedChronology29.weekyears();
//        org.joda.time.Period period32 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType33 = null;
//        org.joda.time.Period period34 = period32.normalizedStandard(periodType33);
//        org.joda.time.Period period36 = period32.minusSeconds(0);
//        boolean boolean37 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField30, (java.lang.Object) period32);
//        org.joda.time.PeriodType periodType38 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType39 = periodType38.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField43 = new org.joda.time.field.ScaledDurationField(durationField30, durationFieldType41, (-1));
//        java.lang.Number number46 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException47 = new org.joda.time.IllegalFieldValueException(durationFieldType41, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number46);
//        org.joda.time.field.PreciseDurationField preciseDurationField49 = new org.joda.time.field.PreciseDurationField(durationFieldType41, (long) 100);
//        boolean boolean50 = periodType15.isSupported(durationFieldType41);
//        org.joda.time.field.PreciseDurationField preciseDurationField52 = new org.joda.time.field.PreciseDurationField(durationFieldType41, (-2707200000L));
//        boolean boolean53 = preciseDurationField52.isPrecise();
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(minutes7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pacific Standard Time" + "'", str26.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-28800000) + "'", int28 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(period34);
//        org.junit.Assert.assertNotNull(period36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(periodType38);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(durationFieldType41);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset(0L);
        java.lang.String str4 = dateTimeZone1.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(4);
        long long8 = dateTimeZone1.getMillisKeepLocal(dateTimeZone6, 28800000L);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone10 = iSOChronology9.getZone();
        org.joda.time.DurationField durationField11 = iSOChronology9.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("PeriodType[YearDay]", "org.joda.time.IllegalFieldValueException: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]", (int) (short) -1, (-100));
        java.util.TimeZone timeZone17 = fixedDateTimeZone16.toTimeZone();
        java.lang.String str19 = fixedDateTimeZone16.getNameKey(0L);
        long long21 = fixedDateTimeZone16.nextTransition(2440471L);
        org.joda.time.Chronology chronology22 = iSOChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-4L) + "'", long8 == (-4L));
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]" + "'", str19.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2440471L + "'", long21 == 2440471L);
        org.junit.Assert.assertNotNull(chronology22);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test008");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int5 = offsetDateTimeField3.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 5200L, "");
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean12 = iSOChronology10.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        int int20 = dateTimeZone15.getOffset(readableInstant19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone15);
//        org.joda.time.DurationField durationField22 = zonedChronology21.weekyears();
//        org.joda.time.Period period24 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period24.normalizedStandard(periodType25);
//        org.joda.time.Period period28 = period24.minusSeconds(0);
//        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField22, (java.lang.Object) period24);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType31 = periodType30.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (-1));
//        long long37 = scaledDurationField35.getMillis((long) 'a');
//        int int40 = scaledDurationField35.getDifference(0L, (-31556952000L));
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, (org.joda.time.DurationField) scaledDurationField35);
//        org.joda.time.DurationField durationField42 = unsupportedDateTimeField41.getDurationField();
//        java.util.Locale locale44 = null;
//        try {
//            java.lang.String str45 = unsupportedDateTimeField41.getAsText(5, locale44);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28800000) + "'", int20 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3061024344000L) + "'", long37 == (-3061024344000L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertNotNull(durationField42);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        long long5 = offsetDateTimeField3.roundFloor((long) (short) -1);
        int int7 = offsetDateTimeField3.getLeapAmount(0L);
        int int8 = offsetDateTimeField3.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2678400000L) + "'", long5 == (-2678400000L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology4.era();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str10 = offsetDateTimeField9.getName();
        int int11 = offsetDateTimeField9.getOffset();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType12);
        long long15 = zeroIsMaxDateTimeField13.remainder((long) (-7));
        int int16 = zeroIsMaxDateTimeField13.getMinimumValue();
        long long18 = zeroIsMaxDateTimeField13.roundCeiling((-3687056755200422000L));
        long long21 = zeroIsMaxDateTimeField13.addWrapField(26784000L, (-25199998));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "monthOfYear" + "'", str10.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 62135946599993L + "'", long15 == 62135946599993L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62135946600000L) + "'", long18 == (-62135946600000L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 26784000L + "'", long21 == 26784000L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = period1.normalizedStandard(periodType2);
        org.joda.time.Period period5 = period3.withWeeks((-10));
        org.joda.time.Period period7 = period5.multipliedBy((-25199998));
        org.joda.time.Period period9 = period5.minusMinutes((-1));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(100, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 800 + "'", int2 == 800);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test013");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfMonth();
//        org.joda.time.Period period10 = new org.joda.time.Period((-10), (int) (short) -1, (-10), (int) (short) 0);
//        org.joda.time.Days days11 = period10.toStandardDays();
//        boolean boolean12 = gregorianChronology4.equals((java.lang.Object) period10);
//        org.joda.time.DurationField durationField13 = gregorianChronology4.hours();
//        org.joda.time.DurationFieldType durationFieldType14 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField13, durationFieldType14, (-97));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(days11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField5 = iSOChronology0.hours();
        org.joda.time.DurationField durationField6 = iSOChronology0.millis();
        org.joda.time.DurationField durationField7 = iSOChronology0.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDay();
        java.lang.String str3 = periodType2.toString();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int5 = periodType2.size();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[YearDay]" + "'", str3.equals("PeriodType[YearDay]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period3 = period1.withDays((int) ' ');
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test018");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField12 = zonedChronology11.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean16 = iSOChronology14.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.secondOfMinute();
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone19.getName((long) (byte) 0, locale21);
//        org.joda.time.ReadableInstant readableInstant23 = null;
//        int int24 = dateTimeZone19.getOffset(readableInstant23);
//        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, dateTimeZone19);
//        org.joda.time.DurationField durationField26 = zonedChronology25.weekyears();
//        org.joda.time.DurationField durationField27 = zonedChronology25.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone28 = zonedChronology25.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone29 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone28);
//        java.lang.Object obj30 = new java.lang.Object();
//        boolean boolean31 = cachedDateTimeZone29.equals(obj30);
//        long long33 = cachedDateTimeZone29.nextTransition(0L);
//        int int35 = cachedDateTimeZone29.getStandardOffset((-10L));
//        org.joda.time.Chronology chronology36 = zonedChronology11.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone29);
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField39 = iSOChronology38.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 4);
//        java.lang.String str42 = offsetDateTimeField41.getName();
//        int int45 = offsetDateTimeField41.getDifference((long) 4, (long) '#');
//        org.joda.time.ReadablePartial readablePartial46 = null;
//        int[] intArray50 = new int[] { (byte) 100, 4, ' ' };
//        int int51 = offsetDateTimeField41.getMinimumValue(readablePartial46, intArray50);
//        try {
//            zonedChronology11.validate(readablePartial37, intArray50);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Pacific Standard Time" + "'", str22.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-25200000) + "'", int24 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9972000000L + "'", long33 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-28800000) + "'", int35 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "monthOfYear" + "'", str42.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 5 + "'", int51 == 5);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        long long5 = offsetDateTimeField3.roundFloor((long) (short) -1);
        java.lang.String str7 = offsetDateTimeField3.getAsText(0L);
        long long9 = offsetDateTimeField3.roundHalfCeiling((long) (short) -1);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText(readablePartial10, 100, locale12);
        int int15 = offsetDateTimeField3.getLeapAmount((-31556952000L));
        int int17 = offsetDateTimeField3.getLeapAmount((long) 4);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField3.getAsText(readablePartial18, 800, locale20);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2678400000L) + "'", long5 == (-2678400000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "5" + "'", str7.equals("5"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "800" + "'", str21.equals("800"));
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test020");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int5 = offsetDateTimeField3.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 5200L, "");
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean12 = iSOChronology10.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        int int20 = dateTimeZone15.getOffset(readableInstant19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone15);
//        org.joda.time.DurationField durationField22 = zonedChronology21.weekyears();
//        org.joda.time.Period period24 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period24.normalizedStandard(periodType25);
//        org.joda.time.Period period28 = period24.minusSeconds(0);
//        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField22, (java.lang.Object) period24);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType31 = periodType30.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (-1));
//        long long37 = scaledDurationField35.getMillis((long) 'a');
//        int int40 = scaledDurationField35.getDifference(0L, (-31556952000L));
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, (org.joda.time.DurationField) scaledDurationField35);
//        try {
//            long long43 = unsupportedDateTimeField41.roundFloor((long) 4);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-25200000) + "'", int20 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3061024344000L) + "'", long37 == (-3061024344000L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test021");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology4.era();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
//        java.lang.String str10 = offsetDateTimeField9.getName();
//        int int11 = offsetDateTimeField9.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType12);
//        int int14 = zeroIsMaxDateTimeField13.getMinimumValue();
//        long long16 = zeroIsMaxDateTimeField13.roundCeiling((long) 'a');
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean22 = iSOChronology20.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology20.secondOfMinute();
//        java.lang.String str24 = iSOChronology20.toString();
//        java.util.TimeZone timeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forTimeZone(timeZone25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = dateTimeZone26.getName((long) (byte) 0, locale28);
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = dateTimeZone26.getShortName((long) 0, locale31);
//        org.joda.time.Chronology chronology33 = iSOChronology20.withZone(dateTimeZone26);
//        org.joda.time.Chronology chronology34 = iSOChronology20.withUTC();
//        org.joda.time.Period period35 = new org.joda.time.Period(157248000000L, chronology34);
//        int[] intArray36 = period35.getValues();
//        try {
//            int[] intArray38 = zeroIsMaxDateTimeField13.set(readablePartial17, (-1), intArray36, 800);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 800 for monthOfYear must be in the range [1,2]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(lenientChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "monthOfYear" + "'", str10.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036504975807L + "'", long16 == 9223372036504975807L);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[UTC]" + "'", str24.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Pacific Standard Time" + "'", str29.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PST" + "'", str32.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(intArray36);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((-25199998), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-25199998) + "'", int2 == (-25199998));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) 1, (java.lang.Number) 16, (java.lang.Number) 9972000000L);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType5);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test024");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int5 = offsetDateTimeField3.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 5200L, "");
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean12 = iSOChronology10.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        int int20 = dateTimeZone15.getOffset(readableInstant19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone15);
//        org.joda.time.DurationField durationField22 = zonedChronology21.weekyears();
//        org.joda.time.Period period24 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period24.normalizedStandard(periodType25);
//        org.joda.time.Period period28 = period24.minusSeconds(0);
//        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField22, (java.lang.Object) period24);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType31 = periodType30.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (-1));
//        long long37 = scaledDurationField35.getMillis((long) 'a');
//        int int40 = scaledDurationField35.getDifference(0L, (-31556952000L));
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, (org.joda.time.DurationField) scaledDurationField35);
//        long long44 = unsupportedDateTimeField41.add(2678400001L, (-57601969));
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        java.util.Locale locale47 = null;
//        try {
//            java.lang.String str48 = unsupportedDateTimeField41.getAsShortText(readablePartial45, (int) '#', locale47);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-25200000) + "'", int20 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3061024344000L) + "'", long37 == (-3061024344000L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1817742573820800001L + "'", long44 == 1817742573820800001L);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int7 = offsetDateTimeField3.getDifference((long) 4, (long) '#');
        long long9 = offsetDateTimeField3.roundHalfCeiling((long) (-28800000));
        int int11 = offsetDateTimeField3.getLeapAmount(28800000L);
        long long14 = offsetDateTimeField3.add(0L, (int) (byte) 0);
        long long16 = offsetDateTimeField3.roundHalfCeiling((-5756400001L));
        long long19 = offsetDateTimeField3.add((long) 'a', (int) (short) 10);
        org.joda.time.DurationField durationField20 = offsetDateTimeField3.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-5270400000L) + "'", long16 == (-5270400000L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 26265600097L + "'", long19 == 26265600097L);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int7 = offsetDateTimeField3.getDifference((long) 4, (long) '#');
        long long9 = offsetDateTimeField3.remainder(0L);
        int int11 = offsetDateTimeField3.getLeapAmount((long) 10);
        int int12 = offsetDateTimeField3.getMaximumValue();
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumTextLength(locale13);
        int int16 = offsetDateTimeField3.getLeapAmount((-210866760000000L));
        long long18 = offsetDateTimeField3.roundCeiling((-900L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period4 = new org.joda.time.Period(1L, (long) (short) 1, periodType3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (-100), periodType3, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.chrono.LenientChronology lenientChronology7 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology8 = iSOChronology5.withUTC();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(lenientChronology7);
        org.junit.Assert.assertNotNull(chronology8);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test028");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        java.lang.Number number28 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number28);
//        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType23, (long) 100);
//        java.lang.Object obj32 = null;
//        boolean boolean33 = preciseDurationField31.equals(obj32);
//        long long36 = preciseDurationField31.getValueAsLong((-210866760000000L), (long) 5);
//        long long39 = preciseDurationField31.getMillis(40, 795235190400000000L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-2108667600000L) + "'", long36 == (-2108667600000L));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 4000L + "'", long39 == 4000L);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period3 = period1.withWeeks((int) '#');
        org.joda.time.Period period5 = period3.minusHours(419);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("0", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test031");
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
//        org.joda.time.Period period5 = period3.withMinutes(0);
//        org.joda.time.Period period7 = period3.withSeconds((-100));
//        org.joda.time.Period period9 = period3.plusHours(10);
//        org.joda.time.Period period11 = period9.plusMonths((int) (short) 0);
//        org.joda.time.Period period13 = period9.plusHours((int) (short) 100);
//        org.joda.time.Period period15 = period9.plusMonths((int) (short) 1);
//        org.joda.time.Duration duration16 = period9.toStandardDuration();
//        org.joda.time.ReadableInstant readableInstant17 = null;
//        org.joda.time.Period period18 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant17);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean21 = iSOChronology19.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.secondOfMinute();
//        java.util.TimeZone timeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone24.getName((long) (byte) 0, locale26);
//        org.joda.time.ReadableInstant readableInstant28 = null;
//        int int29 = dateTimeZone24.getOffset(readableInstant28);
//        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology19, dateTimeZone24);
//        org.joda.time.DurationField durationField31 = zonedChronology30.weekyears();
//        org.joda.time.Period period33 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType34 = null;
//        org.joda.time.Period period35 = period33.normalizedStandard(periodType34);
//        org.joda.time.Period period37 = period33.minusSeconds(0);
//        boolean boolean38 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField31, (java.lang.Object) period33);
//        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType40 = periodType39.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType42 = periodType40.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField44 = new org.joda.time.field.ScaledDurationField(durationField31, durationFieldType42, (-1));
//        boolean boolean45 = period18.isSupported(durationFieldType42);
//        org.joda.time.field.PreciseDurationField preciseDurationField47 = new org.joda.time.field.PreciseDurationField(durationFieldType42, (-1L));
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, 4);
//        java.lang.String str52 = offsetDateTimeField51.getName();
//        org.joda.time.ReadablePartial readablePartial53 = null;
//        int int54 = offsetDateTimeField51.getMaximumValue(readablePartial53);
//        java.lang.String str56 = offsetDateTimeField51.getAsText(6682L);
//        org.joda.time.DurationField durationField57 = offsetDateTimeField51.getLeapDurationField();
//        boolean boolean58 = preciseDurationField47.equals((java.lang.Object) offsetDateTimeField51);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertNotNull(period9);
//        org.junit.Assert.assertNotNull(period11);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(period15);
//        org.junit.Assert.assertNotNull(duration16);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-25200000) + "'", int29 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(period37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(periodType40);
//        org.junit.Assert.assertNotNull(durationFieldType42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "monthOfYear" + "'", str52.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 16 + "'", int54 == 16);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "5" + "'", str56.equals("5"));
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test032");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int5 = offsetDateTimeField3.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 5200L, "");
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean12 = iSOChronology10.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        int int20 = dateTimeZone15.getOffset(readableInstant19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone15);
//        org.joda.time.DurationField durationField22 = zonedChronology21.weekyears();
//        org.joda.time.Period period24 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period24.normalizedStandard(periodType25);
//        org.joda.time.Period period28 = period24.minusSeconds(0);
//        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField22, (java.lang.Object) period24);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType31 = periodType30.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (-1));
//        long long37 = scaledDurationField35.getMillis((long) 'a');
//        int int40 = scaledDurationField35.getDifference(0L, (-31556952000L));
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, (org.joda.time.DurationField) scaledDurationField35);
//        long long44 = unsupportedDateTimeField41.add(2678400001L, (-57601969));
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        int[] intArray46 = null;
//        try {
//            int int47 = unsupportedDateTimeField41.getMinimumValue(readablePartial45, intArray46);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-25200000) + "'", int20 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3061024344000L) + "'", long37 == (-3061024344000L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1817742573820800001L + "'", long44 == 1817742573820800001L);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test033");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        java.lang.Number number28 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number28);
//        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType23, (long) 100);
//        int int33 = preciseDurationField31.getValue((long) (byte) 10);
//        boolean boolean34 = preciseDurationField31.isSupported();
//        boolean boolean35 = preciseDurationField31.isPrecise();
//        long long38 = preciseDurationField31.add(2721600000L, 0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2721600000L + "'", long38 == 2721600000L);
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test034");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int5 = offsetDateTimeField3.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 5200L, "");
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean12 = iSOChronology10.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        int int20 = dateTimeZone15.getOffset(readableInstant19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone15);
//        org.joda.time.DurationField durationField22 = zonedChronology21.weekyears();
//        org.joda.time.Period period24 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period24.normalizedStandard(periodType25);
//        org.joda.time.Period period28 = period24.minusSeconds(0);
//        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField22, (java.lang.Object) period24);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType31 = periodType30.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (-1));
//        long long37 = scaledDurationField35.getMillis((long) 'a');
//        int int40 = scaledDurationField35.getDifference(0L, (-31556952000L));
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, (org.joda.time.DurationField) scaledDurationField35);
//        org.joda.time.DurationField durationField42 = unsupportedDateTimeField41.getDurationField();
//        org.joda.time.DurationField durationField43 = unsupportedDateTimeField41.getDurationField();
//        org.joda.time.ReadablePartial readablePartial44 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField47 = iSOChronology46.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, 4);
//        java.lang.String str50 = offsetDateTimeField49.getName();
//        org.joda.time.ReadablePartial readablePartial51 = null;
//        int int52 = offsetDateTimeField49.getMaximumValue(readablePartial51);
//        java.lang.String str54 = offsetDateTimeField49.getAsText(6682L);
//        long long56 = offsetDateTimeField49.remainder(0L);
//        org.joda.time.ReadablePartial readablePartial57 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Period period61 = org.joda.time.Period.days((int) (byte) 0);
//        org.joda.time.Minutes minutes62 = period61.toStandardMinutes();
//        long long65 = iSOChronology59.add((org.joda.time.ReadablePeriod) period61, (long) (byte) 100, (int) (byte) 100);
//        org.joda.time.DurationField durationField66 = iSOChronology59.weeks();
//        long long70 = iSOChronology59.add((-4L), (long) (byte) 1, 4);
//        org.joda.time.ReadableInstant readableInstant71 = null;
//        org.joda.time.ReadableInstant readableInstant72 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology73 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Period period75 = org.joda.time.Period.days((int) (byte) 0);
//        org.joda.time.Minutes minutes76 = period75.toStandardMinutes();
//        long long79 = iSOChronology73.add((org.joda.time.ReadablePeriod) period75, (long) (byte) 100, (int) (byte) 100);
//        org.joda.time.Duration duration80 = period75.toStandardDuration();
//        org.joda.time.ReadableInstant readableInstant81 = null;
//        org.joda.time.PeriodType periodType82 = org.joda.time.PeriodType.hours();
//        org.joda.time.Period period83 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration80, readableInstant81, periodType82);
//        org.joda.time.Period period84 = new org.joda.time.Period(readableInstant72, (org.joda.time.ReadableDuration) duration80);
//        org.joda.time.Period period85 = new org.joda.time.Period(readableInstant71, (org.joda.time.ReadableDuration) duration80);
//        int[] intArray88 = iSOChronology59.get((org.joda.time.ReadablePeriod) period85, (long) 0, (long) (short) 10);
//        int[] intArray90 = offsetDateTimeField49.addWrapPartial(readablePartial57, (-25200000), intArray88, 0);
//        try {
//            int[] intArray92 = unsupportedDateTimeField41.addWrapField(readablePartial44, 800, intArray90, 800);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-25200000) + "'", int20 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3061024344000L) + "'", long37 == (-3061024344000L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(iSOChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "monthOfYear" + "'", str50.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 16 + "'", int52 == 16);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "5" + "'", str54.equals("5"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(period61);
//        org.junit.Assert.assertNotNull(minutes62);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 100L + "'", long65 == 100L);
//        org.junit.Assert.assertNotNull(durationField66);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology73);
//        org.junit.Assert.assertNotNull(period75);
//        org.junit.Assert.assertNotNull(minutes76);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 100L + "'", long79 == 100L);
//        org.junit.Assert.assertNotNull(duration80);
//        org.junit.Assert.assertNotNull(periodType82);
//        org.junit.Assert.assertNotNull(intArray88);
//        org.junit.Assert.assertNotNull(intArray90);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        long long7 = offsetDateTimeField3.roundCeiling((long) (byte) 1);
        boolean boolean9 = offsetDateTimeField3.isLeap((long) (byte) -1);
        long long12 = offsetDateTimeField3.add((long) (byte) 0, (-3499));
        try {
            long long15 = offsetDateTimeField3.set((-908902348099200000L), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [5,16]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2678400000L + "'", long7 == 2678400000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9201513600000L) + "'", long12 == (-9201513600000L));
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test036");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        java.lang.String str14 = dateTimeZone13.getID();
//        org.joda.time.Chronology chronology15 = zonedChronology11.withZone(dateTimeZone13);
//        org.joda.time.DurationField durationField16 = zonedChronology11.months();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "America/Los_Angeles" + "'", str14.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) 10);
        int int2 = period1.getWeeks();
        try {
            org.joda.time.Duration duration3 = period1.toStandardDuration();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Duration as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test038");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        long long9 = gregorianChronology4.getDateTimeMillis((-28800000), (int) (byte) 10, 1, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology4.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
//        boolean boolean12 = cachedDateTimeZone11.isFixed();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-908902361117221990L) + "'", long9 == (-908902361117221990L));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test039");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        java.util.TimeZone timeZone4 = dateTimeZone1.toTimeZone();
//        java.lang.String str6 = dateTimeZone1.getShortName((-77013825840422000L));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-07:52:58" + "'", str6.equals("-07:52:58"));
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("PST", (int) (short) 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("org.joda.time.IllegalFieldValueException: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]", (-97));
        java.io.DataOutput dataOutput8 = null;
        try {
            dateTimeZoneBuilder6.writeTo("-10", dataOutput8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes4 = period3.toStandardMinutes();
        long long7 = iSOChronology1.add((org.joda.time.ReadablePeriod) period3, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.Duration duration8 = period3.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType10);
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8);
        org.joda.time.Period period14 = period12.withMinutes(8);
        org.joda.time.DurationFieldType[] durationFieldTypeArray15 = period12.getFieldTypes();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(minutes4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(durationFieldTypeArray15);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int7 = offsetDateTimeField3.getDifference((long) 4, (long) '#');
        long long9 = offsetDateTimeField3.roundHalfCeiling((long) (-28800000));
        int int11 = offsetDateTimeField3.getLeapAmount(28800000L);
        long long13 = offsetDateTimeField3.roundFloor((-10098432000L));
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean18 = iSOChronology16.equals((java.lang.Object) (short) 0);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.clockhourOfDay();
        org.joda.time.PeriodType periodType21 = null;
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period((long) (short) 0, periodType21, chronology22);
        org.joda.time.Period period25 = period23.withMinutes(0);
        org.joda.time.Period period27 = period23.withSeconds((-100));
        org.joda.time.Period period29 = period23.plusHours(10);
        org.joda.time.Period period31 = period29.plusMonths((int) (short) 0);
        org.joda.time.Period period33 = period29.plusHours((int) (short) 100);
        org.joda.time.Period period35 = period29.plusMonths((int) (short) 1);
        int[] intArray38 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) (-25199998), (long) (short) 100);
        try {
            int[] intArray40 = offsetDateTimeField3.addWrapPartial(readablePartial14, (-9), intArray38, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10540800000L) + "'", long13 == (-10540800000L));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(intArray38);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology4.era();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str10 = offsetDateTimeField9.getName();
        int int11 = offsetDateTimeField9.getOffset();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType12);
        long long15 = zeroIsMaxDateTimeField13.remainder((long) (-7));
        int int16 = zeroIsMaxDateTimeField13.getMinimumValue();
        try {
            long long19 = zeroIsMaxDateTimeField13.add(795235190400000000L, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "monthOfYear" + "'", str10.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 62135946599993L + "'", long15 == 62135946599993L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = period1.normalizedStandard(periodType2);
        org.joda.time.Period period5 = period3.withWeeks((-10));
        org.joda.time.Weeks weeks6 = period5.toStandardWeeks();
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, periodType8, chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.Period period12 = period10.minus(readablePeriod11);
        org.joda.time.Period period14 = period12.plusDays((int) (byte) -1);
        org.joda.time.Period period15 = period5.withFields((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period17 = period12.plusMinutes((-97));
        org.joda.time.Period period18 = period17.negated();
        int int20 = period18.getValue((int) (short) 1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(weeks6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test047");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField12 = zonedChronology11.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.weekyear();
//        org.joda.time.DateTimeField dateTimeField14 = zonedChronology11.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = zonedChronology11.hourOfHalfday();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes4 = period3.toStandardMinutes();
        long long7 = iSOChronology1.add((org.joda.time.ReadablePeriod) period3, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.Duration duration8 = period3.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType10);
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8);
        org.joda.time.PeriodType periodType14 = null;
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((-1L), periodType14, chronology15);
        org.joda.time.Period period18 = period16.minusMonths((int) (byte) 100);
        org.joda.time.Period period19 = period12.plus((org.joda.time.ReadablePeriod) period16);
        org.joda.time.Period period21 = period12.plusHours((int) (short) -1);
        org.joda.time.Period period22 = period12.toPeriod();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(minutes4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period22);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test049");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long28 = scaledDurationField25.getDifferenceAsLong((long) '4', (long) (byte) 100);
//        long long31 = scaledDurationField25.subtract((long) 0, (long) (-28800000));
//        long long33 = scaledDurationField25.getValueAsLong((long) 5);
//        long long36 = scaledDurationField25.getMillis((int) (short) -1, (long) 5);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-908840217600422000L) + "'", long31 == (-908840217600422000L));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 32054400000L + "'", long36 == 32054400000L);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test050");
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
//        org.joda.time.Period period5 = period3.withMinutes(0);
//        org.joda.time.Period period7 = period3.withSeconds((-100));
//        org.joda.time.Period period9 = period3.plusHours(10);
//        org.joda.time.Period period11 = period9.plusMonths((int) (short) 0);
//        org.joda.time.Period period13 = period9.plusHours((int) (short) 100);
//        org.joda.time.Period period15 = period9.plusMonths((int) (short) 1);
//        org.joda.time.Duration duration16 = period9.toStandardDuration();
//        org.joda.time.ReadableInstant readableInstant17 = null;
//        org.joda.time.Period period18 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant17);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean21 = iSOChronology19.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.secondOfMinute();
//        java.util.TimeZone timeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone24.getName((long) (byte) 0, locale26);
//        org.joda.time.ReadableInstant readableInstant28 = null;
//        int int29 = dateTimeZone24.getOffset(readableInstant28);
//        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology19, dateTimeZone24);
//        org.joda.time.DurationField durationField31 = zonedChronology30.weekyears();
//        org.joda.time.Period period33 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType34 = null;
//        org.joda.time.Period period35 = period33.normalizedStandard(periodType34);
//        org.joda.time.Period period37 = period33.minusSeconds(0);
//        boolean boolean38 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField31, (java.lang.Object) period33);
//        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType40 = periodType39.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType42 = periodType40.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField44 = new org.joda.time.field.ScaledDurationField(durationField31, durationFieldType42, (-1));
//        boolean boolean45 = period18.isSupported(durationFieldType42);
//        org.joda.time.Period period47 = period18.withMillis((-28378000));
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertNotNull(period9);
//        org.junit.Assert.assertNotNull(period11);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(period15);
//        org.junit.Assert.assertNotNull(duration16);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-25200000) + "'", int29 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(period37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(periodType40);
//        org.junit.Assert.assertNotNull(durationFieldType42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(period47);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int7 = offsetDateTimeField3.getDifference((long) 4, (long) '#');
        long long9 = offsetDateTimeField3.roundHalfCeiling((long) (-28800000));
        int int11 = offsetDateTimeField3.getLeapAmount(28800000L);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField3.getMaximumShortTextLength(locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField3.getAsText(100, locale15);
        int int17 = offsetDateTimeField3.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "100" + "'", str16.equals("100"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test052");
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
//        org.joda.time.Period period5 = period3.withMinutes(0);
//        org.joda.time.Period period7 = period3.withSeconds((-100));
//        org.joda.time.Period period9 = period3.plusHours(10);
//        org.joda.time.Period period11 = period9.plusMonths((int) (short) 0);
//        org.joda.time.Period period13 = period9.plusHours((int) (short) 100);
//        org.joda.time.Period period15 = period9.plusMonths((int) (short) 1);
//        org.joda.time.Duration duration16 = period9.toStandardDuration();
//        org.joda.time.ReadableInstant readableInstant17 = null;
//        org.joda.time.Period period18 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant17);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean21 = iSOChronology19.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.secondOfMinute();
//        java.util.TimeZone timeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone24.getName((long) (byte) 0, locale26);
//        org.joda.time.ReadableInstant readableInstant28 = null;
//        int int29 = dateTimeZone24.getOffset(readableInstant28);
//        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology19, dateTimeZone24);
//        org.joda.time.DurationField durationField31 = zonedChronology30.weekyears();
//        org.joda.time.Period period33 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType34 = null;
//        org.joda.time.Period period35 = period33.normalizedStandard(periodType34);
//        org.joda.time.Period period37 = period33.minusSeconds(0);
//        boolean boolean38 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField31, (java.lang.Object) period33);
//        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType40 = periodType39.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType42 = periodType40.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField44 = new org.joda.time.field.ScaledDurationField(durationField31, durationFieldType42, (-1));
//        boolean boolean45 = period18.isSupported(durationFieldType42);
//        org.joda.time.field.PreciseDurationField preciseDurationField47 = new org.joda.time.field.PreciseDurationField(durationFieldType42, (-1L));
//        long long50 = preciseDurationField47.add((long) 2, (-77013825840000000L));
//        long long53 = preciseDurationField47.add(9223372035446400000L, (long) 111999);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertNotNull(period9);
//        org.junit.Assert.assertNotNull(period11);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(period15);
//        org.junit.Assert.assertNotNull(duration16);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-25200000) + "'", int29 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(period37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(periodType40);
//        org.junit.Assert.assertNotNull(durationFieldType42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 77013825840000002L + "'", long50 == 77013825840000002L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 9223372035446288001L + "'", long53 == 9223372035446288001L);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period3 = period1.withWeeks((int) '#');
        org.joda.time.Period period5 = period1.minusYears((int) (short) 100);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
        try {
            org.joda.time.Period period9 = period7.withWeeks(16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("org.joda.time.IllegalFieldValueException: 100.0: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'org.joda.time.IllegalFieldValueException: 100.0: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
        java.lang.String str4 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.era();
        org.joda.time.Chronology chronology6 = iSOChronology0.withUTC();
        org.joda.time.chrono.LenientChronology lenientChronology7 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("PeriodType[YearDay]", "org.joda.time.IllegalFieldValueException: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]", (int) (short) -1, (-100));
        java.util.TimeZone timeZone13 = fixedDateTimeZone12.toTimeZone();
        java.util.TimeZone timeZone14 = fixedDateTimeZone12.toTimeZone();
        int int16 = fixedDateTimeZone12.getOffset((long) 'a');
        boolean boolean17 = lenientChronology7.equals((java.lang.Object) 'a');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(lenientChronology7);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(419, 1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (-9));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-9) + "'", int1 == (-9));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Period period5 = period3.minus(readablePeriod4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period7 = period3.normalizedStandard(periodType6);
        org.joda.time.Period period9 = period3.multipliedBy((-1));
        org.joda.time.Period period11 = period9.minusMillis((int) (short) 1);
        org.joda.time.Period period13 = period11.plusMillis(16);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test059");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology11.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        long long17 = cachedDateTimeZone15.previousTransition((long) (-100));
//        java.lang.String str19 = cachedDateTimeZone15.getNameKey((long) (short) 10);
//        boolean boolean20 = cachedDateTimeZone15.isFixed();
//        long long23 = cachedDateTimeZone15.adjustOffset(9971999999L, true);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-5756400001L) + "'", long17 == (-5756400001L));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9971999999L + "'", long23 == 9971999999L);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-57601969), 40, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        long long6 = iSOChronology0.add((org.joda.time.ReadablePeriod) period2, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.Period period8 = period2.multipliedBy(0);
        int int9 = period2.getMinutes();
        org.joda.time.Period period10 = period2.normalizedStandard();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(minutes3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int7 = offsetDateTimeField3.getDifference((long) 4, (long) '#');
        long long9 = offsetDateTimeField3.remainder(0L);
        int int11 = offsetDateTimeField3.getLeapAmount((-28799900L));
        org.joda.time.DurationField durationField12 = offsetDateTimeField3.getRangeDurationField();
        long long15 = offsetDateTimeField3.addWrapField(36000000L, (int) '4');
        long long17 = offsetDateTimeField3.roundHalfFloor((long) (byte) 100);
        java.util.Locale locale18 = null;
        int int19 = offsetDateTimeField3.getMaximumShortTextLength(locale18);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10404000000L + "'", long15 == 10404000000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period4 = new org.joda.time.Period(1L, (long) (short) 1, periodType3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (-100), periodType3, (org.joda.time.Chronology) iSOChronology5);
        try {
            org.joda.time.Period period8 = period6.plusSeconds((-2));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology5);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test064");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int5 = offsetDateTimeField3.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 5200L, "");
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean12 = iSOChronology10.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        int int20 = dateTimeZone15.getOffset(readableInstant19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone15);
//        org.joda.time.DurationField durationField22 = zonedChronology21.weekyears();
//        org.joda.time.Period period24 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period24.normalizedStandard(periodType25);
//        org.joda.time.Period period28 = period24.minusSeconds(0);
//        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField22, (java.lang.Object) period24);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType31 = periodType30.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (-1));
//        long long37 = scaledDurationField35.getMillis((long) 'a');
//        int int40 = scaledDurationField35.getDifference(0L, (-31556952000L));
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, (org.joda.time.DurationField) scaledDurationField35);
//        org.joda.time.DurationField durationField42 = unsupportedDateTimeField41.getDurationField();
//        org.joda.time.DurationField durationField43 = unsupportedDateTimeField41.getDurationField();
//        try {
//            long long45 = unsupportedDateTimeField41.roundHalfEven(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-25200000) + "'", int20 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3061024344000L) + "'", long37 == (-3061024344000L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(durationField43);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField5 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.dayOfYear();
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        boolean boolean10 = dateTimeZone8.isStandardOffset(0L);
        java.lang.String str11 = dateTimeZone8.toString();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(4);
        long long15 = dateTimeZone8.getMillisKeepLocal(dateTimeZone13, 28800000L);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-4L) + "'", long15 == (-4L));
        org.junit.Assert.assertNotNull(zonedChronology16);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "-25200000", "GregorianChronology[UTC]");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        int int7 = offsetDateTimeField3.getLeapAmount(100L);
        java.lang.String str8 = offsetDateTimeField3.toString();
        java.lang.String str10 = offsetDateTimeField3.getAsText((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 4);
        java.lang.String str15 = offsetDateTimeField14.getName();
        int int16 = offsetDateTimeField14.getOffset();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) 5200L, "");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType17, (-100), 1012541, (-9));
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType17, 800, 0, (-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 800 for monthOfYear must be in the range [0,-10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DateTimeField[monthOfYear]" + "'", str8.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "5" + "'", str10.equals("5"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "monthOfYear" + "'", str15.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology4.era();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str10 = offsetDateTimeField9.getName();
        int int11 = offsetDateTimeField9.getOffset();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType12);
        int int14 = zeroIsMaxDateTimeField13.getMinimumValue();
        long long16 = zeroIsMaxDateTimeField13.remainder(0L);
        long long18 = zeroIsMaxDateTimeField13.roundHalfEven((long) (-2));
        try {
            long long21 = zeroIsMaxDateTimeField13.getDifferenceAsLong((long) (-100), 1610L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "monthOfYear" + "'", str10.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 62135946600000L + "'", long16 == 62135946600000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62135946600000L) + "'", long18 == (-62135946600000L));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        long long5 = offsetDateTimeField3.roundFloor((long) (short) -1);
        java.lang.String str7 = offsetDateTimeField3.getAsText(0L);
        long long9 = offsetDateTimeField3.roundHalfCeiling((long) (short) -1);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText(readablePartial10, 100, locale12);
        java.util.Locale locale14 = null;
        int int15 = offsetDateTimeField3.getMaximumTextLength(locale14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period20 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes21 = period20.toStandardMinutes();
        long long24 = iSOChronology18.add((org.joda.time.ReadablePeriod) period20, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology18.clockhourOfHalfday();
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.Period period29 = new org.joda.time.Period(readableInstant26, readableInstant27, periodType28);
        org.joda.time.Period period31 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType32 = null;
        org.joda.time.Period period33 = period31.normalizedStandard(periodType32);
        org.joda.time.Period period34 = period31.negated();
        org.joda.time.Period period35 = period29.withFields((org.joda.time.ReadablePeriod) period34);
        int[] intArray37 = iSOChronology18.get((org.joda.time.ReadablePeriod) period34, 0L);
        try {
            int[] intArray39 = offsetDateTimeField3.add(readablePartial16, (int) (short) 1, intArray37, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for monthOfYear must be in the range [5,16]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2678400000L) + "'", long5 == (-2678400000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "5" + "'", str7.equals("5"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(minutes21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(intArray37);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test070");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int5 = offsetDateTimeField3.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 5200L, "");
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean12 = iSOChronology10.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        int int20 = dateTimeZone15.getOffset(readableInstant19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone15);
//        org.joda.time.DurationField durationField22 = zonedChronology21.weekyears();
//        org.joda.time.Period period24 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period24.normalizedStandard(periodType25);
//        org.joda.time.Period period28 = period24.minusSeconds(0);
//        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField22, (java.lang.Object) period24);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType31 = periodType30.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (-1));
//        long long37 = scaledDurationField35.getMillis((long) 'a');
//        int int40 = scaledDurationField35.getDifference(0L, (-31556952000L));
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, (org.joda.time.DurationField) scaledDurationField35);
//        long long44 = unsupportedDateTimeField41.add(2678400001L, (-57601969));
//        try {
//            long long46 = unsupportedDateTimeField41.roundHalfFloor((long) (-3499));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-25200000) + "'", int20 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3061024344000L) + "'", long37 == (-3061024344000L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1817742573820800001L + "'", long44 == 1817742573820800001L);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        int int7 = offsetDateTimeField3.getLeapAmount(100L);
        long long10 = offsetDateTimeField3.add(6682L, 0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 6682L + "'", long10 == 6682L);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test072");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.lang.String str4 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean9 = iSOChronology7.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.secondOfMinute();
//        java.util.TimeZone timeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getName((long) (byte) 0, locale14);
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        int int17 = dateTimeZone12.getOffset(readableInstant16);
//        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone12);
//        org.joda.time.DurationField durationField19 = zonedChronology18.weekyears();
//        org.joda.time.DurationField durationField20 = zonedChronology18.weekyears();
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        boolean boolean24 = dateTimeZone22.isStandardOffset(0L);
//        org.joda.time.Chronology chronology25 = zonedChronology18.withZone(dateTimeZone22);
//        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) lenientChronology6, dateTimeZone22);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Pacific Standard Time" + "'", str15.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-25200000) + "'", int17 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(zonedChronology26);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test073");
//        org.joda.time.Period period0 = new org.joda.time.Period();
//        org.joda.time.Period period2 = period0.plusMonths((int) (short) -1);
//        org.joda.time.Period period4 = period0.minusMinutes((int) '#');
//        org.joda.time.PeriodType periodType6 = null;
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 0, periodType6, chronology7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.Period period10 = period8.minus(readablePeriod9);
//        org.joda.time.Period period12 = period8.plusMillis((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean15 = iSOChronology13.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.secondOfMinute();
//        java.util.TimeZone timeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) (byte) 0, locale20);
//        org.joda.time.ReadableInstant readableInstant22 = null;
//        int int23 = dateTimeZone18.getOffset(readableInstant22);
//        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology13, dateTimeZone18);
//        org.joda.time.DurationField durationField25 = zonedChronology24.weekyears();
//        org.joda.time.Period period27 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType28 = null;
//        org.joda.time.Period period29 = period27.normalizedStandard(periodType28);
//        org.joda.time.Period period31 = period27.minusSeconds(0);
//        boolean boolean32 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField25, (java.lang.Object) period27);
//        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType34 = periodType33.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField38 = new org.joda.time.field.ScaledDurationField(durationField25, durationFieldType36, (-1));
//        boolean boolean39 = period8.isSupported(durationFieldType36);
//        boolean boolean40 = period4.isSupported(durationFieldType36);
//        org.joda.time.Days days41 = period4.toStandardDays();
//        org.junit.Assert.assertNotNull(period2);
//        org.junit.Assert.assertNotNull(period4);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-25200000) + "'", int23 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(period31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(periodType33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(days41);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("LenientChronology[GregorianChronology[+97:10]]", number1, (java.lang.Number) (-2678399900L), (java.lang.Number) (-74626937766000001L));
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test075");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int5 = offsetDateTimeField3.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 5200L, "");
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean12 = iSOChronology10.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        int int20 = dateTimeZone15.getOffset(readableInstant19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone15);
//        org.joda.time.DurationField durationField22 = zonedChronology21.weekyears();
//        org.joda.time.Period period24 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period24.normalizedStandard(periodType25);
//        org.joda.time.Period period28 = period24.minusSeconds(0);
//        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField22, (java.lang.Object) period24);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType31 = periodType30.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (-1));
//        long long37 = scaledDurationField35.getMillis((long) 'a');
//        int int40 = scaledDurationField35.getDifference(0L, (-31556952000L));
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, (org.joda.time.DurationField) scaledDurationField35);
//        org.joda.time.DurationField durationField42 = unsupportedDateTimeField41.getDurationField();
//        org.joda.time.DurationField durationField43 = unsupportedDateTimeField41.getDurationField();
//        org.joda.time.ReadablePartial readablePartial44 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Period period47 = org.joda.time.Period.days((int) (byte) 0);
//        org.joda.time.Minutes minutes48 = period47.toStandardMinutes();
//        long long51 = iSOChronology45.add((org.joda.time.ReadablePeriod) period47, (long) (byte) 100, (int) (byte) 100);
//        org.joda.time.DurationField durationField52 = iSOChronology45.weeks();
//        long long56 = iSOChronology45.add((-4L), (long) (byte) 1, 4);
//        org.joda.time.ReadableInstant readableInstant57 = null;
//        org.joda.time.ReadableInstant readableInstant58 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Period period61 = org.joda.time.Period.days((int) (byte) 0);
//        org.joda.time.Minutes minutes62 = period61.toStandardMinutes();
//        long long65 = iSOChronology59.add((org.joda.time.ReadablePeriod) period61, (long) (byte) 100, (int) (byte) 100);
//        org.joda.time.Duration duration66 = period61.toStandardDuration();
//        org.joda.time.ReadableInstant readableInstant67 = null;
//        org.joda.time.PeriodType periodType68 = org.joda.time.PeriodType.hours();
//        org.joda.time.Period period69 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration66, readableInstant67, periodType68);
//        org.joda.time.Period period70 = new org.joda.time.Period(readableInstant58, (org.joda.time.ReadableDuration) duration66);
//        org.joda.time.Period period71 = new org.joda.time.Period(readableInstant57, (org.joda.time.ReadableDuration) duration66);
//        int[] intArray74 = iSOChronology45.get((org.joda.time.ReadablePeriod) period71, (long) 0, (long) (short) 10);
//        try {
//            int int75 = unsupportedDateTimeField41.getMaximumValue(readablePartial44, intArray74);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-25200000) + "'", int20 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3061024344000L) + "'", long37 == (-3061024344000L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(period47);
//        org.junit.Assert.assertNotNull(minutes48);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 100L + "'", long51 == 100L);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(period61);
//        org.junit.Assert.assertNotNull(minutes62);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 100L + "'", long65 == 100L);
//        org.junit.Assert.assertNotNull(duration66);
//        org.junit.Assert.assertNotNull(periodType68);
//        org.junit.Assert.assertNotNull(intArray74);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        org.joda.time.ReadablePartial readablePartial5 = null;
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, periodType8, chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.Period period12 = period10.minus(readablePeriod11);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period14 = period10.normalizedStandard(periodType13);
        int[] intArray15 = period10.getValues();
        java.util.Locale locale17 = null;
        try {
            int[] intArray18 = offsetDateTimeField3.set(readablePartial5, 28800000, intArray15, "GregorianChronology[America/Los_Angeles]", locale17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[America/Los_Angeles]\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology4.era();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str10 = offsetDateTimeField9.getName();
        int int11 = offsetDateTimeField9.getOffset();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType12);
        int int14 = zeroIsMaxDateTimeField13.getMinimumValue();
        long long16 = zeroIsMaxDateTimeField13.roundHalfFloor((-5270400000L));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "monthOfYear" + "'", str10.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036504975807L + "'", long16 == 9223372036504975807L);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test078");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long28 = scaledDurationField25.getDifferenceAsLong(2440588L, 0L);
//        int int29 = scaledDurationField25.getScalar();
//        long long32 = scaledDurationField25.getDifferenceAsLong((long) 10, 28800004L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test079");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean3 = iSOChronology1.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        org.joda.time.ReadableInstant readableInstant10 = null;
//        int int11 = dateTimeZone6.getOffset(readableInstant10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone6);
//        org.joda.time.DurationField durationField13 = zonedChronology12.weekyears();
//        org.joda.time.DateTimeField dateTimeField14 = zonedChronology12.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology12.getZone();
//        long long21 = zonedChronology12.getDateTimeMillis(0L, 0, (int) (short) 10, 0, (int) (byte) 100);
//        org.joda.time.Period period22 = new org.joda.time.Period((-2108696400000L), (org.joda.time.Chronology) zonedChronology12);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-25200000) + "'", int11 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-56999900L) + "'", long21 == (-56999900L));
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]");
        boolean boolean5 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        java.lang.String str6 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]" + "'", str6.equals("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology4.era();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str10 = offsetDateTimeField9.getName();
        int int11 = offsetDateTimeField9.getOffset();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType12);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "-25200000");
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "monthOfYear" + "'", str10.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test082");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int7 = offsetDateTimeField3.getDifference((long) 4, (long) '#');
//        long long9 = offsetDateTimeField3.remainder(0L);
//        int int11 = offsetDateTimeField3.getLeapAmount((long) 10);
//        int int13 = offsetDateTimeField3.get((long) (-1));
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean19 = iSOChronology17.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.secondOfMinute();
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = dateTimeZone22.getName((long) (byte) 0, locale24);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        int int27 = dateTimeZone22.getOffset(readableInstant26);
//        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology17, dateTimeZone22);
//        org.joda.time.DurationField durationField29 = zonedChronology28.weekyears();
//        org.joda.time.DateTimeField dateTimeField30 = zonedChronology28.clockhourOfDay();
//        boolean boolean31 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 2440588L, (java.lang.Object) zonedChronology28);
//        org.joda.time.Period period33 = org.joda.time.Period.days((int) '4');
//        org.joda.time.Period period35 = period33.withWeeks((int) '#');
//        org.joda.time.Period period37 = period33.minusYears((int) (short) 100);
//        int[] intArray39 = zonedChronology28.get((org.joda.time.ReadablePeriod) period33, (-1L));
//        try {
//            int[] intArray41 = offsetDateTimeField3.addWrapPartial(readablePartial14, (-25199998), intArray39, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -25199998");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Pacific Standard Time" + "'", str25.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-25200000) + "'", int27 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(period37);
//        org.junit.Assert.assertNotNull(intArray39);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology4.era();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str10 = offsetDateTimeField9.getName();
        int int11 = offsetDateTimeField9.getOffset();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType12);
        long long15 = zeroIsMaxDateTimeField13.remainder((long) (-7));
        long long17 = zeroIsMaxDateTimeField13.roundHalfCeiling(6682L);
        long long19 = zeroIsMaxDateTimeField13.remainder((-21168000001L));
        boolean boolean21 = zeroIsMaxDateTimeField13.isLeap(0L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "monthOfYear" + "'", str10.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 62135946599993L + "'", long15 == 62135946599993L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135946600000L) + "'", long17 == (-62135946600000L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 62114778599999L + "'", long19 == 62114778599999L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = period1.normalizedStandard(periodType2);
        org.joda.time.Period period4 = period1.negated();
        org.joda.time.Period period6 = period4.withDays(2);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.millis();
        java.lang.String str8 = periodType7.getName();
        org.joda.time.PeriodType periodType9 = periodType7.withWeeksRemoved();
        org.joda.time.Period period10 = period6.normalizedStandard(periodType9);
        org.joda.time.Period period11 = period6.negated();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Millis" + "'", str8.equals("Millis"));
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int7 = offsetDateTimeField3.getDifference((long) 4, (long) '#');
        long long9 = offsetDateTimeField3.remainder(0L);
        int int11 = offsetDateTimeField3.getLeapAmount((long) 10);
        int int12 = offsetDateTimeField3.getMaximumValue();
        long long15 = offsetDateTimeField3.add((-2108667600000L), (-25199998));
        long long17 = offsetDateTimeField3.roundHalfCeiling((-21168000000L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-66271702597200000L) + "'", long15 == (-66271702597200000L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-21168000000L) + "'", long17 == (-21168000000L));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 0, periodType4, chronology5);
        org.joda.time.Period period8 = period6.withMinutes(0);
        org.joda.time.Period period10 = period6.withSeconds((-100));
        org.joda.time.Period period12 = period6.plusHours(10);
        org.joda.time.Period period14 = period12.plusMonths((int) (short) 0);
        org.joda.time.Period period16 = period12.plusHours((int) (short) 100);
        org.joda.time.Period period18 = period12.plusMonths((int) (short) 1);
        org.joda.time.Duration duration19 = period12.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration19, readableInstant20);
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration19);
        long long23 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration19);
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration19);
        org.joda.time.PeriodType periodType26 = null;
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (short) 0, periodType26, chronology27);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.Period period30 = period28.minus(readablePeriod29);
        org.joda.time.PeriodType periodType31 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period32 = period28.normalizedStandard(periodType31);
        org.joda.time.PeriodType periodType33 = periodType31.withMonthsRemoved();
        java.lang.String str34 = periodType33.getName();
        org.joda.time.Period period35 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration19, periodType33);
        try {
            org.joda.time.Period period37 = period35.plusMillis(4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 36000000L + "'", long23 == 36000000L);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "YearDay" + "'", str34.equals("YearDay"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.Period period1 = org.joda.time.Period.years(1);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test088");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        java.lang.Number number28 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number28);
//        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType23, (long) 100);
//        int int33 = preciseDurationField31.getValue((long) (byte) 10);
//        boolean boolean34 = preciseDurationField31.isSupported();
//        long long35 = preciseDurationField31.getUnitMillis();
//        long long38 = preciseDurationField31.add((long) (byte) 10, (long) 16);
//        java.lang.String str39 = preciseDurationField31.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1610L + "'", long38 == 1610L);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DurationField[years]" + "'", str39.equals("DurationField[years]"));
//    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test089");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology4.era();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
//        java.lang.String str10 = offsetDateTimeField9.getName();
//        int int11 = offsetDateTimeField9.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType12);
//        long long15 = zeroIsMaxDateTimeField13.remainder((long) (-7));
//        long long17 = zeroIsMaxDateTimeField13.roundHalfCeiling(6682L);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean21 = iSOChronology19.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.secondOfMinute();
//        java.util.TimeZone timeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone24.getName((long) (byte) 0, locale26);
//        org.joda.time.ReadableInstant readableInstant28 = null;
//        int int29 = dateTimeZone24.getOffset(readableInstant28);
//        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology19, dateTimeZone24);
//        org.joda.time.Period period35 = new org.joda.time.Period((-10), (int) (short) -1, (-10), (int) (short) 0);
//        org.joda.time.Days days36 = period35.toStandardDays();
//        long long39 = iSOChronology19.add((org.joda.time.ReadablePeriod) days36, (-1009411200001L), 0);
//        org.joda.time.PeriodType periodType41 = null;
//        org.joda.time.Chronology chronology42 = null;
//        org.joda.time.Period period43 = new org.joda.time.Period((long) (short) 0, periodType41, chronology42);
//        org.joda.time.Period period45 = period43.withMinutes(0);
//        org.joda.time.Period period47 = period43.withSeconds((-100));
//        org.joda.time.Period period49 = period43.plusHours(10);
//        org.joda.time.Period period51 = period49.plusMonths((int) (short) 0);
//        org.joda.time.Period period53 = period49.plusHours((int) (short) 100);
//        org.joda.time.Period period55 = period53.plusMillis((int) (byte) -1);
//        org.joda.time.Period period57 = period53.withMonths((-100));
//        int[] intArray59 = iSOChronology19.get((org.joda.time.ReadablePeriod) period57, 3155846401610L);
//        int int60 = zeroIsMaxDateTimeField13.getMinimumValue(readablePartial18, intArray59);
//        org.joda.time.DateTimeField dateTimeField61 = zeroIsMaxDateTimeField13.getWrappedField();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(lenientChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "monthOfYear" + "'", str10.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 62135946599993L + "'", long15 == 62135946599993L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135946600000L) + "'", long17 == (-62135946600000L));
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-25200000) + "'", int29 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology30);
//        org.junit.Assert.assertNotNull(days36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-1009411200001L) + "'", long39 == (-1009411200001L));
//        org.junit.Assert.assertNotNull(period45);
//        org.junit.Assert.assertNotNull(period47);
//        org.junit.Assert.assertNotNull(period49);
//        org.junit.Assert.assertNotNull(period51);
//        org.junit.Assert.assertNotNull(period53);
//        org.junit.Assert.assertNotNull(period55);
//        org.junit.Assert.assertNotNull(period57);
//        org.junit.Assert.assertNotNull(intArray59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test090");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long28 = scaledDurationField25.getDifferenceAsLong((long) '4', (long) (byte) 100);
//        long long30 = scaledDurationField25.getValueAsLong((-908902361117221990L));
//        org.joda.time.DurationField durationField31 = scaledDurationField25.getWrappedField();
//        long long33 = scaledDurationField25.getValueAsLong(9972000000L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28801969L + "'", long30 == 28801969L);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        int int7 = offsetDateTimeField3.getLeapAmount(100L);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray10 = null;
        try {
            int[] intArray12 = offsetDateTimeField3.set(readablePartial8, (int) (byte) 10, intArray10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [5,16]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test092");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int5 = offsetDateTimeField3.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 5200L, "");
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean12 = iSOChronology10.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        int int20 = dateTimeZone15.getOffset(readableInstant19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone15);
//        org.joda.time.DurationField durationField22 = zonedChronology21.weekyears();
//        org.joda.time.Period period24 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period24.normalizedStandard(periodType25);
//        org.joda.time.Period period28 = period24.minusSeconds(0);
//        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField22, (java.lang.Object) period24);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType31 = periodType30.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (-1));
//        long long37 = scaledDurationField35.getMillis((long) 'a');
//        int int40 = scaledDurationField35.getDifference(0L, (-31556952000L));
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, (org.joda.time.DurationField) scaledDurationField35);
//        try {
//            long long44 = unsupportedDateTimeField41.addWrapField((-10L), (-25199998));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-25200000) + "'", int20 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3061024344000L) + "'", long37 == (-3061024344000L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(1L, (long) (short) 1, periodType2);
        org.joda.time.Period period5 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period7 = period5.withSeconds((-1));
        int int8 = period7.getYears();
        boolean boolean9 = periodType2.equals((java.lang.Object) period7);
        org.joda.time.PeriodType periodType10 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType11 = periodType10.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test094");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int5 = offsetDateTimeField3.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 5200L, "");
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean12 = iSOChronology10.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        int int20 = dateTimeZone15.getOffset(readableInstant19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone15);
//        org.joda.time.DurationField durationField22 = zonedChronology21.weekyears();
//        org.joda.time.Period period24 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period24.normalizedStandard(periodType25);
//        org.joda.time.Period period28 = period24.minusSeconds(0);
//        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField22, (java.lang.Object) period24);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType31 = periodType30.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (-1));
//        long long37 = scaledDurationField35.getMillis((long) 'a');
//        int int40 = scaledDurationField35.getDifference(0L, (-31556952000L));
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, (org.joda.time.DurationField) scaledDurationField35);
//        org.joda.time.DurationField durationField42 = unsupportedDateTimeField41.getDurationField();
//        org.joda.time.ReadablePartial readablePartial43 = null;
//        java.util.Locale locale44 = null;
//        try {
//            java.lang.String str45 = unsupportedDateTimeField41.getAsShortText(readablePartial43, locale44);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-25200000) + "'", int20 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3061024344000L) + "'", long37 == (-3061024344000L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertNotNull(durationField42);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology4.minuteOfHour();
        org.joda.time.DurationField durationField6 = lenientChronology4.halfdays();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDayTime]", (java.lang.Number) 100.0d, (java.lang.Number) (-97), (java.lang.Number) 10.0d);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        java.lang.String str6 = illegalFieldValueException4.getFieldName();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PeriodType[YearMonthDayTime]" + "'", str5.equals("PeriodType[YearMonthDayTime]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PeriodType[YearMonthDayTime]" + "'", str6.equals("PeriodType[YearMonthDayTime]"));
        org.junit.Assert.assertNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-97) + "'", number8.equals((-97)));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        long long7 = offsetDateTimeField3.roundFloor((long) (short) 100);
        long long9 = offsetDateTimeField3.roundHalfFloor((long) 4);
        java.util.Locale locale12 = null;
        try {
            long long13 = offsetDateTimeField3.set(26784000L, "-28378000", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28378000 for monthOfYear must be in the range [5,16]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test098");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        java.lang.Number number28 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number28);
//        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType23, (long) 100);
//        int int33 = preciseDurationField31.getValue((long) (byte) 10);
//        boolean boolean34 = preciseDurationField31.isSupported();
//        long long35 = preciseDurationField31.getUnitMillis();
//        long long38 = preciseDurationField31.add((long) (byte) 10, (long) 16);
//        long long41 = preciseDurationField31.add(0L, 2440471L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1610L + "'", long38 == 1610L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 244047100L + "'", long41 == 244047100L);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test099");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int5 = offsetDateTimeField3.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 5200L, "");
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean12 = iSOChronology10.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        int int20 = dateTimeZone15.getOffset(readableInstant19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone15);
//        org.joda.time.DurationField durationField22 = zonedChronology21.weekyears();
//        org.joda.time.Period period24 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period24.normalizedStandard(periodType25);
//        org.joda.time.Period period28 = period24.minusSeconds(0);
//        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField22, (java.lang.Object) period24);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType31 = periodType30.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (-1));
//        long long37 = scaledDurationField35.getMillis((long) 'a');
//        int int40 = scaledDurationField35.getDifference(0L, (-31556952000L));
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, (org.joda.time.DurationField) scaledDurationField35);
//        org.joda.time.DurationField durationField42 = unsupportedDateTimeField41.getDurationField();
//        org.joda.time.DurationField durationField43 = unsupportedDateTimeField41.getDurationField();
//        org.joda.time.ReadablePartial readablePartial44 = null;
//        try {
//            int int45 = unsupportedDateTimeField41.getMaximumValue(readablePartial44);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-25200000) + "'", int20 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3061024344000L) + "'", long37 == (-3061024344000L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(durationField43);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("-25200000");
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(1L, (long) (short) 1, periodType2);
        org.joda.time.Period period5 = org.joda.time.Period.days((int) '4');
        org.joda.time.Period period7 = period5.withSeconds((-1));
        int int8 = period7.getYears();
        boolean boolean9 = periodType2.equals((java.lang.Object) period7);
        org.joda.time.PeriodType periodType10 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType11 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Hours", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Hours/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withMinutes(0);
        int int6 = period5.getMillis();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test104");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        java.lang.Number number28 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number28);
//        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType23, (long) 100);
//        java.lang.Object obj32 = null;
//        boolean boolean33 = preciseDurationField31.equals(obj32);
//        long long36 = preciseDurationField31.getValueAsLong((-210866760000000L), (long) 5);
//        long long39 = preciseDurationField31.add(11044933200000000L, 0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-2108667600000L) + "'", long36 == (-2108667600000L));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 11044933200000000L + "'", long39 == 11044933200000000L);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test105");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
//        boolean boolean9 = gregorianChronology4.equals((java.lang.Object) (short) 10);
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.Chronology chronology13 = gregorianChronology4.withZone(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(chronology13);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test106");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology11.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        long long17 = cachedDateTimeZone15.previousTransition((long) (-100));
//        int int19 = cachedDateTimeZone15.getOffset((-97L));
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = cachedDateTimeZone15.getName(1L, locale21);
//        long long25 = cachedDateTimeZone15.convertLocalToUTC((long) 4, true);
//        org.joda.time.DateTimeZone dateTimeZone26 = cachedDateTimeZone15.getUncachedZone();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-5756400001L) + "'", long17 == (-5756400001L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Pacific Standard Time" + "'", str22.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800004L + "'", long25 == 28800004L);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology4.era();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str10 = offsetDateTimeField9.getName();
        int int11 = offsetDateTimeField9.getOffset();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType12);
        long long15 = zeroIsMaxDateTimeField13.remainder((long) (-7));
        long long17 = zeroIsMaxDateTimeField13.roundFloor((-210866760000000L));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "monthOfYear" + "'", str10.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 62135946599993L + "'", long15 == 62135946599993L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036504975808L + "'", long17 == 9223372036504975808L);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test108");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long28 = scaledDurationField25.getDifferenceAsLong((long) '4', (long) (byte) 100);
//        long long30 = scaledDurationField25.getValueAsLong((-908902361117221990L));
//        org.joda.time.DurationField durationField31 = scaledDurationField25.getWrappedField();
//        int int33 = scaledDurationField25.getValue((long) 5);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28801969L + "'", long30 == 28801969L);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test109");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology11.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        long long17 = cachedDateTimeZone15.previousTransition((long) (-100));
//        int int19 = cachedDateTimeZone15.getStandardOffset(0L);
//        int int21 = cachedDateTimeZone15.getOffset(10L);
//        org.joda.time.DateTimeZone dateTimeZone22 = cachedDateTimeZone15.getUncachedZone();
//        long long24 = cachedDateTimeZone15.nextTransition(25200000L);
//        org.joda.time.DateTimeZone dateTimeZone25 = cachedDateTimeZone15.getUncachedZone();
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        int int27 = cachedDateTimeZone15.getOffset(readableInstant26);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-5756400001L) + "'", long17 == (-5756400001L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9972000000L + "'", long24 == 9972000000L);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-25200000) + "'", int27 == (-25200000));
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.Period period1 = org.joda.time.Period.hours((-25200000));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "org.joda.time.IllegalFieldValueException: 100.0: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test112");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        java.lang.String str14 = zonedChronology11.toString();
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology11);
//        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology11.getZone();
//        org.joda.time.DateTimeField dateTimeField17 = zonedChronology11.millisOfSecond();
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        boolean boolean21 = dateTimeZone19.isStandardOffset(0L);
//        java.lang.String str22 = dateTimeZone19.toString();
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis(4);
//        long long26 = dateTimeZone19.getMillisKeepLocal(dateTimeZone24, 28800000L);
//        java.lang.String str28 = dateTimeZone24.getShortName((long) (-97));
//        org.joda.time.Chronology chronology29 = zonedChronology11.withZone(dateTimeZone24);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "America/Los_Angeles" + "'", str22.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-4L) + "'", long26 == (-4L));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00:00.004" + "'", str28.equals("+00:00:00.004"));
//        org.junit.Assert.assertNotNull(chronology29);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        long long6 = iSOChronology0.add((org.joda.time.ReadablePeriod) period2, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.DurationField durationField7 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.secondOfMinute();
        org.joda.time.DurationField durationField10 = iSOChronology0.years();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(minutes3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        boolean boolean5 = offsetDateTimeField3.isLeap((long) 0);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 10, (-25200000));
        java.lang.String str10 = offsetDateTimeField3.getAsShortText((long) (byte) -1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText(2, locale12);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "16" + "'", str10.equals("16"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2" + "'", str13.equals("2"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int7 = offsetDateTimeField3.getDifference((long) 4, (long) '#');
        long long9 = offsetDateTimeField3.roundHalfFloor((-31060800000L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31536000000L) + "'", long9 == (-31536000000L));
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test116");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = zonedChronology11.weekyears();
//        java.lang.String str14 = zonedChronology11.toString();
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology11);
//        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology11.getZone();
//        org.joda.time.DateTimeField dateTimeField17 = zonedChronology11.hourOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test118");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
//        org.joda.time.Period period14 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType15 = null;
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = period14.minusSeconds(0);
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField12, (java.lang.Object) period14);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField25 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType23, (-1));
//        long long28 = scaledDurationField25.getDifferenceAsLong((long) '4', (long) (byte) 100);
//        int int30 = scaledDurationField25.getValue(3155846401610L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(durationFieldType23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-100) + "'", int30 == (-100));
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period4 = new org.joda.time.Period(1L, (long) (short) 1, periodType3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (-100), periodType3, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.PeriodType periodType7 = periodType3.withSecondsRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period10 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes11 = period10.toStandardMinutes();
        long long14 = iSOChronology8.add((org.joda.time.ReadablePeriod) period10, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology8.clockhourOfHalfday();
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant16, readableInstant17, periodType18);
        org.joda.time.Period period21 = org.joda.time.Period.days((int) '4');
        org.joda.time.PeriodType periodType22 = null;
        org.joda.time.Period period23 = period21.normalizedStandard(periodType22);
        org.joda.time.Period period24 = period21.negated();
        org.joda.time.Period period25 = period19.withFields((org.joda.time.ReadablePeriod) period24);
        int[] intArray27 = iSOChronology8.get((org.joda.time.ReadablePeriod) period24, 0L);
        try {
            org.joda.time.Period period28 = new org.joda.time.Period((java.lang.Object) periodType7, (org.joda.time.Chronology) iSOChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(minutes11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(intArray27);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test120");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int5 = offsetDateTimeField3.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 5200L, "");
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean12 = iSOChronology10.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        int int20 = dateTimeZone15.getOffset(readableInstant19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone15);
//        org.joda.time.DurationField durationField22 = zonedChronology21.weekyears();
//        org.joda.time.Period period24 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period24.normalizedStandard(periodType25);
//        org.joda.time.Period period28 = period24.minusSeconds(0);
//        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField22, (java.lang.Object) period24);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType31 = periodType30.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (-1));
//        long long37 = scaledDurationField35.getMillis((long) 'a');
//        int int40 = scaledDurationField35.getDifference(0L, (-31556952000L));
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, (org.joda.time.DurationField) scaledDurationField35);
//        long long44 = unsupportedDateTimeField41.add(2678400001L, (-57601969));
//        org.joda.time.DurationField durationField45 = unsupportedDateTimeField41.getRangeDurationField();
//        java.util.Locale locale47 = null;
//        try {
//            java.lang.String str48 = unsupportedDateTimeField41.getAsShortText((long) 5, locale47);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-25200000) + "'", int20 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3061024344000L) + "'", long37 == (-3061024344000L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1817742573820800001L + "'", long44 == 1817742573820800001L);
//        org.junit.Assert.assertNull(durationField45);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
        long long5 = offsetDateTimeField3.roundHalfCeiling((-1009411200001L));
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsText(readablePartial6, 8, locale8);
        long long11 = offsetDateTimeField3.roundHalfEven(895523247360111999L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1009843200000L) + "'", long5 == (-1009843200000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "8" + "'", str9.equals("8"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 895523246928000000L + "'", long11 == 895523246928000000L);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test122");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) (byte) 0, locale7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone5.getOffset(readableInstant9);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        java.lang.String str14 = dateTimeZone13.getID();
//        org.joda.time.Chronology chronology15 = zonedChronology11.withZone(dateTimeZone13);
//        org.joda.time.DurationField durationField16 = zonedChronology11.hours();
//        org.joda.time.PeriodType periodType18 = null;
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.Period period20 = new org.joda.time.Period((-1L), periodType18, chronology19);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Period period23 = org.joda.time.Period.days((int) (byte) 0);
//        org.joda.time.Minutes minutes24 = period23.toStandardMinutes();
//        long long27 = iSOChronology21.add((org.joda.time.ReadablePeriod) period23, (long) (byte) 100, (int) (byte) 100);
//        org.joda.time.Period period29 = period23.withDays((-1));
//        org.joda.time.Period period30 = period20.plus((org.joda.time.ReadablePeriod) period23);
//        java.lang.Object obj31 = null;
//        org.joda.time.PeriodType periodType32 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period33 = new org.joda.time.Period(obj31, periodType32);
//        org.joda.time.Period period34 = period20.normalizedStandard(periodType32);
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean37 = iSOChronology35.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology35.secondOfMinute();
//        java.util.TimeZone timeZone39 = null;
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forTimeZone(timeZone39);
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = dateTimeZone40.getName((long) (byte) 0, locale42);
//        org.joda.time.ReadableInstant readableInstant44 = null;
//        int int45 = dateTimeZone40.getOffset(readableInstant44);
//        org.joda.time.chrono.ZonedChronology zonedChronology46 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology35, dateTimeZone40);
//        org.joda.time.DurationField durationField47 = zonedChronology46.weekyears();
//        org.joda.time.Period period49 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType50 = null;
//        org.joda.time.Period period51 = period49.normalizedStandard(periodType50);
//        org.joda.time.Period period53 = period49.minusSeconds(0);
//        boolean boolean54 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField47, (java.lang.Object) period49);
//        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType56 = periodType55.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType58 = periodType56.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField60 = new org.joda.time.field.ScaledDurationField(durationField47, durationFieldType58, (-1));
//        java.lang.Number number63 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(durationFieldType58, (java.lang.Number) 8, (java.lang.Number) (-28799900L), number63);
//        org.joda.time.field.PreciseDurationField preciseDurationField66 = new org.joda.time.field.PreciseDurationField(durationFieldType58, (long) 100);
//        boolean boolean67 = periodType32.isSupported(durationFieldType58);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField68 = new org.joda.time.field.DecoratedDurationField(durationField16, durationFieldType58);
//        int int71 = decoratedDurationField68.getDifference((long) (-28378000), (long) (short) 0);
//        long long74 = decoratedDurationField68.add((-3061024344000L), (long) (byte) -1);
//        org.joda.time.DurationField durationField75 = decoratedDurationField68.getWrappedField();
//        long long77 = decoratedDurationField68.getValueAsLong((-10097712004L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "America/Los_Angeles" + "'", str14.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(period23);
//        org.junit.Assert.assertNotNull(minutes24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertNotNull(periodType32);
//        org.junit.Assert.assertNotNull(period34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Pacific Standard Time" + "'", str43.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-25200000) + "'", int45 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(period49);
//        org.junit.Assert.assertNotNull(period51);
//        org.junit.Assert.assertNotNull(period53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(periodType55);
//        org.junit.Assert.assertNotNull(periodType56);
//        org.junit.Assert.assertNotNull(durationFieldType58);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-7) + "'", int71 == (-7));
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-3061027944000L) + "'", long74 == (-3061027944000L));
//        org.junit.Assert.assertNotNull(durationField75);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-2804L) + "'", long77 == (-2804L));
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology4.era();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str10 = offsetDateTimeField9.getName();
        int int11 = offsetDateTimeField9.getOffset();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType12);
        long long15 = zeroIsMaxDateTimeField13.remainder((long) (-7));
        long long17 = zeroIsMaxDateTimeField13.roundHalfCeiling(6682L);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int int19 = zeroIsMaxDateTimeField13.getMaximumValue(readablePartial18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = zeroIsMaxDateTimeField13.getAsText((int) (byte) 10, locale21);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "monthOfYear" + "'", str10.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 62135946599993L + "'", long15 == 62135946599993L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135946600000L) + "'", long17 == (-62135946600000L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10" + "'", str22.equals("10"));
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test124");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int5 = offsetDateTimeField3.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 5200L, "");
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean12 = iSOChronology10.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        int int20 = dateTimeZone15.getOffset(readableInstant19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone15);
//        org.joda.time.DurationField durationField22 = zonedChronology21.weekyears();
//        org.joda.time.Period period24 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period24.normalizedStandard(periodType25);
//        org.joda.time.Period period28 = period24.minusSeconds(0);
//        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField22, (java.lang.Object) period24);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType31 = periodType30.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (-1));
//        long long37 = scaledDurationField35.getMillis((long) 'a');
//        int int40 = scaledDurationField35.getDifference(0L, (-31556952000L));
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, (org.joda.time.DurationField) scaledDurationField35);
//        long long44 = unsupportedDateTimeField41.add(2678400001L, (-57601969));
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        java.lang.Object obj46 = null;
//        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period48 = new org.joda.time.Period(obj46, periodType47);
//        org.joda.time.JodaTimePermission jodaTimePermission50 = new org.joda.time.JodaTimePermission("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]");
//        org.joda.time.JodaTimePermission jodaTimePermission52 = new org.joda.time.JodaTimePermission("monthOfYear");
//        boolean boolean53 = jodaTimePermission50.implies((java.security.Permission) jodaTimePermission52);
//        java.lang.Object obj54 = null;
//        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.yearMonthDayTime();
//        org.joda.time.Period period56 = new org.joda.time.Period(obj54, periodType55);
//        jodaTimePermission50.checkGuard((java.lang.Object) periodType55);
//        org.joda.time.JodaTimePermission jodaTimePermission59 = new org.joda.time.JodaTimePermission("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]");
//        org.joda.time.JodaTimePermission jodaTimePermission61 = new org.joda.time.JodaTimePermission("monthOfYear");
//        boolean boolean62 = jodaTimePermission59.implies((java.security.Permission) jodaTimePermission61);
//        boolean boolean63 = jodaTimePermission50.implies((java.security.Permission) jodaTimePermission59);
//        boolean boolean64 = periodType47.equals((java.lang.Object) jodaTimePermission50);
//        org.joda.time.Period period66 = org.joda.time.Period.minutes((int) (byte) 100);
//        int[] intArray67 = period66.getValues();
//        jodaTimePermission50.checkGuard((java.lang.Object) intArray67);
//        try {
//            int int69 = unsupportedDateTimeField41.getMinimumValue(readablePartial45, intArray67);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-25200000) + "'", int20 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3061024344000L) + "'", long37 == (-3061024344000L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1817742573820800001L + "'", long44 == 1817742573820800001L);
//        org.junit.Assert.assertNotNull(periodType47);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(periodType55);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(period66);
//        org.junit.Assert.assertNotNull(intArray67);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test125");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int5 = offsetDateTimeField3.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 5200L, "");
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean12 = iSOChronology10.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        int int20 = dateTimeZone15.getOffset(readableInstant19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone15);
//        org.joda.time.DurationField durationField22 = zonedChronology21.weekyears();
//        org.joda.time.Period period24 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period24.normalizedStandard(periodType25);
//        org.joda.time.Period period28 = period24.minusSeconds(0);
//        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField22, (java.lang.Object) period24);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType31 = periodType30.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (-1));
//        long long37 = scaledDurationField35.getMillis((long) 'a');
//        int int40 = scaledDurationField35.getDifference(0L, (-31556952000L));
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, (org.joda.time.DurationField) scaledDurationField35);
//        long long44 = unsupportedDateTimeField41.add(2678400001L, (-57601969));
//        try {
//            java.lang.String str46 = unsupportedDateTimeField41.getAsText((long) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-25200000) + "'", int20 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3061024344000L) + "'", long37 == (-3061024344000L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1817742573820800001L + "'", long44 == 1817742573820800001L);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology4.era();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str10 = offsetDateTimeField9.getName();
        int int11 = offsetDateTimeField9.getOffset();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType12);
        int int14 = zeroIsMaxDateTimeField13.getMinimumValue();
        long long16 = zeroIsMaxDateTimeField13.remainder(0L);
        long long18 = zeroIsMaxDateTimeField13.roundHalfEven((long) (-2));
        org.joda.time.DurationField durationField19 = zeroIsMaxDateTimeField13.getLeapDurationField();
        long long21 = zeroIsMaxDateTimeField13.roundHalfEven(9223372035471600000L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "monthOfYear" + "'", str10.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 62135946600000L + "'", long16 == 62135946600000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62135946600000L) + "'", long18 == (-62135946600000L));
        org.junit.Assert.assertNull(durationField19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62135946600000L) + "'", long21 == (-62135946600000L));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withMinutes(0);
        org.joda.time.Period period7 = period3.withSeconds((-100));
        int int8 = period3.getMillis();
        org.joda.time.Period period10 = period3.plusHours(0);
        int int11 = period10.getDays();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test128");
//        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDay();
//        int int1 = periodType0.size();
//        org.joda.time.PeriodType periodType3 = null;
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, periodType3, chronology4);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.Period period7 = period5.minus(readablePeriod6);
//        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.Period period9 = period5.normalizedStandard(periodType8);
//        int[] intArray10 = period5.getValues();
//        org.joda.time.Period period12 = period5.minusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean15 = iSOChronology13.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.secondOfMinute();
//        java.util.TimeZone timeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) (byte) 0, locale20);
//        org.joda.time.ReadableInstant readableInstant22 = null;
//        int int23 = dateTimeZone18.getOffset(readableInstant22);
//        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology13, dateTimeZone18);
//        org.joda.time.DurationField durationField25 = zonedChronology24.weekyears();
//        org.joda.time.Period period27 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType28 = null;
//        org.joda.time.Period period29 = period27.normalizedStandard(periodType28);
//        org.joda.time.Period period31 = period27.minusSeconds(0);
//        boolean boolean32 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField25, (java.lang.Object) period27);
//        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType34 = periodType33.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType36 = periodType34.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField38 = new org.joda.time.field.ScaledDurationField(durationField25, durationFieldType36, (-1));
//        int int39 = period12.get(durationFieldType36);
//        int int40 = periodType0.indexOf(durationFieldType36);
//        org.junit.Assert.assertNotNull(periodType0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertNotNull(period9);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-25200000) + "'", int23 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(period31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(periodType33);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(durationFieldType36);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-100) + "'", int39 == (-100));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((-1L), periodType3, chronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period8 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.Minutes minutes9 = period8.toStandardMinutes();
        long long12 = iSOChronology6.add((org.joda.time.ReadablePeriod) period8, (long) (byte) 100, (int) (byte) 100);
        org.joda.time.Period period14 = period8.withDays((-1));
        org.joda.time.Period period15 = period5.plus((org.joda.time.ReadablePeriod) period8);
        java.lang.Object obj16 = null;
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period18 = new org.joda.time.Period(obj16, periodType17);
        org.joda.time.Period period19 = period5.normalizedStandard(periodType17);
        org.joda.time.Period period20 = new org.joda.time.Period(0L, 9223372036504975807L, periodType17);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(minutes9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(period19);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test130");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 4);
//        java.lang.String str4 = offsetDateTimeField3.getName();
//        int int5 = offsetDateTimeField3.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 5200L, "");
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean12 = iSOChronology10.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        int int20 = dateTimeZone15.getOffset(readableInstant19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone15);
//        org.joda.time.DurationField durationField22 = zonedChronology21.weekyears();
//        org.joda.time.Period period24 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period24.normalizedStandard(periodType25);
//        org.joda.time.Period period28 = period24.minusSeconds(0);
//        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField22, (java.lang.Object) period24);
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType31 = periodType30.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (-1));
//        long long37 = scaledDurationField35.getMillis((long) 'a');
//        int int40 = scaledDurationField35.getDifference(0L, (-31556952000L));
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, (org.joda.time.DurationField) scaledDurationField35);
//        org.joda.time.DurationField durationField42 = unsupportedDateTimeField41.getDurationField();
//        org.joda.time.DurationField durationField43 = unsupportedDateTimeField41.getDurationField();
//        org.joda.time.ReadablePartial readablePartial44 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Period period48 = org.joda.time.Period.days((int) (byte) 0);
//        org.joda.time.Minutes minutes49 = period48.toStandardMinutes();
//        long long52 = iSOChronology46.add((org.joda.time.ReadablePeriod) period48, (long) (byte) 100, (int) (byte) 100);
//        org.joda.time.DurationField durationField53 = iSOChronology46.weeks();
//        long long57 = iSOChronology46.add((-4L), (long) (byte) 1, 4);
//        org.joda.time.ReadableInstant readableInstant58 = null;
//        org.joda.time.ReadableInstant readableInstant59 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology60 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Period period62 = org.joda.time.Period.days((int) (byte) 0);
//        org.joda.time.Minutes minutes63 = period62.toStandardMinutes();
//        long long66 = iSOChronology60.add((org.joda.time.ReadablePeriod) period62, (long) (byte) 100, (int) (byte) 100);
//        org.joda.time.Duration duration67 = period62.toStandardDuration();
//        org.joda.time.ReadableInstant readableInstant68 = null;
//        org.joda.time.PeriodType periodType69 = org.joda.time.PeriodType.hours();
//        org.joda.time.Period period70 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration67, readableInstant68, periodType69);
//        org.joda.time.Period period71 = new org.joda.time.Period(readableInstant59, (org.joda.time.ReadableDuration) duration67);
//        org.joda.time.Period period72 = new org.joda.time.Period(readableInstant58, (org.joda.time.ReadableDuration) duration67);
//        int[] intArray75 = iSOChronology46.get((org.joda.time.ReadablePeriod) period72, (long) 0, (long) (short) 10);
//        try {
//            int[] intArray77 = unsupportedDateTimeField41.set(readablePartial44, 1, intArray75, (-28378000));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-25200000) + "'", int20 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3061024344000L) + "'", long37 == (-3061024344000L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(iSOChronology46);
//        org.junit.Assert.assertNotNull(period48);
//        org.junit.Assert.assertNotNull(minutes49);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 100L + "'", long52 == 100L);
//        org.junit.Assert.assertNotNull(durationField53);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology60);
//        org.junit.Assert.assertNotNull(period62);
//        org.junit.Assert.assertNotNull(minutes63);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 100L + "'", long66 == 100L);
//        org.junit.Assert.assertNotNull(duration67);
//        org.junit.Assert.assertNotNull(periodType69);
//        org.junit.Assert.assertNotNull(intArray75);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, periodType3, chronology4);
        org.joda.time.Period period7 = period5.withMinutes(0);
        org.joda.time.Period period9 = period5.withSeconds((-100));
        org.joda.time.Period period11 = period5.plusHours(10);
        org.joda.time.Period period13 = period11.plusMonths((int) (short) 0);
        org.joda.time.Period period15 = period11.plusHours((int) (short) 100);
        org.joda.time.Period period17 = period11.plusMonths((int) (short) 1);
        org.joda.time.Duration duration18 = period11.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration18, readableInstant19);
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration18);
        long long22 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration18);
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration18);
        int int24 = period23.getMinutes();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 36000000L + "'", long22 == 36000000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test132");
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, periodType1, chronology2);
//        org.joda.time.Period period5 = period3.withMinutes(0);
//        org.joda.time.Period period7 = period3.withSeconds((-100));
//        org.joda.time.Period period9 = period3.plusHours(10);
//        org.joda.time.Period period11 = period9.plusMonths((int) (short) 0);
//        org.joda.time.Period period13 = period9.plusHours((int) (short) 100);
//        org.joda.time.Period period15 = period9.plusMonths((int) (short) 1);
//        org.joda.time.Duration duration16 = period9.toStandardDuration();
//        org.joda.time.ReadableInstant readableInstant17 = null;
//        org.joda.time.Period period18 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant17);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean21 = iSOChronology19.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.secondOfMinute();
//        java.util.TimeZone timeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone24.getName((long) (byte) 0, locale26);
//        org.joda.time.ReadableInstant readableInstant28 = null;
//        int int29 = dateTimeZone24.getOffset(readableInstant28);
//        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology19, dateTimeZone24);
//        org.joda.time.DurationField durationField31 = zonedChronology30.weekyears();
//        org.joda.time.Period period33 = org.joda.time.Period.days((int) '4');
//        org.joda.time.PeriodType periodType34 = null;
//        org.joda.time.Period period35 = period33.normalizedStandard(periodType34);
//        org.joda.time.Period period37 = period33.minusSeconds(0);
//        boolean boolean38 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField31, (java.lang.Object) period33);
//        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType40 = periodType39.withDaysRemoved();
//        org.joda.time.DurationFieldType durationFieldType42 = periodType40.getFieldType(0);
//        org.joda.time.field.ScaledDurationField scaledDurationField44 = new org.joda.time.field.ScaledDurationField(durationField31, durationFieldType42, (-1));
//        boolean boolean45 = period18.isSupported(durationFieldType42);
//        org.joda.time.Period period47 = period18.withMonths((-97));
//        org.joda.time.MutablePeriod mutablePeriod48 = period47.toMutablePeriod();
//        org.joda.time.Period period50 = period47.withMillis(8);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertNotNull(period9);
//        org.junit.Assert.assertNotNull(period11);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(period15);
//        org.junit.Assert.assertNotNull(duration16);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-25200000) + "'", int29 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(period37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(periodType39);
//        org.junit.Assert.assertNotNull(periodType40);
//        org.junit.Assert.assertNotNull(durationFieldType42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(period47);
//        org.junit.Assert.assertNotNull(mutablePeriod48);
//        org.junit.Assert.assertNotNull(period50);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test133");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.minuteOfHour();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.lang.String str9 = dateTimeZone7.getShortName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        long long15 = gregorianChronology10.getDateTimeMillis((-28800000), (int) (byte) 10, 1, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology10.getZone();
//        boolean boolean17 = gregorianChronology4.equals((java.lang.Object) gregorianChronology10);
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology4.getZone();
//        org.joda.time.DurationField durationField19 = gregorianChronology4.months();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PST" + "'", str9.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-908902361117221990L) + "'", long15 == (-908902361117221990L));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(durationField19);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology4.era();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str10 = offsetDateTimeField9.getName();
        int int11 = offsetDateTimeField9.getOffset();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType12);
        long long15 = zeroIsMaxDateTimeField13.remainder((long) (-7));
        long long17 = zeroIsMaxDateTimeField13.roundHalfCeiling(6682L);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int int19 = zeroIsMaxDateTimeField13.getMaximumValue(readablePartial18);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.lang.Object obj21 = null;
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period23 = new org.joda.time.Period(obj21, periodType22);
        org.joda.time.JodaTimePermission jodaTimePermission25 = new org.joda.time.JodaTimePermission("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]");
        org.joda.time.JodaTimePermission jodaTimePermission27 = new org.joda.time.JodaTimePermission("monthOfYear");
        boolean boolean28 = jodaTimePermission25.implies((java.security.Permission) jodaTimePermission27);
        java.lang.Object obj29 = null;
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period31 = new org.joda.time.Period(obj29, periodType30);
        jodaTimePermission25.checkGuard((java.lang.Object) periodType30);
        org.joda.time.JodaTimePermission jodaTimePermission34 = new org.joda.time.JodaTimePermission("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]");
        org.joda.time.JodaTimePermission jodaTimePermission36 = new org.joda.time.JodaTimePermission("monthOfYear");
        boolean boolean37 = jodaTimePermission34.implies((java.security.Permission) jodaTimePermission36);
        boolean boolean38 = jodaTimePermission25.implies((java.security.Permission) jodaTimePermission34);
        boolean boolean39 = periodType22.equals((java.lang.Object) jodaTimePermission25);
        org.joda.time.Period period41 = org.joda.time.Period.minutes((int) (byte) 100);
        int[] intArray42 = period41.getValues();
        jodaTimePermission25.checkGuard((java.lang.Object) intArray42);
        int int44 = zeroIsMaxDateTimeField13.getMinimumValue(readablePartial20, intArray42);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "monthOfYear" + "'", str10.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 62135946599993L + "'", long15 == 62135946599993L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135946600000L) + "'", long17 == (-62135946600000L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test135");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
//        java.lang.String str4 = iSOChronology0.toString();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone6.getShortName((long) 0, locale11);
//        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.weekyear();
//        org.joda.time.Chronology chronology18 = iSOChronology0.withUTC();
//        org.joda.time.DurationField durationField19 = iSOChronology0.months();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology0.year();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PeriodType[YearDay]", "org.joda.time.IllegalFieldValueException: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]", (int) (short) -1, (-100));
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getNameKey(0L);
        java.lang.String str9 = fixedDateTimeZone4.getNameKey(13046400000L);
        java.lang.Object obj10 = null;
        boolean boolean11 = fixedDateTimeZone4.equals(obj10);
        boolean boolean12 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]" + "'", str9.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for PeriodType[YearMonthDayTime] must be in the range [-97,10.0]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test137");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDayTime]", (java.lang.Number) 100.0d, (java.lang.Number) (-97), (java.lang.Number) 10.0d);
//        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
//        java.lang.String str6 = illegalFieldValueException4.getFieldName();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean10 = iSOChronology8.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.secondOfMinute();
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getName((long) (byte) 0, locale15);
//        org.joda.time.ReadableInstant readableInstant17 = null;
//        int int18 = dateTimeZone13.getOffset(readableInstant17);
//        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology8, dateTimeZone13);
//        org.joda.time.DurationField durationField20 = zonedChronology19.weekyears();
//        org.joda.time.DateTimeField dateTimeField21 = zonedChronology19.clockhourOfDay();
//        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 2440588L, (java.lang.Object) zonedChronology19);
//        org.joda.time.DateTimeField dateTimeField23 = zonedChronology19.halfdayOfDay();
//        boolean boolean24 = org.joda.time.field.FieldUtils.equals((java.lang.Object) str6, (java.lang.Object) dateTimeField23);
//        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-97) + "'", number5.equals((-97)));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PeriodType[YearMonthDayTime]" + "'", str6.equals("PeriodType[YearMonthDayTime]"));
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pacific Standard Time" + "'", str16.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-25200000) + "'", int18 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test138");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology4.era();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
//        java.lang.String str10 = offsetDateTimeField9.getName();
//        int int11 = offsetDateTimeField9.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType12);
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean17 = iSOChronology15.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.secondOfMinute();
//        java.lang.String str19 = iSOChronology15.toString();
//        java.util.TimeZone timeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone21.getName((long) (byte) 0, locale23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone21.getShortName((long) 0, locale26);
//        org.joda.time.Chronology chronology28 = iSOChronology15.withZone(dateTimeZone21);
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology15.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology15.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology15.centuryOfEra();
//        org.joda.time.Period period33 = org.joda.time.Period.weeks(0);
//        org.joda.time.Period period35 = period33.withSeconds((-28800000));
//        org.joda.time.DurationFieldType[] durationFieldTypeArray36 = period33.getFieldTypes();
//        int[] intArray38 = iSOChronology15.get((org.joda.time.ReadablePeriod) period33, (-113512000L));
//        int int39 = zeroIsMaxDateTimeField13.getMinimumValue(readablePartial14, intArray38);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, 4);
//        boolean boolean46 = offsetDateTimeField44.isLeap((long) 0);
//        long long49 = offsetDateTimeField44.addWrapField((long) (short) 10, (-25200000));
//        java.lang.String str51 = offsetDateTimeField44.getAsShortText((long) (byte) -1);
//        org.joda.time.ReadablePartial readablePartial52 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean56 = iSOChronology54.equals((java.lang.Object) (short) 0);
//        org.joda.time.DateTimeField dateTimeField57 = iSOChronology54.secondOfMinute();
//        java.util.TimeZone timeZone58 = null;
//        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.forTimeZone(timeZone58);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = dateTimeZone59.getName((long) (byte) 0, locale61);
//        org.joda.time.ReadableInstant readableInstant63 = null;
//        int int64 = dateTimeZone59.getOffset(readableInstant63);
//        org.joda.time.chrono.ZonedChronology zonedChronology65 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology54, dateTimeZone59);
//        org.joda.time.DurationField durationField66 = zonedChronology65.weekyears();
//        org.joda.time.DateTimeField dateTimeField67 = zonedChronology65.clockhourOfDay();
//        boolean boolean68 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 2440588L, (java.lang.Object) zonedChronology65);
//        org.joda.time.Period period70 = org.joda.time.Period.days((int) '4');
//        org.joda.time.Period period72 = period70.withWeeks((int) '#');
//        org.joda.time.Period period74 = period70.minusYears((int) (short) 100);
//        int[] intArray76 = zonedChronology65.get((org.joda.time.ReadablePeriod) period70, (-1L));
//        int int77 = offsetDateTimeField44.getMaximumValue(readablePartial52, intArray76);
//        int int78 = zeroIsMaxDateTimeField13.getMaximumValue(readablePartial40, intArray76);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(lenientChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "monthOfYear" + "'", str10.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[UTC]" + "'", str19.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "PST" + "'", str27.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(durationFieldTypeArray36);
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(iSOChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 10L + "'", long49 == 10L);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "16" + "'", str51.equals("16"));
//        org.junit.Assert.assertNotNull(iSOChronology54);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTimeZone59);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Pacific Standard Time" + "'", str62.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-25200000) + "'", int64 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology65);
//        org.junit.Assert.assertNotNull(durationField66);
//        org.junit.Assert.assertNotNull(dateTimeField67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(period70);
//        org.junit.Assert.assertNotNull(period72);
//        org.junit.Assert.assertNotNull(period74);
//        org.junit.Assert.assertNotNull(intArray76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 16 + "'", int77 == 16);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2 + "'", int78 == 2);
//    }
//}

