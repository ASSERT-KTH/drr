import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, (int) (short) 1, (int) (byte) 1, (int) '#');
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1L, (long) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.withMillis((long) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            int int7 = dateTime2.get(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) true, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.withMillis((long) (short) 100);
        try {
            org.joda.time.DateTime dateTime7 = dateTime2.withHourOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 0, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-100L) + "'", long2 == (-100L));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime5 = dateTime2.withEra((int) (byte) 1);
        boolean boolean7 = dateTime2.equals((java.lang.Object) (-1));
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("0", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
        try {
            long long8 = iSOChronology1.getDateTimeMillis(11, 0, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        try {
            long long2 = dateTimeFormatter0.parseMillis("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[America/Los_Angeles]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
        java.util.Locale locale11 = null;
        java.util.Calendar calendar12 = dateTime9.toCalendar(locale11);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(calendar12);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.secondOfMinute();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10, (-1), 3, (-1), (int) (short) 100, (int) (byte) -1, (org.joda.time.Chronology) iSOChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        long long11 = dateTimeZone7.convertLocalToUTC(0L, false, (long) 100);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(2000, 11, (-1), (int) (byte) 1, 11, 0, (int) (short) -1, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) (byte) -1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.withMillis((long) (short) 100);
        try {
            org.joda.time.DateTime dateTime7 = dateTime2.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) dateTime5);
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withDayOfMonth(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        org.joda.time.DateTime dateTime6 = property3.roundCeilingCopy();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.DateTime dateTime9 = dateTime6.withFieldAdded(durationFieldType7, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime.Property property14 = dateTime10.minuteOfDay();
        java.lang.String str15 = property14.getName();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "minuteOfDay" + "'", str15.equals("minuteOfDay"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter2.withPivotYear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
        java.lang.String str10 = property9.toString();
        org.joda.time.DateTime dateTime12 = property9.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime15 = dateTime12.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate16 = dateTime15.toLocalDate();
        java.lang.String str17 = dateTimeFormatter5.print((org.joda.time.ReadablePartial) localDate16);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfMinute]" + "'", str10.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1970W013T������.000" + "'", str17.equals("1970W013T������.000"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(59, (int) (short) 1, 19, 11, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(2000, (int) (byte) 0, (int) (short) -1, 12, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime5 = property3.roundFloorCopy();
        java.util.Locale locale7 = null;
        try {
            org.joda.time.DateTime dateTime8 = property3.setCopy("", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (-100L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("ISOChronology[America/Los_Angeles]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[America/Los_Angeles]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
        java.lang.Class<?> wildcardClass4 = dateTimeField3.getClass();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("Property[secondOfMinute]", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("secondOfMinute", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 3);
        int int11 = fixedDateTimeZone4.getStandardOffset((long) 11);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2000);
        try {
            org.joda.time.DateTime dateTime3 = dateTime1.withDayOfYear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 1, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1970W013T������.000", "Coordinated Universal Time");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfDay();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = iSOChronology1.get(readablePeriod5, (long) 59, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        boolean boolean8 = dateTime6.isEqual((long) 16);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("Property[secondOfMinute]", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        int int4 = dateTimeFormatter3.getDefaultYear();
        java.lang.Appendable appendable5 = null;
        try {
            dateTimeFormatter3.printTo(appendable5, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2000 + "'", int4 == 2000);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.DurationField durationField33 = iSOChronology32.years();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
        org.joda.time.DurationField durationField36 = iSOChronology35.years();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField37 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType29, durationField33, durationField36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(durationField36);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.withMillis((long) (short) 100);
        try {
            org.joda.time.DateTime dateTime7 = dateTime2.withMonthOfYear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        java.lang.String str5 = property4.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTime dateTime11 = dateTime8.withMillis((long) (short) 100);
        int int12 = property4.getDifference((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime14 = dateTime11.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.DateTime.Property property31 = dateTime14.property(dateTimeFieldType30);
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField37 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType30, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[secondOfMinute]" + "'", str5.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(property31);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("+00:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) '4', (int) (short) 0, 11, 3, (int) (short) 100, 3, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfMinute();
        org.joda.time.DateTime dateTime6 = property5.roundHalfFloorCopy();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 1970, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1969L + "'", long2 == 1969L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Coordinated Universal Time/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
        int int10 = dateTime6.getDayOfWeek();
        long long11 = dateTime6.getMillis();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfMinute();
        java.lang.String str8 = property7.toString();
        org.joda.time.DateTime dateTime10 = property7.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate14 = dateTime13.toLocalDate();
        java.lang.String str15 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) localDate14);
        boolean boolean16 = dateTimeFormatter3.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[secondOfMinute]" + "'", str8.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970W013T������.000" + "'", str15.equals("1970W013T������.000"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10, (java.lang.Number) (-1), (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(100, (int) (byte) 100, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
        long long7 = iSOChronology1.add((long) 1, (-100L), 0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        java.lang.String str5 = property4.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTime dateTime11 = dateTime8.withMillis((long) (short) 100);
        int int12 = property4.getDifference((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime14 = dateTime11.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.DateTime.Property property31 = dateTime14.property(dateTimeFieldType30);
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[secondOfMinute]" + "'", str5.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(property31);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1969L, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 19690L + "'", long2 == 19690L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone11.getName((long) '#', locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11, 3);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(10, 3, (int) '4', 1969, 12, 16, 0, (org.joda.time.Chronology) gregorianChronology16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
        org.junit.Assert.assertNotNull(gregorianChronology16);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfMinute();
        java.lang.String str6 = property5.toString();
        org.joda.time.DateTime dateTime8 = property5.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime11 = dateTime8.withDurationAdded((long) 'a', (-1));
        int int12 = dateTime8.getDayOfWeek();
        org.joda.time.DateTime dateTime17 = dateTime8.withTime((int) (short) 1, (int) '4', (int) (byte) 1, (int) 'a');
        org.joda.time.DateTime dateTime19 = dateTime8.minusSeconds((int) (byte) 0);
        org.joda.time.YearMonthDay yearMonthDay20 = dateTime19.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) yearMonthDay20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[secondOfMinute]" + "'", str6.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(yearMonthDay20);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName(10L);
//        long long6 = dateTimeZone0.convertLocalToUTC((long) 11, true, (long) 2);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 11L + "'", long6 == 11L);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.Chronology chronology4 = gregorianChronology1.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.year();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType4, (int) '#', (int) (short) -1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime9 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.secondOfMinute();
        java.lang.String str14 = property13.toString();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
        org.joda.time.DateTime dateTime20 = dateTime17.withMillis((long) (short) 100);
        int int21 = property13.getDifference((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime23 = dateTime20.plusWeeks((-1));
        org.joda.time.DateTime.Property property24 = dateTime20.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        try {
            org.joda.time.DateTime dateTime27 = dateTime5.withField(dateTimeFieldType25, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for minuteOfDay must be in the range [0,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Property[secondOfMinute]" + "'", str14.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        int int5 = dateTime4.getCenturyOfEra();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
//        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str15 = dateTimeZone13.getName(10L);
//        int int17 = dateTimeZone13.getOffsetFromLocal((long) 19);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        org.joda.time.Chronology chronology19 = zonedChronology12.withZone(dateTimeZone18);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone18.getShortName(19690L, locale21);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UTC" + "'", str22.equals("UTC"));
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 1, 16, (int) (short) 0, 19, 59, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        try {
            org.joda.time.LocalDateTime localDateTime5 = dateTimeFormatter3.parseLocalDateTime("ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[America/Los_Angeles]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = dateTime5.toString("minuteOfDay", locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
        int int10 = dateTime6.getDayOfWeek();
        org.joda.time.DateTime dateTime15 = dateTime6.withTime((int) (short) 1, (int) '4', (int) (byte) 1, (int) 'a');
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            int int17 = dateTime6.get(dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray3 = iSOChronology0.get(readablePeriod1, (long) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.Object obj0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime8 = property7.withMaximumValue();
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int14 = fixedDateTimeZone12.getStandardOffset((long) 2);
        java.util.Locale locale16 = null;
        java.lang.String str17 = fixedDateTimeZone12.getShortName((long) 59, locale16);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.Chronology chronology19 = zonedChronology18.withUTC();
        try {
            org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((int) '4', (int) (byte) 10, (int) 'a', (int) (byte) 100, 0, 12, (org.joda.time.Chronology) zonedChronology18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) '4', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 152 + "'", int2 == 152);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int12 = fixedDateTimeZone10.getStandardOffset((long) 2);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(19, 1, 0, 1969, 19, 152, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.minusMillis((int) ' ');
        boolean boolean16 = dateTime15.isBeforeNow();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
        org.joda.time.DurationField durationField7 = property6.getLeapDurationField();
        int int8 = property6.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2000);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy(2);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (-1), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("Property[secondOfMinute]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[secondOfMinute]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.withMillis((long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.year();
        int int10 = dateTime2.get(dateTimeField9);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.getAsText();
        int int5 = property3.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfMinute();
        java.lang.String str8 = property7.toString();
        org.joda.time.DateTime dateTime10 = property7.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate14 = dateTime13.toLocalDate();
        java.lang.String str15 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) localDate14);
        boolean boolean16 = dateTimeFormatter3.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[secondOfMinute]" + "'", str8.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970W013T������.000" + "'", str15.equals("1970W013T������.000"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long4 = dateTimeZone0.convertLocalToUTC(0L, false, (long) 100);
        boolean boolean6 = dateTimeZone0.isStandardOffset(1969L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (byte) -1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime10.plus(readableDuration14);
        org.joda.time.DateTime dateTime17 = dateTime10.withYearOfCentury(2);
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = dateTime17.toString("1970W013T������.000", locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: W");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.minusMillis((int) ' ');
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime13.withDurationAdded(readableDuration16, (int) '4');
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone9.getName((long) '#', locale11);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9, 3);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(0, 960, (int) (byte) -1, 152, (int) (short) 1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 152 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertNotNull(gregorianChronology14);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("secondOfMinute", "ISOChronology[America/Los_Angeles]");
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName(10L);
//        long long5 = dateTimeZone0.adjustOffset(0L, true);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("1970W013T������.000", (int) (byte) -1, 1970, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for 1970W013T������.000 must be in the range [1970,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) (byte) 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName(10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZone(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType29, 12, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12 for minuteOfDay must be in the range [0,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        long long6 = dateTime5.getMillis();
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withDayOfMonth((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.withMillis((long) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minus(10L);
        int int8 = dateTime7.getDayOfYear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DurationField durationField5 = iSOChronology1.weeks();
        org.joda.time.DurationField durationField6 = iSOChronology1.eras();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        boolean boolean8 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readableDuration9);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2000);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        int int5 = dateTime3.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        org.joda.time.DurationField durationField6 = property3.getRangeDurationField();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.millis();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        try {
            long long11 = iSOChronology1.getDateTimeMillis(152, (int) (byte) 10, (int) (byte) 0, 2000, (int) (byte) -1, 1969, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        java.util.Locale locale5 = null;
        int int6 = property3.getMaximumShortTextLength(locale5);
        org.joda.time.DateTimeField dateTimeField7 = property3.getField();
        org.joda.time.DateTimeField dateTimeField8 = property3.getField();
        org.joda.time.DurationField durationField9 = property3.getLeapDurationField();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNull(durationField9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsString();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.year();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime9 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property10 = dateTime9.weekyear();
        org.joda.time.ReadableInstant readableInstant11 = null;
        try {
            int int12 = property10.compareTo(readableInstant11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        org.joda.time.DateTime dateTime6 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property3.roundHalfEvenCopy();
        org.joda.time.DurationField durationField8 = property3.getLeapDurationField();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNull(durationField8);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int14 = fixedDateTimeZone12.getStandardOffset((long) 2);
        java.util.Locale locale16 = null;
        java.lang.String str17 = fixedDateTimeZone12.getShortName((long) 59, locale16);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((int) (short) 100, (int) (byte) 0, (int) (short) 0, 1969, (int) (short) 1, 11, (org.joda.time.Chronology) iSOChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology18);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekOfWeekyear((int) (short) 1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfMinute();
        java.lang.String str8 = property7.toString();
        org.joda.time.DateTime dateTime10 = property7.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate14 = dateTime13.toLocalDate();
        java.lang.String str15 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter3.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter3.withOffsetParsed();
        java.io.Writer writer18 = null;
        org.joda.time.ReadablePartial readablePartial19 = null;
        try {
            dateTimeFormatter17.printTo(writer18, readablePartial19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[secondOfMinute]" + "'", str8.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970W013T������.000" + "'", str15.equals("1970W013T������.000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        try {
            long long2 = dateTimeFormatter0.parseMillis("+00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        boolean boolean5 = dateTime4.isEqualNow();
        int int6 = dateTime4.getSecondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime.Property property16 = dateTime10.minuteOfHour();
        java.lang.String str17 = property16.getAsString();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.secondOfMinute();
        java.lang.String str21 = iSOChronology19.toString();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology19);
        org.joda.time.YearMonthDay yearMonthDay23 = dateTime22.toYearMonthDay();
        try {
            int int24 = property16.compareTo((org.joda.time.ReadablePartial) yearMonthDay23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str21.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(yearMonthDay23);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.halfdayOfDay();
        org.joda.time.ReadablePartial readablePartial4 = null;
        int[] intArray8 = new int[] { '#', (short) 10, 365 };
        try {
            iSOChronology1.validate(readablePartial4, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
        int int10 = dateTime6.getDayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime6.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime6.plus(readableDuration13);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readableDuration15);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        org.joda.time.DateTime dateTime6 = property3.roundCeilingCopy();
        java.util.Locale locale8 = null;
        try {
            org.joda.time.DateTime dateTime9 = property3.setCopy("UTC", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("0");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"0\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"0\")"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("1970W013T������.000", 0);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("1969", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfMonth();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DateTime.Property property11 = dateTime9.yearOfEra();
        boolean boolean12 = dateTime9.isAfterNow();
        int int13 = dateTime6.compareTo((org.joda.time.ReadableInstant) dateTime9);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        java.lang.String str5 = property4.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTime dateTime11 = dateTime8.withMillis((long) (short) 100);
        int int12 = property4.getDifference((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime14 = dateTime11.plusYears((int) '4');
        org.joda.time.DateTime dateTime16 = dateTime11.minusDays(11);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone18);
        org.joda.time.DateTime.Property property20 = dateTime19.secondOfMinute();
        java.lang.String str21 = property20.toString();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone23);
        org.joda.time.DateTime.Property property25 = dateTime24.secondOfDay();
        org.joda.time.DateTime dateTime27 = dateTime24.withMillis((long) (short) 100);
        int int28 = property20.getDifference((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime dateTime30 = dateTime27.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone32);
        org.joda.time.DateTime.Property property34 = dateTime33.secondOfMinute();
        java.lang.String str35 = property34.toString();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone37);
        org.joda.time.DateTime.Property property39 = dateTime38.secondOfDay();
        org.joda.time.DateTime dateTime41 = dateTime38.withMillis((long) (short) 100);
        int int42 = property34.getDifference((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTime dateTime44 = dateTime41.plusWeeks((-1));
        org.joda.time.DateTime.Property property45 = dateTime41.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.DateTime.Property property47 = dateTime30.property(dateTimeFieldType46);
        org.joda.time.IllegalFieldValueException illegalFieldValueException51 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType46, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
        org.joda.time.DateTime.Property property52 = dateTime16.property(dateTimeFieldType46);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[secondOfMinute]" + "'", str5.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Property[secondOfMinute]" + "'", str21.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Property[secondOfMinute]" + "'", str35.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(property52);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        int int7 = dateTime6.getCenturyOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.roundFloorCopy();
        try {
            org.joda.time.DateTime dateTime11 = property8.setCopy("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ISOChronology[UTC]\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter3.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter3.withPivotYear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfMinute();
        java.lang.String str11 = property10.toString();
        org.joda.time.DateTime dateTime13 = property10.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
        java.lang.String str18 = dateTimeFormatter6.print((org.joda.time.ReadablePartial) localDate17);
        int[] intArray22 = new int[] { 19, (short) 10, (short) 100 };
        try {
            iSOChronology1.validate((org.joda.time.ReadablePartial) localDate17, intArray22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must not be larger than 31");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[secondOfMinute]" + "'", str11.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970W013T������.000" + "'", str18.equals("1970W013T������.000"));
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        java.lang.String str5 = property4.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTime dateTime11 = dateTime8.withMillis((long) (short) 100);
        int int12 = property4.getDifference((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime14 = dateTime11.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.DateTime.Property property31 = dateTime14.property(dateTimeFieldType30);
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField36 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[secondOfMinute]" + "'", str5.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(property31);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
//        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str15 = dateTimeZone13.getName(10L);
//        int int17 = dateTimeZone13.getOffsetFromLocal((long) 19);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        org.joda.time.Chronology chronology19 = zonedChronology12.withZone(dateTimeZone18);
//        java.lang.String str20 = zonedChronology12.toString();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ZonedChronology[ISOChronology[UTC], hi!]" + "'", str20.equals("ZonedChronology[ISOChronology[UTC], hi!]"));
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withPivotYear((int) (byte) -1);
        boolean boolean5 = dateTimeFormatter1.isPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withDefaultYear(10);
        try {
            org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.parse("ISOChronology[UTC]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DurationField durationField13 = iSOChronology1.months();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.DateTime dateTime32 = dateTime13.minusMonths((int) (short) 1);
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        try {
            org.joda.time.DateTime dateTime35 = dateTime32.withDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 10, (int) (byte) 100, (int) (byte) 0, (int) (short) 100, (-1), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField4 = gregorianChronology2.months();
        try {
            long long9 = gregorianChronology2.getDateTimeMillis((int) (byte) 10, 69, 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("1970W013T������.000", 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder3.addCutover(19, '#', 59, 1969, (int) 'a', true, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2000);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        int int5 = property4.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField6 = property4.getField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2000);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay(1);
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        long long5 = durationField2.subtract(0L, 16);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-691200000L) + "'", long5 == (-691200000L));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
        int int10 = dateTime6.getDayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime6.withWeekOfWeekyear((int) (short) 1);
        java.lang.Object obj13 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(obj13, (org.joda.time.DateTimeZone) fixedDateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        try {
            java.lang.String str22 = dateTime12.toString("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: U");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
        int int10 = dateTime6.getDayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime6.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime6.plus(readableDuration13);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.secondOfMinute();
        java.lang.String str19 = iSOChronology17.toString();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTime dateTime22 = dateTime20.withWeekOfWeekyear((int) (byte) 10);
        boolean boolean23 = dateTime14.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime25 = dateTime22.minusMonths(0);
        org.joda.time.DateTime.Property property26 = dateTime22.centuryOfEra();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str19.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime.Property property16 = dateTime10.minuteOfHour();
        org.joda.time.DateTime dateTime18 = dateTime10.plusMinutes((int) (byte) -1);
        org.joda.time.DateTime dateTime20 = dateTime10.withEra((int) (short) 1);
        org.joda.time.DateTime dateTime22 = dateTime20.plusMillis(0);
        int int23 = dateTime22.getCenturyOfEra();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19 + "'", int23 == 19);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime5 = property3.roundFloorCopy();
        org.joda.time.DurationField durationField6 = property3.getLeapDurationField();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNull(durationField6);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime5 = property3.addToCopy((int) ' ');
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.getAsText();
        boolean boolean5 = property3.isLeap();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfMinute();
        java.lang.String str8 = property7.toString();
        org.joda.time.DateTime dateTime10 = property7.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate14 = dateTime13.toLocalDate();
        java.lang.String str15 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter3.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter3.withOffsetParsed();
        org.joda.time.Chronology chronology18 = dateTimeFormatter3.getChronology();
        java.util.Locale locale19 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter3.withLocale(locale19);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[secondOfMinute]" + "'", str8.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970W013T������.000" + "'", str15.equals("1970W013T������.000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1970W013T������.000", "Coordinated Universal Time");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        java.lang.Number number5 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNull(number5);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560635854838L + "'", long0 == 1560635854838L);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DurationField durationField5 = iSOChronology1.weekyears();
        long long8 = durationField5.subtract((long) 152, (-28800000L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 908840217600000152L + "'", long8 == 908840217600000152L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        int int16 = dateTime15.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter3.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter3.withPivotYear((int) (short) 1);
        java.lang.Appendable appendable7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        try {
            dateTimeFormatter6.printTo(appendable7, readableInstant8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(365, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12775 + "'", int2 == 12775);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        boolean boolean5 = dateTime4.isEqualNow();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        java.util.GregorianCalendar gregorianCalendar10 = dateTime8.toGregorianCalendar();
        boolean boolean11 = dateTime4.isAfter((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime13 = dateTime8.withMillisOfSecond(59);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DurationField durationField5 = iSOChronology1.minutes();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone14);
        org.joda.time.DateTime.Property property16 = dateTime15.secondOfMinute();
        java.lang.String str17 = property16.toString();
        org.joda.time.DateTime dateTime19 = property16.addWrapFieldToCopy(0);
        int int20 = dateTime19.getCenturyOfEra();
        org.joda.time.LocalDateTime localDateTime21 = dateTime19.toLocalDateTime();
        long long23 = zonedChronology12.set((org.joda.time.ReadablePartial) localDateTime21, (long) 100);
        org.joda.time.DateTimeField dateTimeField24 = zonedChronology12.millisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Property[secondOfMinute]" + "'", str17.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 19 + "'", int20 == 19);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-28800000L) + "'", long23 == (-28800000L));
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        boolean boolean4 = dateTimeFormatter0.isPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withDefaultYear(10);
        try {
            org.joda.time.LocalDate localDate8 = dateTimeFormatter0.parseLocalDate("ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[America/Los_Angeles]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2000);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.Chronology chronology13 = gregorianChronology10.withUTC();
        int int14 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.DateTime dateTime32 = dateTime13.toDateTime(chronology31);
        org.joda.time.DateTime dateTime34 = dateTime13.withMinuteOfHour((int) (short) 1);
        org.joda.time.DateTime.Property property35 = dateTime13.dayOfYear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        boolean boolean2 = dateTimeZone0.isStandardOffset(0L);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(11, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime10 = dateTime8.plusSeconds(16);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("Property[secondOfMinute]", 0, 960, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for Property[secondOfMinute] must be in the range [960,35]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 3);
        org.joda.time.DurationField durationField10 = gregorianChronology9.seconds();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.Object obj0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        org.joda.time.Interval interval7 = property3.toInterval();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(interval7);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        boolean boolean7 = property4.isLeap();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName(10L);
//        int int4 = dateTimeZone0.getOffsetFromLocal((long) 19);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.withMillis((long) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minus(10L);
        boolean boolean8 = dateTime5.isBeforeNow();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField5 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType3, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.minusMillis((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone17);
        org.joda.time.DateTime.Property property19 = dateTime18.secondOfMinute();
        java.lang.String str20 = property19.toString();
        org.joda.time.DateTime dateTime22 = property19.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded((long) 'a', (-1));
        int int26 = dateTime22.getDayOfWeek();
        org.joda.time.DateTime dateTime31 = dateTime22.withTime((int) (short) 1, (int) '4', (int) (byte) 1, (int) 'a');
        org.joda.time.DateTime dateTime33 = dateTime22.minusSeconds((int) (byte) 0);
        org.joda.time.YearMonthDay yearMonthDay34 = dateTime33.toYearMonthDay();
        boolean boolean35 = dateTime15.isBefore((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime37 = dateTime33.minus(readablePeriod36);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Property[secondOfMinute]" + "'", str20.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(yearMonthDay34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTime37);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.minusMillis((int) ' ');
        org.joda.time.DateTime.Property property16 = dateTime15.millisOfDay();
        long long17 = dateTime15.getMillis();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1640995200068L + "'", long17 == 1640995200068L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
        org.joda.time.DurationField durationField7 = property6.getLeapDurationField();
        java.util.Locale locale9 = null;
        try {
            org.joda.time.DateTime dateTime10 = property6.setCopy("", locale9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNull(durationField7);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
//        java.lang.String str4 = property3.toString();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
//        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
//        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
//        org.joda.time.DateTime.Property property16 = dateTime10.minuteOfHour();
//        java.lang.String str17 = property16.getAsString();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.secondOfMinute();
//        java.lang.String str21 = iSOChronology19.toString();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology19);
//        org.joda.time.YearMonthDay yearMonthDay23 = dateTime22.toYearMonthDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.plusDays((int) (short) 0);
//        long long26 = property16.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime25);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ISOChronology[hi!]" + "'", str21.equals("ISOChronology[hi!]"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(yearMonthDay23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-26010597L) + "'", long26 == (-26010597L));
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        long long6 = dateTime5.getMillis();
        int int7 = dateTime5.getMillisOfSecond();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DurationField durationField3 = iSOChronology1.seconds();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime.Property property16 = dateTime10.minuteOfHour();
        org.joda.time.DateTime dateTime18 = dateTime10.plusMinutes((int) (byte) -1);
        int int19 = dateTime10.getSecondOfMinute();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfDay();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime6);
        org.joda.time.DateTime dateTime9 = dateTime6.minusHours((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.secondOfMinute();
        java.lang.String str14 = property13.toString();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
        org.joda.time.DateTime dateTime20 = dateTime17.withMillis((long) (short) 100);
        int int21 = property13.getDifference((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime23 = dateTime20.plusWeeks((-1));
        org.joda.time.DateTime.Property property24 = dateTime20.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        int int26 = dateTime6.get(dateTimeFieldType25);
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) 1970, (java.lang.Number) 1560635854838L, (java.lang.Number) 3);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField31 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Property[secondOfMinute]" + "'", str14.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        int int4 = dateTimeFormatter3.getDefaultYear();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter3.withLocale(locale5);
        java.lang.Integer int7 = dateTimeFormatter3.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2000 + "'", int4 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7.equals((-1)));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DurationField durationField4 = property3.getDurationField();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            int[] intArray6 = iSOChronology1.get(readablePartial4, 1560635854838L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        long long4 = dateTimeZone0.convertLocalToUTC(0L, false, (long) 100);
//        java.lang.String str6 = dateTimeZone0.getShortName((long) 16);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int6 = fixedDateTimeZone4.getStandardOffset((long) 2);
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone4.getShortName((long) 59, locale8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.secondOfMinute();
        org.joda.time.DateTime dateTime14 = property13.roundHalfFloorCopy();
        boolean boolean15 = fixedDateTimeZone4.equals((java.lang.Object) dateTime14);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) 1, (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3L) + "'", long2 == (-3L));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 3);
        java.lang.String str11 = fixedDateTimeZone4.getShortName((long) ' ');
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        java.lang.String str8 = gregorianChronology7.toString();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        long long13 = dateTimeZone9.convertLocalToUTC((long) 100, true, (long) 2000);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(3, 12775, (int) (byte) 100, 2000, (int) (short) 100, 11, dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        org.joda.time.DateTime dateTime6 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime8 = property3.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) dateTime5);
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withMonthOfYear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology2.add(readablePeriod3, (long) 1969, 12);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology2.getZone();
        java.lang.String str8 = dateTimeZone7.getID();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withZone(dateTimeZone7);
        org.joda.time.Chronology chronology10 = dateTimeFormatter9.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1969L + "'", long6 == 1969L);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNull(chronology10);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        org.joda.time.DateTime dateTime7 = property3.addToCopy((int) (byte) -1);
        org.joda.time.DurationField durationField8 = property3.getDurationField();
        long long9 = property3.remainder();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
        int int10 = dateTime6.getDayOfWeek();
        boolean boolean11 = dateTime6.isEqualNow();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withPivotYear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
        java.lang.String str9 = property8.toString();
        org.joda.time.DateTime dateTime11 = property8.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
        java.lang.String str16 = dateTimeFormatter4.print((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter4.withOffsetParsed();
        try {
            org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.parse("ISOChronology[hi!]", dateTimeFormatter4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[hi!]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[secondOfMinute]" + "'", str9.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970W013T������.000" + "'", str16.equals("1970W013T������.000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone7.getName((long) '#', locale9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology13);
        boolean boolean15 = fixedDateTimeZone7.equals((java.lang.Object) gregorianChronology13);
        long long17 = fixedDateTimeZone7.nextTransition((long) 19);
        long long19 = fixedDateTimeZone7.nextTransition((long) (byte) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone21 = zonedChronology20.getZone();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 19L + "'", long17 == 19L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int16 = fixedDateTimeZone14.getStandardOffset((long) 2);
        java.util.Locale locale18 = null;
        java.lang.String str19 = fixedDateTimeZone14.getShortName((long) 59, locale18);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology9, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone22);
        org.joda.time.DateTime.Property property24 = dateTime23.secondOfMinute();
        java.lang.String str25 = property24.toString();
        org.joda.time.DateTime dateTime27 = property24.addWrapFieldToCopy(0);
        int int28 = dateTime27.getCenturyOfEra();
        org.joda.time.LocalDateTime localDateTime29 = dateTime27.toLocalDateTime();
        long long31 = zonedChronology20.set((org.joda.time.ReadablePartial) localDateTime29, (long) 100);
        boolean boolean32 = dateTimeZone7.isLocalDateTimeGap(localDateTime29);
        try {
            org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(10, 12, 0, (int) (short) 100, 100, 0, (int) (short) 10, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Property[secondOfMinute]" + "'", str25.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 19 + "'", int28 == 19);
        org.junit.Assert.assertNotNull(localDateTime29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime.Property property16 = dateTime10.minuteOfHour();
        java.lang.String str17 = property16.getAsString();
        org.joda.time.DateTimeField dateTimeField18 = property16.getField();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 152);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfMinute();
        java.lang.String str6 = property5.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.withMillis((long) (short) 100);
        int int13 = property5.getDifference((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime12.plusWeeks((-1));
        org.joda.time.DateTime dateTime17 = dateTime12.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime.Property property18 = dateTime12.minuteOfHour();
        java.lang.Object obj19 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(obj19, (org.joda.time.DateTimeZone) fixedDateTimeZone24);
        int int26 = dateTime12.compareTo((org.joda.time.ReadableInstant) dateTime25);
        boolean boolean27 = dateTime1.isEqual((org.joda.time.ReadableInstant) dateTime12);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[secondOfMinute]" + "'", str6.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.DateTime dateTime31 = property30.withMinimumValue();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfMonth();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime7 = property5.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) (short) -1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.DateTime dateTime32 = dateTime13.toDateTime(chronology31);
        org.joda.time.DateTime.Property property33 = dateTime13.centuryOfEra();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int21 = fixedDateTimeZone19.getStandardOffset((long) 2);
        java.util.Locale locale23 = null;
        java.lang.String str24 = fixedDateTimeZone19.getShortName((long) 59, locale23);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        java.util.TimeZone timeZone27 = fixedDateTimeZone19.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DurationField durationField29 = iSOChronology28.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        int int6 = dateTime4.getYearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[hi!]" + "'", str3.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 70 + "'", int6 == 70);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("1969");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        org.joda.time.DateTime dateTime6 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property3.withMaximumValue();
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1970W013T������.000", "Coordinated Universal Time");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNull(durationFieldType5);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[hi!]" + "'", str3.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter3.withOffsetParsed();
        boolean boolean5 = dateTimeFormatter4.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
        int int10 = dateTime6.getDayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime6.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime14 = dateTime6.toDateTime(dateTimeZone13);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int6 = fixedDateTimeZone4.getStandardOffset((long) 2);
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone4.getShortName((long) 59, locale8);
        int int11 = fixedDateTimeZone4.getOffset((-100L));
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone4.getName(11L, locale13);
        java.util.TimeZone timeZone15 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
        org.junit.Assert.assertNotNull(timeZone15);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfMinute();
        java.lang.String str7 = property6.toString();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime13 = dateTime10.withMillis((long) (short) 100);
        int int14 = property6.getDifference((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.plusYears((int) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.minusMillis((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfMinute();
        java.lang.String str23 = property22.toString();
        org.joda.time.DateTime dateTime25 = property22.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime28 = dateTime25.withDurationAdded((long) 'a', (-1));
        int int29 = dateTime25.getDayOfWeek();
        org.joda.time.DateTime dateTime34 = dateTime25.withTime((int) (short) 1, (int) '4', (int) (byte) 1, (int) 'a');
        org.joda.time.DateTime dateTime36 = dateTime25.minusSeconds((int) (byte) 0);
        org.joda.time.YearMonthDay yearMonthDay37 = dateTime36.toYearMonthDay();
        boolean boolean38 = dateTime18.isBefore((org.joda.time.ReadableInstant) dateTime36);
        org.joda.time.DateTime dateTime39 = dateTime36.withEarlierOffsetAtOverlap();
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadableInstant) dateTime39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[secondOfMinute]" + "'", str7.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Property[secondOfMinute]" + "'", str23.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(yearMonthDay37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTime39);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1970W013T������.000", "Coordinated Universal Time");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
        java.lang.String str9 = property8.toString();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.secondOfDay();
        org.joda.time.DateTime dateTime15 = dateTime12.withMillis((long) (short) 100);
        int int16 = property8.getDifference((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime18 = dateTime15.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfMinute();
        java.lang.String str23 = property22.toString();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone25);
        org.joda.time.DateTime.Property property27 = dateTime26.secondOfDay();
        org.joda.time.DateTime dateTime29 = dateTime26.withMillis((long) (short) 100);
        int int30 = property22.getDifference((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime32 = dateTime29.plusWeeks((-1));
        org.joda.time.DateTime.Property property33 = dateTime29.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.DateTime.Property property35 = dateTime18.property(dateTimeFieldType34);
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException39);
        java.lang.Number number41 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[secondOfMinute]" + "'", str9.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Property[secondOfMinute]" + "'", str23.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNull(number41);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.weekyear();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.DateTime dateTime32 = dateTime13.toDateTime(chronology31);
        int int33 = dateTime13.getDayOfYear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 359 + "'", int33 == 359);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        org.joda.time.DateTime dateTime7 = property3.addWrapFieldToCopy((int) (short) 1);
        org.joda.time.DurationField durationField8 = property3.getRangeDurationField();
        java.lang.Class<?> wildcardClass9 = durationField8.getClass();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-1), (int) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-35L) + "'", long2 == (-35L));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.minus(readableDuration10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime11);
        org.joda.time.DateTime dateTime14 = dateTime11.minusHours((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        int int31 = dateTime11.get(dateTimeFieldType30);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField33 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType30, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField4 = gregorianChronology2.months();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology2.getZone();
        java.util.TimeZone timeZone6 = dateTimeZone5.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter3.withOffsetParsed();
        try {
            org.joda.time.LocalTime localTime6 = dateTimeFormatter4.parseLocalTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DurationField durationField5 = iSOChronology1.years();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(359, 152, (-1), 59, 1969, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (-3L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
        java.lang.String str10 = property9.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime13.secondOfDay();
        org.joda.time.DateTime dateTime16 = dateTime13.withMillis((long) (short) 100);
        int int17 = property9.getDifference((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime19 = dateTime16.plusYears((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime16.minusDays(11);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone23);
        org.joda.time.DateTime.Property property25 = dateTime24.secondOfMinute();
        java.lang.String str26 = property25.toString();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone28);
        org.joda.time.DateTime.Property property30 = dateTime29.secondOfDay();
        org.joda.time.DateTime dateTime32 = dateTime29.withMillis((long) (short) 100);
        int int33 = property25.getDifference((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime dateTime35 = dateTime32.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone37);
        org.joda.time.DateTime.Property property39 = dateTime38.secondOfMinute();
        java.lang.String str40 = property39.toString();
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone42);
        org.joda.time.DateTime.Property property44 = dateTime43.secondOfDay();
        org.joda.time.DateTime dateTime46 = dateTime43.withMillis((long) (short) 100);
        int int47 = property39.getDifference((org.joda.time.ReadableInstant) dateTime46);
        org.joda.time.DateTime dateTime49 = dateTime46.plusWeeks((-1));
        org.joda.time.DateTime.Property property50 = dateTime46.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.DateTime.Property property52 = dateTime35.property(dateTimeFieldType51);
        org.joda.time.IllegalFieldValueException illegalFieldValueException56 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType51, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
        org.joda.time.DateTime.Property property57 = dateTime21.property(dateTimeFieldType51);
        org.joda.time.DateTime.Property property58 = dateTime4.property(dateTimeFieldType51);
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.chrono.ISOChronology iSOChronology60 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone59);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology60.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField62 = iSOChronology60.monthOfYear();
        org.joda.time.DateTime dateTime63 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology60);
        org.joda.time.DurationField durationField64 = iSOChronology60.weeks();
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone65);
        org.joda.time.DurationField durationField67 = iSOChronology66.halfdays();
        org.joda.time.DurationField durationField68 = iSOChronology66.seconds();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField69 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType51, durationField64, durationField68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The effective range must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[hi!]" + "'", str3.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfMinute]" + "'", str10.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[secondOfMinute]" + "'", str26.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Property[secondOfMinute]" + "'", str40.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(iSOChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(durationField64);
        org.junit.Assert.assertNotNull(iSOChronology66);
        org.junit.Assert.assertNotNull(durationField67);
        org.junit.Assert.assertNotNull(durationField68);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTime.Property property4 = dateTime2.monthOfYear();
        org.joda.time.DurationField durationField5 = property4.getLeapDurationField();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (-35L), (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone14);
        org.joda.time.DateTime.Property property16 = dateTime15.secondOfMinute();
        java.lang.String str17 = property16.toString();
        org.joda.time.DateTime dateTime19 = property16.addWrapFieldToCopy(0);
        int int20 = dateTime19.getCenturyOfEra();
        org.joda.time.LocalDateTime localDateTime21 = dateTime19.toLocalDateTime();
        long long23 = zonedChronology12.set((org.joda.time.ReadablePartial) localDateTime21, (long) 100);
        long long29 = zonedChronology12.getDateTimeMillis(0L, 0, 9, 9, 0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Property[secondOfMinute]" + "'", str17.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 19 + "'", int20 == 19);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 549000L + "'", long29 == 549000L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter3.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter3.withPivotYear((int) (short) 1);
        try {
            org.joda.time.DateTime dateTime8 = dateTimeFormatter3.parseDateTime("Property[secondOfMinute]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[secondOfMinute]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime10.minusDays(11);
        boolean boolean17 = dateTime10.equals((java.lang.Object) (-100L));
        int int18 = dateTime10.getMinuteOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(1970, 70, 1969, 152, 0, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 152 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime10.plus(readableDuration14);
        boolean boolean17 = dateTime15.isEqual(0L);
        int int18 = dateTime15.getMinuteOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int21 = fixedDateTimeZone19.getStandardOffset((long) 2);
        java.util.Locale locale23 = null;
        java.lang.String str24 = fixedDateTimeZone19.getShortName((long) 59, locale23);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone28);
        org.joda.time.DateTime.Property property30 = dateTime29.secondOfMinute();
        java.lang.String str31 = property30.toString();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone33);
        org.joda.time.DateTime.Property property35 = dateTime34.secondOfDay();
        org.joda.time.DateTime dateTime37 = dateTime34.withMillis((long) (short) 100);
        int int38 = property30.getDifference((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime dateTime40 = dateTime37.plusWeeks((-1));
        boolean boolean41 = fixedDateTimeZone19.equals((java.lang.Object) dateTime37);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Property[secondOfMinute]" + "'", str31.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        int int7 = dateTime6.getCenturyOfEra();
        org.joda.time.DateTime dateTime9 = dateTime6.plusHours(0);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(3);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone13);
        org.joda.time.DateTime.Property property15 = dateTime14.secondOfMinute();
        java.lang.String str16 = property15.toString();
        org.joda.time.DateTime dateTime18 = property15.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime21 = dateTime18.withDurationAdded((long) 'a', (-1));
        int int22 = dateTime18.getDayOfWeek();
        org.joda.time.DateTime dateTime27 = dateTime18.withTime((int) (short) 1, (int) '4', (int) (byte) 1, (int) 'a');
        org.joda.time.DateTime dateTime29 = dateTime18.minusSeconds((int) (byte) 0);
        org.joda.time.YearMonthDay yearMonthDay30 = dateTime29.toYearMonthDay();
        int int31 = dateTime9.compareTo((org.joda.time.ReadableInstant) dateTime29);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Property[secondOfMinute]" + "'", str16.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(yearMonthDay30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("secondOfMinute", "hi!", (int) '#', 59);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 10, 9, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("0");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"0/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.DateTime dateTime32 = dateTime13.minusMonths((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime33 = dateTime32.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName(10L);
//        long long5 = dateTimeZone0.convertLocalToUTC((long) (short) 1, true);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = iSOChronology1.get(readablePeriod3, 0L, (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType4);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.millis();
        org.joda.time.DurationField durationField4 = iSOChronology2.halfdays();
        org.joda.time.DurationField durationField5 = iSOChronology2.hours();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((-100L), (org.joda.time.Chronology) iSOChronology2);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime.Property property16 = dateTime10.minuteOfHour();
        java.lang.Object obj17 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj17, (org.joda.time.DateTimeZone) fixedDateTimeZone22);
        int int24 = dateTime10.compareTo((org.joda.time.ReadableInstant) dateTime23);
        try {
            org.joda.time.DateTime dateTime26 = dateTime23.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 960, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("UTC", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withEra(0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1970W013T������.000", "Coordinated Universal Time");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
        java.lang.String str9 = property8.toString();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.secondOfDay();
        org.joda.time.DateTime dateTime15 = dateTime12.withMillis((long) (short) 100);
        int int16 = property8.getDifference((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime18 = dateTime15.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfMinute();
        java.lang.String str23 = property22.toString();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone25);
        org.joda.time.DateTime.Property property27 = dateTime26.secondOfDay();
        org.joda.time.DateTime dateTime29 = dateTime26.withMillis((long) (short) 100);
        int int30 = property22.getDifference((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime32 = dateTime29.plusWeeks((-1));
        org.joda.time.DateTime.Property property33 = dateTime29.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.DateTime.Property property35 = dateTime18.property(dateTimeFieldType34);
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException39);
        illegalFieldValueException39.prependMessage("secondOfMinute");
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[secondOfMinute]" + "'", str9.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Property[secondOfMinute]" + "'", str23.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(property35);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long16 = fixedDateTimeZone4.convertLocalToUTC((long) ' ', false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 32L + "'", long16 == 32L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        try {
            long long17 = gregorianChronology10.getDateTimeMillis((int) (byte) 1, 0, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.lang.Integer int2 = dateTimeFormatter1.getPivotYear();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("ISOChronology[UTC]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int21 = fixedDateTimeZone19.getStandardOffset((long) 2);
        java.util.Locale locale23 = null;
        java.lang.String str24 = fixedDateTimeZone19.getShortName((long) 59, locale23);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology12.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology29 = zonedChronology12.withZone(dateTimeZone28);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(chronology29);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.year();
        org.joda.time.Chronology chronology4 = iSOChronology1.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant16 = null;
        boolean boolean17 = dateTime15.isAfter(readableInstant16);
        org.joda.time.DateTime.Property property18 = dateTime15.hourOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DurationField durationField5 = iSOChronology1.weeks();
        org.joda.time.DurationField durationField6 = iSOChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        int int4 = dateTimeFormatter3.getDefaultYear();
        java.lang.String str6 = dateTimeFormatter3.print(0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2000 + "'", int4 == 2000);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970W014T000000.000Z" + "'", str6.equals("1970W014T000000.000Z"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        boolean boolean16 = dateTime15.isAfterNow();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
//        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str15 = dateTimeZone13.getName(10L);
//        int int17 = dateTimeZone13.getOffsetFromLocal((long) 19);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        org.joda.time.Chronology chronology19 = zonedChronology12.withZone(dateTimeZone18);
//        org.joda.time.DurationField durationField20 = zonedChronology12.seconds();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.DateTime dateTime32 = dateTime13.toDateTime(chronology31);
        org.joda.time.DateTime dateTime34 = dateTime13.withMinuteOfHour((int) (short) 1);
        org.joda.time.DateTime.Property property35 = dateTime13.era();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(960, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-52) + "'", int1 == (-52));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        java.lang.String str5 = property4.toString();
        org.joda.time.DateTime dateTime7 = property4.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime10.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone29);
        org.joda.time.DateTime.Property property31 = dateTime30.secondOfMinute();
        java.lang.String str32 = property31.toString();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone34);
        org.joda.time.DateTime.Property property36 = dateTime35.secondOfDay();
        org.joda.time.DateTime dateTime38 = dateTime35.withMillis((long) (short) 100);
        int int39 = property31.getDifference((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTime dateTime41 = dateTime38.plusWeeks((-1));
        org.joda.time.DateTime.Property property42 = dateTime38.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
        org.joda.time.DateTime.Property property44 = dateTime27.property(dateTimeFieldType43);
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
        org.joda.time.DateTime dateTime50 = dateTime10.withField(dateTimeFieldType43, 3);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType43, 2000, 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfDay must be in the range [0,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[secondOfMinute]" + "'", str5.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Property[secondOfMinute]" + "'", str32.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime50);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime10.minusDays(11);
        int int16 = dateTime10.getHourOfDay();
        org.joda.time.DateTime.Property property17 = dateTime10.dayOfMonth();
        org.joda.time.DateTime dateTime19 = dateTime10.minusMinutes((int) (byte) 1);
        int int20 = dateTime10.getYearOfEra();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1970 + "'", int20 == 1970);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 11, (-52));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-572L) + "'", long2 == (-572L));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.Chronology chronology13 = zonedChronology12.withUTC();
        java.lang.Object obj14 = null;
        boolean boolean15 = zonedChronology12.equals(obj14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale22 = null;
        java.lang.String str23 = fixedDateTimeZone20.getName((long) '#', locale22);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, 3);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone27);
        org.joda.time.DateTime.Property property29 = dateTime28.secondOfMinute();
        java.lang.String str30 = property29.toString();
        org.joda.time.DateTime dateTime32 = property29.addWrapFieldToCopy(0);
        int int33 = dateTime32.getCenturyOfEra();
        org.joda.time.LocalDateTime localDateTime34 = dateTime32.toLocalDateTime();
        boolean boolean35 = fixedDateTimeZone20.isLocalDateTimeGap(localDateTime34);
        long long37 = zonedChronology12.set((org.joda.time.ReadablePartial) localDateTime34, (-572L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Property[secondOfMinute]" + "'", str30.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 19 + "'", int33 == 19);
        org.junit.Assert.assertNotNull(localDateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 9, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9L) + "'", long2 == (-9L));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(11, (int) (byte) 100, 152, 100, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            int[] intArray3 = gregorianChronology0.get(readablePartial1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 12775);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology1.add(readablePeriod2, (long) 1969, 12);
        java.lang.String str6 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfMinute();
        java.lang.String str13 = property12.toString();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withMillis((long) (short) 100);
        int int20 = property12.getDifference((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime22 = dateTime19.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone24);
        org.joda.time.DateTime.Property property26 = dateTime25.secondOfMinute();
        java.lang.String str27 = property26.toString();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone29);
        org.joda.time.DateTime.Property property31 = dateTime30.secondOfDay();
        org.joda.time.DateTime dateTime33 = dateTime30.withMillis((long) (short) 100);
        int int34 = property26.getDifference((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime36 = dateTime33.plusWeeks((-1));
        org.joda.time.DateTime.Property property37 = dateTime33.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
        org.joda.time.DateTime.Property property39 = dateTime22.property(dateTimeFieldType38);
        org.joda.time.DateTime dateTime41 = dateTime22.minusMonths((int) (short) 1);
        org.joda.time.LocalDate localDate42 = dateTime41.toLocalDate();
        boolean boolean43 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate42);
        int[] intArray45 = gregorianChronology8.get((org.joda.time.ReadablePartial) localDate42, (long) 12775);
        int[] intArray47 = gregorianChronology1.get((org.joda.time.ReadablePartial) localDate42, (-26010597L));
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        try {
            int[] intArray51 = gregorianChronology1.get(readablePeriod48, (long) (short) 10, 19690L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[UTC]" + "'", str6.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[secondOfMinute]" + "'", str13.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Property[secondOfMinute]" + "'", str27.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray47);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("0", (int) 'a', 11, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for 0 must be in the range [11,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        java.util.GregorianCalendar gregorianCalendar14 = dateTime13.toGregorianCalendar();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.DateTime dateTime32 = dateTime13.minusMonths((int) (short) 1);
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        org.joda.time.DateTime dateTime35 = dateTime32.plusDays(3);
        org.joda.time.DateTime dateTime37 = dateTime35.plusMinutes((int) (byte) 1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.minusMillis((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone17);
        org.joda.time.DateTime.Property property19 = dateTime18.secondOfMinute();
        java.lang.String str20 = property19.toString();
        org.joda.time.DateTime dateTime22 = property19.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded((long) 'a', (-1));
        int int26 = dateTime22.getDayOfWeek();
        org.joda.time.DateTime dateTime31 = dateTime22.withTime((int) (short) 1, (int) '4', (int) (byte) 1, (int) 'a');
        org.joda.time.DateTime dateTime33 = dateTime22.minusSeconds((int) (byte) 0);
        org.joda.time.YearMonthDay yearMonthDay34 = dateTime33.toYearMonthDay();
        boolean boolean35 = dateTime15.isBefore((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime36 = dateTime33.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime38 = dateTime33.withWeekyear(2000);
        org.joda.time.DateTime.Property property39 = dateTime33.weekyear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Property[secondOfMinute]" + "'", str20.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(yearMonthDay34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime10.minusDays(11);
        try {
            org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((-52));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -52 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.withMillis((long) (short) 100);
        boolean boolean6 = dateTime2.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds((int) 'a');
        org.joda.time.DateTime.Property property9 = dateTime2.yearOfCentury();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfMinute();
        java.lang.String str8 = property7.toString();
        org.joda.time.DateTime dateTime10 = property7.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate14 = dateTime13.toLocalDate();
        java.lang.String str15 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter3.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter3.withOffsetParsed();
        java.lang.StringBuffer stringBuffer18 = null;
        try {
            dateTimeFormatter3.printTo(stringBuffer18, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[secondOfMinute]" + "'", str8.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970W013T������.000" + "'", str15.equals("1970W013T������.000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.lang.String str4 = iSOChronology2.toString();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) iSOChronology2);
        int int6 = dateTime5.getMillisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime5.withDayOfYear(359);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[hi!]" + "'", str4.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        org.joda.time.DateTime dateTime6 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property3.roundHalfEvenCopy();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.Chronology chronology13 = zonedChronology12.withUTC();
        java.lang.Object obj14 = null;
        boolean boolean15 = zonedChronology12.equals(obj14);
        try {
            long long21 = zonedChronology12.getDateTimeMillis((long) 359, 9, 0, 2000, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        java.util.Locale locale5 = null;
        java.util.Calendar calendar6 = dateTime4.toCalendar(locale5);
        boolean boolean7 = dateTime4.isEqualNow();
        int int8 = dateTime4.getMillisOfSecond();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime4.minus(readableDuration9);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(calendar6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Property[secondOfMinute]");
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.monthOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology7.millisOfSecond();
        int int12 = dateTime4.get(dateTimeField11);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime4);
        org.joda.time.JodaTimePermission jodaTimePermission15 = new org.joda.time.JodaTimePermission("Property[secondOfMinute]");
        boolean boolean16 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter17.withPivotYear((int) (byte) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter20.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter20.withPivotYear((int) (short) 1);
        boolean boolean24 = jodaTimePermission15.equals((java.lang.Object) dateTimeFormatter20);
        java.lang.String str25 = jodaTimePermission15.getName();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Property[secondOfMinute]" + "'", str25.equals("Property[secondOfMinute]"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.DateTime dateTime31 = property30.roundHalfEvenCopy();
        try {
            org.joda.time.DateTime dateTime33 = dateTime31.withSecondOfMinute(359);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 359 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        org.joda.time.DateTime dateTime6 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property3.withMaximumValue();
        int int8 = property3.get();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
//        java.lang.String str4 = property3.toString();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
//        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
//        org.joda.time.DateTime.Property property14 = dateTime10.minuteOfDay();
//        org.joda.time.DateTime dateTime15 = property14.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        long long21 = gregorianChronology17.add(readablePeriod18, (long) 1969, 12);
//        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology17.getZone();
//        java.lang.String str23 = dateTimeZone22.getID();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone30 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
//        int int32 = fixedDateTimeZone30.getStandardOffset((long) 2);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = fixedDateTimeZone30.getShortName((long) 59, locale34);
//        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology25, (org.joda.time.DateTimeZone) fixedDateTimeZone30);
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str39 = dateTimeZone37.getName(10L);
//        int int41 = dateTimeZone37.getOffsetFromLocal((long) 19);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeUtils.getZone(dateTimeZone37);
//        org.joda.time.Chronology chronology43 = zonedChronology36.withZone(dateTimeZone42);
//        long long45 = dateTimeZone22.getMillisKeepLocal(dateTimeZone42, (long) 32);
//        try {
//            org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((java.lang.Object) property14, dateTimeZone22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1969L + "'", long21 == 1969L);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UTC" + "'", str23.equals("UTC"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 59 + "'", int32 == 59);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "+00:00" + "'", str35.equals("+00:00"));
//        org.junit.Assert.assertNotNull(zonedChronology36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Coordinated Universal Time" + "'", str39.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 32L + "'", long45 == 32L);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 16);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        int int7 = dateTime6.getCenturyOfEra();
        org.joda.time.DateTime dateTime9 = dateTime6.plusHours(0);
        org.joda.time.DateTime.Property property10 = dateTime6.weekyear();
        int int11 = property10.get();
        org.joda.time.DateTime dateTime13 = property10.addToCopy(100L);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.DateTime dateTime32 = dateTime13.toDateTime(chronology31);
        org.joda.time.DateTime dateTime34 = dateTime13.withMinuteOfHour((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType35 = null;
        try {
            org.joda.time.DateTime dateTime37 = dateTime13.withFieldAdded(durationFieldType35, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime14 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime16 = dateTime13.withYear((int) ' ');
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        boolean boolean8 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime9 = dateTime2.toDateTimeISO();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime.Property property16 = dateTime10.minuteOfHour();
        org.joda.time.DateTime dateTime18 = dateTime10.plusMinutes((int) (byte) -1);
        java.lang.String str19 = dateTime10.toString();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970-01-01T00:00:00.100Z" + "'", str19.equals("1970-01-01T00:00:00.100Z"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime.Property property16 = dateTime15.minuteOfHour();
        org.joda.time.DateTime dateTime17 = property16.withMaximumValue();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.DateTime dateTime32 = dateTime13.minusMonths((int) (short) 1);
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        org.joda.time.DateTime dateTime35 = dateTime32.plusDays(3);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime38 = dateTime35.withPeriodAdded(readablePeriod36, 12);
        boolean boolean40 = dateTime38.isBefore((long) 69);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime9 = dateTime5.withTimeAtStartOfDay();
        try {
            org.joda.time.DateTime dateTime13 = dateTime9.withDate(19, 10, 70);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.year();
        org.joda.time.DurationField durationField4 = iSOChronology1.seconds();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        org.joda.time.DateTime dateTime6 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime8 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime9 = property3.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 10, (long) 12775);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-12765L) + "'", long2 == (-12765L));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[hi!]", "", 960, 2000);
        java.lang.Class<?> wildcardClass5 = fixedDateTimeZone4.getClass();
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gregorianChronology7.add(readablePeriod8, (long) 1969, 12);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology7.getZone();
        java.lang.String str13 = dateTimeZone12.getID();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter5.withZone(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology15.millisOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(365);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        java.lang.String str5 = property4.toString();
        org.joda.time.DateTime dateTime7 = property4.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime10.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone29);
        org.joda.time.DateTime.Property property31 = dateTime30.secondOfMinute();
        java.lang.String str32 = property31.toString();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone34);
        org.joda.time.DateTime.Property property36 = dateTime35.secondOfDay();
        org.joda.time.DateTime dateTime38 = dateTime35.withMillis((long) (short) 100);
        int int39 = property31.getDifference((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTime dateTime41 = dateTime38.plusWeeks((-1));
        org.joda.time.DateTime.Property property42 = dateTime38.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
        org.joda.time.DateTime.Property property44 = dateTime27.property(dateTimeFieldType43);
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
        org.joda.time.DateTime dateTime50 = dateTime10.withField(dateTimeFieldType43, 3);
        int int51 = dateTime50.getWeekyear();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[secondOfMinute]" + "'", str5.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Property[secondOfMinute]" + "'", str32.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1970 + "'", int51 == 1970);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int21 = fixedDateTimeZone19.getStandardOffset((long) 2);
        java.util.Locale locale23 = null;
        java.lang.String str24 = fixedDateTimeZone19.getShortName((long) 59, locale23);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        int int28 = fixedDateTimeZone19.getOffsetFromLocal((long) 11);
        int int30 = fixedDateTimeZone19.getOffset((long) 32);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.lang.Object obj0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        int int8 = gregorianChronology7.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1970W014T000000.000Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1970W014T000000.000Z' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("GregorianChronology[UTC]", (java.lang.Number) 100.0f, (java.lang.Number) (byte) 100, (java.lang.Number) (-3L));
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-3L) + "'", number5.equals((-3L)));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        boolean boolean4 = dateTimeFormatter0.isPrinter();
        java.lang.StringBuffer stringBuffer5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gregorianChronology7.add(readablePeriod8, (long) 1969, 12);
        java.lang.String str12 = gregorianChronology7.toString();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone30);
        org.joda.time.DateTime.Property property32 = dateTime31.secondOfMinute();
        java.lang.String str33 = property32.toString();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone35);
        org.joda.time.DateTime.Property property37 = dateTime36.secondOfDay();
        org.joda.time.DateTime dateTime39 = dateTime36.withMillis((long) (short) 100);
        int int40 = property32.getDifference((org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.DateTime dateTime42 = dateTime39.plusWeeks((-1));
        org.joda.time.DateTime.Property property43 = dateTime39.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.DateTime.Property property45 = dateTime28.property(dateTimeFieldType44);
        org.joda.time.DateTime dateTime47 = dateTime28.minusMonths((int) (short) 1);
        org.joda.time.LocalDate localDate48 = dateTime47.toLocalDate();
        boolean boolean49 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate48);
        int[] intArray51 = gregorianChronology14.get((org.joda.time.ReadablePartial) localDate48, (long) 12775);
        int[] intArray53 = gregorianChronology7.get((org.joda.time.ReadablePartial) localDate48, (-26010597L));
        try {
            dateTimeFormatter0.printTo(stringBuffer5, (org.joda.time.ReadablePartial) localDate48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[UTC]" + "'", str12.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Property[secondOfMinute]" + "'", str33.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray53);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfMinute();
        java.lang.String str6 = property5.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.withMillis((long) (short) 100);
        int int13 = property5.getDifference((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime12.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone17);
        org.joda.time.DateTime.Property property19 = dateTime18.secondOfMinute();
        java.lang.String str20 = property19.toString();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone22);
        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
        org.joda.time.DateTime dateTime26 = dateTime23.withMillis((long) (short) 100);
        int int27 = property19.getDifference((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTime dateTime29 = dateTime26.plusWeeks((-1));
        org.joda.time.DateTime.Property property30 = dateTime26.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.DateTime.Property property32 = dateTime15.property(dateTimeFieldType31);
        org.joda.time.DateTime dateTime34 = dateTime15.minusMonths((int) (short) 1);
        org.joda.time.LocalDate localDate35 = dateTime34.toLocalDate();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        long long41 = gregorianChronology37.add(readablePeriod38, (long) 1969, 12);
        java.lang.String str42 = gregorianChronology37.toString();
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone46);
        org.joda.time.DateTime.Property property48 = dateTime47.secondOfMinute();
        java.lang.String str49 = property48.toString();
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone51);
        org.joda.time.DateTime.Property property53 = dateTime52.secondOfDay();
        org.joda.time.DateTime dateTime55 = dateTime52.withMillis((long) (short) 100);
        int int56 = property48.getDifference((org.joda.time.ReadableInstant) dateTime55);
        org.joda.time.DateTime dateTime58 = dateTime55.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone60);
        org.joda.time.DateTime.Property property62 = dateTime61.secondOfMinute();
        java.lang.String str63 = property62.toString();
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone65);
        org.joda.time.DateTime.Property property67 = dateTime66.secondOfDay();
        org.joda.time.DateTime dateTime69 = dateTime66.withMillis((long) (short) 100);
        int int70 = property62.getDifference((org.joda.time.ReadableInstant) dateTime69);
        org.joda.time.DateTime dateTime72 = dateTime69.plusWeeks((-1));
        org.joda.time.DateTime.Property property73 = dateTime69.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType74 = property73.getFieldType();
        org.joda.time.DateTime.Property property75 = dateTime58.property(dateTimeFieldType74);
        org.joda.time.DateTime dateTime77 = dateTime58.minusMonths((int) (short) 1);
        org.joda.time.LocalDate localDate78 = dateTime77.toLocalDate();
        boolean boolean79 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate78);
        int[] intArray81 = gregorianChronology44.get((org.joda.time.ReadablePartial) localDate78, (long) 12775);
        int[] intArray83 = gregorianChronology37.get((org.joda.time.ReadablePartial) localDate78, (-26010597L));
        iSOChronology1.validate((org.joda.time.ReadablePartial) localDate35, intArray83);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[secondOfMinute]" + "'", str6.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Property[secondOfMinute]" + "'", str20.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1969L + "'", long41 == 1969L);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "GregorianChronology[UTC]" + "'", str42.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Property[secondOfMinute]" + "'", str49.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Property[secondOfMinute]" + "'", str63.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property67);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(property73);
        org.junit.Assert.assertNotNull(dateTimeFieldType74);
        org.junit.Assert.assertNotNull(property75);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertNotNull(localDate78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray83);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) '#', 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime10.minusDays(11);
        int int16 = dateTime10.getHourOfDay();
        org.joda.time.DateTime.Property property17 = dateTime10.dayOfMonth();
        org.joda.time.DateTime dateTime19 = dateTime10.minusMinutes((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.MutableDateTime mutableDateTime21 = dateTime10.toMutableDateTime(dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone23);
        org.joda.time.DateTime.Property property25 = dateTime24.secondOfMinute();
        java.lang.String str26 = property25.toString();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone28);
        org.joda.time.DateTime.Property property30 = dateTime29.secondOfDay();
        org.joda.time.DateTime dateTime32 = dateTime29.withMillis((long) (short) 100);
        int int33 = property25.getDifference((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime dateTime35 = dateTime32.plusWeeks((-1));
        org.joda.time.DateTime dateTime37 = dateTime32.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime.Property property38 = dateTime32.minuteOfHour();
        java.lang.Object obj39 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone44 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(obj39, (org.joda.time.DateTimeZone) fixedDateTimeZone44);
        int int46 = dateTime32.compareTo((org.joda.time.ReadableInstant) dateTime45);
        boolean boolean48 = dateTime32.isEqual((long) (short) 10);
        boolean boolean49 = mutableDateTime21.isAfter((org.joda.time.ReadableInstant) dateTime32);
        int int50 = mutableDateTime21.getDayOfYear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[secondOfMinute]" + "'", str26.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        java.util.Locale locale5 = null;
        java.util.Calendar calendar6 = dateTime4.toCalendar(locale5);
        boolean boolean7 = dateTime4.isAfterNow();
        org.joda.time.DateTime dateTime10 = dateTime4.withDurationAdded((-35L), 0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(calendar6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.withMillis((long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = dateTime5.withZone(dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime5.dayOfWeek();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        int int34 = dividedDateTimeField32.get(32L);
        int int36 = dividedDateTimeField32.get((long) 960);
        org.joda.time.DurationField durationField37 = dividedDateTimeField32.getDurationField();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(durationField37);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime4.plusSeconds((int) ' ');
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[hi!]" + "'", str3.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.DateTime dateTime31 = property30.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime33 = dateTime31.plusYears(12775);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.secondOfMinute();
        org.joda.time.Chronology chronology6 = iSOChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.weekOfWeekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone12.getName((long) '#', locale14);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology18);
        boolean boolean20 = fixedDateTimeZone12.equals((java.lang.Object) gregorianChronology18);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone24);
        org.joda.time.DateTime.Property property26 = dateTime25.secondOfMinute();
        java.lang.String str27 = property26.toString();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone29);
        org.joda.time.DateTime.Property property31 = dateTime30.secondOfDay();
        org.joda.time.DateTime dateTime33 = dateTime30.withMillis((long) (short) 100);
        int int34 = property26.getDifference((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime36 = dateTime33.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone38);
        org.joda.time.DateTime.Property property40 = dateTime39.secondOfMinute();
        java.lang.String str41 = property40.toString();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone43);
        org.joda.time.DateTime.Property property45 = dateTime44.secondOfDay();
        org.joda.time.DateTime dateTime47 = dateTime44.withMillis((long) (short) 100);
        int int48 = property40.getDifference((org.joda.time.ReadableInstant) dateTime47);
        org.joda.time.DateTime dateTime50 = dateTime47.plusWeeks((-1));
        org.joda.time.DateTime.Property property51 = dateTime47.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property51.getFieldType();
        org.joda.time.DateTime.Property property53 = dateTime36.property(dateTimeFieldType52);
        org.joda.time.DateTime dateTime55 = dateTime36.minusMonths((int) (short) 1);
        org.joda.time.LocalDate localDate56 = dateTime55.toLocalDate();
        int[] intArray58 = iSOChronology21.get((org.joda.time.ReadablePartial) localDate56, (-691200000L));
        long long60 = iSOChronology1.set((org.joda.time.ReadablePartial) localDate56, (-100L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[hi!]" + "'", str3.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00" + "'", str15.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Property[secondOfMinute]" + "'", str27.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Property[secondOfMinute]" + "'", str41.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-3110400100L) + "'", long60 == (-3110400100L));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Property[secondOfMinute]");
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.monthOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology7.millisOfSecond();
        int int12 = dateTime4.get(dateTimeField11);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime4);
        org.joda.time.JodaTimePermission jodaTimePermission15 = new org.joda.time.JodaTimePermission("Property[secondOfMinute]");
        boolean boolean16 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission15);
        java.lang.String str17 = jodaTimePermission1.getActions();
        java.security.PermissionCollection permissionCollection18 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(permissionCollection18);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
        int int10 = dateTime6.getDayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime6.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime6.plus(readableDuration13);
        int int15 = dateTime14.getMinuteOfDay();
        int int16 = dateTime14.getMinuteOfHour();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 3);
        int int11 = fixedDateTimeZone4.getOffsetFromLocal((long) '4');
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime13.minusMillis(2000);
        org.joda.time.DateTime dateTime17 = dateTime13.withYearOfCentury((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone19);
        org.joda.time.DateTime.Property property21 = dateTime20.secondOfDay();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.minus(readableDuration22);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) dateTime23);
        org.joda.time.DateTime dateTime26 = dateTime23.minusHours((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone28);
        org.joda.time.DateTime.Property property30 = dateTime29.secondOfMinute();
        java.lang.String str31 = property30.toString();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone33);
        org.joda.time.DateTime.Property property35 = dateTime34.secondOfDay();
        org.joda.time.DateTime dateTime37 = dateTime34.withMillis((long) (short) 100);
        int int38 = property30.getDifference((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime dateTime40 = dateTime37.plusWeeks((-1));
        org.joda.time.DateTime.Property property41 = dateTime37.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
        int int43 = dateTime23.get(dateTimeFieldType42);
        org.joda.time.DateTime.Property property44 = dateTime17.property(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Property[secondOfMinute]" + "'", str31.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(property44);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("UTC", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(property2);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) (short) -1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField4 = gregorianChronology2.months();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology2.getZone();
        org.joda.time.DurationField durationField6 = gregorianChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
//        java.lang.String str3 = iSOChronology1.toString();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
//        boolean boolean5 = dateTime4.isEqualNow();
//        org.joda.time.DateTime dateTime6 = dateTime4.toDateTimeISO();
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[hi!]" + "'", str3.equals("ISOChronology[hi!]"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        org.joda.time.DateTime dateTime6 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime8 = property3.withMinimumValue();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Coordinated Universal Time");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime10.plus(readableDuration14);
        org.joda.time.DateTime dateTime16 = dateTime10.toDateTimeISO();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int23 = fixedDateTimeZone21.getStandardOffset((long) 2);
        org.joda.time.DateTime dateTime24 = dateTime10.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 59 + "'", int23 == 59);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Property[secondOfMinute]");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("0");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.dayOfWeek();
        boolean boolean10 = jodaTimePermission4.equals((java.lang.Object) iSOChronology6);
        boolean boolean11 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfMonth();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        int int7 = property5.getMinimumValue();
        try {
            org.joda.time.DateTime dateTime9 = property5.setCopy((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime10.minusDays(11);
        int int16 = dateTime10.getHourOfDay();
        boolean boolean18 = dateTime10.isEqual(0L);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(24, 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime.Property property16 = dateTime10.minuteOfHour();
        java.lang.Object obj17 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj17, (org.joda.time.DateTimeZone) fixedDateTimeZone22);
        int int24 = dateTime10.compareTo((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.LocalDate localDate25 = dateTime10.toLocalDate();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(localDate25);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime10.minusDays(11);
        int int16 = dateTime10.getHourOfDay();
        org.joda.time.DateTime.Property property17 = dateTime10.dayOfMonth();
        org.joda.time.DateTime dateTime19 = dateTime10.minusMinutes((int) (byte) 1);
        int int20 = dateTime10.getWeekyear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1970 + "'", int20 == 1970);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.minusMillis((int) ' ');
        org.joda.time.DateTime.Property property16 = dateTime15.millisOfDay();
        org.joda.time.DateTime.Property property17 = dateTime15.yearOfCentury();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime.Property property16 = dateTime10.minuteOfHour();
        org.joda.time.DateTime dateTime18 = dateTime10.plusMinutes((int) (byte) -1);
        org.joda.time.DateTime dateTime20 = dateTime10.withEra((int) (short) 1);
        try {
            org.joda.time.DateTime dateTime22 = dateTime10.withDayOfWeek((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfWeek();
        org.joda.time.DurationField durationField4 = iSOChronology1.hours();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DurationField durationField5 = iSOChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1970W013T������.000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970W013T������.000\" is malformed at \"W013T������.000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfMinute();
        java.lang.String str13 = property12.toString();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withMillis((long) (short) 100);
        int int20 = property12.getDifference((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime22 = dateTime19.plusWeeks((-1));
        org.joda.time.DateTime.Property property23 = dateTime19.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        int int25 = dateTime5.get(dateTimeFieldType24);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 1970, (java.lang.Number) 1560635854838L, (java.lang.Number) 3);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DurationField durationField32 = iSOChronology31.millis();
        long long35 = durationField32.subtract(0L, (long) (short) 0);
        org.joda.time.JodaTimePermission jodaTimePermission37 = new org.joda.time.JodaTimePermission("0");
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology39.dayOfWeek();
        boolean boolean43 = jodaTimePermission37.equals((java.lang.Object) iSOChronology39);
        org.joda.time.DurationField durationField44 = iSOChronology39.months();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType24, durationField32, durationField44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[secondOfMinute]" + "'", str13.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(durationField44);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 1969);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int15 = fixedDateTimeZone13.getStandardOffset((long) 2);
        java.util.Locale locale17 = null;
        java.lang.String str18 = fixedDateTimeZone13.getShortName((long) 59, locale17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology8, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
        int int21 = fixedDateTimeZone13.getStandardOffset((long) (short) 10);
        org.joda.time.Chronology chronology22 = iSOChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.DurationField durationField23 = iSOChronology1.centuries();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 59 + "'", int15 == 59);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00" + "'", str18.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) ' ', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.Chronology chronology13 = zonedChronology12.withUTC();
        java.lang.Object obj14 = null;
        boolean boolean15 = zonedChronology12.equals(obj14);
        org.joda.time.Chronology chronology16 = zonedChronology12.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.Object obj0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.minus((-572L));
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((-1));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear(100);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        try {
            long long7 = iSOChronology1.getDateTimeMillis(0, 4, 12775, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12775 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime10.minusDays(11);
        int int16 = dateTime10.getHourOfDay();
        org.joda.time.DateTime.Property property17 = dateTime10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone19);
        org.joda.time.DateTime.Property property21 = dateTime20.secondOfMinute();
        java.lang.String str22 = property21.toString();
        org.joda.time.DateTime dateTime24 = property21.addWrapFieldToCopy(0);
        int int25 = dateTime24.getCenturyOfEra();
        org.joda.time.DateTime dateTime27 = dateTime24.plusHours(0);
        boolean boolean28 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime24);
        int int29 = dateTime10.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone31);
        org.joda.time.DateTime.Property property33 = dateTime32.secondOfMinute();
        java.lang.String str34 = property33.toString();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone36);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTime dateTime40 = dateTime37.withMillis((long) (short) 100);
        int int41 = property33.getDifference((org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DateTime dateTime43 = dateTime40.plusYears((int) '4');
        org.joda.time.DateTime dateTime45 = dateTime43.minusMillis((int) ' ');
        boolean boolean46 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTime.Property property47 = dateTime10.monthOfYear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Property[secondOfMinute]" + "'", str22.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 19 + "'", int25 == 19);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Property[secondOfMinute]" + "'", str34.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(property47);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        java.lang.String str5 = property4.toString();
        org.joda.time.DateTime dateTime7 = property4.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime10.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone29);
        org.joda.time.DateTime.Property property31 = dateTime30.secondOfMinute();
        java.lang.String str32 = property31.toString();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone34);
        org.joda.time.DateTime.Property property36 = dateTime35.secondOfDay();
        org.joda.time.DateTime dateTime38 = dateTime35.withMillis((long) (short) 100);
        int int39 = property31.getDifference((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTime dateTime41 = dateTime38.plusWeeks((-1));
        org.joda.time.DateTime.Property property42 = dateTime38.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
        org.joda.time.DateTime.Property property44 = dateTime27.property(dateTimeFieldType43);
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
        org.joda.time.DateTime dateTime50 = dateTime10.withField(dateTimeFieldType43, 3);
        org.joda.time.DateTime dateTime51 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology52 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime51);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[secondOfMinute]" + "'", str5.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Property[secondOfMinute]" + "'", str32.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(chronology52);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime10.plus(readableDuration14);
        org.joda.time.DateTime dateTime16 = dateTime10.toDateTimeISO();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int23 = fixedDateTimeZone21.getStandardOffset((long) 2);
        org.joda.time.DateTime dateTime24 = dateTime10.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        long long27 = fixedDateTimeZone21.adjustOffset((long) 960, true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 59 + "'", int23 == 59);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 960L + "'", long27 == 960L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        java.util.GregorianCalendar gregorianCalendar4 = dateTime2.toGregorianCalendar();
        int int5 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime7 = dateTime2.minus(19L);
        try {
            org.joda.time.DateTime dateTime12 = dateTime2.withTime(0, (int) (short) -1, 960, 11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gregorianCalendar4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime9 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property10 = dateTime9.weekyear();
        int int11 = dateTime9.getHourOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        java.util.Date date31 = dateTime13.toDate();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        java.util.Locale locale5 = null;
        java.util.Calendar calendar6 = dateTime4.toCalendar(locale5);
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime9 = dateTime4.withYear((int) '4');
        org.joda.time.DateTime dateTime11 = dateTime9.withYear((int) (short) 0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(calendar6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.DateTime dateTime32 = dateTime13.minusMonths((int) (short) 1);
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        org.joda.time.DateTime dateTime35 = dateTime32.plusDays(3);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime38 = dateTime35.withPeriodAdded(readablePeriod36, 12);
        try {
            org.joda.time.DateTime dateTime40 = dateTime38.withWeekOfWeekyear((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime38);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
        java.lang.String str10 = property9.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime13.secondOfDay();
        org.joda.time.DateTime dateTime16 = dateTime13.withMillis((long) (short) 100);
        int int17 = property9.getDifference((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime19 = dateTime16.plusYears((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime16.minusDays(11);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone23);
        org.joda.time.DateTime.Property property25 = dateTime24.secondOfMinute();
        java.lang.String str26 = property25.toString();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone28);
        org.joda.time.DateTime.Property property30 = dateTime29.secondOfDay();
        org.joda.time.DateTime dateTime32 = dateTime29.withMillis((long) (short) 100);
        int int33 = property25.getDifference((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime dateTime35 = dateTime32.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone37);
        org.joda.time.DateTime.Property property39 = dateTime38.secondOfMinute();
        java.lang.String str40 = property39.toString();
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone42);
        org.joda.time.DateTime.Property property44 = dateTime43.secondOfDay();
        org.joda.time.DateTime dateTime46 = dateTime43.withMillis((long) (short) 100);
        int int47 = property39.getDifference((org.joda.time.ReadableInstant) dateTime46);
        org.joda.time.DateTime dateTime49 = dateTime46.plusWeeks((-1));
        org.joda.time.DateTime.Property property50 = dateTime46.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.DateTime.Property property52 = dateTime35.property(dateTimeFieldType51);
        org.joda.time.IllegalFieldValueException illegalFieldValueException56 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType51, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
        org.joda.time.DateTime.Property property57 = dateTime21.property(dateTimeFieldType51);
        org.joda.time.DateTime.Property property58 = dateTime4.property(dateTimeFieldType51);
        int int59 = property58.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[hi!]" + "'", str3.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfMinute]" + "'", str10.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[secondOfMinute]" + "'", str26.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Property[secondOfMinute]" + "'", str40.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1439 + "'", int59 == 1439);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
        int int10 = dateTime6.getDayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime6.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime6.plus(readableDuration13);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.secondOfMinute();
        java.lang.String str19 = iSOChronology17.toString();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTime dateTime22 = dateTime20.withWeekOfWeekyear((int) (byte) 10);
        boolean boolean23 = dateTime14.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime25 = dateTime22.minusMonths(0);
        int int26 = dateTime22.getMinuteOfHour();
        int int27 = dateTime22.getYearOfCentury();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[hi!]" + "'", str19.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 70 + "'", int27 == 70);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        java.util.Locale locale3 = dateTimeFormatter0.getLocale();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 3);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.secondOfMinute();
        java.lang.String str14 = property13.toString();
        org.joda.time.DateTime dateTime16 = property13.addWrapFieldToCopy(0);
        int int17 = dateTime16.getCenturyOfEra();
        org.joda.time.LocalDateTime localDateTime18 = dateTime16.toLocalDateTime();
        boolean boolean19 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime18);
        int int21 = fixedDateTimeZone4.getOffset((-9L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Property[secondOfMinute]" + "'", str14.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
        org.junit.Assert.assertNotNull(localDateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int21 = fixedDateTimeZone19.getStandardOffset((long) 2);
        java.util.Locale locale23 = null;
        java.lang.String str24 = fixedDateTimeZone19.getShortName((long) 59, locale23);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        int int28 = fixedDateTimeZone19.getOffsetFromLocal((long) 11);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        try {
            long long17 = gregorianChronology10.getDateTimeMillis(2000, 19, (int) (byte) 0, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        java.lang.String str34 = dividedDateTimeField32.getAsShortText(1969L);
        java.lang.String str36 = dividedDateTimeField32.getAsText(0L);
        int int39 = dividedDateTimeField32.getDifference(549000L, (-3110400100L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter5.withPivotYear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfMinute();
        java.lang.String str13 = property12.toString();
        org.joda.time.DateTime dateTime15 = property12.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate19 = dateTime18.toLocalDate();
        java.lang.String str20 = dateTimeFormatter8.print((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter8.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter8.withOffsetParsed();
        org.joda.time.Chronology chronology23 = dateTimeFormatter8.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter8.withZoneUTC();
        org.joda.time.format.DateTimePrinter dateTimePrinter25 = dateTimeFormatter24.getPrinter();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray26 = new org.joda.time.format.DateTimeParser[] {};
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder4.append(dateTimePrinter25, dateTimeParserArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[secondOfMinute]" + "'", str13.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970W013T������.000" + "'", str20.equals("1970W013T������.000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimePrinter25);
        org.junit.Assert.assertNotNull(dateTimeParserArray26);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (short) 0, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime.Property property14 = dateTime10.minuteOfDay();
        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(durationField15);
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560635891495L + "'", long1 == 1560635891495L);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        int int34 = dividedDateTimeField32.get(32L);
        long long37 = dividedDateTimeField32.add(549000L, 10);
        long long39 = dividedDateTimeField32.remainder(0L);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone41);
        org.joda.time.DateTime.Property property43 = dateTime42.secondOfMinute();
        java.lang.String str44 = property43.toString();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone46);
        org.joda.time.DateTime.Property property48 = dateTime47.secondOfDay();
        org.joda.time.DateTime dateTime50 = dateTime47.withMillis((long) (short) 100);
        int int51 = property43.getDifference((org.joda.time.ReadableInstant) dateTime50);
        org.joda.time.DateTime dateTime53 = dateTime50.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone55);
        org.joda.time.DateTime.Property property57 = dateTime56.secondOfMinute();
        java.lang.String str58 = property57.toString();
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone60);
        org.joda.time.DateTime.Property property62 = dateTime61.secondOfDay();
        org.joda.time.DateTime dateTime64 = dateTime61.withMillis((long) (short) 100);
        int int65 = property57.getDifference((org.joda.time.ReadableInstant) dateTime64);
        org.joda.time.DateTime dateTime67 = dateTime64.plusWeeks((-1));
        org.joda.time.DateTime.Property property68 = dateTime64.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = property68.getFieldType();
        org.joda.time.DateTime.Property property70 = dateTime53.property(dateTimeFieldType69);
        org.joda.time.DateTime dateTime72 = dateTime53.minusMonths((int) (short) 1);
        org.joda.time.LocalDate localDate73 = dateTime72.toLocalDate();
        boolean boolean74 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate73);
        int[] intArray76 = new int[] {};
        try {
            int[] intArray78 = dividedDateTimeField32.addWrapPartial((org.joda.time.ReadablePartial) localDate73, 152, intArray76, 152);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 152");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 193536549000L + "'", long37 == 193536549000L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Property[secondOfMinute]" + "'", str44.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Property[secondOfMinute]" + "'", str58.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(property68);
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(localDate73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(intArray76);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        java.lang.String str5 = property4.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTime dateTime11 = dateTime8.withMillis((long) (short) 100);
        int int12 = property4.getDifference((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime14 = dateTime11.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.DateTime.Property property31 = dateTime14.property(dateTimeFieldType30);
        org.joda.time.DateTime dateTime33 = dateTime14.minusMonths((int) (short) 1);
        org.joda.time.LocalDate localDate34 = dateTime33.toLocalDate();
        org.joda.time.DateTime dateTime36 = dateTime33.plusDays(3);
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.DateTime dateTime39 = dateTime36.withPeriodAdded(readablePeriod37, 12);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone40);
        org.joda.time.DurationField durationField42 = iSOChronology41.halfdays();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology41.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology41.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology41.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone47);
        org.joda.time.DateTime.Property property49 = dateTime48.secondOfDay();
        org.joda.time.ReadableDuration readableDuration50 = null;
        org.joda.time.DateTime dateTime51 = dateTime48.minus(readableDuration50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((java.lang.Object) dateTime51);
        org.joda.time.DateTime dateTime54 = dateTime51.minusHours((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone56);
        org.joda.time.DateTime.Property property58 = dateTime57.secondOfMinute();
        java.lang.String str59 = property58.toString();
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone61);
        org.joda.time.DateTime.Property property63 = dateTime62.secondOfDay();
        org.joda.time.DateTime dateTime65 = dateTime62.withMillis((long) (short) 100);
        int int66 = property58.getDifference((org.joda.time.ReadableInstant) dateTime65);
        org.joda.time.DateTime dateTime68 = dateTime65.plusWeeks((-1));
        org.joda.time.DateTime.Property property69 = dateTime65.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = property69.getFieldType();
        int int71 = dateTime51.get(dateTimeFieldType70);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField73 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, dateTimeFieldType70, 19);
        org.joda.time.DateTime.Property property74 = dateTime36.property(dateTimeFieldType70);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField75 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[secondOfMinute]" + "'", str5.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Property[secondOfMinute]" + "'", str59.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertNotNull(property74);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        int int4 = dateTimeFormatter3.getDefaultYear();
        try {
            org.joda.time.DateTime dateTime6 = dateTimeFormatter3.parseDateTime("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2000 + "'", int4 == 2000);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter0.getParser();
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNull(dateTimeZone5);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-1), 365, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.minus(readablePeriod14);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime.Property property16 = dateTime10.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone18);
        org.joda.time.DateTime.Property property20 = dateTime19.secondOfMinute();
        java.lang.String str21 = property20.toString();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone23);
        org.joda.time.DateTime.Property property25 = dateTime24.secondOfDay();
        org.joda.time.DateTime dateTime27 = dateTime24.withMillis((long) (short) 100);
        int int28 = property20.getDifference((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime dateTime30 = dateTime27.plusYears((int) '4');
        org.joda.time.ReadableDuration readableDuration31 = null;
        org.joda.time.DateTime dateTime32 = dateTime27.plus(readableDuration31);
        org.joda.time.DateTime dateTime34 = dateTime27.withYearOfCentury(2);
        long long35 = property16.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
        java.lang.String str38 = gregorianChronology37.toString();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
        org.joda.time.DateTime dateTime40 = dateTime27.withChronology((org.joda.time.Chronology) gregorianChronology37);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Property[secondOfMinute]" + "'", str21.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "GregorianChronology[UTC]" + "'", str38.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfDay(1439, 1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfMinute();
        java.lang.String str8 = property7.toString();
        org.joda.time.DateTime dateTime10 = property7.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate14 = dateTime13.toLocalDate();
        java.lang.String str15 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter3.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter3.withOffsetParsed();
        org.joda.time.Chronology chronology18 = dateTimeFormatter3.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter3.withZoneUTC();
        java.io.Writer writer20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int30 = fixedDateTimeZone28.getStandardOffset((long) 2);
        java.util.Locale locale32 = null;
        java.lang.String str33 = fixedDateTimeZone28.getShortName((long) 59, locale32);
        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology23, (org.joda.time.DateTimeZone) fixedDateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone36);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
        java.lang.String str39 = property38.toString();
        org.joda.time.DateTime dateTime41 = property38.addWrapFieldToCopy(0);
        int int42 = dateTime41.getCenturyOfEra();
        org.joda.time.LocalDateTime localDateTime43 = dateTime41.toLocalDateTime();
        long long45 = zonedChronology34.set((org.joda.time.ReadablePartial) localDateTime43, (long) 100);
        boolean boolean46 = dateTimeZone21.isLocalDateTimeGap(localDateTime43);
        try {
            dateTimeFormatter19.printTo(writer20, (org.joda.time.ReadablePartial) localDateTime43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[secondOfMinute]" + "'", str8.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970W013T������.000" + "'", str15.equals("1970W013T������.000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 59 + "'", int30 == 59);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00" + "'", str33.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology34);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Property[secondOfMinute]" + "'", str39.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 19 + "'", int42 == 19);
        org.junit.Assert.assertNotNull(localDateTime43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
        int int10 = dateTime6.getDayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime6.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime6.plus(readableDuration13);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.secondOfMinute();
        java.lang.String str19 = iSOChronology17.toString();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTime dateTime22 = dateTime20.withWeekOfWeekyear((int) (byte) 10);
        boolean boolean23 = dateTime14.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime25 = dateTime22.minusMonths(0);
        java.lang.Class<?> wildcardClass26 = dateTime25.getClass();
        org.joda.time.YearMonthDay yearMonthDay27 = dateTime25.toYearMonthDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[hi!]" + "'", str19.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(yearMonthDay27);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (byte) 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfYear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        java.lang.String str6 = property3.getName();
        org.joda.time.DateTime dateTime7 = property3.withMinimumValue();
        org.joda.time.Interval interval8 = property3.toInterval();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval8);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval8);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale17 = null;
        java.lang.String str18 = fixedDateTimeZone15.getName((long) '#', locale17);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology21);
        boolean boolean23 = fixedDateTimeZone15.equals((java.lang.Object) gregorianChronology21);
        long long25 = fixedDateTimeZone15.nextTransition((long) 19);
        long long27 = fixedDateTimeZone15.nextTransition((long) (byte) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance(chronology10, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "secondOfMinute" + "'", str6.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00" + "'", str18.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 19L + "'", long25 == 19L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology28);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.joda.time.DurationField durationField3 = iSOChronology1.hours();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        boolean boolean8 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime6);
        int int9 = dateTime2.getMillisOfSecond();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime2.toMutableDateTime(chronology10);
        int int12 = mutableDateTime11.getSecondOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.secondOfMinute();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = iSOChronology1.add(readablePeriod6, (long) 365, (int) (short) 10);
        org.joda.time.Chronology chronology10 = iSOChronology1.withUTC();
        java.lang.Object obj11 = null;
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology1, obj11);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[hi!]" + "'", str3.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 365L + "'", long9 == 365L);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        int int34 = dividedDateTimeField32.get(32L);
        long long37 = dividedDateTimeField32.add(549000L, 10);
        long long39 = dividedDateTimeField32.remainder(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser41 = dateTimeFormatter40.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter40.withPivotYear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone45);
        org.joda.time.DateTime.Property property47 = dateTime46.secondOfMinute();
        java.lang.String str48 = property47.toString();
        org.joda.time.DateTime dateTime50 = property47.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime53 = dateTime50.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate54 = dateTime53.toLocalDate();
        java.lang.String str55 = dateTimeFormatter43.print((org.joda.time.ReadablePartial) localDate54);
        java.util.Locale locale56 = null;
        try {
            java.lang.String str57 = dividedDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate54, locale56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 193536549000L + "'", long37 == 193536549000L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimeParser41);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Property[secondOfMinute]" + "'", str48.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1970W013T������.000" + "'", str55.equals("1970W013T������.000"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        int int34 = dividedDateTimeField32.get(32L);
        int int35 = dividedDateTimeField32.getMaximumValue();
        long long38 = dividedDateTimeField32.add(1969L, (-3L));
        java.lang.String str40 = dividedDateTimeField32.getAsShortText((long) 32);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-58060798031L) + "'", long38 == (-58060798031L));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "0" + "'", str40.equals("0"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        int int34 = dividedDateTimeField32.get(32L);
        int int35 = dividedDateTimeField32.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone37);
        org.joda.time.DateTime.Property property39 = dateTime38.secondOfMinute();
        java.lang.String str40 = property39.toString();
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone42);
        org.joda.time.DateTime.Property property44 = dateTime43.secondOfDay();
        org.joda.time.DateTime dateTime46 = dateTime43.withMillis((long) (short) 100);
        int int47 = property39.getDifference((org.joda.time.ReadableInstant) dateTime46);
        org.joda.time.DateTime dateTime49 = dateTime46.plusYears((int) '4');
        int int50 = dateTime46.getMinuteOfDay();
        org.joda.time.LocalTime localTime51 = dateTime46.toLocalTime();
        int int52 = dividedDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) localTime51);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Property[secondOfMinute]" + "'", str40.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(localTime51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("1970W013T������.000", 0);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime.Property property16 = dateTime10.minuteOfHour();
        org.joda.time.DateTime dateTime18 = dateTime10.plusMinutes((int) (byte) -1);
        org.joda.time.DateTime dateTime20 = dateTime10.withEra((int) (short) 1);
        org.joda.time.DateTime dateTime22 = dateTime20.plusMillis(0);
        int int23 = dateTime22.getYearOfEra();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1970 + "'", int23 == 1970);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        java.lang.String str34 = dividedDateTimeField32.getAsShortText(1969L);
        org.joda.time.DurationField durationField35 = dividedDateTimeField32.getDurationField();
        java.lang.String str37 = dividedDateTimeField32.getAsText((long) (short) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("0");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.dayOfWeek();
        boolean boolean7 = jodaTimePermission1.equals((java.lang.Object) iSOChronology3);
        org.joda.time.DurationField durationField8 = iSOChronology3.hours();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime5 = property3.getDateTime();
        int int6 = dateTime5.getHourOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("1970W013T������.000", 0);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("ISOChronology[America/Los_Angeles]", false);
        java.io.DataOutput dataOutput8 = null;
        try {
            dateTimeZoneBuilder0.writeTo("ISOChronology[UTC]", dataOutput8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[hi!]", "", 960, 2000);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
        java.lang.String str10 = property9.toString();
        org.joda.time.DateTime dateTime12 = property9.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime15 = dateTime12.withDurationAdded((long) 'a', (-1));
        int int16 = dateTime12.getDayOfWeek();
        org.joda.time.DateTime dateTime18 = dateTime12.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime20 = dateTime12.plus(readableDuration19);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.secondOfMinute();
        java.lang.String str25 = iSOChronology23.toString();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) iSOChronology23);
        org.joda.time.DateTime dateTime28 = dateTime26.withWeekOfWeekyear((int) (byte) 10);
        boolean boolean29 = dateTime20.isBefore((org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.DateTime dateTime31 = dateTime28.minusMonths(0);
        java.lang.Class<?> wildcardClass32 = dateTime31.getClass();
        int int33 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime31);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfMinute]" + "'", str10.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ISOChronology[hi!]" + "'", str25.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 960 + "'", int33 == 960);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        boolean boolean5 = dateTime4.isEqualNow();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        java.util.GregorianCalendar gregorianCalendar10 = dateTime8.toGregorianCalendar();
        boolean boolean11 = dateTime4.isAfter((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property12 = dateTime8.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[hi!]" + "'", str3.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.weekyears();
        org.joda.time.DurationField durationField3 = iSOChronology0.eras();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.minus(readableDuration10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime11);
        org.joda.time.DateTime dateTime14 = dateTime11.minusHours((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        int int31 = dateTime11.get(dateTimeFieldType30);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType30, 19);
        long long35 = offsetDateTimeField33.roundHalfEven((-26010597L));
        int int37 = offsetDateTimeField33.getLeapAmount(19690L);
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField33.getAsText((long) 960, locale39);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "20" + "'", str40.equals("20"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.secondOfMinute();
        org.joda.time.Chronology chronology6 = iSOChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.weekOfWeekyear();
        java.lang.String str8 = iSOChronology1.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[hi!]" + "'", str3.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[hi!]" + "'", str8.equals("ISOChronology[hi!]"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        java.lang.String str34 = dividedDateTimeField32.getAsShortText(1969L);
        org.joda.time.DurationField durationField35 = dividedDateTimeField32.getDurationField();
        java.lang.String str36 = dividedDateTimeField32.getName();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "minuteOfDay" + "'", str36.equals("minuteOfDay"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withMillis((long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfMinute();
        java.lang.String str13 = property12.toString();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withMillis((long) (short) 100);
        int int20 = property12.getDifference((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime22 = dateTime19.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone24);
        org.joda.time.DateTime.Property property26 = dateTime25.secondOfMinute();
        java.lang.String str27 = property26.toString();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone29);
        org.joda.time.DateTime.Property property31 = dateTime30.secondOfDay();
        org.joda.time.DateTime dateTime33 = dateTime30.withMillis((long) (short) 100);
        int int34 = property26.getDifference((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime36 = dateTime33.plusWeeks((-1));
        org.joda.time.DateTime.Property property37 = dateTime33.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
        org.joda.time.DateTime.Property property39 = dateTime22.property(dateTimeFieldType38);
        org.joda.time.DateTime dateTime41 = dateTime8.withField(dateTimeFieldType38, 2);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType38, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[secondOfMinute]" + "'", str13.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Property[secondOfMinute]" + "'", str27.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime41);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        int int7 = dateTime6.getCenturyOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.dayOfWeek();
        long long9 = property8.remainder();
        try {
            org.joda.time.DateTime dateTime11 = property8.setCopy("0");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"0\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.DateTime dateTime31 = property30.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime33 = dateTime31.minusDays(0);
        org.joda.time.DateTime dateTime35 = dateTime31.minusWeeks(100);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        boolean boolean8 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime6);
        int int9 = dateTime2.getMillisOfSecond();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime2.plus(readableDuration10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMillis((int) (byte) 100);
        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks(0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Property[secondOfMinute]");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.lang.String str3 = jodaTimePermission1.getName();
        java.lang.String str4 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Property[secondOfMinute]" + "'", str3.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Property[secondOfMinute]\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"Property[secondOfMinute]\")"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder0.toParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendPattern("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: oo");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
        org.joda.time.DateTime.Property property10 = dateTime6.secondOfMinute();
        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
        boolean boolean12 = property10.isLeap();
        int int13 = property10.getLeapAmount();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfMinute();
        java.lang.String str7 = property6.toString();
        org.joda.time.DateTime dateTime9 = property6.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, (org.joda.time.ReadableInstant) dateTime12);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[secondOfMinute]" + "'", str7.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime.Property property16 = dateTime10.minuteOfHour();
        org.joda.time.DateTime dateTime18 = dateTime10.plusMinutes((int) (byte) -1);
        org.joda.time.DateTime dateTime20 = dateTime10.minusYears((int) (short) 0);
        java.util.Date date21 = dateTime20.toDate();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(date21);
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology1.add(readablePeriod2, (long) 1969, 12);
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology1.getZone();
//        java.lang.String str7 = dateTimeZone6.getID();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
//        int int16 = fixedDateTimeZone14.getStandardOffset((long) 2);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = fixedDateTimeZone14.getShortName((long) 59, locale18);
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology9, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str23 = dateTimeZone21.getName(10L);
//        int int25 = dateTimeZone21.getOffsetFromLocal((long) 19);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
//        org.joda.time.Chronology chronology27 = zonedChronology20.withZone(dateTimeZone26);
//        long long29 = dateTimeZone6.getMillisKeepLocal(dateTimeZone26, (long) 32);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone26);
//        long long33 = dateTimeZone26.convertLocalToUTC((long) '#', true);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
//        org.junit.Assert.assertNotNull(zonedChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Coordinated Universal Time" + "'", str23.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 32L + "'", long29 == 32L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 35L + "'", long33 == 35L);
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone6.getName((long) '#', locale8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology12);
        boolean boolean14 = fixedDateTimeZone6.equals((java.lang.Object) gregorianChronology12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        long long17 = dateTimeZone0.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone6, 1560635854838L);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale24 = null;
        java.lang.String str25 = fixedDateTimeZone22.getName((long) '#', locale24);
        long long27 = fixedDateTimeZone6.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone22, 0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560635854838L + "'", long17 == 1560635854838L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00" + "'", str25.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        int int34 = dividedDateTimeField32.get(32L);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone41 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int43 = fixedDateTimeZone41.getStandardOffset((long) 2);
        java.util.Locale locale45 = null;
        java.lang.String str46 = fixedDateTimeZone41.getShortName((long) 59, locale45);
        org.joda.time.chrono.ZonedChronology zonedChronology47 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology36, (org.joda.time.DateTimeZone) fixedDateTimeZone41);
        org.joda.time.Chronology chronology48 = zonedChronology47.withUTC();
        org.joda.time.DateTimeField dateTimeField49 = zonedChronology47.hourOfHalfday();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone54 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale56 = null;
        java.lang.String str57 = fixedDateTimeZone54.getName((long) '#', locale56);
        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone54, 3);
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone61);
        org.joda.time.DateTime.Property property63 = dateTime62.secondOfMinute();
        java.lang.String str64 = property63.toString();
        org.joda.time.DateTime dateTime66 = property63.addWrapFieldToCopy(0);
        int int67 = dateTime66.getCenturyOfEra();
        org.joda.time.LocalDateTime localDateTime68 = dateTime66.toLocalDateTime();
        boolean boolean69 = fixedDateTimeZone54.isLocalDateTimeGap(localDateTime68);
        int[] intArray71 = zonedChronology47.get((org.joda.time.ReadablePartial) localDateTime68, 0L);
        int[] intArray72 = null;
        int int73 = dividedDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) localDateTime68, intArray72);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 59 + "'", int43 == 59);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+00:00" + "'", str46.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology47);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "+00:00" + "'", str57.equals("+00:00"));
        org.junit.Assert.assertNotNull(gregorianChronology59);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "Property[secondOfMinute]" + "'", str64.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 19 + "'", int67 == 19);
        org.junit.Assert.assertNotNull(localDateTime68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
        int int10 = dateTime6.getDayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime6.withWeekOfWeekyear((int) (short) 1);
        int int13 = dateTime6.getWeekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone29);
        org.joda.time.DateTime.Property property31 = dateTime30.secondOfMinute();
        java.lang.String str32 = property31.toString();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone34);
        org.joda.time.DateTime.Property property36 = dateTime35.secondOfDay();
        org.joda.time.DateTime dateTime38 = dateTime35.withMillis((long) (short) 100);
        int int39 = property31.getDifference((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTime dateTime41 = dateTime38.plusWeeks((-1));
        org.joda.time.DateTime.Property property42 = dateTime38.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
        org.joda.time.DateTime.Property property44 = dateTime27.property(dateTimeFieldType43);
        org.joda.time.DateTime dateTime45 = property44.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime47 = dateTime45.minusDays(0);
        boolean boolean48 = dateTime6.equals((java.lang.Object) dateTime45);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Property[secondOfMinute]" + "'", str32.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.Chronology chronology13 = zonedChronology12.withUTC();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology12.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = zonedChronology12.withZone(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYear(2000);
        org.joda.time.DateTime dateTime6 = dateTime2.plusDays((int) (byte) 10);
        org.joda.time.Instant instant7 = dateTime2.toInstant();
        int int8 = dateTime2.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatterBuilder2.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        java.lang.String str34 = dividedDateTimeField32.getAsShortText(1969L);
        java.lang.String str36 = dividedDateTimeField32.getAsText(0L);
        try {
            long long39 = dividedDateTimeField32.set(0L, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for minuteOfDay must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 70, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        java.util.Locale locale5 = null;
        int int6 = property3.getMaximumShortTextLength(locale5);
        org.joda.time.DateTimeField dateTimeField7 = property3.getField();
        int int8 = property3.getMaximumValue();
        org.joda.time.DateTime dateTime9 = property3.roundCeilingCopy();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfWeek();
        org.joda.time.DurationField durationField4 = iSOChronology1.days();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = iSOChronology1.get(readablePeriod5, (long) 12, (long) 960);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        boolean boolean9 = dateTimeZone7.isStandardOffset(0L);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(2, (int) (byte) 10, (int) (short) 1, 1, (int) (short) 0, (int) '4', 0, dateTimeZone7);
        java.lang.Object obj11 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(obj11, (org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear(359);
        int int20 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "-1", "1970W014T000000.000Z");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.DateTime dateTime32 = dateTime13.minusMonths((int) (short) 1);
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        org.joda.time.DateTime dateTime35 = dateTime32.plusDays(3);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime38 = dateTime35.withPeriodAdded(readablePeriod36, 12);
        org.joda.time.DateTime dateTime40 = dateTime38.plusMinutes(4);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.minus(readableDuration10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime11);
        org.joda.time.DateTime dateTime14 = dateTime11.minusHours((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        int int31 = dateTime11.get(dateTimeFieldType30);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType30, 19);
        long long35 = offsetDateTimeField33.roundHalfEven((-26010597L));
        int int37 = offsetDateTimeField33.getLeapAmount(19690L);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone39);
        org.joda.time.DateTime.Property property41 = dateTime40.secondOfMinute();
        java.lang.String str42 = property41.toString();
        org.joda.time.DateTime dateTime44 = property41.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime47 = dateTime44.withDurationAdded((long) 'a', (-1));
        int int48 = dateTime44.getDayOfWeek();
        org.joda.time.DateTime dateTime53 = dateTime44.withTime((int) (short) 1, (int) '4', (int) (byte) 1, (int) 'a');
        org.joda.time.DateTime dateTime55 = dateTime44.minusSeconds((int) (byte) 0);
        org.joda.time.YearMonthDay yearMonthDay56 = dateTime55.toYearMonthDay();
        int[] intArray64 = new int[] { 16, 4, 11, 12775, 1, (byte) 100 };
        try {
            int[] intArray66 = offsetDateTimeField33.addWrapPartial((org.joda.time.ReadablePartial) yearMonthDay56, 4, intArray64, 16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 17 for minuteOfDay must be in the range [20,385]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Property[secondOfMinute]" + "'", str42.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(yearMonthDay56);
        org.junit.Assert.assertNotNull(intArray64);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime5 = dateTime2.withEra((int) (byte) 1);
        org.joda.time.Instant instant6 = dateTime5.toInstant();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        int int6 = property3.getLeapAmount();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant16 = null;
        boolean boolean17 = dateTime15.isAfter(readableInstant16);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime15.toTimeOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeOfDay18);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.minus(readableDuration10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime11);
        org.joda.time.DateTime dateTime14 = dateTime11.minusHours((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        int int31 = dateTime11.get(dateTimeFieldType30);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType30, 19);
        int int35 = offsetDateTimeField33.getLeapAmount((long) (-52));
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone37);
        org.joda.time.DateTime.Property property39 = dateTime38.secondOfMinute();
        java.lang.String str40 = property39.toString();
        org.joda.time.DateTime dateTime42 = property39.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime45 = dateTime42.withDurationAdded((long) 'a', (-1));
        int int46 = dateTime42.getDayOfWeek();
        org.joda.time.DateTime dateTime51 = dateTime42.withTime((int) (short) 1, (int) '4', (int) (byte) 1, (int) 'a');
        org.joda.time.DateTime dateTime53 = dateTime42.minusSeconds((int) (byte) 0);
        org.joda.time.YearMonthDay yearMonthDay54 = dateTime53.toYearMonthDay();
        java.util.Locale locale56 = null;
        java.lang.String str57 = offsetDateTimeField33.getAsText((org.joda.time.ReadablePartial) yearMonthDay54, (-1), locale56);
        int int58 = offsetDateTimeField33.getOffset();
        org.joda.time.DurationField durationField59 = offsetDateTimeField33.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Property[secondOfMinute]" + "'", str40.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(yearMonthDay54);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "-1" + "'", str57.equals("-1"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 19 + "'", int58 == 19);
        org.junit.Assert.assertNull(durationField59);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.lang.Object obj0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime9 = dateTime6.withDayOfYear(16);
        org.joda.time.DateTime dateTime12 = dateTime6.withDurationAdded((long) 365, 32);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        int int7 = dateTime6.getCenturyOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.dayOfWeek();
        java.lang.String str9 = dateTime6.toString();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-01-01T00:00:00.000Z" + "'", str9.equals("1970-01-01T00:00:00.000Z"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        int int3 = dateTime2.getYear();
        org.joda.time.DateTime dateTime5 = dateTime2.minusWeeks((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime9 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded((-691200000L), 12);
        int int13 = dateTime12.getMinuteOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.lang.Object obj0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        int int34 = dividedDateTimeField32.get(32L);
        long long37 = dividedDateTimeField32.add(549000L, 10);
        long long39 = dividedDateTimeField32.remainder(0L);
        long long41 = dividedDateTimeField32.roundHalfCeiling((-691200000L));
        long long44 = dividedDateTimeField32.add((-26010597L), (long) (-1));
        long long47 = dividedDateTimeField32.add(0L, 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 193536549000L + "'", long37 == 193536549000L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 6393600000L + "'", long41 == 6393600000L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-19379610597L) + "'", long44 == (-19379610597L));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 19353600000L + "'", long47 == 19353600000L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2000);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        int int7 = dateTime3.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.secondOfMinute();
        org.joda.time.Chronology chronology6 = iSOChronology1.withUTC();
        org.joda.time.DurationField durationField7 = iSOChronology1.seconds();
        try {
            long long13 = iSOChronology1.getDateTimeMillis(1L, (int) '#', (int) '#', 1, 1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[hi!]" + "'", str3.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName(10L);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
//        int int11 = fixedDateTimeZone9.getStandardOffset((long) 2);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = fixedDateTimeZone9.getShortName((long) 59, locale13);
//        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone17);
//        org.joda.time.DateTime.Property property19 = dateTime18.secondOfMinute();
//        java.lang.String str20 = property19.toString();
//        org.joda.time.DateTime dateTime22 = property19.addWrapFieldToCopy(0);
//        int int23 = dateTime22.getCenturyOfEra();
//        org.joda.time.LocalDateTime localDateTime24 = dateTime22.toLocalDateTime();
//        long long26 = zonedChronology15.set((org.joda.time.ReadablePartial) localDateTime24, (long) 100);
//        boolean boolean27 = dateTimeZone0.isLocalDateTimeGap(localDateTime24);
//        java.util.TimeZone timeZone28 = dateTimeZone0.toTimeZone();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
//        org.junit.Assert.assertNotNull(zonedChronology15);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Property[secondOfMinute]" + "'", str20.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19 + "'", int23 == 19);
//        org.junit.Assert.assertNotNull(localDateTime24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(timeZone28);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int10 = fixedDateTimeZone8.getStandardOffset((long) 2);
        java.util.Locale locale12 = null;
        java.lang.String str13 = fixedDateTimeZone8.getShortName((long) 59, locale12);
        int int15 = fixedDateTimeZone8.getOffset((-100L));
        java.util.Locale locale17 = null;
        java.lang.String str18 = fixedDateTimeZone8.getName(11L, locale17);
        org.joda.time.Chronology chronology19 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfMinute();
        java.lang.String str24 = property23.toString();
        org.joda.time.DateTime dateTime26 = property23.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime29 = dateTime26.withDurationAdded((long) 'a', (-1));
        int int30 = dateTime26.getDayOfWeek();
        org.joda.time.DateTime dateTime32 = dateTime26.withWeekOfWeekyear((int) (short) 1);
        java.lang.Object obj33 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(obj33, (org.joda.time.DateTimeZone) fixedDateTimeZone38);
        org.joda.time.DateTime dateTime40 = dateTime32.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone38);
        org.joda.time.Chronology chronology41 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone38);
        java.util.TimeZone timeZone42 = fixedDateTimeZone38.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00" + "'", str18.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Property[secondOfMinute]" + "'", str24.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(timeZone42);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        int int34 = dividedDateTimeField32.get(32L);
        int int36 = dividedDateTimeField32.get((long) 960);
        java.lang.String str38 = dividedDateTimeField32.getAsText((long) 70);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "0" + "'", str38.equals("0"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDecimal(dateTimeFieldType1, 1969, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }
}

