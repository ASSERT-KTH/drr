import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1970W013T������.000", "Coordinated Universal Time");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
        java.lang.String str9 = property8.toString();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.secondOfDay();
        org.joda.time.DateTime dateTime15 = dateTime12.withMillis((long) (short) 100);
        int int16 = property8.getDifference((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime18 = dateTime15.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfMinute();
        java.lang.String str23 = property22.toString();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone25);
        org.joda.time.DateTime.Property property27 = dateTime26.secondOfDay();
        org.joda.time.DateTime dateTime29 = dateTime26.withMillis((long) (short) 100);
        int int30 = property22.getDifference((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime32 = dateTime29.plusWeeks((-1));
        org.joda.time.DateTime.Property property33 = dateTime29.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.DateTime.Property property35 = dateTime18.property(dateTimeFieldType34);
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException39);
        java.lang.String str41 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Number number42 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[secondOfMinute]" + "'", str9.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Property[secondOfMinute]" + "'", str23.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Coordinated Universal Time" + "'", str41.equals("Coordinated Universal Time"));
        org.junit.Assert.assertNull(number42);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.millis();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = fixedDateTimeZone10.getName((long) '#', locale12);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology16);
//        boolean boolean18 = fixedDateTimeZone10.equals((java.lang.Object) gregorianChronology16);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
//        long long21 = dateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone10, 1560635854838L);
//        org.joda.time.MutableDateTime mutableDateTime22 = dateTime3.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone10);
//        org.joda.time.DateTime dateTime23 = dateTime3.toDateTime();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560635854838L + "'", long21 == 1560635854838L);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(1560635854838L, (-19379610597L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1541256244241L + "'", long2 == 1541256244241L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int21 = fixedDateTimeZone19.getStandardOffset((long) 2);
        java.util.Locale locale23 = null;
        java.lang.String str24 = fixedDateTimeZone19.getShortName((long) 59, locale23);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        java.util.TimeZone timeZone27 = fixedDateTimeZone19.toTimeZone();
        java.lang.String str29 = fixedDateTimeZone19.getNameKey((long) (byte) 0);
        java.util.TimeZone timeZone30 = fixedDateTimeZone19.toTimeZone();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(timeZone30);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
//        java.lang.String str4 = property3.toString();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
//        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
//        org.joda.time.DateTime dateTime15 = dateTime13.minusMillis((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone17);
//        org.joda.time.DateTime.Property property19 = dateTime18.secondOfMinute();
//        java.lang.String str20 = property19.toString();
//        org.joda.time.DateTime dateTime22 = property19.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded((long) 'a', (-1));
//        int int26 = dateTime22.getDayOfWeek();
//        org.joda.time.DateTime dateTime31 = dateTime22.withTime((int) (short) 1, (int) '4', (int) (byte) 1, (int) 'a');
//        org.joda.time.DateTime dateTime33 = dateTime22.minusSeconds((int) (byte) 0);
//        org.joda.time.YearMonthDay yearMonthDay34 = dateTime33.toYearMonthDay();
//        boolean boolean35 = dateTime15.isBefore((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime dateTime36 = dateTime15.withLaterOffsetAtOverlap();
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Property[secondOfMinute]" + "'", str20.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(yearMonthDay34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTime36);
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
//        java.lang.String str4 = property3.toString();
//        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
//        int int10 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime dateTime12 = dateTime6.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime6.plus(readableDuration13);
//        org.joda.time.DateTime dateTime16 = dateTime14.minusHours((int) (byte) 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType29, (int) (byte) 1, (int) (short) -1, 16);
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 2, (java.lang.Number) (-1.0d), (java.lang.Number) 12);
        illegalFieldValueException42.prependMessage("(\"org.joda.time.JodaTimePermission\" \"Property[secondOfMinute]\")");
        java.lang.Number number45 = illegalFieldValueException42.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 2 + "'", number45.equals(2));
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = gregorianChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
//        int int10 = fixedDateTimeZone8.getStandardOffset((long) 2);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = fixedDateTimeZone8.getShortName((long) 59, locale12);
//        int int15 = fixedDateTimeZone8.getOffset((-100L));
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = fixedDateTimeZone8.getName(11L, locale17);
//        org.joda.time.Chronology chronology19 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfMinute();
//        java.lang.String str24 = property23.toString();
//        org.joda.time.DateTime dateTime26 = property23.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime29 = dateTime26.withDurationAdded((long) 'a', (-1));
//        int int30 = dateTime26.getDayOfWeek();
//        org.joda.time.DateTime dateTime32 = dateTime26.withWeekOfWeekyear((int) (short) 1);
//        java.lang.Object obj33 = null;
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(obj33, (org.joda.time.DateTimeZone) fixedDateTimeZone38);
//        org.joda.time.DateTime dateTime40 = dateTime32.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone38);
//        org.joda.time.Chronology chronology41 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone38);
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology1.centuryOfEra();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00" + "'", str18.equals("+00:00"));
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Property[secondOfMinute]" + "'", str24.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(chronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime.Property property16 = dateTime10.minuteOfHour();
        boolean boolean18 = dateTime10.isBefore((long) (short) 10);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology1.add(readablePeriod2, (long) 1969, 12);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology1.getZone();
        int int7 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
//        java.lang.String str4 = property3.toString();
//        int int5 = property3.getMaximumValueOverall();
//        java.lang.String str6 = property3.getName();
//        org.joda.time.DateTime dateTime7 = property3.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        long long14 = gregorianChronology10.add(readablePeriod11, (long) 1969, 12);
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology10.getZone();
//        java.lang.String str16 = dateTimeZone15.getID();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter8.withZone(dateTimeZone15);
//        boolean boolean18 = dateTimeFormatter17.isPrinter();
//        java.lang.String str19 = dateTime7.toString(dateTimeFormatter17);
//        java.io.Writer writer20 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone22);
//        org.joda.time.DateTime.Property property24 = dateTime23.secondOfMinute();
//        java.lang.String str25 = property24.toString();
//        org.joda.time.DateTime dateTime27 = property24.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime30 = dateTime27.withDurationAdded((long) 'a', (-1));
//        int int31 = dateTime27.getDayOfWeek();
//        org.joda.time.DateTime dateTime33 = dateTime27.withWeekOfWeekyear((int) (short) 1);
//        try {
//            dateTimeFormatter17.printTo(writer20, (org.joda.time.ReadableInstant) dateTime27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "secondOfMinute" + "'", str6.equals("secondOfMinute"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1969L + "'", long14 == 1969L);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "00:00:00.000" + "'", str19.equals("00:00:00.000"));
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Property[secondOfMinute]" + "'", str25.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
//        org.junit.Assert.assertNotNull(dateTime33);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 59, (java.lang.Number) (-3L), number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        java.lang.String str34 = dividedDateTimeField32.getAsShortText(1969L);
        long long36 = dividedDateTimeField32.remainder(1541256244241L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1521902644241L + "'", long36 == 1521902644241L);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
//        org.joda.time.DateTime dateTime5 = dateTime2.withMillis((long) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime7 = dateTime5.withZone(dateTimeZone6);
//        boolean boolean8 = dateTime5.isBeforeNow();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.secondOfMinute();
//        java.lang.String str13 = property12.toString();
//        org.joda.time.DateTime dateTime15 = property12.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded((long) 'a', (-1));
//        int int19 = dateTime15.getDayOfWeek();
//        org.joda.time.DateTime dateTime21 = dateTime15.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime15.plus(readableDuration22);
//        int int24 = dateTime23.getMinuteOfDay();
//        boolean boolean25 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
//        try {
//            org.joda.time.DateTime.Property property27 = dateTime5.property(dateTimeFieldType26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[secondOfMinute]" + "'", str13.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
//        java.lang.String str3 = iSOChronology1.toString();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime dateTime7 = dateTime4.plusSeconds((int) ' ');
//        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfEra(10);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[hi!]" + "'", str3.equals("ISOChronology[hi!]"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("0");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.dayOfWeek();
        boolean boolean7 = jodaTimePermission1.equals((java.lang.Object) iSOChronology3);
        org.joda.time.DurationField durationField8 = iSOChronology3.months();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.secondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.DateTime dateTime32 = dateTime13.minusMonths((int) (short) 1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone37 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((java.lang.Object) dateTime13, (org.joda.time.DateTimeZone) fixedDateTimeZone37);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, (int) '4');
        boolean boolean8 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        int int7 = dateTime6.getCenturyOfEra();
        org.joda.time.DateTime dateTime9 = dateTime6.plusHours(0);
        int int10 = dateTime9.getMinuteOfHour();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(1439, (int) (short) 1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39 + "'", int3 == 39);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("1970-01-01T00:00:00.000Z", false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 39, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = dateTimeFormatter0.parseMutableDateTime("1970-01-01T00:00:00.000Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970-01-01T00:00:00.000Z\" is malformed at \"-01-01T00:00:00.000Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-52));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Property[secondOfMinute]");
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.monthOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology7.millisOfSecond();
        int int12 = dateTime4.get(dateTimeField11);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime4);
        org.joda.time.JodaTimePermission jodaTimePermission15 = new org.joda.time.JodaTimePermission("Property[secondOfMinute]");
        boolean boolean16 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission15);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone18);
        org.joda.time.DateTime.Property property20 = dateTime19.secondOfDay();
        org.joda.time.DateTime.Property property21 = dateTime19.monthOfYear();
        boolean boolean22 = jodaTimePermission1.equals((java.lang.Object) dateTime19);
        java.lang.String str23 = jodaTimePermission1.toString();
        java.security.PermissionCollection permissionCollection24 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Property[secondOfMinute]\")" + "'", str23.equals("(\"org.joda.time.JodaTimePermission\" \"Property[secondOfMinute]\")"));
        org.junit.Assert.assertNotNull(permissionCollection24);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant16 = null;
        boolean boolean17 = dateTime15.isAfter(readableInstant16);
        org.joda.time.DateTime.Property property18 = dateTime15.weekyear();
        org.joda.time.DateTime.Property property19 = dateTime15.millisOfSecond();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        int int7 = dateTime6.getCenturyOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.dayOfWeek();
        boolean boolean9 = property8.isLeap();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, (int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.append(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.minus(readableDuration10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime11);
//        org.joda.time.DateTime dateTime14 = dateTime11.minusHours((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
//        java.lang.String str19 = property18.toString();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
//        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
//        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        int int31 = dateTime11.get(dateTimeFieldType30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType30, 19);
//        int int35 = offsetDateTimeField33.getLeapAmount((long) (-52));
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone37);
//        org.joda.time.DateTime.Property property39 = dateTime38.secondOfMinute();
//        java.lang.String str40 = property39.toString();
//        org.joda.time.DateTime dateTime42 = property39.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime45 = dateTime42.withDurationAdded((long) 'a', (-1));
//        int int46 = dateTime42.getDayOfWeek();
//        org.joda.time.DateTime dateTime51 = dateTime42.withTime((int) (short) 1, (int) '4', (int) (byte) 1, (int) 'a');
//        org.joda.time.DateTime dateTime53 = dateTime42.minusSeconds((int) (byte) 0);
//        org.joda.time.YearMonthDay yearMonthDay54 = dateTime53.toYearMonthDay();
//        java.util.Locale locale56 = null;
//        java.lang.String str57 = offsetDateTimeField33.getAsText((org.joda.time.ReadablePartial) yearMonthDay54, (-1), locale56);
//        java.util.Locale locale58 = null;
//        int int59 = offsetDateTimeField33.getMaximumTextLength(locale58);
//        org.joda.time.DateTimeZone dateTimeZone61 = null;
//        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone61);
//        org.joda.time.DateTime.Property property63 = dateTime62.secondOfMinute();
//        java.lang.String str64 = property63.toString();
//        org.joda.time.DateTimeZone dateTimeZone66 = null;
//        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone66);
//        org.joda.time.DateTime.Property property68 = dateTime67.secondOfDay();
//        org.joda.time.DateTime dateTime70 = dateTime67.withMillis((long) (short) 100);
//        int int71 = property63.getDifference((org.joda.time.ReadableInstant) dateTime70);
//        org.joda.time.DateTime dateTime73 = dateTime70.plusWeeks((-1));
//        org.joda.time.DateTimeZone dateTimeZone75 = null;
//        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone75);
//        org.joda.time.DateTime.Property property77 = dateTime76.secondOfMinute();
//        java.lang.String str78 = property77.toString();
//        org.joda.time.DateTimeZone dateTimeZone80 = null;
//        org.joda.time.DateTime dateTime81 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone80);
//        org.joda.time.DateTime.Property property82 = dateTime81.secondOfDay();
//        org.joda.time.DateTime dateTime84 = dateTime81.withMillis((long) (short) 100);
//        int int85 = property77.getDifference((org.joda.time.ReadableInstant) dateTime84);
//        org.joda.time.DateTime dateTime87 = dateTime84.plusWeeks((-1));
//        org.joda.time.DateTime.Property property88 = dateTime84.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType89 = property88.getFieldType();
//        org.joda.time.DateTime.Property property90 = dateTime73.property(dateTimeFieldType89);
//        org.joda.time.DateTime dateTime92 = dateTime73.minusMonths((int) (short) 1);
//        org.joda.time.LocalDate localDate93 = dateTime92.toLocalDate();
//        boolean boolean94 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate93);
//        java.util.Locale locale96 = null;
//        java.lang.String str97 = offsetDateTimeField33.getAsShortText((org.joda.time.ReadablePartial) localDate93, 1969, locale96);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Property[secondOfMinute]" + "'", str40.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(yearMonthDay54);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "-1" + "'", str57.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 3 + "'", int59 == 3);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "Property[secondOfMinute]" + "'", str64.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(property77);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "Property[secondOfMinute]" + "'", str78.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property82);
//        org.junit.Assert.assertNotNull(dateTime84);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
//        org.junit.Assert.assertNotNull(dateTime87);
//        org.junit.Assert.assertNotNull(property88);
//        org.junit.Assert.assertNotNull(dateTimeFieldType89);
//        org.junit.Assert.assertNotNull(property90);
//        org.junit.Assert.assertNotNull(dateTime92);
//        org.junit.Assert.assertNotNull(localDate93);
//        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
//        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "1969" + "'", str97.equals("1969"));
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("0");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.dayOfWeek();
        boolean boolean12 = jodaTimePermission6.equals((java.lang.Object) iSOChronology8);
        org.joda.time.DurationField durationField13 = iSOChronology8.months();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) periodType1, (org.joda.time.Chronology) iSOChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(durationField13);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
//        java.lang.String str4 = property3.toString();
//        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
//        int int10 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime dateTime12 = dateTime6.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime6.minus(readablePeriod13);
//        org.joda.time.DateTime.Property property15 = dateTime6.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.withMillis((long) (short) 100);
        boolean boolean6 = dateTime2.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime2.minusSeconds((int) 'a');
        int int9 = dateTime2.getWeekyear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology14.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology14.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int28 = fixedDateTimeZone26.getStandardOffset((long) 2);
        java.util.Locale locale30 = null;
        java.lang.String str31 = fixedDateTimeZone26.getShortName((long) 59, locale30);
        org.joda.time.chrono.ZonedChronology zonedChronology32 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology21, (org.joda.time.DateTimeZone) fixedDateTimeZone26);
        int int34 = fixedDateTimeZone26.getStandardOffset((long) (short) 10);
        org.joda.time.Chronology chronology35 = iSOChronology14.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        boolean boolean36 = fixedDateTimeZone4.equals((java.lang.Object) fixedDateTimeZone26);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 59 + "'", int28 == 59);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00" + "'", str31.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 59 + "'", int34 == 59);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        java.lang.String str34 = dividedDateTimeField32.getAsShortText(1969L);
        org.joda.time.DurationField durationField35 = dividedDateTimeField32.getDurationField();
        long long38 = dividedDateTimeField32.add((long) 152, (-12765L));
        try {
            long long40 = dividedDateTimeField32.roundCeiling(32L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-247048703999848L) + "'", long38 == (-247048703999848L));
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = gregorianChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
//        int int10 = fixedDateTimeZone8.getStandardOffset((long) 2);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = fixedDateTimeZone8.getShortName((long) 59, locale12);
//        int int15 = fixedDateTimeZone8.getOffset((-100L));
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = fixedDateTimeZone8.getName(11L, locale17);
//        org.joda.time.Chronology chronology19 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfMinute();
//        java.lang.String str24 = property23.toString();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone26);
//        org.joda.time.DateTime.Property property28 = dateTime27.secondOfDay();
//        org.joda.time.DateTime dateTime30 = dateTime27.withMillis((long) (short) 100);
//        int int31 = property23.getDifference((org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTime dateTime33 = dateTime30.plusWeeks((-1));
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone35);
//        org.joda.time.DateTime.Property property37 = dateTime36.secondOfMinute();
//        java.lang.String str38 = property37.toString();
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone40);
//        org.joda.time.DateTime.Property property42 = dateTime41.secondOfDay();
//        org.joda.time.DateTime dateTime44 = dateTime41.withMillis((long) (short) 100);
//        int int45 = property37.getDifference((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTime dateTime47 = dateTime44.plusWeeks((-1));
//        org.joda.time.DateTime.Property property48 = dateTime44.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property48.getFieldType();
//        org.joda.time.DateTime.Property property50 = dateTime33.property(dateTimeFieldType49);
//        org.joda.time.DateTime dateTime52 = dateTime33.minusMonths((int) (short) 1);
//        org.joda.time.LocalDate localDate53 = dateTime52.toLocalDate();
//        long long55 = gregorianChronology1.set((org.joda.time.ReadablePartial) localDate53, 1560635891495L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00" + "'", str18.equals("+00:00"));
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Property[secondOfMinute]" + "'", str24.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Property[secondOfMinute]" + "'", str38.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(localDate53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-3117708505L) + "'", long55 == (-3117708505L));
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
//        java.lang.String str4 = property3.toString();
//        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
//        int int10 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime dateTime12 = dateTime6.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime6.minus(readablePeriod13);
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
//        org.joda.time.DateTime dateTime17 = property15.addWrapFieldToCopy(2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.minusMillis((int) ' ');
        org.joda.time.DateTime.Property property16 = dateTime15.millisOfDay();
        int int17 = property16.getMaximumValue();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86399999 + "'", int17 == 86399999);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (byte) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendFractionOfSecond(1970, (int) '4');
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.secondOfMinute();
//        java.lang.String str15 = property14.toString();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone17);
//        org.joda.time.DateTime.Property property19 = dateTime18.secondOfDay();
//        org.joda.time.DateTime dateTime21 = dateTime18.withMillis((long) (short) 100);
//        int int22 = property14.getDifference((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime dateTime24 = dateTime21.plusWeeks((-1));
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone26);
//        org.joda.time.DateTime.Property property28 = dateTime27.secondOfMinute();
//        java.lang.String str29 = property28.toString();
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone31);
//        org.joda.time.DateTime.Property property33 = dateTime32.secondOfDay();
//        org.joda.time.DateTime dateTime35 = dateTime32.withMillis((long) (short) 100);
//        int int36 = property28.getDifference((org.joda.time.ReadableInstant) dateTime35);
//        org.joda.time.DateTime dateTime38 = dateTime35.plusWeeks((-1));
//        org.joda.time.DateTime.Property property39 = dateTime35.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
//        org.joda.time.DateTime.Property property41 = dateTime24.property(dateTimeFieldType40);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, "UTC");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType40);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType40, (int) (short) 100);
//        int int48 = offsetDateTimeField46.get((long) (byte) 0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Property[secondOfMinute]" + "'", str15.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Property[secondOfMinute]" + "'", str29.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 100 + "'", int48 == 100);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime10.plus(readableDuration14);
        org.joda.time.DateTime dateTime16 = dateTime10.toDateTimeISO();
        org.joda.time.DateTime.Property property17 = dateTime10.era();
        org.joda.time.DateTime dateTime19 = dateTime10.minusHours((int) (byte) -1);
        boolean boolean20 = dateTime19.isBeforeNow();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
//        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
//        java.lang.String str19 = property18.toString();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
//        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
//        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone34);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfDay();
//        org.joda.time.ReadableDuration readableDuration37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime35.minus(readableDuration37);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((java.lang.Object) dateTime38);
//        org.joda.time.DateTime dateTime41 = dateTime38.minusHours((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone43);
//        org.joda.time.DateTime.Property property45 = dateTime44.secondOfMinute();
//        java.lang.String str46 = property45.toString();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone48);
//        org.joda.time.DateTime.Property property50 = dateTime49.secondOfDay();
//        org.joda.time.DateTime dateTime52 = dateTime49.withMillis((long) (short) 100);
//        int int53 = property45.getDifference((org.joda.time.ReadableInstant) dateTime52);
//        org.joda.time.DateTime dateTime55 = dateTime52.plusWeeks((-1));
//        org.joda.time.DateTime.Property property56 = dateTime52.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property56.getFieldType();
//        int int58 = dateTime38.get(dateTimeFieldType57);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, (java.lang.Number) 1970, (java.lang.Number) 1560635854838L, (java.lang.Number) 3);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField32, dateTimeFieldType57, 365);
//        int int66 = remainderDateTimeField64.get((long) 19);
//        org.joda.time.DurationField durationField67 = remainderDateTimeField64.getLeapDurationField();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Property[secondOfMinute]" + "'", str46.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertNull(durationField67);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime.Property property16 = dateTime10.minuteOfHour();
        int int17 = property16.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 59 + "'", int17 == 59);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.DateTime dateTime31 = property30.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime33 = property30.setCopy(24);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime.Property property14 = dateTime10.minuteOfDay();
        org.joda.time.DateTime dateTime15 = property14.roundFloorCopy();
        org.joda.time.DateTime dateTime17 = dateTime15.plusDays((int) (short) 0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.minus(readableDuration10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime11);
//        org.joda.time.DateTime dateTime14 = dateTime11.minusHours((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
//        java.lang.String str19 = property18.toString();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
//        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
//        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        int int31 = dateTime11.get(dateTimeFieldType30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType30, 19);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField33.getAsText((-35L), locale35);
//        long long39 = offsetDateTimeField33.addWrapField((-28800000L), 16);
//        org.joda.time.DurationField durationField40 = offsetDateTimeField33.getLeapDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "384" + "'", str36.equals("384"));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-30268800000L) + "'", long39 == (-30268800000L));
//        org.junit.Assert.assertNull(durationField40);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        java.lang.String str5 = property4.toString();
        org.joda.time.DateTime dateTime7 = property4.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded((long) 'a', (-1));
        org.joda.time.DateTime.Property property11 = dateTime7.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        long long18 = gregorianChronology14.add(readablePeriod15, (long) 1969, 12);
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology14.getZone();
        java.lang.String str20 = dateTimeZone19.getID();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter12.withZone(dateTimeZone19);
        boolean boolean23 = dateTimeZone19.isStandardOffset((long) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime7.toMutableDateTime(dateTimeZone19);
        int int27 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime24, "(\"org.joda.time.JodaTimePermission\" \"0\")", (int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[secondOfMinute]" + "'", str5.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1969L + "'", long18 == 1969L);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        org.joda.time.DateTime dateTime6 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property3.roundCeilingCopy();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DurationField durationField5 = iSOChronology1.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
//        java.lang.String str3 = iSOChronology1.toString();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.secondOfMinute();
//        org.joda.time.Chronology chronology6 = iSOChronology1.withUTC();
//        org.joda.time.DurationField durationField7 = iSOChronology1.seconds();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[hi!]" + "'", str3.equals("ISOChronology[hi!]"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int21 = fixedDateTimeZone19.getStandardOffset((long) 2);
        java.util.Locale locale23 = null;
        java.lang.String str24 = fixedDateTimeZone19.getShortName((long) 59, locale23);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        java.util.TimeZone timeZone27 = fixedDateTimeZone19.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology28);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(chronology29);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        org.joda.time.DateTime dateTime7 = property4.withMaximumValue();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Property[secondOfMinute]");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int10 = fixedDateTimeZone8.getStandardOffset((long) 2);
        java.util.Locale locale12 = null;
        java.lang.String str13 = fixedDateTimeZone8.getShortName((long) 59, locale12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.Chronology chronology15 = zonedChronology14.withUTC();
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology14.hourOfHalfday();
        boolean boolean17 = jodaTimePermission1.equals((java.lang.Object) zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendFractionOfHour(4, 24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTimeZoneName(strMap7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        java.lang.String str5 = property4.toString();
        org.joda.time.DateTime dateTime7 = property4.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime10.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone29);
        org.joda.time.DateTime.Property property31 = dateTime30.secondOfMinute();
        java.lang.String str32 = property31.toString();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone34);
        org.joda.time.DateTime.Property property36 = dateTime35.secondOfDay();
        org.joda.time.DateTime dateTime38 = dateTime35.withMillis((long) (short) 100);
        int int39 = property31.getDifference((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTime dateTime41 = dateTime38.plusWeeks((-1));
        org.joda.time.DateTime.Property property42 = dateTime38.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
        org.joda.time.DateTime.Property property44 = dateTime27.property(dateTimeFieldType43);
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
        org.joda.time.DateTime dateTime50 = dateTime10.withField(dateTimeFieldType43, 3);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone52);
        org.joda.time.DateTime.Property property54 = dateTime53.secondOfMinute();
        java.lang.String str55 = property54.toString();
        int int56 = property54.getMaximumValueOverall();
        org.joda.time.DateTime dateTime58 = property54.addToCopy((int) (byte) -1);
        org.joda.time.DurationField durationField59 = property54.getDurationField();
        org.joda.time.DurationField durationField60 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField61 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType43, durationField59, durationField60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[secondOfMinute]" + "'", str5.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Property[secondOfMinute]" + "'", str32.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Property[secondOfMinute]" + "'", str55.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 59 + "'", int56 == 59);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(durationField59);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology1.add(readablePeriod2, (long) 1969, 12);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekyearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property3.getAsText(locale5);
        int int7 = property3.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 59 + "'", int7 == 59);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 20);
        int int5 = offsetDateTimeField4.getOffset();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int10 = fixedDateTimeZone8.getStandardOffset((long) 2);
        java.util.Locale locale12 = null;
        java.lang.String str13 = fixedDateTimeZone8.getShortName((long) 59, locale12);
        int int15 = fixedDateTimeZone8.getOffset((-100L));
        java.util.Locale locale17 = null;
        java.lang.String str18 = fixedDateTimeZone8.getName(11L, locale17);
        org.joda.time.Chronology chronology19 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology1.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00" + "'", str18.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
        org.joda.time.DurationField durationField7 = property6.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        java.lang.String str10 = gregorianChronology9.toString();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology9.getZone();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology9.getZone();
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) durationField7, (org.joda.time.Chronology) gregorianChronology9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDurationField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[UTC]" + "'", str10.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        org.joda.time.DateTime dateTime7 = property3.addWrapFieldToCopy((int) (short) 1);
        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDateTime8);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        int int12 = property3.getMaximumValueOverall();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property3.getAsShortText(locale13);
        java.lang.Object obj15 = null;
        boolean boolean16 = property3.equals(obj15);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone7.getName((long) '#', locale9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology13);
        boolean boolean15 = fixedDateTimeZone7.equals((java.lang.Object) gregorianChronology13);
        long long17 = fixedDateTimeZone7.nextTransition((long) 19);
        long long19 = fixedDateTimeZone7.nextTransition((long) (byte) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DurationField durationField21 = iSOChronology1.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 19L + "'", long17 == 19L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.Chronology chronology13 = zonedChronology12.withUTC();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology12.hourOfHalfday();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale21 = null;
        java.lang.String str22 = fixedDateTimeZone19.getName((long) '#', locale21);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone19, 3);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone26);
        org.joda.time.DateTime.Property property28 = dateTime27.secondOfMinute();
        java.lang.String str29 = property28.toString();
        org.joda.time.DateTime dateTime31 = property28.addWrapFieldToCopy(0);
        int int32 = dateTime31.getCenturyOfEra();
        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
        boolean boolean34 = fixedDateTimeZone19.isLocalDateTimeGap(localDateTime33);
        int[] intArray36 = zonedChronology12.get((org.joda.time.ReadablePartial) localDateTime33, 0L);
        org.joda.time.DateTimeField dateTimeField37 = zonedChronology12.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField38 = zonedChronology12.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00" + "'", str22.equals("+00:00"));
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Property[secondOfMinute]" + "'", str29.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 19 + "'", int32 == 19);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(2000, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendYearOfCentury((int) ' ', 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime.Property property4 = dateTime2.monthOfYear();
        int int5 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime6 = property4.roundHalfFloorCopy();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.DateTime dateTime8 = property4.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
//        org.joda.time.DateTime dateTime5 = dateTime2.withMillis((long) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime7 = dateTime5.withZone(dateTimeZone6);
//        boolean boolean8 = dateTime5.isBeforeNow();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.secondOfMinute();
//        java.lang.String str13 = property12.toString();
//        org.joda.time.DateTime dateTime15 = property12.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded((long) 'a', (-1));
//        int int19 = dateTime15.getDayOfWeek();
//        org.joda.time.DateTime dateTime21 = dateTime15.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime15.plus(readableDuration22);
//        int int24 = dateTime23.getMinuteOfDay();
//        boolean boolean25 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.DateTime dateTime27 = dateTime23.plusDays(4);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[secondOfMinute]" + "'", str13.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTime27);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYear(2000);
        org.joda.time.DateTime.Property property5 = dateTime4.weekyear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int21 = fixedDateTimeZone19.getStandardOffset((long) 2);
        java.util.Locale locale23 = null;
        java.lang.String str24 = fixedDateTimeZone19.getShortName((long) 59, locale23);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology12.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone28 = zonedChronology12.getZone();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime.Property property14 = dateTime10.minuteOfDay();
        org.joda.time.DateTime dateTime16 = property14.addToCopy(12775);
        boolean boolean18 = dateTime16.isEqual((long) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfMinute();
        java.lang.String str23 = property22.toString();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone25);
        org.joda.time.DateTime.Property property27 = dateTime26.secondOfDay();
        org.joda.time.DateTime dateTime29 = dateTime26.withMillis((long) (short) 100);
        int int30 = property22.getDifference((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime32 = dateTime29.plusYears((int) '4');
        org.joda.time.DateTime dateTime34 = dateTime29.minusDays(11);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone36);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
        java.lang.String str39 = property38.toString();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone41);
        org.joda.time.DateTime.Property property43 = dateTime42.secondOfDay();
        org.joda.time.DateTime dateTime45 = dateTime42.withMillis((long) (short) 100);
        int int46 = property38.getDifference((org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTime dateTime48 = dateTime45.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone50);
        org.joda.time.DateTime.Property property52 = dateTime51.secondOfMinute();
        java.lang.String str53 = property52.toString();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone55);
        org.joda.time.DateTime.Property property57 = dateTime56.secondOfDay();
        org.joda.time.DateTime dateTime59 = dateTime56.withMillis((long) (short) 100);
        int int60 = property52.getDifference((org.joda.time.ReadableInstant) dateTime59);
        org.joda.time.DateTime dateTime62 = dateTime59.plusWeeks((-1));
        org.joda.time.DateTime.Property property63 = dateTime59.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property63.getFieldType();
        org.joda.time.DateTime.Property property65 = dateTime48.property(dateTimeFieldType64);
        org.joda.time.IllegalFieldValueException illegalFieldValueException69 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
        org.joda.time.DateTime.Property property70 = dateTime34.property(dateTimeFieldType64);
        org.joda.time.DateTime.Property property71 = dateTime16.property(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Property[secondOfMinute]" + "'", str23.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Property[secondOfMinute]" + "'", str39.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Property[secondOfMinute]" + "'", str53.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(property71);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        org.joda.time.DateTime dateTime6 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property3.withMaximumValue();
        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
        org.joda.time.DateTime dateTime10 = dateTime7.minusMillis(70);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(69);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfDay(12775);
        boolean boolean7 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendWeekOfWeekyear(10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.DateTime dateTime31 = property30.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime33 = dateTime31.plusDays((int) (byte) 100);
        org.joda.time.DateTime.Property property34 = dateTime31.secondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime31.withWeekyear((int) 'a');
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime36);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
//        org.joda.time.DurationField durationField3 = iSOChronology1.eras();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
//        java.lang.String str9 = property8.toString();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone11);
//        org.joda.time.DateTime.Property property13 = dateTime12.secondOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime12.withMillis((long) (short) 100);
//        int int16 = property8.getDifference((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime18 = dateTime15.plusYears((int) '4');
//        org.joda.time.DateTime dateTime20 = dateTime18.minusMillis((int) ' ');
//        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
//        java.lang.String str22 = dateTimeFormatter4.print((org.joda.time.ReadablePartial) localDateTime21);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone26);
//        org.joda.time.DateTime.Property property28 = dateTime27.secondOfMinute();
//        java.lang.String str29 = property28.toString();
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone31);
//        org.joda.time.DateTime.Property property33 = dateTime32.secondOfDay();
//        org.joda.time.DateTime dateTime35 = dateTime32.withMillis((long) (short) 100);
//        int int36 = property28.getDifference((org.joda.time.ReadableInstant) dateTime35);
//        org.joda.time.DateTime dateTime38 = dateTime35.plusWeeks((-1));
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone40);
//        org.joda.time.DateTime.Property property42 = dateTime41.secondOfMinute();
//        java.lang.String str43 = property42.toString();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone45);
//        org.joda.time.DateTime.Property property47 = dateTime46.secondOfDay();
//        org.joda.time.DateTime dateTime49 = dateTime46.withMillis((long) (short) 100);
//        int int50 = property42.getDifference((org.joda.time.ReadableInstant) dateTime49);
//        org.joda.time.DateTime dateTime52 = dateTime49.plusWeeks((-1));
//        org.joda.time.DateTime.Property property53 = dateTime49.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property53.getFieldType();
//        org.joda.time.DateTime.Property property55 = dateTime38.property(dateTimeFieldType54);
//        org.joda.time.DateTime dateTime57 = dateTime38.minusMonths((int) (short) 1);
//        org.joda.time.LocalDate localDate58 = dateTime57.toLocalDate();
//        boolean boolean59 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate58);
//        int[] intArray61 = gregorianChronology24.get((org.joda.time.ReadablePartial) localDate58, (long) 12775);
//        try {
//            iSOChronology1.validate((org.joda.time.ReadablePartial) localDateTime21, intArray61);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[secondOfMinute]" + "'", str9.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localDateTime21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "00:00:00" + "'", str22.equals("00:00:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Property[secondOfMinute]" + "'", str29.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Property[secondOfMinute]" + "'", str43.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(localDate58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertNotNull(intArray61);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(20, (-52), (int) ' ', (int) (short) 100, 0, (int) (short) 0, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime10.minusDays(11);
        boolean boolean17 = dateTime10.equals((java.lang.Object) (-100L));
        org.joda.time.DateTime dateTime19 = dateTime10.withMillisOfDay((int) '4');
        try {
            org.joda.time.DateTime dateTime21 = dateTime19.withMinuteOfHour((-52));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -52 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = dateTimeZoneBuilder15.setFixedSavings("1970W013T������.000", 0);
        org.joda.time.DateTimeZone dateTimeZone21 = dateTimeZoneBuilder15.toDateTimeZone("ISOChronology[America/Los_Angeles]", false);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology13, dateTimeZone21);
        org.joda.time.Chronology chronology23 = zonedChronology22.withUTC();
        org.joda.time.DateTimeZone dateTimeZone24 = zonedChronology22.getZone();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        int int7 = dateTime6.getCenturyOfEra();
        int int8 = dateTime6.getWeekyear();
        org.joda.time.DateTime.Property property9 = dateTime6.hourOfDay();
        org.joda.time.Interval interval10 = property9.toInterval();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(interval10);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime10.plus(readableDuration14);
        org.joda.time.DateTime dateTime16 = dateTime10.toDateTimeISO();
        org.joda.time.DateTime.Property property17 = dateTime10.era();
        org.joda.time.DurationField durationField18 = property17.getRangeDurationField();
        try {
            org.joda.time.Interval interval19 = property17.toInterval();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNull(durationField18);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime10.minusDays(11);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone17);
        org.joda.time.DateTime.Property property19 = dateTime18.secondOfMinute();
        java.lang.String str20 = property19.toString();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone22);
        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
        org.joda.time.DateTime dateTime26 = dateTime23.withMillis((long) (short) 100);
        int int27 = property19.getDifference((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTime dateTime29 = dateTime26.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone31);
        org.joda.time.DateTime.Property property33 = dateTime32.secondOfMinute();
        java.lang.String str34 = property33.toString();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone36);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTime dateTime40 = dateTime37.withMillis((long) (short) 100);
        int int41 = property33.getDifference((org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DateTime dateTime43 = dateTime40.plusWeeks((-1));
        org.joda.time.DateTime.Property property44 = dateTime40.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property44.getFieldType();
        org.joda.time.DateTime.Property property46 = dateTime29.property(dateTimeFieldType45);
        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
        org.joda.time.DateTime.Property property51 = dateTime15.property(dateTimeFieldType45);
        org.joda.time.IllegalFieldValueException illegalFieldValueException54 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, (java.lang.Number) 9, "Coordinated Universal Time");
        java.lang.Number number55 = illegalFieldValueException54.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Property[secondOfMinute]" + "'", str20.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Property[secondOfMinute]" + "'", str34.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + 9 + "'", number55.equals(9));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.Chronology chronology13 = gregorianChronology10.withUTC();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = gregorianChronology10.add(readablePeriod14, (long) (short) 1, (-52));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter18.withPivotYear((-1));
        boolean boolean21 = gregorianChronology10.equals((java.lang.Object) dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology1.add(readablePeriod2, (long) 1969, 12);
        java.lang.String str6 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfMinute();
        java.lang.String str13 = property12.toString();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withMillis((long) (short) 100);
        int int20 = property12.getDifference((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime22 = dateTime19.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone24);
        org.joda.time.DateTime.Property property26 = dateTime25.secondOfMinute();
        java.lang.String str27 = property26.toString();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone29);
        org.joda.time.DateTime.Property property31 = dateTime30.secondOfDay();
        org.joda.time.DateTime dateTime33 = dateTime30.withMillis((long) (short) 100);
        int int34 = property26.getDifference((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime36 = dateTime33.plusWeeks((-1));
        org.joda.time.DateTime.Property property37 = dateTime33.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
        org.joda.time.DateTime.Property property39 = dateTime22.property(dateTimeFieldType38);
        org.joda.time.DateTime dateTime41 = dateTime22.minusMonths((int) (short) 1);
        org.joda.time.LocalDate localDate42 = dateTime41.toLocalDate();
        boolean boolean43 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate42);
        int[] intArray45 = gregorianChronology8.get((org.joda.time.ReadablePartial) localDate42, (long) 12775);
        int[] intArray47 = gregorianChronology1.get((org.joda.time.ReadablePartial) localDate42, (-26010597L));
        org.joda.time.DurationField durationField48 = gregorianChronology1.halfdays();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[UTC]" + "'", str6.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[secondOfMinute]" + "'", str13.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Property[secondOfMinute]" + "'", str27.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(durationField48);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendFractionOfSecond(1970, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime13.secondOfMinute();
        java.lang.String str15 = property14.toString();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone17);
        org.joda.time.DateTime.Property property19 = dateTime18.secondOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.withMillis((long) (short) 100);
        int int22 = property14.getDifference((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime21.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone26);
        org.joda.time.DateTime.Property property28 = dateTime27.secondOfMinute();
        java.lang.String str29 = property28.toString();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone31);
        org.joda.time.DateTime.Property property33 = dateTime32.secondOfDay();
        org.joda.time.DateTime dateTime35 = dateTime32.withMillis((long) (short) 100);
        int int36 = property28.getDifference((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime dateTime38 = dateTime35.plusWeeks((-1));
        org.joda.time.DateTime.Property property39 = dateTime35.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
        org.joda.time.DateTime.Property property41 = dateTime24.property(dateTimeFieldType40);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, "UTC");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType40);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType40, (int) (short) 100);
        int int47 = offsetDateTimeField46.getOffset();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Property[secondOfMinute]" + "'", str15.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Property[secondOfMinute]" + "'", str29.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 100 + "'", int47 == 100);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        java.lang.String str34 = dividedDateTimeField32.getAsShortText(1969L);
        java.lang.String str36 = dividedDateTimeField32.getAsText(0L);
        long long39 = dividedDateTimeField32.addWrapField((long) 16, 365);
        long long42 = dividedDateTimeField32.addWrapField((long) 12775, 359);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 19353600016L + "'", long39 == 19353600016L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 19353612775L + "'", long42 == 19353612775L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        int int34 = dividedDateTimeField32.get(32L);
        int int35 = dividedDateTimeField32.getMaximumValue();
        long long38 = dividedDateTimeField32.add(1969L, (-3L));
        java.util.Locale locale39 = null;
        int int40 = dividedDateTimeField32.getMaximumShortTextLength(locale39);
        int int41 = dividedDateTimeField32.getMaximumValue();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-58060798031L) + "'", long38 == (-58060798031L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName(10L);
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone0.getName((long) 12775, locale4);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.halfdayOfDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
//        int int15 = fixedDateTimeZone13.getStandardOffset((long) 2);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = fixedDateTimeZone13.getShortName((long) 59, locale17);
//        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology8, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfMinute();
//        java.lang.String str24 = property23.toString();
//        org.joda.time.DateTime dateTime26 = property23.addWrapFieldToCopy(0);
//        int int27 = dateTime26.getCenturyOfEra();
//        org.joda.time.LocalDateTime localDateTime28 = dateTime26.toLocalDateTime();
//        long long30 = zonedChronology19.set((org.joda.time.ReadablePartial) localDateTime28, (long) 100);
//        boolean boolean31 = dateTimeZone6.isLocalDateTimeGap(localDateTime28);
//        int[] intArray33 = iSOChronology1.get((org.joda.time.ReadablePartial) localDateTime28, (-1L));
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 59 + "'", int15 == 59);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00" + "'", str18.equals("+00:00"));
//        org.junit.Assert.assertNotNull(zonedChronology19);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Property[secondOfMinute]" + "'", str24.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 19 + "'", int27 == 19);
//        org.junit.Assert.assertNotNull(localDateTime28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(intArray33);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("0");
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.dayOfWeek();
        boolean boolean14 = jodaTimePermission8.equals((java.lang.Object) iSOChronology10);
        org.joda.time.DurationField durationField15 = iSOChronology10.months();
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(2, (int) (byte) 100, 32, (-1), 0, (int) (byte) 1, (int) (short) 0, (org.joda.time.Chronology) iSOChronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int6 = fixedDateTimeZone4.getStandardOffset((long) 2);
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone4.getShortName((long) 59, locale8);
        int int11 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        int int13 = fixedDateTimeZone4.getStandardOffset(0L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        org.joda.time.DateTime dateTime6 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property3.roundHalfEvenCopy();
        java.lang.String str8 = property3.getAsText();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology2.add(readablePeriod3, (long) 1969, 12);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology2.getZone();
        java.lang.String str8 = dateTimeZone7.getID();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withZone(dateTimeZone7);
        java.lang.String str11 = dateTimeFormatter9.print(1969L);
        java.lang.StringBuffer stringBuffer12 = null;
        try {
            dateTimeFormatter9.printTo(stringBuffer12, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1969L + "'", long6 == 1969L);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "00:00:01.969" + "'", str11.equals("00:00:01.969"));
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
//        java.lang.String str4 = iSOChronology2.toString();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.DateTime dateTime7 = dateTime5.withWeekOfWeekyear((int) (byte) 10);
//        int int8 = dateTime7.getYearOfEra();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusMonths((int) (short) 1);
//        org.joda.time.DateTime.Property property11 = dateTime7.minuteOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[hi!]" + "'", str4.equals("ISOChronology[hi!]"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
//        java.lang.String str3 = iSOChronology1.toString();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DurationField durationField5 = iSOChronology1.eras();
//        try {
//            long long11 = iSOChronology1.getDateTimeMillis((-28800000L), 2, 12775, 2000, 152);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12775 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[hi!]" + "'", str3.equals("ISOChronology[hi!]"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(durationField5);
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.minus(readableDuration10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime11);
//        org.joda.time.DateTime dateTime14 = dateTime11.minusHours((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
//        java.lang.String str19 = property18.toString();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
//        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
//        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        int int31 = dateTime11.get(dateTimeFieldType30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType30, 19);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField33.getAsText((-35L), locale35);
//        long long38 = offsetDateTimeField33.roundHalfFloor((long) (byte) 100);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "384" + "'", str36.equals("384"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
        org.joda.time.DateTime.Property property10 = dateTime6.secondOfMinute();
        org.joda.time.DateTime dateTime12 = dateTime6.withMillisOfDay(69);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2000);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime3.minusWeeks((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DurationField durationField5 = iSOChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.centuryOfEra();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTime dateTime15 = dateTime10.withHourOfDay((int) (byte) 10);
        int int16 = dateTime15.getMillisOfSecond();
        java.util.Date date17 = dateTime15.toDate();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendFractionOfHour(4, 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMinuteOfDay(1439);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
//        java.lang.String str4 = property3.toString();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
//        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
//        org.joda.time.DateTime dateTime15 = dateTime13.minusMillis((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone17);
//        org.joda.time.DateTime.Property property19 = dateTime18.secondOfMinute();
//        java.lang.String str20 = property19.toString();
//        org.joda.time.DateTime dateTime22 = property19.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded((long) 'a', (-1));
//        int int26 = dateTime22.getDayOfWeek();
//        org.joda.time.DateTime dateTime31 = dateTime22.withTime((int) (short) 1, (int) '4', (int) (byte) 1, (int) 'a');
//        org.joda.time.DateTime dateTime33 = dateTime22.minusSeconds((int) (byte) 0);
//        org.joda.time.YearMonthDay yearMonthDay34 = dateTime33.toYearMonthDay();
//        boolean boolean35 = dateTime15.isBefore((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime dateTime36 = dateTime33.withEarlierOffsetAtOverlap();
//        org.joda.time.Chronology chronology37 = dateTime36.getChronology();
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Property[secondOfMinute]" + "'", str20.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(yearMonthDay34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(chronology37);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("-1", (java.lang.Number) 69, (java.lang.Number) (byte) 100, (java.lang.Number) 24);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        illegalFieldValueException4.prependMessage("ZonedChronology[ISOChronology[UTC], hi!]");
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 69 + "'", number5.equals(69));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.Chronology chronology3 = gregorianChronology1.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2000);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.plus(readableDuration7);
        org.joda.time.DateTime dateTime10 = dateTime3.minusYears((-52));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2000);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property2.addToCopy((int) (byte) 100);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendEraText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatterBuilder7.toFormatter();
        try {
            org.joda.time.LocalTime localTime11 = dateTimeFormatter9.parseLocalTime("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
//        java.lang.String str3 = iSOChronology1.toString();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
//        boolean boolean5 = dateTime4.isEqualNow();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
//        java.util.GregorianCalendar gregorianCalendar10 = dateTime8.toGregorianCalendar();
//        boolean boolean11 = dateTime4.isAfter((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime13 = dateTime4.withDayOfYear(152);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[hi!]" + "'", str3.equals("ISOChronology[hi!]"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(gregorianCalendar10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
//        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
//        java.lang.String str19 = property18.toString();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
//        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
//        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone34);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfDay();
//        org.joda.time.ReadableDuration readableDuration37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime35.minus(readableDuration37);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((java.lang.Object) dateTime38);
//        org.joda.time.DateTime dateTime41 = dateTime38.minusHours((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone43);
//        org.joda.time.DateTime.Property property45 = dateTime44.secondOfMinute();
//        java.lang.String str46 = property45.toString();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone48);
//        org.joda.time.DateTime.Property property50 = dateTime49.secondOfDay();
//        org.joda.time.DateTime dateTime52 = dateTime49.withMillis((long) (short) 100);
//        int int53 = property45.getDifference((org.joda.time.ReadableInstant) dateTime52);
//        org.joda.time.DateTime dateTime55 = dateTime52.plusWeeks((-1));
//        org.joda.time.DateTime.Property property56 = dateTime52.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property56.getFieldType();
//        int int58 = dateTime38.get(dateTimeFieldType57);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, (java.lang.Number) 1970, (java.lang.Number) 1560635854838L, (java.lang.Number) 3);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField32, dateTimeFieldType57, 365);
//        long long67 = dividedDateTimeField32.getDifferenceAsLong((long) (byte) 100, (long) (short) 10);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Property[secondOfMinute]" + "'", str46.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        java.lang.String str34 = dividedDateTimeField32.getAsShortText(1969L);
        org.joda.time.DurationField durationField35 = dividedDateTimeField32.getDurationField();
        long long38 = dividedDateTimeField32.add((long) 152, (-12765L));
        int int40 = dividedDateTimeField32.getLeapAmount((long) (short) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-247048703999848L) + "'", long38 == (-247048703999848L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.year();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.secondOfMinute();
//        java.lang.String str7 = iSOChronology5.toString();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology5);
//        org.joda.time.YearMonthDay yearMonthDay9 = dateTime8.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone11);
//        org.joda.time.DateTime.Property property13 = dateTime12.secondOfMinute();
//        java.lang.String str14 = property13.toString();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
//        org.joda.time.DateTime dateTime20 = dateTime17.withMillis((long) (short) 100);
//        int int21 = property13.getDifference((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime23 = dateTime20.plusYears((int) '4');
//        org.joda.time.DateTime dateTime25 = dateTime20.minusDays(11);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone27);
//        org.joda.time.DateTime.Property property29 = dateTime28.secondOfMinute();
//        java.lang.String str30 = property29.toString();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.secondOfDay();
//        org.joda.time.DateTime dateTime36 = dateTime33.withMillis((long) (short) 100);
//        int int37 = property29.getDifference((org.joda.time.ReadableInstant) dateTime36);
//        org.joda.time.DateTime dateTime39 = dateTime36.plusWeeks((-1));
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone41);
//        org.joda.time.DateTime.Property property43 = dateTime42.secondOfMinute();
//        java.lang.String str44 = property43.toString();
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone46);
//        org.joda.time.DateTime.Property property48 = dateTime47.secondOfDay();
//        org.joda.time.DateTime dateTime50 = dateTime47.withMillis((long) (short) 100);
//        int int51 = property43.getDifference((org.joda.time.ReadableInstant) dateTime50);
//        org.joda.time.DateTime dateTime53 = dateTime50.plusWeeks((-1));
//        org.joda.time.DateTime.Property property54 = dateTime50.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property54.getFieldType();
//        org.joda.time.DateTime.Property property56 = dateTime39.property(dateTimeFieldType55);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException60 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType55, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
//        org.joda.time.DateTime.Property property61 = dateTime25.property(dateTimeFieldType55);
//        org.joda.time.DateTime.Property property62 = dateTime8.property(dateTimeFieldType55);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType55, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[hi!]" + "'", str7.equals("ISOChronology[hi!]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(yearMonthDay9);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Property[secondOfMinute]" + "'", str14.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Property[secondOfMinute]" + "'", str30.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Property[secondOfMinute]" + "'", str44.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
//        java.lang.String str4 = property3.toString();
//        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
//        int int7 = dateTime6.getCenturyOfEra();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusHours(0);
//        org.joda.time.DateTime.Property property10 = dateTime6.dayOfMonth();
//        int int11 = dateTime6.getDayOfYear();
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfDay(1439, 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral('4');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendTimeZoneOffset("1970W014T000000.000Z", false, 365, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
//        java.lang.String str4 = property3.toString();
//        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
//        int int10 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime dateTime12 = dateTime6.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime6.plus(readableDuration13);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.secondOfMinute();
//        java.lang.String str19 = iSOChronology17.toString();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTime dateTime22 = dateTime20.withWeekOfWeekyear((int) (byte) 10);
//        boolean boolean23 = dateTime14.isBefore((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTime dateTime25 = dateTime22.minusMonths(0);
//        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime25);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[hi!]" + "'", str19.equals("ISOChronology[hi!]"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(chronology26);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        java.lang.String str5 = gregorianChronology4.toString();
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology4.getZone();
//        java.lang.String str8 = dateTimeZone6.getShortName((long) 16);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[UTC]" + "'", str5.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendTimeZoneOffset("ISOChronology[America/Los_Angeles]", "1970W013T������.000", true, 2, (int) '4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int21 = fixedDateTimeZone19.getStandardOffset((long) 2);
        java.util.Locale locale23 = null;
        java.lang.String str24 = fixedDateTimeZone19.getShortName((long) 59, locale23);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        java.util.TimeZone timeZone27 = fixedDateTimeZone19.toTimeZone();
        boolean boolean28 = fixedDateTimeZone19.isFixed();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime10.plus(readableDuration14);
        org.joda.time.DateTime dateTime16 = dateTime10.toDateTimeISO();
        org.joda.time.DateTime.Property property17 = dateTime10.era();
        org.joda.time.DurationField durationField18 = property17.getRangeDurationField();
        java.util.Locale locale19 = null;
        int int20 = property17.getMaximumTextLength(locale19);
        int int21 = property17.getMaximumValue();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
//        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
//        java.lang.String str19 = property18.toString();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
//        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
//        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone34);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfDay();
//        org.joda.time.ReadableDuration readableDuration37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime35.minus(readableDuration37);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((java.lang.Object) dateTime38);
//        org.joda.time.DateTime dateTime41 = dateTime38.minusHours((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone43);
//        org.joda.time.DateTime.Property property45 = dateTime44.secondOfMinute();
//        java.lang.String str46 = property45.toString();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone48);
//        org.joda.time.DateTime.Property property50 = dateTime49.secondOfDay();
//        org.joda.time.DateTime dateTime52 = dateTime49.withMillis((long) (short) 100);
//        int int53 = property45.getDifference((org.joda.time.ReadableInstant) dateTime52);
//        org.joda.time.DateTime dateTime55 = dateTime52.plusWeeks((-1));
//        org.joda.time.DateTime.Property property56 = dateTime52.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property56.getFieldType();
//        int int58 = dateTime38.get(dateTimeFieldType57);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, (java.lang.Number) 1970, (java.lang.Number) 1560635854838L, (java.lang.Number) 3);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField32, dateTimeFieldType57, 365);
//        int int66 = remainderDateTimeField64.get((long) 19);
//        java.lang.String str68 = remainderDateTimeField64.getAsShortText((-9L));
//        try {
//            long long71 = remainderDateTimeField64.addWrapField((long) 385, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfDay must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Property[secondOfMinute]" + "'", str46.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "0" + "'", str68.equals("0"));
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.millis();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DurationField durationField4 = iSOChronology1.hours();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = iSOChronology1.get(readablePeriod5, 0L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
        org.joda.time.DurationField durationField7 = property6.getLeapDurationField();
        org.joda.time.Interval interval8 = property6.toInterval();
        org.joda.time.DateTime dateTime9 = property6.roundHalfEvenCopy();
        java.lang.Class<?> wildcardClass10 = dateTime9.getClass();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 20);
//        int int6 = offsetDateTimeField4.get((long) 86399999);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField4.getType();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1459 + "'", int6 == 1459);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = dateTimeZoneBuilder15.setFixedSavings("1970W013T������.000", 0);
        org.joda.time.DateTimeZone dateTimeZone21 = dateTimeZoneBuilder15.toDateTimeZone("ISOChronology[America/Los_Angeles]", false);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology13, dateTimeZone21);
        org.joda.time.Chronology chronology23 = zonedChronology22.withUTC();
        org.joda.time.DurationField durationField24 = zonedChronology22.minutes();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(durationField24);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
//        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
//        java.lang.String str19 = property18.toString();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
//        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
//        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone34);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfDay();
//        org.joda.time.ReadableDuration readableDuration37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime35.minus(readableDuration37);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((java.lang.Object) dateTime38);
//        org.joda.time.DateTime dateTime41 = dateTime38.minusHours((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone43);
//        org.joda.time.DateTime.Property property45 = dateTime44.secondOfMinute();
//        java.lang.String str46 = property45.toString();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone48);
//        org.joda.time.DateTime.Property property50 = dateTime49.secondOfDay();
//        org.joda.time.DateTime dateTime52 = dateTime49.withMillis((long) (short) 100);
//        int int53 = property45.getDifference((org.joda.time.ReadableInstant) dateTime52);
//        org.joda.time.DateTime dateTime55 = dateTime52.plusWeeks((-1));
//        org.joda.time.DateTime.Property property56 = dateTime52.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property56.getFieldType();
//        int int58 = dateTime38.get(dateTimeFieldType57);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, (java.lang.Number) 1970, (java.lang.Number) 1560635854838L, (java.lang.Number) 3);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField32, dateTimeFieldType57, 365);
//        int int65 = remainderDateTimeField64.getMinimumValue();
//        try {
//            long long68 = remainderDateTimeField64.set((long) 3, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfDay must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Property[secondOfMinute]" + "'", str46.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        java.lang.String str18 = property17.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((long) (short) 100);
        int int25 = property17.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.plusWeeks((-1));
        org.joda.time.DateTime.Property property28 = dateTime24.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
        org.joda.time.DateTime dateTime31 = property30.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime33 = dateTime31.withDayOfMonth((int) (short) 1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfMinute]" + "'", str18.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = gregorianChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        java.lang.String str6 = dateTimeZone4.getShortName((long) 16);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withZone(dateTimeZone4);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone4.getOffset(readableInstant9);
//        long long13 = dateTimeZone4.convertLocalToUTC(35L, false);
//        org.joda.time.JodaTimePermission jodaTimePermission15 = new org.joda.time.JodaTimePermission("0");
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.dayOfWeek();
//        boolean boolean21 = jodaTimePermission15.equals((java.lang.Object) iSOChronology17);
//        org.joda.time.DurationField durationField22 = iSOChronology17.months();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology17);
//        int int24 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        int int14 = fixedDateTimeZone6.getStandardOffset((long) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime dateTime30 = dateTime25.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime.Property property31 = dateTime25.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone33);
        org.joda.time.DateTime.Property property35 = dateTime34.secondOfMinute();
        java.lang.String str36 = property35.toString();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone38);
        org.joda.time.DateTime.Property property40 = dateTime39.secondOfDay();
        org.joda.time.DateTime dateTime42 = dateTime39.withMillis((long) (short) 100);
        int int43 = property35.getDifference((org.joda.time.ReadableInstant) dateTime42);
        org.joda.time.DateTime dateTime45 = dateTime42.plusYears((int) '4');
        org.joda.time.ReadableDuration readableDuration46 = null;
        org.joda.time.DateTime dateTime47 = dateTime42.plus(readableDuration46);
        org.joda.time.DateTime dateTime48 = dateTime42.toDateTimeISO();
        int int49 = property31.getDifference((org.joda.time.ReadableInstant) dateTime42);
        boolean boolean51 = dateTime42.isBefore((-572L));
        boolean boolean52 = fixedDateTimeZone6.equals((java.lang.Object) dateTime42);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Property[secondOfMinute]" + "'", str36.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
//        java.lang.String str4 = property3.toString();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withMillis((long) (short) 100);
//        int int11 = property3.getDifference((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((int) '4');
//        org.joda.time.DateTime dateTime15 = dateTime13.minusMillis((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone17);
//        org.joda.time.DateTime.Property property19 = dateTime18.secondOfMinute();
//        java.lang.String str20 = property19.toString();
//        org.joda.time.DateTime dateTime22 = property19.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded((long) 'a', (-1));
//        int int26 = dateTime22.getDayOfWeek();
//        org.joda.time.DateTime dateTime31 = dateTime22.withTime((int) (short) 1, (int) '4', (int) (byte) 1, (int) 'a');
//        org.joda.time.DateTime dateTime33 = dateTime22.minusSeconds((int) (byte) 0);
//        org.joda.time.YearMonthDay yearMonthDay34 = dateTime33.toYearMonthDay();
//        boolean boolean35 = dateTime15.isBefore((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime dateTime36 = dateTime33.withEarlierOffsetAtOverlap();
//        boolean boolean38 = dateTime33.isAfter((long) (byte) 100);
//        org.joda.time.DateTime.Property property39 = dateTime33.monthOfYear();
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Property[secondOfMinute]" + "'", str20.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(yearMonthDay34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(property39);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        int int14 = fixedDateTimeZone6.getStandardOffset((long) (short) 10);
        java.lang.String str16 = fixedDateTimeZone6.getShortName((long) 24);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendHourOfDay(365);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime.Property property4 = dateTime2.monthOfYear();
//        int int5 = property4.getMaximumValue();
//        org.joda.time.DateTime dateTime6 = property4.roundHalfFloorCopy();
//        int int7 = property4.get();
//        org.joda.time.DurationField durationField8 = property4.getDurationField();
//        org.joda.time.DateTime dateTime10 = property4.addToCopy((long) (short) 0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
//        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
//        java.lang.String str19 = property18.toString();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
//        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
//        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone34);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfDay();
//        org.joda.time.ReadableDuration readableDuration37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime35.minus(readableDuration37);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((java.lang.Object) dateTime38);
//        org.joda.time.DateTime dateTime41 = dateTime38.minusHours((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone43);
//        org.joda.time.DateTime.Property property45 = dateTime44.secondOfMinute();
//        java.lang.String str46 = property45.toString();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone48);
//        org.joda.time.DateTime.Property property50 = dateTime49.secondOfDay();
//        org.joda.time.DateTime dateTime52 = dateTime49.withMillis((long) (short) 100);
//        int int53 = property45.getDifference((org.joda.time.ReadableInstant) dateTime52);
//        org.joda.time.DateTime dateTime55 = dateTime52.plusWeeks((-1));
//        org.joda.time.DateTime.Property property56 = dateTime52.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property56.getFieldType();
//        int int58 = dateTime38.get(dateTimeFieldType57);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, (java.lang.Number) 1970, (java.lang.Number) 1560635854838L, (java.lang.Number) 3);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField32, dateTimeFieldType57, 365);
//        java.util.Locale locale66 = null;
//        java.lang.String str67 = dividedDateTimeField32.getAsShortText((long) 69, locale66);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Property[secondOfMinute]" + "'", str46.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "0" + "'", str67.equals("0"));
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.minus(readableDuration10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime11);
//        org.joda.time.DateTime dateTime14 = dateTime11.minusHours((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
//        java.lang.String str19 = property18.toString();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
//        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
//        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        int int31 = dateTime11.get(dateTimeFieldType30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType30, 19);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField33.getAsText((-35L), locale35);
//        long long39 = offsetDateTimeField33.addWrapField((-28800000L), 16);
//        org.joda.time.ReadableInstant readableInstant40 = null;
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone42);
//        org.joda.time.DateTime.Property property44 = dateTime43.secondOfMinute();
//        java.lang.String str45 = property44.toString();
//        org.joda.time.DateTime dateTime47 = property44.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime50 = dateTime47.withDurationAdded((long) 'a', (-1));
//        org.joda.time.LocalDate localDate51 = dateTime50.toLocalDate();
//        org.joda.time.Chronology chronology52 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant40, (org.joda.time.ReadableInstant) dateTime50);
//        org.joda.time.MutableDateTime mutableDateTime53 = dateTime50.toMutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone55);
//        org.joda.time.DateTime.Property property57 = dateTime56.secondOfMinute();
//        java.lang.String str58 = property57.toString();
//        org.joda.time.DateTimeZone dateTimeZone60 = null;
//        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone60);
//        org.joda.time.DateTime.Property property62 = dateTime61.secondOfDay();
//        org.joda.time.DateTime dateTime64 = dateTime61.withMillis((long) (short) 100);
//        int int65 = property57.getDifference((org.joda.time.ReadableInstant) dateTime64);
//        org.joda.time.DateTime dateTime67 = dateTime64.plusWeeks((-1));
//        org.joda.time.DateTimeZone dateTimeZone69 = null;
//        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone69);
//        org.joda.time.DateTime.Property property71 = dateTime70.secondOfMinute();
//        java.lang.String str72 = property71.toString();
//        org.joda.time.DateTimeZone dateTimeZone74 = null;
//        org.joda.time.DateTime dateTime75 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone74);
//        org.joda.time.DateTime.Property property76 = dateTime75.secondOfDay();
//        org.joda.time.DateTime dateTime78 = dateTime75.withMillis((long) (short) 100);
//        int int79 = property71.getDifference((org.joda.time.ReadableInstant) dateTime78);
//        org.joda.time.DateTime dateTime81 = dateTime78.plusWeeks((-1));
//        org.joda.time.DateTime.Property property82 = dateTime78.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType83 = property82.getFieldType();
//        org.joda.time.DateTime.Property property84 = dateTime67.property(dateTimeFieldType83);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException88 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType83, (java.lang.Number) 10, (java.lang.Number) 11, (java.lang.Number) (byte) 0);
//        org.joda.time.DateTime dateTime90 = dateTime50.withField(dateTimeFieldType83, 3);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField94 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField33, dateTimeFieldType83, 70, (int) (byte) 100, 24);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "384" + "'", str36.equals("384"));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-30268800000L) + "'", long39 == (-30268800000L));
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Property[secondOfMinute]" + "'", str45.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(localDate51);
//        org.junit.Assert.assertNotNull(chronology52);
//        org.junit.Assert.assertNotNull(mutableDateTime53);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Property[secondOfMinute]" + "'", str58.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(property71);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "Property[secondOfMinute]" + "'", str72.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property76);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
//        org.junit.Assert.assertNotNull(dateTime81);
//        org.junit.Assert.assertNotNull(property82);
//        org.junit.Assert.assertNotNull(dateTimeFieldType83);
//        org.junit.Assert.assertNotNull(property84);
//        org.junit.Assert.assertNotNull(dateTime90);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(2000, 3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatter9.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.append(dateTimePrinter10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder13.appendFractionOfSecond(1970, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone22);
        org.joda.time.DateTime.Property property24 = dateTime23.secondOfMinute();
        java.lang.String str25 = property24.toString();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone27);
        org.joda.time.DateTime.Property property29 = dateTime28.secondOfDay();
        org.joda.time.DateTime dateTime31 = dateTime28.withMillis((long) (short) 100);
        int int32 = property24.getDifference((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime dateTime34 = dateTime31.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone36);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
        java.lang.String str39 = property38.toString();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone41);
        org.joda.time.DateTime.Property property43 = dateTime42.secondOfDay();
        org.joda.time.DateTime dateTime45 = dateTime42.withMillis((long) (short) 100);
        int int46 = property38.getDifference((org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTime dateTime48 = dateTime45.plusWeeks((-1));
        org.joda.time.DateTime.Property property49 = dateTime45.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = property49.getFieldType();
        org.joda.time.DateTime.Property property51 = dateTime34.property(dateTimeFieldType50);
        org.joda.time.IllegalFieldValueException illegalFieldValueException53 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType50, "UTC");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder20.appendShortText(dateTimeFieldType50);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser56 = dateTimeFormatter55.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = dateTimeFormatter55.withPivotYear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone60);
        org.joda.time.DateTime.Property property62 = dateTime61.secondOfMinute();
        java.lang.String str63 = property62.toString();
        org.joda.time.DateTime dateTime65 = property62.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime68 = dateTime65.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate69 = dateTime68.toLocalDate();
        java.lang.String str70 = dateTimeFormatter58.print((org.joda.time.ReadablePartial) localDate69);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter71 = dateTimeFormatter58.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = dateTimeFormatter58.withOffsetParsed();
        org.joda.time.Chronology chronology73 = dateTimeFormatter58.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter74 = dateTimeFormatter58.withZoneUTC();
        org.joda.time.format.DateTimePrinter dateTimePrinter75 = dateTimeFormatter74.getPrinter();
        org.joda.time.DateTimeZone dateTimeZone76 = null;
        org.joda.time.chrono.ISOChronology iSOChronology77 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone76);
        org.joda.time.DateTimeField dateTimeField78 = iSOChronology77.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField79 = iSOChronology77.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField80 = iSOChronology77.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField81 = iSOChronology77.dayOfYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter82 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser83 = dateTimeFormatter82.getParser();
        boolean boolean84 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeField81, (java.lang.Object) dateTimeParser83);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder85 = dateTimeFormatterBuilder54.append(dateTimePrinter75, dateTimeParser83);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder86 = dateTimeFormatterBuilder12.append(dateTimeParser83);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimePrinter10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Property[secondOfMinute]" + "'", str25.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Property[secondOfMinute]" + "'", str39.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatter55);
        org.junit.Assert.assertNotNull(dateTimeParser56);
        org.junit.Assert.assertNotNull(dateTimeFormatter58);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Property[secondOfMinute]" + "'", str63.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(localDate69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "1970W013T������.000" + "'", str70.equals("1970W013T������.000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter71);
        org.junit.Assert.assertNotNull(dateTimeFormatter72);
        org.junit.Assert.assertNull(chronology73);
        org.junit.Assert.assertNotNull(dateTimeFormatter74);
        org.junit.Assert.assertNotNull(dateTimePrinter75);
        org.junit.Assert.assertNotNull(iSOChronology77);
        org.junit.Assert.assertNotNull(dateTimeField78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertNotNull(dateTimeFormatter82);
        org.junit.Assert.assertNotNull(dateTimeParser83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder85);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder86);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.minus(readableDuration10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime11);
//        org.joda.time.DateTime dateTime14 = dateTime11.minusHours((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
//        java.lang.String str19 = property18.toString();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
//        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
//        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        int int31 = dateTime11.get(dateTimeFieldType30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType30, 19);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField33.getAsText((-35L), locale35);
//        long long39 = offsetDateTimeField33.addWrapField((-28800000L), 16);
//        org.joda.time.DurationField durationField40 = offsetDateTimeField33.getDurationField();
//        org.joda.time.ReadablePartial readablePartial41 = null;
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone46 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = fixedDateTimeZone46.getName((long) '#', locale48);
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology52);
//        boolean boolean54 = fixedDateTimeZone46.equals((java.lang.Object) gregorianChronology52);
//        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone46);
//        org.joda.time.DateTimeField dateTimeField56 = iSOChronology55.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone58);
//        org.joda.time.DateTime.Property property60 = dateTime59.secondOfMinute();
//        java.lang.String str61 = property60.toString();
//        org.joda.time.DateTimeZone dateTimeZone63 = null;
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone63);
//        org.joda.time.DateTime.Property property65 = dateTime64.secondOfDay();
//        org.joda.time.DateTime dateTime67 = dateTime64.withMillis((long) (short) 100);
//        int int68 = property60.getDifference((org.joda.time.ReadableInstant) dateTime67);
//        org.joda.time.DateTime dateTime70 = dateTime67.plusWeeks((-1));
//        org.joda.time.DateTimeZone dateTimeZone72 = null;
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone72);
//        org.joda.time.DateTime.Property property74 = dateTime73.secondOfMinute();
//        java.lang.String str75 = property74.toString();
//        org.joda.time.DateTimeZone dateTimeZone77 = null;
//        org.joda.time.DateTime dateTime78 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone77);
//        org.joda.time.DateTime.Property property79 = dateTime78.secondOfDay();
//        org.joda.time.DateTime dateTime81 = dateTime78.withMillis((long) (short) 100);
//        int int82 = property74.getDifference((org.joda.time.ReadableInstant) dateTime81);
//        org.joda.time.DateTime dateTime84 = dateTime81.plusWeeks((-1));
//        org.joda.time.DateTime.Property property85 = dateTime81.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType86 = property85.getFieldType();
//        org.joda.time.DateTime.Property property87 = dateTime70.property(dateTimeFieldType86);
//        org.joda.time.DateTime dateTime89 = dateTime70.minusMonths((int) (short) 1);
//        org.joda.time.LocalDate localDate90 = dateTime89.toLocalDate();
//        int[] intArray92 = iSOChronology55.get((org.joda.time.ReadablePartial) localDate90, (-691200000L));
//        int int93 = offsetDateTimeField33.getMinimumValue(readablePartial41, intArray92);
//        int int94 = offsetDateTimeField33.getOffset();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "384" + "'", str36.equals("384"));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-30268800000L) + "'", long39 == (-30268800000L));
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "+00:00" + "'", str49.equals("+00:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(gregorianChronology52);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(iSOChronology55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Property[secondOfMinute]" + "'", str61.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(property74);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "Property[secondOfMinute]" + "'", str75.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property79);
//        org.junit.Assert.assertNotNull(dateTime81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
//        org.junit.Assert.assertNotNull(dateTime84);
//        org.junit.Assert.assertNotNull(property85);
//        org.junit.Assert.assertNotNull(dateTimeFieldType86);
//        org.junit.Assert.assertNotNull(property87);
//        org.junit.Assert.assertNotNull(dateTime89);
//        org.junit.Assert.assertNotNull(localDate90);
//        org.junit.Assert.assertNotNull(intArray92);
//        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 20 + "'", int93 == 20);
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 19 + "'", int94 == 19);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2000);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property3.getAsText(locale5);
        org.joda.time.DateTime dateTime8 = property3.addToCopy((long) 4);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        java.lang.String str4 = gregorianChronology3.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
        long long9 = dateTimeZone5.convertLocalToUTC((long) 100, true, (long) 2000);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone(dateTimeZone5);
        java.util.Locale locale11 = dateTimeFormatter10.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNull(locale11);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.weekyears();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int9 = fixedDateTimeZone7.getStandardOffset((long) 2);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone7.getShortName((long) 59, locale11);
        int int14 = fixedDateTimeZone7.getOffset((-100L));
        java.util.Locale locale16 = null;
        java.lang.String str17 = fixedDateTimeZone7.getName(11L, locale16);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone19 = zonedChronology18.getZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 59 + "'", int9 == 59);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.Chronology chronology15 = iSOChronology13.withUTC();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.lang.Object obj0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withDayOfYear(359);
        int int9 = dateTime8.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 25 + "'", int9 == 25);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 1459);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        int int5 = property3.getMaximumValueOverall();
        java.lang.String str6 = property3.getName();
        org.joda.time.DateTime dateTime7 = property3.withMaximumValue();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "secondOfMinute" + "'", str6.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = dateTimeZoneBuilder15.setFixedSavings("1970W013T������.000", 0);
        org.joda.time.DateTimeZone dateTimeZone21 = dateTimeZoneBuilder15.toDateTimeZone("ISOChronology[America/Los_Angeles]", false);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology13, dateTimeZone21);
        org.joda.time.Chronology chronology23 = zonedChronology22.withUTC();
        org.joda.time.DateTimeField dateTimeField24 = zonedChronology22.secondOfMinute();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
        int int7 = dateTime6.getCenturyOfEra();
        org.joda.time.DateTime dateTime9 = dateTime6.plusHours(0);
        org.joda.time.DateTime.Property property10 = dateTime6.weekyear();
        int int11 = property10.get();
        int int12 = property10.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 292278993 + "'", int12 == 292278993);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int8 = fixedDateTimeZone6.getStandardOffset((long) 2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone6.getShortName((long) 59, locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        int int21 = fixedDateTimeZone19.getStandardOffset((long) 2);
        java.util.Locale locale23 = null;
        java.lang.String str24 = fixedDateTimeZone19.getShortName((long) 59, locale23);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DurationField durationField27 = zonedChronology12.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(durationField27);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter5);
        java.lang.StringBuffer stringBuffer7 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfMinute();
        org.joda.time.DateTime dateTime13 = dateTime10.withEra((int) (byte) 1);
        try {
            dateTimeFormatter5.printTo(stringBuffer7, (org.joda.time.ReadableInstant) dateTime13);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
//        java.lang.String str4 = property3.toString();
//        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) 'a', (-1));
//        int int10 = dateTime6.getDayOfWeek();
//        int int11 = dateTime6.getMillisOfDay();
//        int int12 = dateTime6.getDayOfMonth();
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[secondOfMinute]" + "'", str4.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfMinute();
        java.lang.String str8 = property7.toString();
        org.joda.time.DateTime dateTime10 = property7.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded((long) 'a', (-1));
        org.joda.time.LocalDate localDate14 = dateTime13.toLocalDate();
        java.lang.String str15 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter3.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter3.withOffsetParsed();
        org.joda.time.Chronology chronology18 = dateTimeFormatter3.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter3.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter19.withPivotYear((java.lang.Integer) 365);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[secondOfMinute]" + "'", str8.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970W013T������.000" + "'", str15.equals("1970W013T������.000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2000);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.minus(readableDuration10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime11);
//        org.joda.time.DateTime dateTime14 = dateTime11.minusHours((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
//        java.lang.String str19 = property18.toString();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
//        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
//        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        int int31 = dateTime11.get(dateTimeFieldType30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType30, 19);
//        long long35 = offsetDateTimeField33.roundHalfEven((-26010597L));
//        int int37 = offsetDateTimeField33.getLeapAmount(19690L);
//        int int39 = offsetDateTimeField33.getLeapAmount((long) (short) -1);
//        int int41 = offsetDateTimeField33.getMaximumValue(0L);
//        java.util.Locale locale42 = null;
//        int int43 = offsetDateTimeField33.getMaximumShortTextLength(locale42);
//        long long45 = offsetDateTimeField33.roundHalfEven(10L);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 385 + "'", int41 == 385);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 3 + "'", int43 == 3);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, 59);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '#', locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 12, (org.joda.time.Chronology) gregorianChronology10);
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        java.lang.String str19 = property18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillis((long) (short) 100);
        int int26 = property18.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusWeeks((-1));
        org.joda.time.DateTime.Property property29 = dateTime25.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType30, 32);
        java.lang.String str34 = dividedDateTimeField32.getAsShortText(1969L);
        try {
            long long37 = dividedDateTimeField32.set((long) (byte) 100, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9 for minuteOfDay must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
    }
}

