import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay5 = dateTime3.toTimeOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime3.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime8 = dateTime3.toDateTime((org.joda.time.Chronology) buddhistChronology7);
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology10);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology10);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology7, readableDateTime9, (org.joda.time.ReadableDateTime) dateTime12);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology16);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology16);
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology16.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology15, (org.joda.time.DateTimeField) delegatedDateTimeField21);
//        java.lang.String str24 = skipDateTimeField22.getAsText(0L);
//        int int25 = skipDateTimeField22.getMinimumValue();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone30 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
//        long long33 = fixedDateTimeZone30.convertLocalToUTC((long) (-1), false);
//        org.joda.time.MutableDateTime mutableDateTime34 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone30);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendTwoDigitWeekyear((int) (short) 100);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology38 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology38);
//        org.joda.time.DateTime.Property property40 = dateTime39.secondOfMinute();
//        org.joda.time.DateTime dateTime42 = property40.addToCopy(100);
//        org.joda.time.DateTime dateTime44 = property40.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property40.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, (java.lang.Number) 0.0d, "26");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType45, 12);
//        int int51 = mutableDateTime34.get(dateTimeFieldType45);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField22, dateTimeFieldType45, (-28800000));
//        int int54 = offsetDateTimeField53.getMinimumValue();
//        int int57 = offsetDateTimeField53.getDifference((long) 50, 0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology58);
//        org.joda.time.DateTime.Property property60 = dateTime59.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay61 = dateTime59.toTimeOfDay();
//        org.joda.time.DateTime.Property property62 = dateTime59.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology63 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime64 = dateTime59.toDateTime((org.joda.time.Chronology) buddhistChronology63);
//        org.joda.time.TimeOfDay timeOfDay65 = dateTime59.toTimeOfDay();
//        java.util.Locale locale66 = null;
//        java.lang.String str67 = offsetDateTimeField53.getAsShortText((org.joda.time.ReadablePartial) timeOfDay65, locale66);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) timeOfDay65);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(timeOfDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(limitChronology15);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2513" + "'", str24.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292268512) + "'", int25 == (-292268512));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-60L) + "'", long33 == (-60L));
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(buddhistChronology38);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 40 + "'", int51 == 40);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-321068512) + "'", int54 == (-321068512));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology58);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(timeOfDay61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertNotNull(buddhistChronology63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(timeOfDay65);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "40" + "'", str67.equals("40"));
//    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        java.lang.String str3 = dateTimeFormatter1.print((long) (short) 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970W014T000000.060+0000" + "'", str3.equals("1970W014T000000.060+0000"));
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = dateTime1.minusWeeks((int) (byte) 0);
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfSecond();
        java.lang.String str7 = dateTime1.toString("29");
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "29" + "'", str7.equals("29"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long9 = buddhistChronology5.add((-1L), 100L, (int) 'a');
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology5.millisOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField10, (int) (byte) -1);
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket(9223371985593602562L, (org.joda.time.Chronology) gJChronology1, locale14);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        org.joda.time.DateTime dateTime19 = property18.roundHalfEvenCopy();
        org.joda.time.DateTimeField dateTimeField20 = property18.getField();
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology21);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology21);
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime23.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant25 = null;
        boolean boolean26 = mutableDateTime24.isEqual(readableInstant25);
        java.util.GregorianCalendar gregorianCalendar27 = mutableDateTime24.toGregorianCalendar();
        org.joda.time.DateTimeField dateTimeField28 = mutableDateTime24.getRoundingField();
        mutableDateTime24.addMinutes(10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.secondOfMinute();
        org.joda.time.DateTime dateTime35 = property33.addToCopy(100);
        org.joda.time.DateTime dateTime37 = property33.setCopy("30");
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 0.0d, "26");
        org.joda.time.MutableDateTime.Property property42 = mutableDateTime24.property(dateTimeFieldType38);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, dateTimeFieldType38, 8, 6, 45);
        dateTimeParserBucket15.saveField((org.joda.time.DateTimeField) offsetDateTimeField46, (int) (byte) 1);
        int int50 = offsetDateTimeField46.getMinimumValue((long) (-13));
        int int51 = offsetDateTimeField46.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9699L + "'", long9 == 9699L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar27);
        org.junit.Assert.assertNull(dateTimeField28);
        org.junit.Assert.assertNotNull(buddhistChronology31);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 8 + "'", int50 == 8);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 8 + "'", int51 == 8);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        int int0 = org.joda.time.MutableDateTime.ROUND_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1640995200000L, (java.lang.Number) 46, (java.lang.Number) 53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property2.addToCopy(100);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra(2000);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withDurationAdded(readableDuration9, 0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.DateTime.Property property3 = dateTime1.secondOfMinute();
//        java.lang.String str4 = dateTime1.toString();
//        org.joda.time.DateTime.Property property5 = dateTime1.yearOfCentury();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2562-06-12T12:50:41.217Z" + "'", str4.equals("2562-06-12T12:50:41.217Z"));
//        org.junit.Assert.assertNotNull(property5);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField2 = julianChronology1.halfdays();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology1, locale3, (java.lang.Integer) (-28800000));
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) 1);
        org.joda.time.Instant instant9 = instant7.minus((long) 6);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Instant instant11 = instant7.plus(readableDuration10);
        boolean boolean12 = dateTimeParserBucket5.restoreState((java.lang.Object) instant7);
        org.joda.time.Chronology chronology13 = dateTimeParserBucket5.getChronology();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay4 = dateTime2.toTimeOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology9);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) ' ');
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology6, readableDateTime8, (org.joda.time.ReadableDateTime) dateTime11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
        long long22 = fixedDateTimeZone19.convertLocalToUTC((long) (-1), false);
        org.joda.time.Chronology chronology23 = limitChronology14.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((long) (short) 100, chronology23);
        java.lang.Object obj25 = mutableDateTime24.clone();
        java.util.GregorianCalendar gregorianCalendar26 = mutableDateTime24.toGregorianCalendar();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(timeOfDay4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(limitChronology14);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-60L) + "'", long22 == (-60L));
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(gregorianCalendar26);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear(41);
        org.joda.time.DateTime.Property property7 = dateTime4.yearOfEra();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime5 = property2.addToCopy((long) 'a');
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.minus((long) '4');
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.minusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime10 = dateTime8.withMillis((-2L));
//        org.joda.time.DateTime dateTime12 = dateTime8.minusWeeks(59);
//        try {
//            org.joda.time.DateTime dateTime14 = dateTime12.withWeekOfWeekyear(2513);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2513 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2562-163T12:50:41Z" + "'", str6.equals("2562-163T12:50:41Z"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        try {
            long long5 = gJChronology0.getDateTimeMillis(24, 52, (int) (byte) 10, 825);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime3.getRoundingField();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        boolean boolean13 = mutableDateTime11.isEqual(readableInstant12);
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
//        mutableDateTime11.setZoneRetainFields(dateTimeZone15);
//        mutableDateTime3.setZone(dateTimeZone15);
//        mutableDateTime3.setYear((-1));
//        org.joda.time.MutableDateTime.Property property20 = mutableDateTime3.millisOfSecond();
//        org.joda.time.Interval interval21 = property20.toInterval();
//        org.joda.time.MutableDateTime mutableDateTime22 = property20.roundHalfEven();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(interval21);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(24);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder0.setStandardOffset(2512);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder0.addCutover(15, '#', 31, 2, 825, false, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2562-163T12:49:27Z");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay5 = dateTime3.toTimeOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfYear();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime3);
        int int8 = dateTime3.getCenturyOfEra();
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(timeOfDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 26 + "'", int8 == 26);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTime dateTime6 = dateTime4.minus((long) '4');
//        java.lang.String str7 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime9 = dateTime6.minusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime11 = dateTime9.withMillis((-2L));
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
//        java.lang.String str15 = dateTimeZone13.getName(0L);
//        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        long long20 = dateTimeZone18.convertUTCToLocal((long) (-13));
//        org.joda.time.DateTime dateTime21 = dateTime9.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime dateTime23 = dateTime21.toDateTime();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2562-163T12:50:41Z" + "'", str7.equals("2562-163T12:50:41Z"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.059" + "'", str15.equals("+00:00:00.059"));
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 46L + "'", long20 == 46L);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay4 = dateTime2.toTimeOfDay();
//        org.joda.time.DateTime.Property property5 = dateTime2.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime((org.joda.time.Chronology) buddhistChronology6);
//        org.joda.time.TimeOfDay timeOfDay8 = dateTime2.toTimeOfDay();
//        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) timeOfDay8);
//        boolean boolean10 = dateTimeFormatter0.isParser();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(timeOfDay4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(timeOfDay8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "����-��-��T12:50:41.881" + "'", str9.equals("����-��-��T12:50:41.881"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime3.getRoundingField();
//        mutableDateTime3.addMinutes(10);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime3.secondOfDay();
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology12 = julianChronology11.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime3, chronology12);
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.minuteOfHour();
//        int int15 = mutableDateTime13.getWeekOfWeekyear();
//        mutableDateTime13.addDays(292279536);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) mutableDateTime13);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 22 + "'", int15 == 22);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2562-163T12:49:27Z");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay5 = dateTime3.toTimeOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfYear();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime3);
        org.joda.time.DateTime.Property property8 = dateTime3.secondOfDay();
        org.joda.time.DateMidnight dateMidnight9 = dateTime3.toDateMidnight();
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(timeOfDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateMidnight9);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
//        mutableDateTime3.setZoneRetainFields(dateTimeZone7);
//        int int10 = dateTimeZone7.getOffsetFromLocal((long) ' ');
//        int int12 = dateTimeZone7.getOffsetFromLocal((-604799997L));
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        boolean boolean15 = cachedDateTimeZone13.equals((java.lang.Object) 39);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear(41);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withPeriodAdded(readablePeriod8, 0);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime6.minus(readablePeriod11);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(100L);
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.DateTime dateTime8 = dateTime6.minus((long) '4');
//        java.lang.String str9 = dateTimeFormatter3.print((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime11 = dateTime8.minusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.withMillis((-2L));
//        mutableDateTime1.setDate((org.joda.time.ReadableInstant) dateTime13);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2562-163T12:50:42Z" + "'", str9.equals("2562-163T12:50:42Z"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant4 = null;
        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime3.getRoundingField();
        mutableDateTime3.addMinutes(10);
        org.joda.time.MutableDateTime mutableDateTime10 = mutableDateTime3.copy();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        mutableDateTime10.add(readablePeriod11);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant4 = null;
        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime3.dayOfWeek();
        java.lang.Object obj8 = mutableDateTime3.clone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology9);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
        org.joda.time.DateTime dateTime13 = dateTime11.minus((long) '4');
        org.joda.time.DateTime dateTime15 = dateTime11.plus((long) (short) 10);
        org.joda.time.DateTime dateTime16 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime18 = dateTime11.withYear(7);
        mutableDateTime3.setTime((org.joda.time.ReadableInstant) dateTime18);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.lang.String str1 = julianChronology0.toString();
//        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
//        try {
//            long long7 = julianChronology0.getDateTimeMillis(46290, (-321068512), 52, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -321068512 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[2562-163T12:49:30Z]" + "'", str1.equals("JulianChronology[2562-163T12:49:30Z]"));
//        org.junit.Assert.assertNotNull(chronology2);
//    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
//        mutableDateTime3.setZoneRetainFields(dateTimeZone7);
//        int int10 = dateTimeZone7.getOffsetFromLocal((long) ' ');
//        int int12 = dateTimeZone7.getOffsetFromLocal((-604799997L));
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.halfdayOfDay();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.year();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) 10);
        boolean boolean3 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.ReadableDateTime readableDateTime7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology5, readableDateTime7, (org.joda.time.ReadableDateTime) dateTime10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField19);
//        java.lang.String str22 = skipDateTimeField20.getAsText(0L);
//        int int23 = skipDateTimeField20.getMinimumValue();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
//        long long31 = fixedDateTimeZone28.convertLocalToUTC((long) (-1), false);
//        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendTwoDigitWeekyear((int) (short) 100);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology36);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
//        org.joda.time.DateTime dateTime40 = property38.addToCopy(100);
//        org.joda.time.DateTime dateTime42 = property38.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property38.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 0.0d, "26");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType43, 12);
//        int int49 = mutableDateTime32.get(dateTimeFieldType43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField20, dateTimeFieldType43, (-28800000));
//        java.util.Locale locale52 = null;
//        int int53 = offsetDateTimeField51.getMaximumShortTextLength(locale52);
//        org.joda.time.DurationField durationField54 = offsetDateTimeField51.getLeapDurationField();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2513" + "'", str22.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292268512) + "'", int23 == (-292268512));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-60L) + "'", long31 == (-60L));
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 42 + "'", int49 == 42);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 9 + "'", int53 == 9);
//        org.junit.Assert.assertNotNull(durationField54);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 2307, (long) 99);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2208L + "'", long2 == 2208L);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
//        mutableDateTime3.setZoneRetainFields(dateTimeZone7);
//        int int10 = dateTimeZone7.getOffsetFromLocal((long) ' ');
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.DateTime.Property property13 = dateTime12.monthOfYear();
//        org.joda.time.DateTime dateTime15 = dateTime12.withMillis((long) 42);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.DateTime dateTime4 = property2.addToCopy(100);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
//        org.joda.time.DateTime dateTime9 = dateTime6.minusMonths((int) (short) 0);
//        org.joda.time.DateTime dateTime14 = dateTime9.withTime(0, (int) (short) 1, 0, 57);
//        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology15.getZone();
//        java.lang.String str18 = dateTimeZone16.getName(0L);
//        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now(dateTimeZone16);
//        org.joda.time.DateTime dateTime20 = dateTime9.withZoneRetainFields(dateTimeZone16);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology21);
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology21);
//        org.joda.time.MutableDateTime mutableDateTime24 = dateTime23.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        boolean boolean26 = mutableDateTime24.isEqual(readableInstant25);
//        java.util.GregorianCalendar gregorianCalendar27 = mutableDateTime24.toGregorianCalendar();
//        org.joda.time.MutableDateTime.Property property28 = mutableDateTime24.monthOfYear();
//        mutableDateTime24.addHours((int) (byte) 10);
//        mutableDateTime24.addWeeks((int) (byte) 10);
//        mutableDateTime24.setYear(31);
//        int int35 = dateTimeZone16.getOffset((org.joda.time.ReadableInstant) mutableDateTime24);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(julianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.059" + "'", str18.equals("+00:00:00.059"));
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(buddhistChronology21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(gregorianCalendar27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 59 + "'", int35 == 59);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime3.getRoundingField();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        boolean boolean13 = mutableDateTime11.isEqual(readableInstant12);
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
//        mutableDateTime11.setZoneRetainFields(dateTimeZone15);
//        mutableDateTime3.setZone(dateTimeZone15);
//        mutableDateTime3.addSeconds((int) '4');
//        org.joda.time.MutableDateTime.Property property20 = mutableDateTime3.hourOfDay();
//        long long21 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime3);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560343895397L + "'", long21 == 1560343895397L);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        java.lang.String str3 = property2.getAsString();
//        java.lang.String str4 = property2.getAsShortText();
//        org.joda.time.DurationField durationField5 = property2.getRangeDurationField();
//        int int6 = property2.get();
//        org.joda.time.DateTime dateTime8 = property2.setCopy((int) (short) 1);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "43" + "'", str3.equals("43"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "43" + "'", str4.equals("43"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 43 + "'", int6 == 43);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.ReadableDateTime readableDateTime7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology5, readableDateTime7, (org.joda.time.ReadableDateTime) dateTime10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField19);
//        java.lang.String str22 = skipDateTimeField20.getAsText(0L);
//        int int23 = skipDateTimeField20.getMinimumValue();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
//        long long31 = fixedDateTimeZone28.convertLocalToUTC((long) (-1), false);
//        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendTwoDigitWeekyear((int) (short) 100);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology36);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
//        org.joda.time.DateTime dateTime40 = property38.addToCopy(100);
//        org.joda.time.DateTime dateTime42 = property38.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property38.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 0.0d, "26");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType43, 12);
//        int int49 = mutableDateTime32.get(dateTimeFieldType43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField20, dateTimeFieldType43, (-28800000));
//        org.joda.time.chrono.BuddhistChronology buddhistChronology52 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology52);
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology52);
//        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology52.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField55, dateTimeFieldType56);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology58);
//        org.joda.time.DateTime.Property property60 = dateTime59.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay61 = dateTime59.toTimeOfDay();
//        int[] intArray65 = new int[] { 4, (short) 100 };
//        int[] intArray67 = delegatedDateTimeField57.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay61, 99, intArray65, (int) (byte) 0);
//        java.util.Locale locale68 = null;
//        java.lang.String str69 = offsetDateTimeField51.getAsShortText((org.joda.time.ReadablePartial) timeOfDay61, locale68);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology71 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime72 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology71);
//        org.joda.time.DateTime.Property property73 = dateTime72.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay74 = dateTime72.toTimeOfDay();
//        org.joda.time.DateTime.Property property75 = dateTime72.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology76 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime77 = dateTime72.toDateTime((org.joda.time.Chronology) buddhistChronology76);
//        org.joda.time.TimeOfDay timeOfDay78 = dateTime72.toTimeOfDay();
//        java.lang.String str79 = dateTimeFormatter70.print((org.joda.time.ReadablePartial) timeOfDay78);
//        int int80 = offsetDateTimeField51.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay78);
//        java.util.Locale locale81 = null;
//        int int82 = offsetDateTimeField51.getMaximumTextLength(locale81);
//        org.joda.time.DurationField durationField83 = offsetDateTimeField51.getLeapDurationField();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2513" + "'", str22.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292268512) + "'", int23 == (-292268512));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-60L) + "'", long31 == (-60L));
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 43 + "'", int49 == 43);
//        org.junit.Assert.assertNotNull(buddhistChronology52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(buddhistChronology58);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(timeOfDay61);
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertNotNull(intArray67);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "43" + "'", str69.equals("43"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter70);
//        org.junit.Assert.assertNotNull(buddhistChronology71);
//        org.junit.Assert.assertNotNull(property73);
//        org.junit.Assert.assertNotNull(timeOfDay74);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNotNull(buddhistChronology76);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(timeOfDay78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "����-��-��T12:50:43.594" + "'", str79.equals("����-��-��T12:50:43.594"));
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 263479536 + "'", int80 == 263479536);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 9 + "'", int82 == 9);
//        org.junit.Assert.assertNotNull(durationField83);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime3.getRoundingField();
//        mutableDateTime3.addMinutes(10);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime3.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        boolean boolean12 = property10.isLeap();
//        org.joda.time.MutableDateTime mutableDateTime13 = property10.roundCeiling();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException2.prependMessage("hi!");
        illegalFieldValueException2.prependMessage("+00:00:00.059");
        java.lang.String str7 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1", "", (int) 'a', 41);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
//        mutableDateTime3.setZoneRetainFields(dateTimeZone7);
//        int int10 = dateTimeZone7.getOffsetFromLocal((long) ' ');
//        int int12 = dateTimeZone7.getOffsetFromLocal((-604799997L));
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        long long15 = cachedDateTimeZone13.nextTransition(0L);
//        long long17 = cachedDateTimeZone13.nextTransition(37L);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 37L + "'", long17 == 37L);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant4 = null;
        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime3.getRoundingField();
        mutableDateTime3.addMinutes(10);
        org.joda.time.MutableDateTime mutableDateTime10 = mutableDateTime3.copy();
        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime3.copy();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.ReadableDateTime readableDateTime7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology5, readableDateTime7, (org.joda.time.ReadableDateTime) dateTime10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField19);
//        java.lang.String str22 = skipDateTimeField20.getAsText(0L);
//        int int23 = skipDateTimeField20.getMinimumValue();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
//        long long31 = fixedDateTimeZone28.convertLocalToUTC((long) (-1), false);
//        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendTwoDigitWeekyear((int) (short) 100);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology36);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
//        org.joda.time.DateTime dateTime40 = property38.addToCopy(100);
//        org.joda.time.DateTime dateTime42 = property38.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property38.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 0.0d, "26");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType43, 12);
//        int int49 = mutableDateTime32.get(dateTimeFieldType43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField20, dateTimeFieldType43, (-28800000));
//        boolean boolean52 = skipDateTimeField20.isLenient();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2513" + "'", str22.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292268512) + "'", int23 == (-292268512));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-60L) + "'", long31 == (-60L));
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 44 + "'", int49 == 44);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(52, (int) ' ', 292279536, 292279536, 12, 53, 18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279536 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendDayOfWeek(59);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withDefaultYear(292279536);
        org.joda.time.Chronology chronology14 = dateTimeFormatter11.getChronolgy();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder7.append(dateTimeFormatter11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendWeekOfWeekyear(26);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.yearOfCentury();
        int int2 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone4);
        org.joda.time.DurationField durationField7 = zonedChronology6.weeks();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime3.getRoundingField();
//        mutableDateTime3.setMillis((long) ' ');
//        mutableDateTime3.setSecondOfMinute(28);
//        mutableDateTime3.setDayOfYear((int) 'a');
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNull(dateTimeField7);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property2.addToCopy(100);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.minusMonths((int) (short) 0);
        org.joda.time.DateTime dateTime11 = dateTime9.plus(0L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.secondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
//        java.lang.String str6 = dateTimeZone4.getName(0L);
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        long long11 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (-25462866110400000L));
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.059" + "'", str6.equals("+00:00:00.059"));
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-25462866110400059L) + "'", long11 == (-25462866110400059L));
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology6);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay9 = dateTime7.toTimeOfDay();
//        int[] intArray13 = new int[] { 4, (short) 100 };
//        int[] intArray15 = delegatedDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay9, 99, intArray13, (int) (byte) 0);
//        java.lang.String str16 = delegatedDateTimeField5.getName();
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = delegatedDateTimeField5.getAsText((long) (byte) 100, locale18);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology20);
//        org.joda.time.DateTime.Property property22 = dateTime21.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay23 = dateTime21.toTimeOfDay();
//        org.joda.time.DateTime.Property property24 = dateTime21.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime26 = dateTime21.toDateTime((org.joda.time.Chronology) buddhistChronology25);
//        org.joda.time.ReadableDateTime readableDateTime27 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology28);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology28);
//        org.joda.time.DateTime dateTime32 = dateTime30.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology33 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology25, readableDateTime27, (org.joda.time.ReadableDateTime) dateTime30);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology34);
//        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology34);
//        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology34.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField39 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37, dateTimeFieldType38);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology33, (org.joda.time.DateTimeField) delegatedDateTimeField39);
//        java.lang.String str42 = skipDateTimeField40.getAsText(0L);
//        int int43 = skipDateTimeField40.getMinimumValue();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone48 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
//        long long51 = fixedDateTimeZone48.convertLocalToUTC((long) (-1), false);
//        org.joda.time.MutableDateTime mutableDateTime52 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone48);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder53.appendTwoDigitWeekyear((int) (short) 100);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology56 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology56);
//        org.joda.time.DateTime.Property property58 = dateTime57.secondOfMinute();
//        org.joda.time.DateTime dateTime60 = property58.addToCopy(100);
//        org.joda.time.DateTime dateTime62 = property58.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType63 = property58.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException66 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType63, (java.lang.Number) 0.0d, "26");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder53.appendFixedDecimal(dateTimeFieldType63, 12);
//        int int69 = mutableDateTime52.get(dateTimeFieldType63);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField40, dateTimeFieldType63, (-28800000));
//        int int72 = offsetDateTimeField71.getMinimumValue();
//        int int75 = offsetDateTimeField71.getDifference((long) 50, 0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology76 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime77 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology76);
//        org.joda.time.DateTime.Property property78 = dateTime77.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay79 = dateTime77.toTimeOfDay();
//        org.joda.time.DateTime.Property property80 = dateTime77.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology81 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime82 = dateTime77.toDateTime((org.joda.time.Chronology) buddhistChronology81);
//        org.joda.time.TimeOfDay timeOfDay83 = dateTime77.toTimeOfDay();
//        java.util.Locale locale84 = null;
//        java.lang.String str85 = offsetDateTimeField71.getAsShortText((org.joda.time.ReadablePartial) timeOfDay83, locale84);
//        int[] intArray87 = null;
//        int[] intArray89 = delegatedDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay83, 4, intArray87, 0);
//        java.util.Locale locale91 = null;
//        java.lang.String str92 = delegatedDateTimeField5.getAsText(1, locale91);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(timeOfDay9);
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "year" + "'", str16.equals("year"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2513" + "'", str19.equals("2513"));
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(timeOfDay23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(buddhistChronology25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(buddhistChronology28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(limitChronology33);
//        org.junit.Assert.assertNotNull(buddhistChronology34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "2513" + "'", str42.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-292268512) + "'", int43 == (-292268512));
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-60L) + "'", long51 == (-60L));
//        org.junit.Assert.assertNotNull(mutableDateTime52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
//        org.junit.Assert.assertNotNull(buddhistChronology56);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(dateTimeFieldType63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 45 + "'", int69 == 45);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-321068512) + "'", int72 == (-321068512));
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology76);
//        org.junit.Assert.assertNotNull(property78);
//        org.junit.Assert.assertNotNull(timeOfDay79);
//        org.junit.Assert.assertNotNull(property80);
//        org.junit.Assert.assertNotNull(buddhistChronology81);
//        org.junit.Assert.assertNotNull(dateTime82);
//        org.junit.Assert.assertNotNull(timeOfDay83);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "45" + "'", str85.equals("45"));
//        org.junit.Assert.assertNull(intArray89);
//        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "1" + "'", str92.equals("1"));
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
//        java.lang.String str5 = buddhistChronology4.toString();
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology4);
//        java.util.Locale locale7 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) 4455, (org.joda.time.Chronology) buddhistChronology4, locale7, (java.lang.Integer) 45, 22);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "BuddhistChronology[2562-163T12:49:30Z]" + "'", str5.equals("BuddhistChronology[2562-163T12:49:30Z]"));
//        org.junit.Assert.assertNotNull(chronology6);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMonths((int) ' ');
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime2.withSecondOfMinute(4);
        org.joda.time.DateTime dateTime8 = dateTime2.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths((int) '#');
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.roundHalfEvenCopy();
        org.joda.time.DateTimeField dateTimeField4 = property2.getField();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime7.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant9 = null;
        boolean boolean10 = mutableDateTime8.isEqual(readableInstant9);
        java.util.GregorianCalendar gregorianCalendar11 = mutableDateTime8.toGregorianCalendar();
        org.joda.time.DateTimeField dateTimeField12 = mutableDateTime8.getRoundingField();
        mutableDateTime8.addMinutes(10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime19 = property17.addToCopy(100);
        org.joda.time.DateTime dateTime21 = property17.setCopy("30");
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 0.0d, "26");
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime8.property(dateTimeFieldType22);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType22, 8, 6, 45);
        long long32 = offsetDateTimeField30.roundCeiling((-31535999992L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar11);
        org.junit.Assert.assertNull(dateTimeField12);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31535999000L) + "'", long32 == (-31535999000L));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long8 = buddhistChronology4.add((-1L), 100L, (int) 'a');
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology4.millisOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField9);
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField9, (int) (byte) -1);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField12.getMaximumTextLength(locale13);
        long long17 = skipDateTimeField12.add((long) (byte) 0, (int) ' ');
        java.lang.String str19 = skipDateTimeField12.getAsShortText(46L);
        int int21 = skipDateTimeField12.getLeapAmount(46L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9699L + "'", long8 == 9699L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 32L + "'", long17 == 32L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "46" + "'", str19.equals("46"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        mutableDateTime0.add(readableDuration1, (-1));
        org.junit.Assert.assertNotNull(mutableDateTime0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.minus((long) '4');
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.minusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime9 = dateTime8.withTimeAtStartOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.lang.String str11 = dateTime8.toString(dateTimeFormatter10);
//        try {
//            org.joda.time.DateTime dateTime13 = dateTimeFormatter10.parseDateTime("2562-163T12:50:13Z");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2562-163T12:50:13Z\" is malformed at \"-163T12:50:13Z\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2562-163T12:50:46Z" + "'", str6.equals("2562-163T12:50:46Z"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "125046.365Z" + "'", str11.equals("125046.365Z"));
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("2562-163T12:49:43Z", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2562-163T12:49:43Z\" is malformed at \"T12:49:43Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.ReadableDateTime readableDateTime7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology5, readableDateTime7, (org.joda.time.ReadableDateTime) dateTime10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField19);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology21);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfMinute();
//        int int24 = property23.getMaximumValue();
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = property23.getAsShortText(locale25);
//        boolean boolean27 = limitChronology13.equals((java.lang.Object) str26);
//        try {
//            long long33 = limitChronology13.getDateTimeMillis((-210863736000000L), 50, 51, (int) (short) 0, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000Z (BuddhistChronology[UTC])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(buddhistChronology21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 59 + "'", int24 == 59);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "46" + "'", str26.equals("46"));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay9 = dateTime7.toTimeOfDay();
        int[] intArray13 = new int[] { 4, (short) 100 };
        int[] intArray15 = delegatedDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay9, 99, intArray13, (int) (byte) 0);
        java.lang.String str16 = delegatedDateTimeField5.toString();
        java.util.Locale locale17 = null;
        int int18 = delegatedDateTimeField5.getMaximumTextLength(locale17);
        try {
            long long21 = delegatedDateTimeField5.set(0L, "2562-163T12:49:30Z");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2562-163T12:49:30Z\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(timeOfDay9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[year]" + "'", str16.equals("DateTimeField[year]"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.minus((long) '4');
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.minusMillis((int) (byte) 10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology9);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime11.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        boolean boolean14 = mutableDateTime12.isEqual(readableInstant13);
//        java.util.GregorianCalendar gregorianCalendar15 = mutableDateTime12.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField16 = mutableDateTime12.getRoundingField();
//        mutableDateTime12.addMinutes(10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology19);
//        org.joda.time.DateTime.Property property21 = dateTime20.secondOfMinute();
//        org.joda.time.DateTime dateTime23 = property21.addToCopy(100);
//        org.joda.time.DateTime dateTime25 = property21.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property21.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) 0.0d, "26");
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime12.property(dateTimeFieldType26);
//        int int31 = dateTime8.get(dateTimeFieldType26);
//        org.joda.time.ReadableDuration readableDuration32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime8.minus(readableDuration32);
//        java.util.Date date34 = dateTime33.toDate();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2562-163T12:50:46Z" + "'", str6.equals("2562-163T12:50:46Z"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar15);
//        org.junit.Assert.assertNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(buddhistChronology19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 46 + "'", int31 == 46);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(date34);
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
//        mutableDateTime3.setZoneRetainFields(dateTimeZone7);
//        int int10 = dateTimeZone7.getOffsetFromLocal((long) ' ');
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(dateTimeZone7);
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
//        org.junit.Assert.assertNotNull(property12);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.clockhourOfHalfday();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10, 8, 52, 2019, 825, (int) (byte) 10, 5, (org.joda.time.Chronology) buddhistChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(292279536, 46290, 12, 100, (int) (byte) -1, 97, 24, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("2562-163T12:50:36Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        java.lang.String str4 = buddhistChronology3.toString();
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology3);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 2000, dateTimeZone7);
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
//        org.joda.time.Chronology chronology11 = buddhistChronology3.withZone(dateTimeZone7);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BuddhistChronology[2562-163T12:49:30Z]" + "'", str4.equals("BuddhistChronology[2562-163T12:49:30Z]"));
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(chronology11);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2562-163T12:49:27Z");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay5 = dateTime3.toTimeOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfYear();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime3);
        java.lang.String str8 = jodaTimePermission1.toString();
        java.lang.String str9 = jodaTimePermission1.getName();
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology10);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology10);
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology10.yearOfEra();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology10.centuryOfEra();
        jodaTimePermission1.checkGuard((java.lang.Object) buddhistChronology10);
        try {
            org.joda.time.Instant instant16 = new org.joda.time.Instant((java.lang.Object) jodaTimePermission1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.JodaTimePermission");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(timeOfDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"2562-163T12:49:27Z\")" + "'", str8.equals("(\"org.joda.time.JodaTimePermission\" \"2562-163T12:49:27Z\")"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2562-163T12:49:27Z" + "'", str9.equals("2562-163T12:49:27Z"));
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property3.addToCopy(28800032L);
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        java.lang.String str3 = dateTimeZone1.getName((long) 2019);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.059" + "'", str3.equals("+00:00:00.059"));
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfMinute(62, (int) (short) 1);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName(strMap6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendMinuteOfHour(2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime5 = dateTime2.withMillisOfSecond((int) (byte) 10);
//        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560343847010L + "'", long6 == 1560343847010L);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 1);
        org.joda.time.Instant instant3 = instant1.minus((long) 6);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant1.plus(readableDuration4);
        org.joda.time.Instant instant8 = instant1.withDurationAdded((long) 12, 0);
        org.joda.time.Instant instant10 = instant1.minus(0L);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField2 = buddhistChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.era();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.yearOfCentury();
        int int7 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology5.getZone();
        org.joda.time.Chronology chronology11 = buddhistChronology0.withZone(dateTimeZone10);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser2);
        boolean boolean4 = dateTimeFormatter3.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser5);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology7);
//        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
//        org.joda.time.DateTime dateTime10 = property9.roundHalfEvenCopy();
//        org.joda.time.DateTimeField dateTimeField11 = property9.getField();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology12);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology12);
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime14.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        boolean boolean17 = mutableDateTime15.isEqual(readableInstant16);
//        java.util.GregorianCalendar gregorianCalendar18 = mutableDateTime15.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField19 = mutableDateTime15.getRoundingField();
//        mutableDateTime15.addMinutes(10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology22);
//        org.joda.time.DateTime.Property property24 = dateTime23.secondOfMinute();
//        org.joda.time.DateTime dateTime26 = property24.addToCopy(100);
//        org.joda.time.DateTime dateTime28 = property24.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property24.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 0.0d, "26");
//        org.joda.time.MutableDateTime.Property property33 = mutableDateTime15.property(dateTimeFieldType29);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType29, 8, 6, 45);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType29, 45);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap40 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder39.appendTimeZoneShortName(strMap40);
//        dateTimeFormatterBuilder41.clear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeParser2);
//        org.junit.Assert.assertNotNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeParser5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(buddhistChronology12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar18);
//        org.junit.Assert.assertNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(buddhistChronology22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.minuteOfHour();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.ReadableDateTime readableDateTime7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology5, readableDateTime7, (org.joda.time.ReadableDateTime) dateTime10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField19);
//        java.lang.String str22 = skipDateTimeField20.getAsText(0L);
//        int int23 = skipDateTimeField20.getMinimumValue();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
//        long long31 = fixedDateTimeZone28.convertLocalToUTC((long) (-1), false);
//        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendTwoDigitWeekyear((int) (short) 100);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology36);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
//        org.joda.time.DateTime dateTime40 = property38.addToCopy(100);
//        org.joda.time.DateTime dateTime42 = property38.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property38.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 0.0d, "26");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType43, 12);
//        int int49 = mutableDateTime32.get(dateTimeFieldType43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField20, dateTimeFieldType43, (-28800000));
//        org.joda.time.chrono.BuddhistChronology buddhistChronology52 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology52);
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology52);
//        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology52.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField55, dateTimeFieldType56);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology58);
//        org.joda.time.DateTime.Property property60 = dateTime59.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay61 = dateTime59.toTimeOfDay();
//        int[] intArray65 = new int[] { 4, (short) 100 };
//        int[] intArray67 = delegatedDateTimeField57.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay61, 99, intArray65, (int) (byte) 0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology68 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology68);
//        org.joda.time.DateTime dateTime70 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology68);
//        org.joda.time.TimeOfDay timeOfDay71 = dateTime70.toTimeOfDay();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology72 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology72);
//        org.joda.time.DateTime dateTime74 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology72);
//        org.joda.time.DateTimeField dateTimeField75 = buddhistChronology72.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField77 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField75, dateTimeFieldType76);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology78 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime79 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology78);
//        org.joda.time.DateTime.Property property80 = dateTime79.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay81 = dateTime79.toTimeOfDay();
//        int[] intArray85 = new int[] { 4, (short) 100 };
//        int[] intArray87 = delegatedDateTimeField77.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay81, 99, intArray85, (int) (byte) 0);
//        int int88 = delegatedDateTimeField57.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay71, intArray85);
//        java.util.Locale locale90 = null;
//        java.lang.String str91 = offsetDateTimeField51.getAsShortText((org.joda.time.ReadablePartial) timeOfDay71, 46290, locale90);
//        long long94 = offsetDateTimeField51.add(0L, (long) '4');
//        boolean boolean96 = offsetDateTimeField51.isLeap((long) 58);
//        long long99 = offsetDateTimeField51.set(1L, 0);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2513" + "'", str22.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292268512) + "'", int23 == (-292268512));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-60L) + "'", long31 == (-60L));
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 47 + "'", int49 == 47);
//        org.junit.Assert.assertNotNull(buddhistChronology52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(buddhistChronology58);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(timeOfDay61);
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertNotNull(intArray67);
//        org.junit.Assert.assertNotNull(buddhistChronology68);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(timeOfDay71);
//        org.junit.Assert.assertNotNull(buddhistChronology72);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertNotNull(buddhistChronology78);
//        org.junit.Assert.assertNotNull(property80);
//        org.junit.Assert.assertNotNull(timeOfDay81);
//        org.junit.Assert.assertNotNull(intArray85);
//        org.junit.Assert.assertNotNull(intArray87);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 292279536 + "'", int88 == 292279536);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "46290" + "'", str91.equals("46290"));
//        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 1640995200000L + "'", long94 == 1640995200000L);
//        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
//        org.junit.Assert.assertTrue("'" + long99 + "' != '" + 908760915014400001L + "'", long99 == 908760915014400001L);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2562-163T12:49:27Z");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay5 = dateTime3.toTimeOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfYear();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime3);
        org.joda.time.DateTime.Property property8 = dateTime3.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime3.withPeriodAdded(readablePeriod9, (int) (byte) 0);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime3.plus(readablePeriod12);
        org.joda.time.DateTime dateTime15 = dateTime3.minus(51L);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(timeOfDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.DateTime dateTime4 = property2.addToCopy(100);
//        org.joda.time.DateTime dateTime6 = property2.setCopy("30");
//        java.util.Locale locale7 = null;
//        int int8 = property2.getMaximumTextLength(locale7);
//        org.joda.time.DateTime dateTime10 = property2.addWrapFieldToCopy(0);
//        org.joda.time.DurationField durationField11 = property2.getDurationField();
//        java.lang.String str12 = property2.getAsString();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "48" + "'", str12.equals("48"));
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        int int3 = property2.getMaximumValue();
        boolean boolean4 = property2.isLeap();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 59 + "'", int3 == 59);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        int int2 = dateTimeFormatter1.getDefaultYear();
        try {
            org.joda.time.Instant instant3 = org.joda.time.Instant.parse("2562-163T12:50:41Z", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2562-163T12:50:41Z\" is malformed at \"Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
//        int int7 = mutableDateTime3.getRoundingMode();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendDayOfWeek(59);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withDefaultYear(292279536);
        org.joda.time.Chronology chronology14 = dateTimeFormatter11.getChronolgy();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder7.append(dateTimeFormatter11);
        boolean boolean16 = dateTimeFormatterBuilder7.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology6);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay9 = dateTime7.toTimeOfDay();
//        int[] intArray13 = new int[] { 4, (short) 100 };
//        int[] intArray15 = delegatedDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay9, 99, intArray13, (int) (byte) 0);
//        java.lang.String str16 = delegatedDateTimeField5.getName();
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = delegatedDateTimeField5.getAsText((long) (byte) 100, locale18);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology20);
//        org.joda.time.DateTime.Property property22 = dateTime21.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay23 = dateTime21.toTimeOfDay();
//        org.joda.time.DateTime.Property property24 = dateTime21.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime26 = dateTime21.toDateTime((org.joda.time.Chronology) buddhistChronology25);
//        org.joda.time.ReadableDateTime readableDateTime27 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology28);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology28);
//        org.joda.time.DateTime dateTime32 = dateTime30.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology33 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology25, readableDateTime27, (org.joda.time.ReadableDateTime) dateTime30);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology34);
//        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology34);
//        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology34.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField39 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37, dateTimeFieldType38);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology33, (org.joda.time.DateTimeField) delegatedDateTimeField39);
//        java.lang.String str42 = skipDateTimeField40.getAsText(0L);
//        int int43 = skipDateTimeField40.getMinimumValue();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone48 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
//        long long51 = fixedDateTimeZone48.convertLocalToUTC((long) (-1), false);
//        org.joda.time.MutableDateTime mutableDateTime52 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone48);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder53.appendTwoDigitWeekyear((int) (short) 100);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology56 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology56);
//        org.joda.time.DateTime.Property property58 = dateTime57.secondOfMinute();
//        org.joda.time.DateTime dateTime60 = property58.addToCopy(100);
//        org.joda.time.DateTime dateTime62 = property58.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType63 = property58.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException66 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType63, (java.lang.Number) 0.0d, "26");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder53.appendFixedDecimal(dateTimeFieldType63, 12);
//        int int69 = mutableDateTime52.get(dateTimeFieldType63);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField40, dateTimeFieldType63, (-28800000));
//        int int72 = offsetDateTimeField71.getMinimumValue();
//        int int75 = offsetDateTimeField71.getDifference((long) 50, 0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology76 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime77 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology76);
//        org.joda.time.DateTime.Property property78 = dateTime77.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay79 = dateTime77.toTimeOfDay();
//        org.joda.time.DateTime.Property property80 = dateTime77.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology81 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime82 = dateTime77.toDateTime((org.joda.time.Chronology) buddhistChronology81);
//        org.joda.time.TimeOfDay timeOfDay83 = dateTime77.toTimeOfDay();
//        java.util.Locale locale84 = null;
//        java.lang.String str85 = offsetDateTimeField71.getAsShortText((org.joda.time.ReadablePartial) timeOfDay83, locale84);
//        int[] intArray87 = null;
//        int[] intArray89 = delegatedDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay83, 4, intArray87, 0);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) delegatedDateTimeField5, 0, 0, (-18));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year must be in the range [0,-18]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(timeOfDay9);
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "year" + "'", str16.equals("year"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2513" + "'", str19.equals("2513"));
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(timeOfDay23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(buddhistChronology25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(buddhistChronology28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(limitChronology33);
//        org.junit.Assert.assertNotNull(buddhistChronology34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "2513" + "'", str42.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-292268512) + "'", int43 == (-292268512));
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-60L) + "'", long51 == (-60L));
//        org.junit.Assert.assertNotNull(mutableDateTime52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
//        org.junit.Assert.assertNotNull(buddhistChronology56);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(dateTimeFieldType63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 48 + "'", int69 == 48);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-321068512) + "'", int72 == (-321068512));
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology76);
//        org.junit.Assert.assertNotNull(property78);
//        org.junit.Assert.assertNotNull(timeOfDay79);
//        org.junit.Assert.assertNotNull(property80);
//        org.junit.Assert.assertNotNull(buddhistChronology81);
//        org.junit.Assert.assertNotNull(dateTime82);
//        org.junit.Assert.assertNotNull(timeOfDay83);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "48" + "'", str85.equals("48"));
//        org.junit.Assert.assertNull(intArray89);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendDayOfWeek(24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatter15.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder14.append(dateTimePrinter17, dateTimeParser19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter22.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter24 = dateTimeFormatter22.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser26 = dateTimeFormatter25.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder21.append(dateTimePrinter24, dateTimeParser26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder27.appendTimeZoneId();
        boolean boolean29 = dateTimeFormatterBuilder28.canBuildParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser31 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter32 = dateTimeFormatter30.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser35 = dateTimeFormatter34.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter36 = dateTimeFormatter34.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser38 = dateTimeFormatter37.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder33.append(dateTimePrinter36, dateTimeParser38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder28.append(dateTimePrinter32, dateTimeParser38);
        org.joda.time.format.DateTimePrinter dateTimePrinter41 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser43 = dateTimeFormatter42.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter41, dateTimeParser43);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser47 = dateTimeFormatter46.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter48 = dateTimeFormatter46.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser50 = dateTimeFormatter49.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder45.append(dateTimePrinter48, dateTimeParser50);
        org.joda.time.format.DateTimeParser dateTimeParser52 = dateTimeFormatterBuilder51.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser55 = dateTimeFormatter54.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter56 = dateTimeFormatter54.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser58 = dateTimeFormatter57.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder53.append(dateTimePrinter56, dateTimeParser58);
        org.joda.time.format.DateTimePrinter dateTimePrinter60 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser62 = dateTimeFormatter61.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter63 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter60, dateTimeParser62);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray64 = new org.joda.time.format.DateTimeParser[] { dateTimeParser19, dateTimeParser38, dateTimeParser43, dateTimeParser52, dateTimeParser58, dateTimeParser62 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder6.append(dateTimePrinter13, dateTimeParserArray64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear(46203108, true);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimePrinter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimePrinter24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeParser26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeParser31);
        org.junit.Assert.assertNotNull(dateTimePrinter32);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeParser35);
        org.junit.Assert.assertNotNull(dateTimePrinter36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimeParser38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(dateTimeParser43);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(dateTimeParser47);
        org.junit.Assert.assertNotNull(dateTimePrinter48);
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
        org.junit.Assert.assertNotNull(dateTimeParser50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeParser52);
        org.junit.Assert.assertNotNull(dateTimeFormatter54);
        org.junit.Assert.assertNotNull(dateTimeParser55);
        org.junit.Assert.assertNotNull(dateTimePrinter56);
        org.junit.Assert.assertNotNull(dateTimeFormatter57);
        org.junit.Assert.assertNotNull(dateTimeParser58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatter61);
        org.junit.Assert.assertNotNull(dateTimeParser62);
        org.junit.Assert.assertNotNull(dateTimeParserArray64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendMillisOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendDayOfMonth(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2562-163T12:49:27Z");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay5 = dateTime3.toTimeOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfYear();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime3);
        org.joda.time.DateTime.Property property8 = dateTime3.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime3.withMillisOfDay(0);
        org.joda.time.DateTime dateTime11 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime13 = dateTime3.plusMonths(42);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(timeOfDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.minus((long) '4');
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.minusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime9 = dateTime8.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime8.minusYears((int) (byte) 100);
//        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long17 = buddhistChronology13.add((-1L), 100L, (int) 'a');
//        org.joda.time.DateTime dateTime18 = dateTime8.withChronology((org.joda.time.Chronology) buddhistChronology13);
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology13.weekyear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2562-163T12:50:48Z" + "'", str6.equals("2562-163T12:50:48Z"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560343848792L + "'", long12 == 1560343848792L);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9699L + "'", long17 == 9699L);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.era();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFractionOfHour(55, 45);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.ReadableDateTime readableDateTime7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology5, readableDateTime7, (org.joda.time.ReadableDateTime) dateTime10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField19);
//        java.lang.String str21 = limitChronology13.toString();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology22);
//        org.joda.time.DateTime.Property property24 = dateTime23.secondOfMinute();
//        org.joda.time.DateTime dateTime26 = property24.addToCopy(100);
//        org.joda.time.DateTime dateTime28 = property24.setCopy("30");
//        org.joda.time.format.DateTimePrinter dateTimePrinter29 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        org.joda.time.format.DateTimeParser dateTimeParser31 = dateTimeFormatter30.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter29, dateTimeParser31);
//        boolean boolean33 = property24.equals((java.lang.Object) dateTimePrinter29);
//        org.joda.time.DateTime dateTime34 = property24.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime36 = dateTime34.plusMinutes(22);
//        boolean boolean37 = limitChronology13.equals((java.lang.Object) dateTime34);
//        org.joda.time.Chronology chronology38 = limitChronology13.withUTC();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "LimitChronology[BuddhistChronology[UTC], NoLimit, 2562-06-12T12:50:48.940Z]" + "'", str21.equals("LimitChronology[BuddhistChronology[UTC], NoLimit, 2562-06-12T12:50:48.940Z]"));
//        org.junit.Assert.assertNotNull(buddhistChronology22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(dateTimeParser31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(chronology38);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.TimeOfDay timeOfDay7 = dateTime1.toTimeOfDay();
        org.joda.time.DateTime dateTime9 = dateTime1.withCenturyOfEra(6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfMinute();
        org.joda.time.DateTime dateTime14 = property12.addToCopy(100);
        org.joda.time.DateTime dateTime16 = property12.setCopy("30");
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) 0.0d, "26");
        org.joda.time.DateTime.Property property21 = dateTime9.property(dateTimeFieldType17);
        org.joda.time.DateTime dateTime22 = property21.roundFloorCopy();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime22);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) '4');
//        org.joda.time.DateTime dateTime6 = dateTime2.plus((long) (short) 10);
//        org.joda.time.DateTime.Property property7 = dateTime2.weekOfWeekyear();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsText(locale8);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "24" + "'", str9.equals("24"));
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 2562);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210645403200000L) + "'", long1 == (-210645403200000L));
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.ReadableDateTime readableDateTime7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology5, readableDateTime7, (org.joda.time.ReadableDateTime) dateTime10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField19);
//        java.lang.String str22 = skipDateTimeField20.getAsText(0L);
//        int int23 = skipDateTimeField20.getMinimumValue();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
//        long long31 = fixedDateTimeZone28.convertLocalToUTC((long) (-1), false);
//        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendTwoDigitWeekyear((int) (short) 100);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology36);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
//        org.joda.time.DateTime dateTime40 = property38.addToCopy(100);
//        org.joda.time.DateTime dateTime42 = property38.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property38.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 0.0d, "26");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType43, 12);
//        int int49 = mutableDateTime32.get(dateTimeFieldType43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField20, dateTimeFieldType43, (-28800000));
//        org.joda.time.chrono.BuddhistChronology buddhistChronology52 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology52);
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology52);
//        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology52.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField55, dateTimeFieldType56);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology58);
//        org.joda.time.DateTime.Property property60 = dateTime59.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay61 = dateTime59.toTimeOfDay();
//        int[] intArray65 = new int[] { 4, (short) 100 };
//        int[] intArray67 = delegatedDateTimeField57.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay61, 99, intArray65, (int) (byte) 0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology68 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology68);
//        org.joda.time.DateTime dateTime70 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology68);
//        org.joda.time.TimeOfDay timeOfDay71 = dateTime70.toTimeOfDay();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology72 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology72);
//        org.joda.time.DateTime dateTime74 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology72);
//        org.joda.time.DateTimeField dateTimeField75 = buddhistChronology72.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField77 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField75, dateTimeFieldType76);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology78 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime79 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology78);
//        org.joda.time.DateTime.Property property80 = dateTime79.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay81 = dateTime79.toTimeOfDay();
//        int[] intArray85 = new int[] { 4, (short) 100 };
//        int[] intArray87 = delegatedDateTimeField77.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay81, 99, intArray85, (int) (byte) 0);
//        int int88 = delegatedDateTimeField57.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay71, intArray85);
//        java.util.Locale locale90 = null;
//        java.lang.String str91 = offsetDateTimeField51.getAsShortText((org.joda.time.ReadablePartial) timeOfDay71, 46290, locale90);
//        int int93 = offsetDateTimeField51.getLeapAmount((long) (short) 100);
//        long long96 = offsetDateTimeField51.add((long) 2307, 45);
//        java.util.Locale locale98 = null;
//        java.lang.String str99 = offsetDateTimeField51.getAsShortText(9, locale98);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2513" + "'", str22.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292268512) + "'", int23 == (-292268512));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-60L) + "'", long31 == (-60L));
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 49 + "'", int49 == 49);
//        org.junit.Assert.assertNotNull(buddhistChronology52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(buddhistChronology58);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(timeOfDay61);
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertNotNull(intArray67);
//        org.junit.Assert.assertNotNull(buddhistChronology68);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(timeOfDay71);
//        org.junit.Assert.assertNotNull(buddhistChronology72);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertNotNull(buddhistChronology78);
//        org.junit.Assert.assertNotNull(property80);
//        org.junit.Assert.assertNotNull(timeOfDay81);
//        org.junit.Assert.assertNotNull(intArray85);
//        org.junit.Assert.assertNotNull(intArray87);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 292279536 + "'", int88 == 292279536);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "46290" + "'", str91.equals("46290"));
//        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
//        org.junit.Assert.assertTrue("'" + long96 + "' != '" + 1420070402307L + "'", long96 == 1420070402307L);
//        org.junit.Assert.assertTrue("'" + str99 + "' != '" + "9" + "'", str99.equals("9"));
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology1.centuryOfEra();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) 12, (org.joda.time.Chronology) buddhistChronology1, locale6, (java.lang.Integer) 9);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime4 = dateTime3.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property2.addToCopy(100);
        org.joda.time.DateTime dateTime6 = property2.setCopy("30");
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter7, dateTimeParser9);
        boolean boolean11 = property2.equals((java.lang.Object) dateTimePrinter7);
        org.joda.time.DateTime dateTime12 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime14 = dateTime12.plusMinutes(22);
        org.joda.time.DateTime dateTime16 = dateTime12.plusHours(2000);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        boolean boolean6 = mutableDateTime4.isEqual(readableInstant5);
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology7.getZone();
//        mutableDateTime4.setZoneRetainFields(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone(dateTimeZone8);
//        java.lang.Appendable appendable11 = null;
//        try {
//            dateTimeFormatter10.printTo(appendable11, (long) 22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long7 = buddhistChronology3.add((-1L), 100L, (int) 'a');
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology3.millisOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8);
        org.joda.time.DurationField durationField10 = buddhistChronology0.days();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9699L + "'", long7 == 9699L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("2562-163T12:50:48Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2562-163T12:50:48Z\" is malformed at \"3T12:50:48Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime3.getRoundingField();
//        mutableDateTime3.addWeekyears((int) (byte) -1);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNull(dateTimeField7);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long9 = buddhistChronology5.add((-1L), 100L, (int) 'a');
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology5.millisOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField10, (int) (byte) -1);
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket(9223371985593602562L, (org.joda.time.Chronology) gJChronology1, locale14);
        long long19 = gJChronology1.add((long) 6, (long) 58, 2562);
        org.joda.time.Chronology chronology20 = gJChronology1.withUTC();
        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology1);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9699L + "'", long9 == 9699L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 148602L + "'", long19 == 148602L);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime3.getRoundingField();
//        mutableDateTime3.addMinutes(10);
//        mutableDateTime3.setWeekyear((int) '#');
//        boolean boolean12 = mutableDateTime3.isEqualNow();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2562-06-12T12:49:47.317Z");
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay9 = dateTime7.toTimeOfDay();
        int[] intArray13 = new int[] { 4, (short) 100 };
        int[] intArray15 = delegatedDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay9, 99, intArray13, (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay19 = dateTime17.toTimeOfDay();
        org.joda.time.DateTime.Property property20 = dateTime17.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime22 = dateTime17.toDateTime((org.joda.time.Chronology) buddhistChronology21);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime17.toTimeOfDay();
        int int24 = delegatedDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay23);
        java.util.Locale locale26 = null;
        java.lang.String str27 = delegatedDateTimeField5.getAsText((long) 'a', locale26);
        org.joda.time.DurationField durationField28 = delegatedDateTimeField5.getRangeDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(timeOfDay9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(timeOfDay19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2513" + "'", str27.equals("2513"));
        org.junit.Assert.assertNull(durationField28);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "2562-163T12:49:30Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime3.getRoundingField();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        boolean boolean13 = mutableDateTime11.isEqual(readableInstant12);
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
//        mutableDateTime11.setZoneRetainFields(dateTimeZone15);
//        mutableDateTime3.setZone(dateTimeZone15);
//        mutableDateTime3.setYear((-1));
//        org.joda.time.MutableDateTime.Property property20 = mutableDateTime3.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime22 = property20.addWrapField(0);
//        org.joda.time.DateTimeField dateTimeField23 = property20.getField();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths((int) ' ');
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology5, readableDateTime7, (org.joda.time.ReadableDateTime) dateTime10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField19);
        org.joda.time.DateTime dateTime21 = limitChronology13.getUpperLimit();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField6 = julianChronology5.halfdays();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology5, locale7, (java.lang.Integer) (-28800000));
        org.joda.time.Instant instant11 = new org.joda.time.Instant((long) 1);
        org.joda.time.Instant instant13 = instant11.minus((long) 6);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Instant instant15 = instant11.plus(readableDuration14);
        boolean boolean16 = dateTimeParserBucket9.restoreState((java.lang.Object) instant11);
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) instant11);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(chronology17);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
//        mutableDateTime3.setZoneRetainFields(dateTimeZone7);
//        int int10 = dateTimeZone7.getOffsetFromLocal((long) ' ');
//        int int12 = dateTimeZone7.getOffsetFromLocal((-604799997L));
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        long long16 = cachedDateTimeZone13.adjustOffset((long) (short) 1, false);
//        int int18 = cachedDateTimeZone13.getOffset((long) (short) 0);
//        int int20 = cachedDateTimeZone13.getOffset((long) 5);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 59 + "'", int18 == 59);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 59 + "'", int20 == 59);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long7 = buddhistChronology3.add((-1L), 100L, (int) 'a');
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology3.millisOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8);
        boolean boolean10 = skipDateTimeField9.isSupported();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9699L + "'", long7 == 9699L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = property2.roundHalfEvenCopy();
//        org.joda.time.DateTimeField dateTimeField4 = property2.getField();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime7.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        boolean boolean10 = mutableDateTime8.isEqual(readableInstant9);
//        java.util.GregorianCalendar gregorianCalendar11 = mutableDateTime8.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField12 = mutableDateTime8.getRoundingField();
//        mutableDateTime8.addMinutes(10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology15);
//        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
//        org.joda.time.DateTime dateTime19 = property17.addToCopy(100);
//        org.joda.time.DateTime dateTime21 = property17.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property17.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 0.0d, "26");
//        org.joda.time.MutableDateTime.Property property26 = mutableDateTime8.property(dateTimeFieldType22);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType22, 8, 6, 45);
//        java.lang.String str31 = offsetDateTimeField30.getName();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar11);
//        org.junit.Assert.assertNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "secondOfMinute" + "'", str31.equals("secondOfMinute"));
//    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.ReadableDateTime readableDateTime7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology5, readableDateTime7, (org.joda.time.ReadableDateTime) dateTime10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField19);
//        java.lang.String str22 = skipDateTimeField20.getAsText(0L);
//        int int23 = skipDateTimeField20.getMinimumValue();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
//        long long31 = fixedDateTimeZone28.convertLocalToUTC((long) (-1), false);
//        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendTwoDigitWeekyear((int) (short) 100);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology36);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
//        org.joda.time.DateTime dateTime40 = property38.addToCopy(100);
//        org.joda.time.DateTime dateTime42 = property38.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property38.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 0.0d, "26");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType43, 12);
//        int int49 = mutableDateTime32.get(dateTimeFieldType43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField20, dateTimeFieldType43, (-28800000));
//        org.joda.time.chrono.BuddhistChronology buddhistChronology52 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology52);
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology52);
//        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology52.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField55, dateTimeFieldType56);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology58);
//        org.joda.time.DateTime.Property property60 = dateTime59.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay61 = dateTime59.toTimeOfDay();
//        int[] intArray65 = new int[] { 4, (short) 100 };
//        int[] intArray67 = delegatedDateTimeField57.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay61, 99, intArray65, (int) (byte) 0);
//        java.util.Locale locale68 = null;
//        java.lang.String str69 = offsetDateTimeField51.getAsShortText((org.joda.time.ReadablePartial) timeOfDay61, locale68);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology71 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime72 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology71);
//        org.joda.time.DateTime.Property property73 = dateTime72.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay74 = dateTime72.toTimeOfDay();
//        org.joda.time.DateTime.Property property75 = dateTime72.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology76 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime77 = dateTime72.toDateTime((org.joda.time.Chronology) buddhistChronology76);
//        org.joda.time.TimeOfDay timeOfDay78 = dateTime72.toTimeOfDay();
//        java.lang.String str79 = dateTimeFormatter70.print((org.joda.time.ReadablePartial) timeOfDay78);
//        int int80 = offsetDateTimeField51.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay78);
//        int int82 = offsetDateTimeField51.getLeapAmount((long) 23);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2513" + "'", str22.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292268512) + "'", int23 == (-292268512));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-60L) + "'", long31 == (-60L));
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 51 + "'", int49 == 51);
//        org.junit.Assert.assertNotNull(buddhistChronology52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(buddhistChronology58);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(timeOfDay61);
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertNotNull(intArray67);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "51" + "'", str69.equals("51"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter70);
//        org.junit.Assert.assertNotNull(buddhistChronology71);
//        org.junit.Assert.assertNotNull(property73);
//        org.junit.Assert.assertNotNull(timeOfDay74);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNotNull(buddhistChronology76);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(timeOfDay78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "����-��-��T12:50:51.548" + "'", str79.equals("����-��-��T12:50:51.548"));
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 263479536 + "'", int80 == 263479536);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long7 = buddhistChronology3.add((-1L), 100L, (int) 'a');
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology3.millisOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8);
        int int11 = skipDateTimeField9.get((long) 29);
        java.util.Locale locale14 = null;
        long long15 = skipDateTimeField9.set((long) 100, "52", locale14);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9699L + "'", long7 == 9699L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 29 + "'", int11 == 29);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 52L + "'", long15 == 52L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
        try {
            org.joda.time.DateTime dateTime11 = dateTime1.withTime((-321068512), 50, 22, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -321068512 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 1);
        org.joda.time.Instant instant3 = instant1.minus((long) 6);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant1.plus(readableDuration4);
        org.joda.time.DateTime dateTime6 = instant5.toDateTimeISO();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.minus((long) '4');
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.minusMillis((int) (byte) 10);
//        org.joda.time.Instant instant9 = dateTime5.toInstant();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2562-163T12:50:53Z" + "'", str6.equals("2562-163T12:50:53Z"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(instant9);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatter9.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter15 = dateTimeFormatter13.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.append(dateTimePrinter15, dateTimeParser17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder7.append(dateTimePrinter11, dateTimeParser17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder7.appendMinuteOfDay((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimePrinter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimePrinter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendDayOfWeek(59);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.append(dateTimePrinter13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendFractionOfDay(12, 55);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder14.appendTwoDigitYear(43);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay6 = dateTime4.toTimeOfDay();
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime9 = dateTime4.toDateTime((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.TimeOfDay timeOfDay10 = dateTime4.toTimeOfDay();
        org.joda.time.DateTime dateTime12 = dateTime4.withCenturyOfEra(6);
        int int13 = property2.compareTo((org.joda.time.ReadableInstant) dateTime12);
        try {
            org.joda.time.DateTime dateTime18 = dateTime12.withTime(21, 292279536, 6, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279536 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(timeOfDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(timeOfDay10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.minus((long) '4');
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.minusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime10 = dateTime8.withMillis((-2L));
//        int int11 = dateTime10.getSecondOfDay();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2562-163T12:50:53Z" + "'", str6.equals("2562-163T12:50:53Z"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 86399 + "'", int11 == 86399);
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime3.getRoundingField();
//        mutableDateTime3.addMinutes(10);
//        org.joda.time.DateTime dateTime10 = mutableDateTime3.toDateTimeISO();
//        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime3.copy();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        mutableDateTime3.setZoneRetainFields(dateTimeZone12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        mutableDateTime3.add(readablePeriod14);
//        org.joda.time.MutableDateTime mutableDateTime16 = mutableDateTime3.toMutableDateTime();
//        mutableDateTime16.setSecondOfDay(0);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long9 = buddhistChronology5.add((-1L), 100L, (int) 'a');
//        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology5.millisOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField10);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField10, (int) (byte) -1);
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
//        java.lang.String str17 = dateTimeZone15.getName(0L);
//        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now(dateTimeZone15);
//        long long21 = dateTimeZone15.convertLocalToUTC((long) ' ', true);
//        org.joda.time.Chronology chronology22 = gJChronology1.withZone(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology1.getZone();
//        org.joda.time.Chronology chronology24 = gJChronology1.withUTC();
//        java.util.Locale locale25 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology1, locale25);
//        dateTimeParserBucket26.setPivotYear((java.lang.Integer) 75);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9699L + "'", long9 == 9699L);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.059" + "'", str17.equals("+00:00:00.059"));
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-27L) + "'", long21 == (-27L));
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(chronology24);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("51");
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long8 = buddhistChronology4.add((-1L), 100L, (int) 'a');
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology4.millisOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField9);
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField9, (int) (byte) -1);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField12.getMaximumTextLength(locale13);
        long long17 = skipDateTimeField12.add((long) (byte) 0, (int) ' ');
        int int19 = skipDateTimeField12.get((long) 55);
        int int21 = skipDateTimeField12.get(908760915014400001L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9699L + "'", long8 == 9699L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 32L + "'", long17 == 32L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 55 + "'", int19 == 55);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 1);
        org.joda.time.Instant instant3 = instant1.minus((long) 6);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant1.plus(readableDuration4);
        org.joda.time.Instant instant8 = instant1.withDurationAdded((long) 12, 0);
        org.joda.time.Instant instant10 = instant1.minus((long) (byte) 0);
        org.joda.time.DateTime dateTime11 = instant10.toDateTimeISO();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long4 = buddhistChronology0.add((-1L), 100L, (int) 'a');
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology0.millisOfDay();
        org.joda.time.DurationField durationField6 = buddhistChronology0.weekyears();
        org.joda.time.DurationField durationField7 = buddhistChronology0.days();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9699L + "'", long4 == 9699L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsShortText(locale8);
//        org.joda.time.DateTime dateTime10 = property7.roundFloorCopy();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46254" + "'", str9.equals("46254"));
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.ReadableDateTime readableDateTime7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology5, readableDateTime7, (org.joda.time.ReadableDateTime) dateTime10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField19);
//        java.lang.String str22 = skipDateTimeField20.getAsText(0L);
//        int int23 = skipDateTimeField20.getMinimumValue();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
//        long long31 = fixedDateTimeZone28.convertLocalToUTC((long) (-1), false);
//        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendTwoDigitWeekyear((int) (short) 100);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology36);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
//        org.joda.time.DateTime dateTime40 = property38.addToCopy(100);
//        org.joda.time.DateTime dateTime42 = property38.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property38.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 0.0d, "26");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType43, 12);
//        int int49 = mutableDateTime32.get(dateTimeFieldType43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField20, dateTimeFieldType43, (-28800000));
//        org.joda.time.chrono.BuddhistChronology buddhistChronology52 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology52);
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology52);
//        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology52.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField55, dateTimeFieldType56);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology58);
//        org.joda.time.DateTime.Property property60 = dateTime59.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay61 = dateTime59.toTimeOfDay();
//        int[] intArray65 = new int[] { 4, (short) 100 };
//        int[] intArray67 = delegatedDateTimeField57.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay61, 99, intArray65, (int) (byte) 0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology68 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology68);
//        org.joda.time.DateTime dateTime70 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology68);
//        org.joda.time.TimeOfDay timeOfDay71 = dateTime70.toTimeOfDay();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology72 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology72);
//        org.joda.time.DateTime dateTime74 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology72);
//        org.joda.time.DateTimeField dateTimeField75 = buddhistChronology72.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField77 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField75, dateTimeFieldType76);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology78 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime79 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology78);
//        org.joda.time.DateTime.Property property80 = dateTime79.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay81 = dateTime79.toTimeOfDay();
//        int[] intArray85 = new int[] { 4, (short) 100 };
//        int[] intArray87 = delegatedDateTimeField77.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay81, 99, intArray85, (int) (byte) 0);
//        int int88 = delegatedDateTimeField57.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay71, intArray85);
//        java.util.Locale locale90 = null;
//        java.lang.String str91 = offsetDateTimeField51.getAsShortText((org.joda.time.ReadablePartial) timeOfDay71, 46290, locale90);
//        long long94 = offsetDateTimeField51.add(0L, (long) '4');
//        long long97 = offsetDateTimeField51.set((long) (byte) 100, (int) ' ');
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2513" + "'", str22.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292268512) + "'", int23 == (-292268512));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-60L) + "'", long31 == (-60L));
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 54 + "'", int49 == 54);
//        org.junit.Assert.assertNotNull(buddhistChronology52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(buddhistChronology58);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(timeOfDay61);
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertNotNull(intArray67);
//        org.junit.Assert.assertNotNull(buddhistChronology68);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(timeOfDay71);
//        org.junit.Assert.assertNotNull(buddhistChronology72);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertNotNull(buddhistChronology78);
//        org.junit.Assert.assertNotNull(property80);
//        org.junit.Assert.assertNotNull(timeOfDay81);
//        org.junit.Assert.assertNotNull(intArray85);
//        org.junit.Assert.assertNotNull(intArray87);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 292279536 + "'", int88 == 292279536);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "46290" + "'", str91.equals("46290"));
//        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 1640995200000L + "'", long94 == 1640995200000L);
//        org.junit.Assert.assertTrue("'" + long97 + "' != '" + 908761924857600100L + "'", long97 == 908761924857600100L);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser5);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMillisOfDay((int) (byte) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendWeekyear(0, (int) '#');
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime.Property property16 = dateTime15.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay17 = dateTime15.toTimeOfDay();
//        org.joda.time.DateTime.Property property18 = dateTime15.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime20 = dateTime15.toDateTime((org.joda.time.Chronology) buddhistChronology19);
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology22);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology22);
//        org.joda.time.DateTime dateTime26 = dateTime24.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology27 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology19, readableDateTime21, (org.joda.time.ReadableDateTime) dateTime24);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology28);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology28);
//        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology28.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31, dateTimeFieldType32);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology27, (org.joda.time.DateTimeField) delegatedDateTimeField33);
//        java.lang.String str36 = skipDateTimeField34.getAsText(0L);
//        int int37 = skipDateTimeField34.getMinimumValue();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone42 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
//        long long45 = fixedDateTimeZone42.convertLocalToUTC((long) (-1), false);
//        org.joda.time.MutableDateTime mutableDateTime46 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone42);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder47.appendTwoDigitWeekyear((int) (short) 100);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology50 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology50);
//        org.joda.time.DateTime.Property property52 = dateTime51.secondOfMinute();
//        org.joda.time.DateTime dateTime54 = property52.addToCopy(100);
//        org.joda.time.DateTime dateTime56 = property52.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property52.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException60 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, (java.lang.Number) 0.0d, "26");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder47.appendFixedDecimal(dateTimeFieldType57, 12);
//        int int63 = mutableDateTime46.get(dateTimeFieldType57);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField34, dateTimeFieldType57, (-28800000));
//        int int66 = offsetDateTimeField65.getMinimumValue();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology67 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology67);
//        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology67);
//        org.joda.time.DateTimeField dateTimeField70 = buddhistChronology67.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType71 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField70, dateTimeFieldType71);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology73 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology73);
//        org.joda.time.DateTime.Property property75 = dateTime74.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay76 = dateTime74.toTimeOfDay();
//        int[] intArray80 = new int[] { 4, (short) 100 };
//        int[] intArray82 = delegatedDateTimeField72.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay76, 99, intArray80, (int) (byte) 0);
//        int int83 = offsetDateTimeField65.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay76);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology84 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime85 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology84);
//        org.joda.time.DateTime dateTime86 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology84);
//        org.joda.time.MutableDateTime mutableDateTime87 = dateTime86.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant88 = null;
//        boolean boolean89 = mutableDateTime87.isEqual(readableInstant88);
//        java.util.GregorianCalendar gregorianCalendar90 = mutableDateTime87.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField91 = mutableDateTime87.getRoundingField();
//        mutableDateTime87.addMinutes(10);
//        org.joda.time.MutableDateTime.Property property94 = mutableDateTime87.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType95 = property94.getFieldType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField96 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField65, dateTimeFieldType95);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder98 = dateTimeFormatterBuilder10.appendFixedDecimal(dateTimeFieldType95, 42);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeParser2);
//        org.junit.Assert.assertNotNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeParser5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(timeOfDay17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(buddhistChronology19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(buddhistChronology22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(limitChronology27);
//        org.junit.Assert.assertNotNull(buddhistChronology28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2513" + "'", str36.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-292268512) + "'", int37 == (-292268512));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-60L) + "'", long45 == (-60L));
//        org.junit.Assert.assertNotNull(mutableDateTime46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(buddhistChronology50);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 54 + "'", int63 == 54);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-321068512) + "'", int66 == (-321068512));
//        org.junit.Assert.assertNotNull(buddhistChronology67);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(buddhistChronology73);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNotNull(timeOfDay76);
//        org.junit.Assert.assertNotNull(intArray80);
//        org.junit.Assert.assertNotNull(intArray82);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-321068512) + "'", int83 == (-321068512));
//        org.junit.Assert.assertNotNull(buddhistChronology84);
//        org.junit.Assert.assertNotNull(dateTime86);
//        org.junit.Assert.assertNotNull(mutableDateTime87);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
//        org.junit.Assert.assertNotNull(gregorianCalendar90);
//        org.junit.Assert.assertNull(dateTimeField91);
//        org.junit.Assert.assertNotNull(property94);
//        org.junit.Assert.assertNotNull(dateTimeFieldType95);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder98);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.ReadableDateTime readableDateTime7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology5, readableDateTime7, (org.joda.time.ReadableDateTime) dateTime10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField19);
//        java.lang.String str22 = skipDateTimeField20.getAsText(0L);
//        int int23 = skipDateTimeField20.getMinimumValue();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
//        long long31 = fixedDateTimeZone28.convertLocalToUTC((long) (-1), false);
//        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendTwoDigitWeekyear((int) (short) 100);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology36);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
//        org.joda.time.DateTime dateTime40 = property38.addToCopy(100);
//        org.joda.time.DateTime dateTime42 = property38.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property38.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 0.0d, "26");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType43, 12);
//        int int49 = mutableDateTime32.get(dateTimeFieldType43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField20, dateTimeFieldType43, (-28800000));
//        int int52 = offsetDateTimeField51.getMinimumValue();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology53);
//        org.joda.time.DateTime dateTime55 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology53);
//        org.joda.time.DateTimeField dateTimeField56 = buddhistChronology53.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField58 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField56, dateTimeFieldType57);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology59 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology59);
//        org.joda.time.DateTime.Property property61 = dateTime60.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay62 = dateTime60.toTimeOfDay();
//        int[] intArray66 = new int[] { 4, (short) 100 };
//        int[] intArray68 = delegatedDateTimeField58.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay62, 99, intArray66, (int) (byte) 0);
//        int int69 = offsetDateTimeField51.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay62);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology70 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology70);
//        org.joda.time.DateTime dateTime72 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology70);
//        org.joda.time.MutableDateTime mutableDateTime73 = dateTime72.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant74 = null;
//        boolean boolean75 = mutableDateTime73.isEqual(readableInstant74);
//        java.util.GregorianCalendar gregorianCalendar76 = mutableDateTime73.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField77 = mutableDateTime73.getRoundingField();
//        mutableDateTime73.addMinutes(10);
//        org.joda.time.MutableDateTime.Property property80 = mutableDateTime73.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType81 = property80.getFieldType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField82 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField51, dateTimeFieldType81);
//        long long84 = delegatedDateTimeField82.roundHalfEven((long) 263479536);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2513" + "'", str22.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292268512) + "'", int23 == (-292268512));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-60L) + "'", long31 == (-60L));
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 55 + "'", int49 == 55);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-321068512) + "'", int52 == (-321068512));
//        org.junit.Assert.assertNotNull(buddhistChronology53);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(buddhistChronology59);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(timeOfDay62);
//        org.junit.Assert.assertNotNull(intArray66);
//        org.junit.Assert.assertNotNull(intArray68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-321068512) + "'", int69 == (-321068512));
//        org.junit.Assert.assertNotNull(buddhistChronology70);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(mutableDateTime73);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
//        org.junit.Assert.assertNotNull(gregorianCalendar76);
//        org.junit.Assert.assertNull(dateTimeField77);
//        org.junit.Assert.assertNotNull(property80);
//        org.junit.Assert.assertNotNull(dateTimeFieldType81);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 0L + "'", long84 == 0L);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long9 = buddhistChronology5.add((-1L), 100L, (int) 'a');
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology5.millisOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField10, (int) (byte) -1);
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket(9223371985593602562L, (org.joda.time.Chronology) gJChronology1, locale14);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        org.joda.time.DateTime dateTime19 = property18.roundHalfEvenCopy();
        org.joda.time.DateTimeField dateTimeField20 = property18.getField();
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology21);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology21);
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime23.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant25 = null;
        boolean boolean26 = mutableDateTime24.isEqual(readableInstant25);
        java.util.GregorianCalendar gregorianCalendar27 = mutableDateTime24.toGregorianCalendar();
        org.joda.time.DateTimeField dateTimeField28 = mutableDateTime24.getRoundingField();
        mutableDateTime24.addMinutes(10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.secondOfMinute();
        org.joda.time.DateTime dateTime35 = property33.addToCopy(100);
        org.joda.time.DateTime dateTime37 = property33.setCopy("30");
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 0.0d, "26");
        org.joda.time.MutableDateTime.Property property42 = mutableDateTime24.property(dateTimeFieldType38);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, dateTimeFieldType38, 8, 6, 45);
        dateTimeParserBucket15.saveField((org.joda.time.DateTimeField) offsetDateTimeField46, (int) (byte) 1);
        int int49 = offsetDateTimeField46.getMaximumValue();
        try {
            org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((java.lang.Object) int49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9699L + "'", long9 == 9699L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar27);
        org.junit.Assert.assertNull(dateTimeField28);
        org.junit.Assert.assertNotNull(buddhistChronology31);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 45 + "'", int49 == 45);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.lang.String str1 = julianChronology0.toString();
//        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.millisOfSecond();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[2562-163T12:49:30Z]" + "'", str1.equals("JulianChronology[2562-163T12:49:30Z]"));
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.ReadableDateTime readableDateTime7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology5, readableDateTime7, (org.joda.time.ReadableDateTime) dateTime10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField19);
//        java.lang.String str22 = skipDateTimeField20.getAsText(0L);
//        int int23 = skipDateTimeField20.getMinimumValue();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
//        long long31 = fixedDateTimeZone28.convertLocalToUTC((long) (-1), false);
//        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendTwoDigitWeekyear((int) (short) 100);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology36);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
//        org.joda.time.DateTime dateTime40 = property38.addToCopy(100);
//        org.joda.time.DateTime dateTime42 = property38.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property38.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 0.0d, "26");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType43, 12);
//        int int49 = mutableDateTime32.get(dateTimeFieldType43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField20, dateTimeFieldType43, (-28800000));
//        java.util.Locale locale52 = null;
//        int int53 = offsetDateTimeField51.getMaximumShortTextLength(locale52);
//        java.lang.String str55 = offsetDateTimeField51.getAsShortText(1544282L);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2513" + "'", str22.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292268512) + "'", int23 == (-292268512));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-60L) + "'", long31 == (-60L));
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 56 + "'", int49 == 56);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 9 + "'", int53 == 9);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "-28797487" + "'", str55.equals("-28797487"));
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long9 = buddhistChronology5.add((-1L), 100L, (int) 'a');
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology5.millisOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField10, (int) (byte) -1);
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket(9223371985593602562L, (org.joda.time.Chronology) gJChronology1, locale14);
        long long19 = gJChronology1.add((long) 6, (long) 58, 2562);
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology1.getZone();
        org.joda.time.DurationField durationField21 = gJChronology1.halfdays();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9699L + "'", long9 == 9699L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 148602L + "'", long19 == 148602L);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(durationField21);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        boolean boolean9 = mutableDateTime7.isEqual(readableInstant8);
//        boolean boolean10 = dateTime1.isAfter((org.joda.time.ReadableInstant) mutableDateTime7);
//        mutableDateTime7.setTime((long) (short) 100);
//        mutableDateTime7.setMillisOfDay((int) (short) 0);
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime7.monthOfYear();
//        boolean boolean16 = mutableDateTime7.isBeforeNow();
//        try {
//            mutableDateTime7.setDate(29, 0, (-292268511));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendMillisOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendDayOfMonth(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder6.appendHourOfHalfday(52);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        java.io.Writer writer3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime5.toTimeOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime10 = dateTime5.toDateTime((org.joda.time.Chronology) buddhistChronology9);
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology12);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology12);
        org.joda.time.DateTime dateTime16 = dateTime14.plusMonths((int) ' ');
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology9, readableDateTime11, (org.joda.time.ReadableDateTime) dateTime14);
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology18);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology18);
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology18.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, dateTimeFieldType22);
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology17, (org.joda.time.DateTimeField) delegatedDateTimeField23);
        org.joda.time.Chronology chronology25 = limitChronology17.withUTC();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(chronology25);
        try {
            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadableInstant) dateTime26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology25);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
//        boolean boolean2 = dateTimeFormatter0.isPrinter();
//        java.io.Writer writer3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        boolean boolean9 = mutableDateTime7.isEqual(readableInstant8);
//        java.util.GregorianCalendar gregorianCalendar10 = mutableDateTime7.toGregorianCalendar();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime7.monthOfYear();
//        mutableDateTime7.addHours((int) (byte) 10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime.Property property16 = dateTime15.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay17 = dateTime15.toTimeOfDay();
//        org.joda.time.DateTime.Property property18 = dateTime15.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime20 = dateTime15.toDateTime((org.joda.time.Chronology) buddhistChronology19);
//        org.joda.time.DateTime.Property property21 = dateTime20.secondOfDay();
//        org.joda.time.DateTime dateTime23 = dateTime20.minusMillis(1);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = julianChronology24.millisOfDay();
//        org.joda.time.DurationField durationField26 = julianChronology24.weeks();
//        org.joda.time.DateTime dateTime27 = dateTime20.toDateTime((org.joda.time.Chronology) julianChronology24);
//        boolean boolean28 = mutableDateTime7.isEqual((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.LocalTime localTime29 = dateTime27.toLocalTime();
//        try {
//            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadablePartial) localTime29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(locale1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(timeOfDay17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(buddhistChronology19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(localTime29);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 55L, (java.lang.Number) (byte) 1, (java.lang.Number) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.minus((long) '4');
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.minusMillis((int) (byte) 10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology9);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime11.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        boolean boolean14 = mutableDateTime12.isEqual(readableInstant13);
//        java.util.GregorianCalendar gregorianCalendar15 = mutableDateTime12.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField16 = mutableDateTime12.getRoundingField();
//        mutableDateTime12.addMinutes(10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology19);
//        org.joda.time.DateTime.Property property21 = dateTime20.secondOfMinute();
//        org.joda.time.DateTime dateTime23 = property21.addToCopy(100);
//        org.joda.time.DateTime dateTime25 = property21.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property21.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) 0.0d, "26");
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime12.property(dateTimeFieldType26);
//        int int31 = dateTime8.get(dateTimeFieldType26);
//        org.joda.time.DateTime dateTime32 = dateTime8.toDateTimeISO();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2562-163T12:50:57Z" + "'", str6.equals("2562-163T12:50:57Z"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(gregorianCalendar15);
//        org.junit.Assert.assertNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(buddhistChronology19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 57 + "'", int31 == 57);
//        org.junit.Assert.assertNotNull(dateTime32);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        int int3 = property2.getMaximumValue();
//        org.joda.time.DateTime dateTime5 = property2.setCopy(0);
//        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withYear((int) (byte) 1);
//        int int9 = dateTime8.getDayOfWeek();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 59 + "'", int3 == 59);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(24);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder0.setStandardOffset(2512);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder0.addCutover(44, ' ', 27, 56, 62, false, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        boolean boolean9 = mutableDateTime7.isEqual(readableInstant8);
//        boolean boolean10 = dateTime1.isAfter((org.joda.time.ReadableInstant) mutableDateTime7);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.clockhourOfHalfday();
//        mutableDateTime7.setRounding(dateTimeField12, 0);
//        int int15 = mutableDateTime7.getDayOfMonth();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        int int3 = property2.getMaximumValue();
//        org.joda.time.DateTime dateTime5 = property2.setCopy(0);
//        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withYear((int) (byte) 1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology9);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay12 = dateTime10.toTimeOfDay();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology13);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        org.joda.time.MutableDateTime mutableDateTime16 = dateTime15.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant17 = null;
//        boolean boolean18 = mutableDateTime16.isEqual(readableInstant17);
//        boolean boolean19 = dateTime10.isAfter((org.joda.time.ReadableInstant) mutableDateTime16);
//        mutableDateTime16.addDays((int) (short) 100);
//        mutableDateTime16.addDays((int) (short) 0);
//        int int24 = dateTime8.compareTo((org.joda.time.ReadableInstant) mutableDateTime16);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 59 + "'", int3 == 59);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(timeOfDay12);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMillisOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendClockhourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatterBuilder6.toFormatter();
        org.joda.time.Chronology chronology10 = dateTimeFormatter9.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNull(chronology10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
        long long7 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), false);
        long long9 = fixedDateTimeZone4.nextTransition((long) (byte) 100);
        int int11 = fixedDateTimeZone4.getOffset((long) (byte) -1);
        long long13 = fixedDateTimeZone4.previousTransition((long) (byte) 0);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DurationField durationField15 = julianChronology14.millis();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
        long long23 = fixedDateTimeZone20.convertLocalToUTC((long) (-1), false);
        long long25 = fixedDateTimeZone20.nextTransition((long) (byte) 100);
        int int27 = fixedDateTimeZone20.getOffset((long) (byte) -1);
        org.joda.time.Chronology chronology28 = julianChronology14.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60L) + "'", long7 == (-60L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-60L) + "'", long23 == (-60L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 59 + "'", int27 == 59);
        org.junit.Assert.assertNotNull(chronology28);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.year();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((long) 1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology9);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime11.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        boolean boolean14 = mutableDateTime12.isEqual(readableInstant13);
//        java.util.GregorianCalendar gregorianCalendar15 = mutableDateTime12.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField16 = mutableDateTime12.getRoundingField();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology17);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology17);
//        org.joda.time.MutableDateTime mutableDateTime20 = dateTime19.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant21 = null;
//        boolean boolean22 = mutableDateTime20.isEqual(readableInstant21);
//        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology23.getZone();
//        mutableDateTime20.setZoneRetainFields(dateTimeZone24);
//        mutableDateTime12.setZone(dateTimeZone24);
//        mutableDateTime12.setYear((-1));
//        org.joda.time.MutableDateTime.Property property29 = mutableDateTime12.millisOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
//        long long37 = fixedDateTimeZone34.convertLocalToUTC((long) (-1), false);
//        org.joda.time.MutableDateTime mutableDateTime38 = mutableDateTime12.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone34);
//        mutableDateTime8.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone34);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone40 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone34);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(gregorianCalendar15);
//        org.junit.Assert.assertNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(julianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-60L) + "'", long37 == (-60L));
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone40);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.secondOfMinute();
        org.joda.time.Chronology chronology2 = gJChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTime dateTime6 = dateTime4.minus((long) '4');
//        java.lang.String str7 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime6);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.parse("29", dateTimeFormatter1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"29\" is too short");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2562-163T12:50:57Z" + "'", str7.equals("2562-163T12:50:57Z"));
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.ReadableDateTime readableDateTime7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology5, readableDateTime7, (org.joda.time.ReadableDateTime) dateTime10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField19);
//        java.lang.String str22 = skipDateTimeField20.getAsText(0L);
//        int int23 = skipDateTimeField20.getMinimumValue();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
//        long long31 = fixedDateTimeZone28.convertLocalToUTC((long) (-1), false);
//        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendTwoDigitWeekyear((int) (short) 100);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology36);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
//        org.joda.time.DateTime dateTime40 = property38.addToCopy(100);
//        org.joda.time.DateTime dateTime42 = property38.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property38.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 0.0d, "26");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType43, 12);
//        int int49 = mutableDateTime32.get(dateTimeFieldType43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField20, dateTimeFieldType43, (-28800000));
//        org.joda.time.chrono.BuddhistChronology buddhistChronology52 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology52);
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology52);
//        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology52.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField55, dateTimeFieldType56);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology58);
//        org.joda.time.DateTime.Property property60 = dateTime59.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay61 = dateTime59.toTimeOfDay();
//        int[] intArray65 = new int[] { 4, (short) 100 };
//        int[] intArray67 = delegatedDateTimeField57.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay61, 99, intArray65, (int) (byte) 0);
//        java.util.Locale locale68 = null;
//        java.lang.String str69 = offsetDateTimeField51.getAsShortText((org.joda.time.ReadablePartial) timeOfDay61, locale68);
//        org.joda.time.DateTimeField dateTimeField70 = offsetDateTimeField51.getWrappedField();
//        java.lang.String str71 = offsetDateTimeField51.toString();
//        java.lang.String str73 = offsetDateTimeField51.getAsShortText((long) 45);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2513" + "'", str22.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292268512) + "'", int23 == (-292268512));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-60L) + "'", long31 == (-60L));
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 58 + "'", int49 == 58);
//        org.junit.Assert.assertNotNull(buddhistChronology52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(buddhistChronology58);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(timeOfDay61);
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertNotNull(intArray67);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "58" + "'", str69.equals("58"));
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str71.equals("DateTimeField[secondOfMinute]"));
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "-28797487" + "'", str73.equals("-28797487"));
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) '4');
        int int5 = dateTime2.getYearOfCentury();
        org.joda.time.DateMidnight dateMidnight6 = dateTime2.toDateMidnight();
        try {
            org.joda.time.DateTime dateTime8 = dateTime2.withDayOfMonth((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 62 + "'", int5 == 62);
        org.junit.Assert.assertNotNull(dateMidnight6);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((-28800000));
        boolean boolean3 = dateTimeFormatter2.isPrinter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay8 = dateTime6.toTimeOfDay();
        org.joda.time.DateTime.Property property9 = dateTime6.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = dateTime6.toDateTime((org.joda.time.Chronology) buddhistChronology10);
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology13);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
        org.joda.time.DateTime dateTime17 = dateTime15.plusMonths((int) ' ');
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology10, readableDateTime12, (org.joda.time.ReadableDateTime) dateTime15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
        long long26 = fixedDateTimeZone23.convertLocalToUTC((long) (-1), false);
        org.joda.time.Chronology chronology27 = limitChronology18.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone23);
        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime(0L, (org.joda.time.DateTimeZone) fixedDateTimeZone23);
        java.lang.String str29 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) mutableDateTime28);
        try {
            mutableDateTime28.setTime(41, 86399, 6, 51);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 41 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(timeOfDay8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-60L) + "'", long26 == (-60L));
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970" + "'", str29.equals("1970"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long7 = buddhistChronology3.add((-1L), 100L, (int) 'a');
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology3.millisOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8);
        long long12 = skipDateTimeField9.getDifferenceAsLong((long) (byte) -1, (long) (byte) 1);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField9, 50);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9699L + "'", long7 == 9699L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2L) + "'", long12 == (-2L));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatterBuilder6.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendSecondOfDay(46);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.minus((long) '4');
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.minusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime10 = dateTime8.withMillis((-2L));
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
//        java.lang.String str14 = dateTimeZone12.getName(0L);
//        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        long long19 = dateTimeZone17.convertUTCToLocal((long) (-13));
//        org.joda.time.DateTime dateTime20 = dateTime8.withZoneRetainFields(dateTimeZone17);
//        org.joda.time.DateTime.Property property21 = dateTime8.dayOfWeek();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2562-163T12:50:58Z" + "'", str6.equals("2562-163T12:50:58Z"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.059" + "'", str14.equals("+00:00:00.059"));
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 46L + "'", long19 == 46L);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "26");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = buddhistChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.hourOfHalfday();
        boolean boolean5 = gregorianChronology1.equals((java.lang.Object) buddhistChronology2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology6);
        boolean boolean9 = gregorianChronology1.equals((java.lang.Object) dateTime8);
        try {
            long long17 = gregorianChronology1.getDateTimeMillis(12, (int) (byte) 1, 56, 4455, 39, (-1), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4455 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(24);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder0.setStandardOffset(2512);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeZoneBuilder0.toDateTimeZone("38", true);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 1);
        org.joda.time.Instant instant3 = instant1.minus((long) 6);
        org.joda.time.DateTime dateTime4 = instant1.toDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, 51);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime3.getRoundingField();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        boolean boolean13 = mutableDateTime11.isEqual(readableInstant12);
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
//        mutableDateTime11.setZoneRetainFields(dateTimeZone15);
//        mutableDateTime3.setZone(dateTimeZone15);
//        mutableDateTime3.setYear((-1));
//        org.joda.time.MutableDateTime.Property property20 = mutableDateTime3.millisOfSecond();
//        org.joda.time.Interval interval21 = property20.toInterval();
//        org.joda.time.ReadableInterval readableInterval22 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval21);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(interval21);
//        org.junit.Assert.assertNotNull(readableInterval22);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.yearOfCentury();
        int int10 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) julianChronology8);
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology8.getZone();
        boolean boolean15 = julianChronology8.equals((java.lang.Object) 2440587.500000035d);
        try {
            org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(39, (-13), 21, 100, 28, 7, 4, (org.joda.time.Chronology) julianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        int int3 = gJChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        boolean boolean9 = mutableDateTime7.isEqual(readableInstant8);
//        boolean boolean10 = dateTime1.isAfter((org.joda.time.ReadableInstant) mutableDateTime7);
//        mutableDateTime7.addDays((int) (short) 100);
//        mutableDateTime7.addDays((int) (short) 0);
//        mutableDateTime7.add((long) (-1));
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.year();
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = dateTime1.minusWeeks((int) (byte) 0);
        boolean boolean6 = dateTime4.isEqual((long) 10);
        org.joda.time.DateTime dateTime8 = dateTime4.withWeekyear((int) (short) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology9);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime11.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant13 = null;
        boolean boolean14 = mutableDateTime12.isEqual(readableInstant13);
        java.util.GregorianCalendar gregorianCalendar15 = mutableDateTime12.toGregorianCalendar();
        org.joda.time.DateTimeField dateTimeField16 = mutableDateTime12.getRoundingField();
        mutableDateTime12.addMinutes(10);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime12.secondOfDay();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology21 = julianChronology20.withUTC();
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime12, chronology21);
        boolean boolean23 = dateTime8.isBefore((org.joda.time.ReadableInstant) mutableDateTime12);
        try {
            org.joda.time.DateTime dateTime27 = dateTime8.withDate(55, 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar15);
        org.junit.Assert.assertNull(dateTimeField16);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("46182", "year", 44, (int) '#');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology6);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology6);
//        org.joda.time.DateTime dateTime10 = dateTime8.minus((long) '4');
//        java.lang.String str11 = dateTimeFormatter5.print((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = dateTime10.minusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillis((-2L));
//        int int16 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2562-163T12:50:58Z" + "'", str11.equals("2562-163T12:50:58Z"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 44 + "'", int16 == 44);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay4 = dateTime2.toTimeOfDay();
        org.joda.time.DateTime.Property property5 = dateTime2.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology9);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) ' ');
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology6, readableDateTime8, (org.joda.time.ReadableDateTime) dateTime11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
        long long22 = fixedDateTimeZone19.convertLocalToUTC((long) (-1), false);
        org.joda.time.Chronology chronology23 = limitChronology14.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime(0L, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        boolean boolean26 = mutableDateTime24.isEqual(32L);
        boolean boolean28 = mutableDateTime24.isAfter((long) 47);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(timeOfDay4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(limitChronology14);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-60L) + "'", long22 == (-60L));
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        int int7 = delegatedDateTimeField5.get((long) 2);
        java.util.Locale locale9 = null;
        java.lang.String str10 = delegatedDateTimeField5.getAsText(62, locale9);
        java.lang.String str11 = delegatedDateTimeField5.getName();
        int int13 = delegatedDateTimeField5.get(0L);
        int int16 = delegatedDateTimeField5.getDifference((long) 2000, (long) 5);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2513 + "'", int7 == 2513);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "62" + "'", str10.equals("62"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "year" + "'", str11.equals("year"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2513 + "'", int13 == 2513);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
        long long7 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), false);
        long long9 = fixedDateTimeZone4.nextTransition((long) (byte) 100);
        java.lang.String str10 = fixedDateTimeZone4.toString();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60L) + "'", long7 == (-60L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2562-163T12:49:30Z" + "'", str10.equals("2562-163T12:49:30Z"));
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.DateTime.Property property6 = dateTime5.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay7 = dateTime5.toTimeOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime5.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime10 = dateTime5.toDateTime((org.joda.time.Chronology) buddhistChronology9);
//        org.joda.time.TimeOfDay timeOfDay11 = dateTime5.toTimeOfDay();
//        org.joda.time.DateTime dateTime13 = dateTime5.withCenturyOfEra(6);
//        int int14 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
//        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.059" + "'", str3.equals("+00:00:00.059"));
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(timeOfDay7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(timeOfDay11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localTime17);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant4 = null;
        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.year();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((long) 1);
        org.joda.time.DurationField durationField9 = property6.getDurationField();
        org.joda.time.MutableDateTime mutableDateTime10 = property6.getMutableDateTime();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology11);
        org.joda.time.DateTime.Property property13 = dateTime12.secondOfMinute();
        org.joda.time.DateTime dateTime14 = property13.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime16 = property13.addToCopy((long) 'a');
        mutableDateTime10.setTime((org.joda.time.ReadableInstant) dateTime16);
        mutableDateTime10.setDate(0L);
        mutableDateTime10.setWeekyear((-292268511));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        boolean boolean9 = mutableDateTime7.isEqual(readableInstant8);
//        boolean boolean10 = dateTime1.isAfter((org.joda.time.ReadableInstant) mutableDateTime7);
//        mutableDateTime7.setTime((long) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        mutableDateTime7.add(readablePeriod13);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology15);
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology15);
//        org.joda.time.MutableDateTime mutableDateTime18 = dateTime17.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        boolean boolean20 = mutableDateTime18.isEqual(readableInstant19);
//        java.util.GregorianCalendar gregorianCalendar21 = mutableDateTime18.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField22 = mutableDateTime18.getRoundingField();
//        mutableDateTime18.addMinutes(10);
//        org.joda.time.DateTime dateTime25 = mutableDateTime18.toDateTimeISO();
//        long long26 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime18);
//        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime7, (org.joda.time.ReadableInstant) mutableDateTime18);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(gregorianCalendar21);
//        org.junit.Assert.assertNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560344459323L + "'", long26 == 1560344459323L);
//        org.junit.Assert.assertNotNull(chronology27);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property2.addToCopy(100);
        org.joda.time.DateTime dateTime6 = property2.setCopy("30");
        int int7 = dateTime6.getYear();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2562 + "'", int7 == 2562);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.yearOfCentury();
        int int2 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        try {
            mutableDateTime3.setDateTime(46203108, 49, 31, 9, 54, 6, 46);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 49 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime7.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        boolean boolean10 = mutableDateTime8.isEqual(readableInstant9);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
//        mutableDateTime8.setZoneRetainFields(dateTimeZone12);
//        long long15 = dateTimeZone1.getMillisKeepLocal(dateTimeZone12, (long) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(dateTimeZone1);
//        int int17 = mutableDateTime16.getWeekyear();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.059" + "'", str3.equals("+00:00:00.059"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.minus((long) '4');
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.minusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime9 = dateTime8.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime8.minusYears((int) (byte) 100);
//        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long17 = buddhistChronology13.add((-1L), 100L, (int) 'a');
//        org.joda.time.DateTime dateTime18 = dateTime8.withChronology((org.joda.time.Chronology) buddhistChronology13);
//        org.joda.time.DurationField durationField19 = buddhistChronology13.millis();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2562-163T12:50:59Z" + "'", str6.equals("2562-163T12:50:59Z"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560343859651L + "'", long12 == 1560343859651L);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9699L + "'", long17 == 9699L);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(durationField19);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant4 = null;
        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime3.getRoundingField();
        mutableDateTime3.addMinutes(10);
        org.joda.time.DateTime dateTime10 = mutableDateTime3.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime3.copy();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime11.copy();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime11.yearOfEra();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant4 = null;
        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime3.dayOfWeek();
        mutableDateTime3.addWeekyears(10);
        mutableDateTime3.setSecondOfMinute((int) ' ');
        mutableDateTime3.setDate((long) 100);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime3.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime15 = property14.roundHalfFloor();
        java.lang.Object obj16 = mutableDateTime15.clone();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone18 = julianChronology17.getZone();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.plusSeconds((int) '#');
        mutableDateTime15.setDate((org.joda.time.ReadableInstant) dateTime21);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long9 = buddhistChronology5.add((-1L), 100L, (int) 'a');
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology5.millisOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField10, (int) (byte) -1);
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket(9223371985593602562L, (org.joda.time.Chronology) gJChronology1, locale14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        java.util.Locale locale18 = null;
        try {
            dateTimeParserBucket15.saveField(dateTimeFieldType16, "LimitChronology[BuddhistChronology[UTC], NoLimit, 2562-06-12T12:50:31.999Z]", locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9699L + "'", long9 == 9699L);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long9 = buddhistChronology5.add((-1L), 100L, (int) 'a');
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology5.millisOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField10, (int) (byte) -1);
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket(9223371985593602562L, (org.joda.time.Chronology) gJChronology1, locale14);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        org.joda.time.DateTime dateTime19 = property18.roundHalfEvenCopy();
        org.joda.time.DateTimeField dateTimeField20 = property18.getField();
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology21);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology21);
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime23.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant25 = null;
        boolean boolean26 = mutableDateTime24.isEqual(readableInstant25);
        java.util.GregorianCalendar gregorianCalendar27 = mutableDateTime24.toGregorianCalendar();
        org.joda.time.DateTimeField dateTimeField28 = mutableDateTime24.getRoundingField();
        mutableDateTime24.addMinutes(10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.secondOfMinute();
        org.joda.time.DateTime dateTime35 = property33.addToCopy(100);
        org.joda.time.DateTime dateTime37 = property33.setCopy("30");
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 0.0d, "26");
        org.joda.time.MutableDateTime.Property property42 = mutableDateTime24.property(dateTimeFieldType38);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, dateTimeFieldType38, 8, 6, 45);
        dateTimeParserBucket15.saveField((org.joda.time.DateTimeField) offsetDateTimeField46, (int) (byte) 1);
        dateTimeParserBucket15.setPivotYear((java.lang.Integer) 0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9699L + "'", long9 == 9699L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar27);
        org.junit.Assert.assertNull(dateTimeField28);
        org.junit.Assert.assertNotNull(buddhistChronology31);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(property42);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(263479536, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 263479571 + "'", int2 == 263479571);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) '4');
//        org.joda.time.DateTime.Property property5 = dateTime2.millisOfDay();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology6);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology6);
//        org.joda.time.DateTime dateTime10 = dateTime8.minus((long) '4');
//        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear(41);
//        long long13 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.MutableDateTime mutableDateTime14 = dateTime10.toMutableDateTime();
//        try {
//            mutableDateTime14.setSecondOfDay((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfDay must be in the range [0,86399]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 51L + "'", long13 == 51L);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long8 = buddhistChronology4.add((-1L), 100L, (int) 'a');
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology4.millisOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField9);
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField9, (int) (byte) -1);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField12.getMaximumTextLength(locale13);
        java.util.Locale locale15 = null;
        int int16 = skipDateTimeField12.getMaximumTextLength(locale15);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9699L + "'", long8 == 9699L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(100L);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.weekOfWeekyear();
        boolean boolean3 = mutableDateTime1.isAfterNow();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.year();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((long) 1);
//        org.joda.time.DurationField durationField9 = property6.getDurationField();
//        org.joda.time.MutableDateTime mutableDateTime10 = property6.getMutableDateTime();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology11);
//        org.joda.time.DateTime.Property property13 = dateTime12.secondOfMinute();
//        org.joda.time.DateTime dateTime14 = property13.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime16 = property13.addToCopy((long) 'a');
//        mutableDateTime10.setTime((org.joda.time.ReadableInstant) dateTime16);
//        java.lang.Object obj18 = mutableDateTime10.clone();
//        mutableDateTime10.addMonths((int) '#');
//        java.lang.String str21 = mutableDateTime10.toString();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2023-05-12T12:52:37.396Z" + "'", str21.equals("2023-05-12T12:52:37.396Z"));
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.era();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.059" + "'", str3.equals("+00:00:00.059"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("����-��-��T12:50:41.881");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����-��-��T12:50:41.881\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
//        mutableDateTime3.setZoneRetainFields(dateTimeZone7);
//        int int10 = dateTimeZone7.getOffsetFromLocal((long) ' ');
//        int int12 = dateTimeZone7.getOffsetFromLocal((-604799997L));
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        long long16 = cachedDateTimeZone13.adjustOffset((long) (short) 1, false);
//        int int18 = cachedDateTimeZone13.getOffset((long) (short) 0);
//        boolean boolean19 = cachedDateTimeZone13.isFixed();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 59 + "'", int18 == 59);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("41");
        java.lang.Object obj2 = null;
        jodaTimePermission1.checkGuard(obj2);
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("2562-163T12:49:27Z");
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay9 = dateTime7.toTimeOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.dayOfYear();
        jodaTimePermission5.checkGuard((java.lang.Object) dateTime7);
        java.lang.String str12 = jodaTimePermission5.toString();
        java.lang.String str13 = jodaTimePermission5.toString();
        boolean boolean15 = jodaTimePermission5.equals((java.lang.Object) 0L);
        boolean boolean16 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(timeOfDay9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"2562-163T12:49:27Z\")" + "'", str12.equals("(\"org.joda.time.JodaTimePermission\" \"2562-163T12:49:27Z\")"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"2562-163T12:49:27Z\")" + "'", str13.equals("(\"org.joda.time.JodaTimePermission\" \"2562-163T12:49:27Z\")"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2000, dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long9 = buddhistChronology5.add((-1L), 100L, (int) 'a');
//        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology5.millisOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField10);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField10, (int) (byte) -1);
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
//        java.lang.String str17 = dateTimeZone15.getName(0L);
//        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now(dateTimeZone15);
//        long long21 = dateTimeZone15.convertLocalToUTC((long) ' ', true);
//        org.joda.time.Chronology chronology22 = gJChronology1.withZone(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology1.getZone();
//        org.joda.time.Chronology chronology24 = gJChronology1.withUTC();
//        java.util.Locale locale25 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology1, locale25);
//        long long28 = dateTimeParserBucket26.computeMillis(true);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
//        long long36 = fixedDateTimeZone33.convertLocalToUTC((long) (-1), false);
//        org.joda.time.MutableDateTime mutableDateTime37 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone33);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendTwoDigitWeekyear((int) (short) 100);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology41);
//        org.joda.time.DateTime.Property property43 = dateTime42.secondOfMinute();
//        org.joda.time.DateTime dateTime45 = property43.addToCopy(100);
//        org.joda.time.DateTime dateTime47 = property43.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = property43.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException51 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType48, (java.lang.Number) 0.0d, "26");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder38.appendFixedDecimal(dateTimeFieldType48, 12);
//        int int54 = mutableDateTime37.get(dateTimeFieldType48);
//        dateTimeParserBucket26.saveField(dateTimeFieldType48, (int) '4');
//        long long59 = dateTimeParserBucket26.computeMillis(false, "2562-163T12:49:30Z");
//        java.lang.Integer int60 = dateTimeParserBucket26.getOffsetInteger();
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9699L + "'", long9 == 9699L);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.059" + "'", str17.equals("+00:00:00.059"));
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-27L) + "'", long21 == (-27L));
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-60L) + "'", long36 == (-60L));
//        org.junit.Assert.assertNotNull(mutableDateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(buddhistChronology41);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTimeFieldType48);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 52000L + "'", long59 == 52000L);
//        org.junit.Assert.assertNull(int60);
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.minus((long) '4');
//        org.joda.time.DateTime dateTime7 = dateTime5.withWeekyear(41);
//        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
//        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime11 = dateTime7.minusSeconds(263479571);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0041-06-14T12" + "'", str9.equals("0041-06-14T12"));
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime.Property property3 = dateTime1.secondOfMinute();
        int int4 = property3.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property2.addToCopy(100);
        org.joda.time.DateTime dateTime6 = property2.setCopy("30");
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter7, dateTimeParser9);
        boolean boolean11 = property2.equals((java.lang.Object) dateTimePrinter7);
        org.joda.time.JodaTimePermission jodaTimePermission13 = new org.joda.time.JodaTimePermission("2562-163T12:49:27Z");
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTime.Property property16 = dateTime15.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay17 = dateTime15.toTimeOfDay();
        org.joda.time.DateTime.Property property18 = dateTime15.dayOfYear();
        jodaTimePermission13.checkGuard((java.lang.Object) dateTime15);
        org.joda.time.DateTime.Property property20 = dateTime15.secondOfDay();
        org.joda.time.DateTime dateTime22 = dateTime15.withMillisOfDay(0);
        int int23 = property2.getDifference((org.joda.time.ReadableInstant) dateTime15);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(timeOfDay17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.ReadableDateTime readableDateTime7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology5, readableDateTime7, (org.joda.time.ReadableDateTime) dateTime10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField19);
//        java.lang.String str22 = skipDateTimeField20.getAsText(0L);
//        int int23 = skipDateTimeField20.getMinimumValue();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
//        long long31 = fixedDateTimeZone28.convertLocalToUTC((long) (-1), false);
//        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendTwoDigitWeekyear((int) (short) 100);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology36);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
//        org.joda.time.DateTime dateTime40 = property38.addToCopy(100);
//        org.joda.time.DateTime dateTime42 = property38.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property38.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 0.0d, "26");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType43, 12);
//        int int49 = mutableDateTime32.get(dateTimeFieldType43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField20, dateTimeFieldType43, (-28800000));
//        java.util.Locale locale52 = null;
//        int int53 = offsetDateTimeField51.getMaximumShortTextLength(locale52);
//        long long56 = offsetDateTimeField51.add((long) 8, (-1));
//        boolean boolean58 = offsetDateTimeField51.isLeap(1560343809154L);
//        boolean boolean59 = offsetDateTimeField51.isLenient();
//        int int61 = offsetDateTimeField51.getMinimumValue(1560344379730L);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2513" + "'", str22.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292268512) + "'", int23 == (-292268512));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-60L) + "'", long31 == (-60L));
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 9 + "'", int53 == 9);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-31535999992L) + "'", long56 == (-31535999992L));
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-321068512) + "'", int61 == (-321068512));
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(7, 0, 263479571, (-1), 0, 99, 55);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant4 = null;
        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.year();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((long) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology9);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime11.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant13 = null;
        boolean boolean14 = mutableDateTime12.isEqual(readableInstant13);
        java.util.GregorianCalendar gregorianCalendar15 = mutableDateTime12.toGregorianCalendar();
        org.joda.time.DateTimeField dateTimeField16 = mutableDateTime12.getRoundingField();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology17);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology17);
        org.joda.time.MutableDateTime mutableDateTime20 = dateTime19.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant21 = null;
        boolean boolean22 = mutableDateTime20.isEqual(readableInstant21);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology23.getZone();
        mutableDateTime20.setZoneRetainFields(dateTimeZone24);
        mutableDateTime12.setZone(dateTimeZone24);
        mutableDateTime12.setYear((-1));
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime12.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
        long long37 = fixedDateTimeZone34.convertLocalToUTC((long) (-1), false);
        org.joda.time.MutableDateTime mutableDateTime38 = mutableDateTime12.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        mutableDateTime8.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        boolean boolean40 = fixedDateTimeZone34.isFixed();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone41 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar15);
        org.junit.Assert.assertNull(dateTimeField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-60L) + "'", long37 == (-60L));
        org.junit.Assert.assertNotNull(mutableDateTime38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone41);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField2 = buddhistChronology0.hours();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException2.prependMessage("hi!");
        illegalFieldValueException2.prependMessage("+00:00:00.059");
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 52000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Coordinated Universal Time");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        org.joda.time.DateTime.Property property5 = dateTime3.secondOfMinute();
        int int6 = property5.getMaximumValue();
        boolean boolean7 = jodaTimePermission1.equals((java.lang.Object) property5);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
        int int9 = property5.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 59 + "'", int9 == 59);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant4 = null;
        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime3.getRoundingField();
        mutableDateTime3.addMinutes(10);
        org.joda.time.DateTime dateTime10 = mutableDateTime3.toDateTimeISO();
        int int11 = mutableDateTime3.getYearOfEra();
        mutableDateTime3.add((long) 9);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendDayOfWeek(59);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.append(dateTimePrinter13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendFractionOfDay(12, 55);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendHourOfDay(97);
        dateTimeFormatterBuilder19.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 1);
        org.joda.time.Instant instant3 = instant1.minus((long) 6);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant1.plus(readableDuration4);
        org.joda.time.Instant instant8 = instant1.withDurationAdded((long) 12, 0);
        org.joda.time.Instant instant10 = instant1.minus((long) (byte) 0);
        boolean boolean12 = instant1.isEqual(52L);
        org.joda.time.MutableDateTime mutableDateTime13 = instant1.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.TimeOfDay timeOfDay7 = dateTime1.toTimeOfDay();
//        int int8 = dateTime1.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime10 = dateTime1.withMillisOfDay((int) (short) 0);
//        boolean boolean12 = dateTime10.isAfter((-321125512L));
//        java.util.Locale locale13 = null;
//        java.util.Calendar calendar14 = dateTime10.toCalendar(locale13);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(timeOfDay7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(calendar14);
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime3.monthOfYear();
//        mutableDateTime3.addHours((int) (byte) 10);
//        mutableDateTime3.addWeeks((int) (byte) 10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology12);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology12);
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime14.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        boolean boolean17 = mutableDateTime15.isEqual(readableInstant16);
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone19 = julianChronology18.getZone();
//        mutableDateTime15.setZoneRetainFields(dateTimeZone19);
//        int int22 = dateTimeZone19.getOffsetFromLocal((long) ' ');
//        int int24 = dateTimeZone19.getOffsetFromLocal((-604799997L));
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone19);
//        long long28 = cachedDateTimeZone25.adjustOffset((long) (short) 1, false);
//        int int30 = cachedDateTimeZone25.getOffset((long) (short) 0);
//        mutableDateTime3.setZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(buddhistChronology12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 59 + "'", int22 == 59);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 59 + "'", int24 == 59);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 59 + "'", int30 == 59);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter1.parseLocalDate("43");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"43\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField2 = buddhistChronology0.weeks();
        long long5 = durationField2.subtract((long) 3, (int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-604799997L) + "'", long5 == (-604799997L));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatterBuilder6.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
        long long7 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), false);
        long long9 = fixedDateTimeZone4.nextTransition((long) (byte) 100);
        int int11 = fixedDateTimeZone4.getOffset((long) (byte) -1);
        long long13 = fixedDateTimeZone4.previousTransition((long) (byte) 0);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DurationField durationField15 = julianChronology14.millis();
        java.lang.String str16 = julianChronology14.toString();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60L) + "'", long7 == (-60L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "JulianChronology[2562-163T12:49:30Z]" + "'", str16.equals("JulianChronology[2562-163T12:49:30Z]"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay9 = dateTime7.toTimeOfDay();
        int[] intArray13 = new int[] { 4, (short) 100 };
        int[] intArray15 = delegatedDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay9, 99, intArray13, (int) (byte) 0);
        long long18 = delegatedDateTimeField5.set((long) (byte) 1, (int) (byte) 100);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) delegatedDateTimeField5, (int) '#', 10, 2513);
        long long25 = delegatedDateTimeField5.set((long) (-13), "52");
        long long27 = delegatedDateTimeField5.roundCeiling((long) (short) -1);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(timeOfDay9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-76147343999999L) + "'", long18 == (-76147343999999L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-77630572800013L) + "'", long25 == (-77630572800013L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.minus((long) '4');
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.minusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime9 = dateTime8.withTimeAtStartOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.lang.String str11 = dateTime8.toString(dateTimeFormatter10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology12);
//        org.joda.time.DateTime.Property property14 = dateTime13.secondOfMinute();
//        org.joda.time.DateTime dateTime16 = property14.addToCopy(100);
//        org.joda.time.DateTime dateTime18 = property14.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property14.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 0.0d, "26");
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = illegalFieldValueException22.getDateTimeFieldType();
//        boolean boolean24 = dateTime8.isSupported(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2562-163T12:51:02Z" + "'", str6.equals("2562-163T12:51:02Z"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "125101.993Z" + "'", str11.equals("125101.993Z"));
//        org.junit.Assert.assertNotNull(buddhistChronology12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime3.getRoundingField();
//        int int8 = mutableDateTime3.getDayOfWeek();
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime3.millisOfSecond();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
//        org.junit.Assert.assertNotNull(property9);
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
//        mutableDateTime3.setZoneRetainFields(dateTimeZone7);
//        int int10 = dateTimeZone7.getOffsetFromLocal((long) ' ');
//        int int12 = dateTimeZone7.getOffsetFromLocal((-604799997L));
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        long long16 = cachedDateTimeZone13.adjustOffset((long) (short) 1, false);
//        int int18 = cachedDateTimeZone13.getOffset((long) (short) 0);
//        long long20 = cachedDateTimeZone13.previousTransition(10L);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 59 + "'", int18 == 59);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendWeekyear(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.appendDayOfYear(5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths((int) ' ');
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology5, readableDateTime7, (org.joda.time.ReadableDateTime) dateTime10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField19);
        long long23 = delegatedDateTimeField19.getDifferenceAsLong((long) 23, 52L);
        boolean boolean25 = delegatedDateTimeField19.isLeap((long) 100);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime6 = dateTime1.minusHours((int) (short) 0);
        boolean boolean7 = dateTime1.isAfterNow();
        org.joda.time.DateTime dateTime8 = dateTime1.toDateTime();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 1);
        org.joda.time.Instant instant3 = instant1.minus((long) 6);
        org.joda.time.DateTime dateTime4 = instant1.toDateTime();
        org.joda.time.DateTime dateTime5 = instant1.toDateTimeISO();
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTimeField dateTimeField10 = property8.getField();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology11);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology11);
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime13.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant15 = null;
        boolean boolean16 = mutableDateTime14.isEqual(readableInstant15);
        java.util.GregorianCalendar gregorianCalendar17 = mutableDateTime14.toGregorianCalendar();
        org.joda.time.DateTimeField dateTimeField18 = mutableDateTime14.getRoundingField();
        mutableDateTime14.addMinutes(10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology21);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfMinute();
        org.joda.time.DateTime dateTime25 = property23.addToCopy(100);
        org.joda.time.DateTime dateTime27 = property23.setCopy("30");
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property23.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 0.0d, "26");
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime14.property(dateTimeFieldType28);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType28, 8, 6, 45);
        org.joda.time.IllegalFieldValueException illegalFieldValueException38 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, "26");
        int int39 = instant1.get(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar17);
        org.junit.Assert.assertNull(dateTimeField18);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant4 = null;
        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime3.dayOfWeek();
        mutableDateTime3.addWeekyears(10);
        mutableDateTime3.setSecondOfMinute((int) ' ');
        mutableDateTime3.addWeekyears(24);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime3.millisOfSecond();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime9 = dateTime6.minusDays(24);
        boolean boolean11 = dateTime9.isBefore((long) 52);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatter9.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter15 = dateTimeFormatter13.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.append(dateTimePrinter15, dateTimeParser17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder7.append(dateTimePrinter11, dateTimeParser17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(62, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder7.appendClockhourOfDay(2562);
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology25);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology25);
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime27.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant29 = null;
        boolean boolean30 = mutableDateTime28.isEqual(readableInstant29);
        java.util.GregorianCalendar gregorianCalendar31 = mutableDateTime28.toGregorianCalendar();
        org.joda.time.DateTimeField dateTimeField32 = mutableDateTime28.getRoundingField();
        mutableDateTime28.addMinutes(10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology35 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology35);
        org.joda.time.DateTime.Property property37 = dateTime36.secondOfMinute();
        org.joda.time.DateTime dateTime39 = property37.addToCopy(100);
        org.joda.time.DateTime dateTime41 = property37.setCopy("30");
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property37.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException45 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 0.0d, "26");
        org.joda.time.MutableDateTime.Property property46 = mutableDateTime28.property(dateTimeFieldType42);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder24.appendFixedDecimal(dateTimeFieldType42, 12);
        org.joda.time.format.DateTimePrinter dateTimePrinter49 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser51 = dateTimeFormatter50.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter49, dateTimeParser51);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder48.append(dateTimeParser51);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimePrinter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimePrinter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar31);
        org.junit.Assert.assertNull(dateTimeField32);
        org.junit.Assert.assertNotNull(buddhistChronology35);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatter50);
        org.junit.Assert.assertNotNull(dateTimeParser51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2562-163T12:49:30Z", "", 59, (int) (short) 10);
        long long6 = fixedDateTimeZone4.nextTransition((long) 0);
        java.lang.String str8 = fixedDateTimeZone4.getName((-27L));
        int int10 = fixedDateTimeZone4.getOffset((long) (-1));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.059" + "'", str8.equals("+00:00:00.059"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        java.util.GregorianCalendar gregorianCalendar6 = mutableDateTime3.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime3.getRoundingField();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        boolean boolean13 = mutableDateTime11.isEqual(readableInstant12);
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
//        mutableDateTime11.setZoneRetainFields(dateTimeZone15);
//        mutableDateTime3.setZone(dateTimeZone15);
//        mutableDateTime3.setYear((-1));
//        org.joda.time.MutableDateTime.Property property20 = mutableDateTime3.millisOfSecond();
//        org.joda.time.MutableDateTime.Property property21 = mutableDateTime3.millisOfSecond();
//        boolean boolean23 = mutableDateTime3.isEqual((-299368883L));
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) '4');
        org.joda.time.DateTime.Property property5 = dateTime2.millisOfDay();
        org.joda.time.DateMidnight dateMidnight6 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime2.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay6 = dateTime4.toTimeOfDay();
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime9 = dateTime4.toDateTime((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.TimeOfDay timeOfDay10 = dateTime4.toTimeOfDay();
        org.joda.time.DateTime dateTime12 = dateTime4.withCenturyOfEra(6);
        int int13 = property2.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = property2.addToCopy(57);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(timeOfDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(timeOfDay10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.DateTime dateTime4 = property2.addToCopy(100);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra(2000);
//        int int9 = dateTime6.getSecondOfDay();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 46363 + "'", int9 == 46363);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths((int) ' ');
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology5, readableDateTime7, (org.joda.time.ReadableDateTime) dateTime10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField19);
        java.lang.String str22 = skipDateTimeField20.getAsText(0L);
        int int23 = skipDateTimeField20.getMinimumValue();
        int int25 = skipDateTimeField20.getMaximumValue(1L);
        org.joda.time.DurationField durationField26 = skipDateTimeField20.getRangeDurationField();
        java.lang.String str28 = skipDateTimeField20.getAsShortText((long) 580);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(timeOfDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2513" + "'", str22.equals("2513"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292268512) + "'", int23 == (-292268512));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 292279536 + "'", int25 == 292279536);
        org.junit.Assert.assertNull(durationField26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2513" + "'", str28.equals("2513"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        long long8 = delegatedDateTimeField5.add((-31535999000L), 825);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 26002944001000L + "'", long8 == 26002944001000L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property2.addToCopy(100);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfMinute();
        org.joda.time.DateTime dateTime12 = property10.addToCopy(100);
        boolean boolean13 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime16.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant18 = null;
        boolean boolean19 = mutableDateTime17.isEqual(readableInstant18);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime17.year();
        org.joda.time.MutableDateTime mutableDateTime22 = property20.add((long) 1);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        mutableDateTime22.add(readablePeriod23, 100);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology26);
        org.joda.time.DateTime.Property property28 = dateTime27.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay29 = dateTime27.toTimeOfDay();
        org.joda.time.DateTime.Property property30 = dateTime27.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime32 = dateTime27.toDateTime((org.joda.time.Chronology) buddhistChronology31);
        org.joda.time.TimeOfDay timeOfDay33 = dateTime27.toTimeOfDay();
        org.joda.time.DateTime dateTime35 = dateTime27.withCenturyOfEra(6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology36);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
        org.joda.time.DateTime dateTime40 = property38.addToCopy(100);
        org.joda.time.DateTime dateTime42 = property38.setCopy("30");
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property38.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 0.0d, "26");
        org.joda.time.DateTime.Property property47 = dateTime35.property(dateTimeFieldType43);
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime22.property(dateTimeFieldType43);
        boolean boolean49 = dateTime12.isSupported(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(timeOfDay29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(buddhistChronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(timeOfDay33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.roundHalfEvenCopy();
        org.joda.time.DateTimeField dateTimeField4 = property2.getField();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime7.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant9 = null;
        boolean boolean10 = mutableDateTime8.isEqual(readableInstant9);
        java.util.GregorianCalendar gregorianCalendar11 = mutableDateTime8.toGregorianCalendar();
        org.joda.time.DateTimeField dateTimeField12 = mutableDateTime8.getRoundingField();
        mutableDateTime8.addMinutes(10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime19 = property17.addToCopy(100);
        org.joda.time.DateTime dateTime21 = property17.setCopy("30");
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 0.0d, "26");
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime8.property(dateTimeFieldType22);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType22, 8, 6, 45);
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, "26");
        java.lang.Number number33 = illegalFieldValueException32.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar11);
        org.junit.Assert.assertNull(dateTimeField12);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNull(number33);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.yearOfCentury();
        int int3 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology1.clockhourOfDay();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology1);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2562-06-12T12:50:41.217Z", "46290", 21, 58);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        boolean boolean5 = mutableDateTime3.isEqual(readableInstant4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.year();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((long) 1);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        mutableDateTime8.add(readablePeriod9, 100);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology12);
//        org.joda.time.DateTime.Property property14 = dateTime13.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay15 = dateTime13.toTimeOfDay();
//        org.joda.time.DateTime.Property property16 = dateTime13.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime18 = dateTime13.toDateTime((org.joda.time.Chronology) buddhistChronology17);
//        org.joda.time.TimeOfDay timeOfDay19 = dateTime13.toTimeOfDay();
//        org.joda.time.DateTime dateTime21 = dateTime13.withCenturyOfEra(6);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology22);
//        org.joda.time.DateTime.Property property24 = dateTime23.secondOfMinute();
//        org.joda.time.DateTime dateTime26 = property24.addToCopy(100);
//        org.joda.time.DateTime dateTime28 = property24.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property24.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 0.0d, "26");
//        org.joda.time.DateTime.Property property33 = dateTime21.property(dateTimeFieldType29);
//        org.joda.time.MutableDateTime.Property property34 = mutableDateTime8.property(dateTimeFieldType29);
//        mutableDateTime8.setDate((long) 8);
//        org.joda.time.ReadableDuration readableDuration37 = null;
//        mutableDateTime8.add(readableDuration37, 292279536);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(buddhistChronology12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(timeOfDay15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(timeOfDay19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(buddhistChronology22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(property34);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.yearOfCentury();
        int int3 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology1.clockhourOfDay();
        org.joda.time.DurationField durationField8 = julianChronology1.weekyears();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay9 = dateTime7.toTimeOfDay();
        int[] intArray13 = new int[] { 4, (short) 100 };
        int[] intArray15 = delegatedDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay9, 99, intArray13, (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
        org.joda.time.TimeOfDay timeOfDay19 = dateTime17.toTimeOfDay();
        org.joda.time.DateTime.Property property20 = dateTime17.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime22 = dateTime17.toDateTime((org.joda.time.Chronology) buddhistChronology21);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime17.toTimeOfDay();
        int int24 = delegatedDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay23);
        int int26 = delegatedDateTimeField5.getMaximumValue((long) 28);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(timeOfDay9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(timeOfDay19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 292279536 + "'", int26 == 292279536);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-210863736000000L));
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours(10);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long9 = buddhistChronology5.add((-1L), 100L, (int) 'a');
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology5.millisOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField10, (int) (byte) -1);
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket(9223371985593602562L, (org.joda.time.Chronology) gJChronology1, locale14);
        long long19 = gJChronology1.add((long) 6, (long) 58, 2562);
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone21 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology1.halfdayOfDay();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9699L + "'", long9 == 9699L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 148602L + "'", long19 == 148602L);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.lang.String str1 = julianChronology0.toString();
//        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        try {
//            int[] intArray5 = julianChronology0.get(readablePeriod3, (long) 8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[2562-163T12:49:30Z]" + "'", str1.equals("JulianChronology[2562-163T12:49:30Z]"));
//        org.junit.Assert.assertNotNull(chronology2);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("53", "50");
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test264");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.ReadableDateTime readableDateTime7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths((int) ' ');
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology5, readableDateTime7, (org.joda.time.ReadableDateTime) dateTime10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.MutableDateTime mutableDateTime17 = dateTime16.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant18 = null;
//        boolean boolean19 = mutableDateTime17.isEqual(readableInstant18);
//        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology20.getZone();
//        mutableDateTime17.setZoneRetainFields(dateTimeZone21);
//        int int24 = dateTimeZone21.getOffsetFromLocal((long) ' ');
//        int int26 = dateTimeZone21.getOffsetFromLocal((-604799997L));
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone21);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone21);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
//        org.joda.time.Chronology chronology30 = iSOChronology29.withUTC();
//        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone32 = julianChronology31.getZone();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone32);
//        java.lang.String str36 = dateTimeZone32.getName((long) 292279536);
//        org.joda.time.Chronology chronology37 = iSOChronology29.withZone(dateTimeZone32);
//        org.joda.time.Chronology chronology38 = limitChronology13.withZone(dateTimeZone32);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(julianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 59 + "'", int24 == 59);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 59 + "'", int26 == 59);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(julianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(buddhistChronology34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "+00:00:00.059" + "'", str36.equals("+00:00:00.059"));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(chronology38);
//    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long9 = buddhistChronology5.add((-1L), 100L, (int) 'a');
//        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology5.millisOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField10);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField10, (int) (byte) -1);
//        java.util.Locale locale14 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket(9223371985593602562L, (org.joda.time.Chronology) gJChronology1, locale14);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology16);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfMinute();
//        org.joda.time.DateTime dateTime19 = property18.roundHalfEvenCopy();
//        org.joda.time.DateTimeField dateTimeField20 = property18.getField();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology21);
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology21);
//        org.joda.time.MutableDateTime mutableDateTime24 = dateTime23.toMutableDateTime();
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        boolean boolean26 = mutableDateTime24.isEqual(readableInstant25);
//        java.util.GregorianCalendar gregorianCalendar27 = mutableDateTime24.toGregorianCalendar();
//        org.joda.time.DateTimeField dateTimeField28 = mutableDateTime24.getRoundingField();
//        mutableDateTime24.addMinutes(10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology31);
//        org.joda.time.DateTime.Property property33 = dateTime32.secondOfMinute();
//        org.joda.time.DateTime dateTime35 = property33.addToCopy(100);
//        org.joda.time.DateTime dateTime37 = property33.setCopy("30");
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property33.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 0.0d, "26");
//        org.joda.time.MutableDateTime.Property property42 = mutableDateTime24.property(dateTimeFieldType38);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, dateTimeFieldType38, 8, 6, 45);
//        dateTimeParserBucket15.saveField((org.joda.time.DateTimeField) offsetDateTimeField46, (int) (byte) 1);
//        int int50 = offsetDateTimeField46.getMinimumValue((long) (-13));
//        org.joda.time.DateTimeField dateTimeField51 = offsetDateTimeField46.getWrappedField();
//        long long54 = offsetDateTimeField46.add((long) 86399, 100);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9699L + "'", long9 == 9699L);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(buddhistChronology21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar27);
//        org.junit.Assert.assertNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 8 + "'", int50 == 8);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 186399L + "'", long54 == 186399L);
//    }
//}

