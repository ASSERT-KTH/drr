import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) 'a', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 197 + "'", int2 == 197);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 'a', dateTimeZone3);
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) (short) -1, dateTimeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        try {
            long long4 = durationField1.subtract((long) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 197);
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) -1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) (short) 1);
        boolean boolean6 = dateTime5.isEqualNow();
        try {
            org.joda.time.DateTime dateTime11 = dateTime5.withTime((int) ' ', 1, (int) (byte) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime8 = property6.setCopy(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DurationField durationField6 = property5.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNull(durationField6);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long12 = dateTimeZone8.convertLocalToUTC((long) 10, false, (long) (-1));
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(0, (int) '4', 197, (int) (short) 100, 100, 0, (int) ' ', dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-359999990L) + "'", long12 == (-359999990L));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        long long10 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime8);
        try {
            org.joda.time.DateTime dateTime12 = property4.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 9, (int) (byte) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        long long10 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.DateTime dateTime13 = dateTime8.withField(dateTimeFieldType11, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) 10, (long) 197);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 207L + "'", long2 == 207L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfSecond();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology2);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) monthDay4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 'a', dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 'a', dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime5.withZoneRetainFields(dateTimeZone8);
        org.joda.time.LocalTime localTime11 = dateTime10.toLocalTime();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localTime11);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        long long5 = iSOChronology0.add(0L, (long) (byte) 1, 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.weekyear();
        try {
            org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(97, 1970, (org.joda.time.Chronology) julianChronology2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("monthOfYear");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 'a', dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.plusDays((int) (short) 1);
        java.util.GregorianCalendar gregorianCalendar8 = dateTime7.toGregorianCalendar();
        try {
            org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime7, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianCalendar8);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(9, (int) '4', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.LocalTime localTime9 = dateTime8.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds(0);
        try {
            org.joda.time.DateTime dateTime13 = dateTime8.withEra((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(9, 0, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 'a', dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a', dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.withZoneRetainFields(dateTimeZone12);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        int int16 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime14.minus(readablePeriod17);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str8 = monthDay6.toString(dateTimeFormatter7);
        boolean boolean9 = monthDay2.isBefore((org.joda.time.ReadablePartial) monthDay6);
        try {
            org.joda.time.MonthDay monthDay11 = monthDay2.withMonthOfYear(360000000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 360000000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����-W��-�" + "'", str8.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(1439, (int) 'a', (int) (byte) 1, 0, 1439, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1439 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(buddhistChronology9);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long5 = dateTimeZone1.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        try {
            org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, 97L, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-359999990L) + "'", long5 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) (short) -1);
        java.lang.String str9 = property6.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[dayOfWeek]" + "'", str9.equals("Property[dayOfWeek]"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMinutes((int) 'a');
        boolean boolean14 = dateTime10.isAfter((long) 10);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        long long10 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime8);
        int int11 = property4.getMinimumValueOverall();
        org.joda.time.ReadablePartial readablePartial12 = null;
        try {
            int int13 = property4.compareTo(readablePartial12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) (short) 1);
        try {
            org.joda.time.DateTime dateTime7 = dateTime3.withHourOfDay(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(4, 9, (int) 'a', (int) (byte) 0, (int) ' ', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) 19);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "T16:00:00.019-08:00" + "'", str2.equals("T16:00:00.019-08:00"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) (short) -1);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime10 = dateTime8.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long5 = dateTimeZone1.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        try {
            org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, 0L, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-359999990L) + "'", long5 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        try {
            long long2 = dateTimeFormatter0.parseMillis("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMonthOfYear((int) (short) 100);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.MonthDay.Property property10 = monthDay9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray14 = new org.joda.time.format.DateTimeParser[] {};
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.append(dateTimePrinter13, dateTimeParserArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeParserArray14);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "T16:00:00.019-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        java.lang.String str8 = skipDateTimeField6.getAsShortText(10L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            long long2 = dateTimeFormatter0.parseMillis("+100:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+100:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a', dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 'a', dateTimeZone16);
        org.joda.time.DateTime dateTime18 = dateTime13.withZoneRetainFields(dateTimeZone16);
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        int int20 = property9.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime.Property property21 = dateTime18.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("Jun");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Jun\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 'a', dateTimeZone13);
        boolean boolean15 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime14);
        int int16 = dateTime14.getCenturyOfEra();
        java.util.Date date17 = dateTime14.toDate();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 19 + "'", int16 == 19);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(0, (int) (byte) 0, 1, (-1), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.MonthDay.Property property11 = monthDay10.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.millisOfSecond();
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str16 = monthDay14.toString(dateTimeFormatter15);
        boolean boolean17 = monthDay10.isBefore((org.joda.time.ReadablePartial) monthDay14);
        int[] intArray19 = new int[] {};
        try {
            int[] intArray21 = skipDateTimeField6.addWrapField((org.joda.time.ReadablePartial) monthDay10, 0, intArray19, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "����-W��-�" + "'", str16.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 'a', dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.plusDays((int) (short) 1);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfSecond();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: hi!");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getName();
        int int5 = property3.get();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property3.getAsShortText(locale6);
        org.joda.time.DurationField durationField8 = property3.getRangeDurationField();
        try {
            org.joda.time.MonthDay monthDay10 = property3.setCopy("monthOfYear");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"monthOfYear\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Dec" + "'", str7.equals("Dec"));
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.weekyear();
        boolean boolean7 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone5, (java.lang.Object) dateTimeFormatter6);
        boolean boolean8 = property3.equals((java.lang.Object) dateTimeZone5);
        int int9 = property3.get();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 0, (long) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.era();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField7 = iSOChronology6.eras();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology4, dateTimeField8, 12);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 'a', dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 'a', dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime14.withZoneRetainFields(dateTimeZone17);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.minus(readableDuration20);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.eras();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.millisOfSecond();
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology23);
        org.joda.time.DateTime dateTime27 = dateTime21.withFields((org.joda.time.ReadablePartial) monthDay26);
        int[] intArray32 = new int[] { (byte) 1, 12, (short) 10 };
        try {
            int[] intArray34 = skipUndoDateTimeField10.addWrapPartial((org.joda.time.ReadablePartial) monthDay26, (int) (short) -1, intArray32, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("+100:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+100:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray7 = iSOChronology0.get(readablePeriod4, (long) (short) 100, (long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 6, dateTimeZone1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str8 = monthDay6.toString(dateTimeFormatter7);
        boolean boolean9 = monthDay2.isBefore((org.joda.time.ReadablePartial) monthDay6);
        try {
            org.joda.time.MonthDay monthDay11 = monthDay6.withDayOfMonth((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����-W��-�" + "'", str8.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        long long10 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime8);
        int int11 = property4.getMaximumValueOverall();
        org.joda.time.DateTime dateTime12 = property4.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime13 = property4.roundHalfEvenCopy();
        int int14 = dateTime13.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1439 + "'", int11 == 1439);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        try {
            org.joda.time.DateTime dateTime8 = property4.setCopy("1969");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for minuteOfDay must be in the range [0,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.era();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField7 = iSOChronology6.eras();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology4, dateTimeField8, 12);
        try {
            long long13 = skipUndoDateTimeField10.set((long) 197, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        java.util.Locale locale6 = null;
        try {
            org.joda.time.MonthDay monthDay7 = property3.setCopy("GJChronology[UTC]", locale6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GJChronology[UTC]\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "December" + "'", str4.equals("December"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        illegalFieldValueException2.prependMessage("");
        java.lang.String str6 = illegalFieldValueException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: : Value \"hi!\" for hi! is not supported" + "'", str6.equals("org.joda.time.IllegalFieldValueException: : Value \"hi!\" for hi! is not supported"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        java.lang.String str2 = dateTimeZone1.getID();
        java.lang.String str4 = dateTimeZone1.getShortName((long) (short) -1);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+100:00" + "'", str2.equals("+100:00"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+100:00" + "'", str4.equals("+100:00"));
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology8 = gJChronology7.withUTC();
        org.joda.time.DurationField durationField9 = gJChronology7.seconds();
        java.lang.String str10 = gJChronology7.toString();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(0, 9, (int) (byte) -1, 97, 0, (int) (short) 100, 12, (org.joda.time.Chronology) gJChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GJChronology[UTC]" + "'", str10.equals("GJChronology[UTC]"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology4.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField6);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField6);
        long long10 = skipUndoDateTimeField8.roundHalfFloor((long) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfSecond();
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology11);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) ' ', locale15);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        try {
            org.joda.time.MonthDay monthDay19 = monthDay13.withFieldAdded(durationFieldType17, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 950400000L + "'", long10 == 950400000L);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "32" + "'", str16.equals("32"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        illegalFieldValueException2.prependMessage("");
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNull(dateTimeFieldType6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneShortName();
        java.lang.Class<?> wildcardClass8 = dateTimeFormatterBuilder6.getClass();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("June");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'June' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str8 = monthDay6.toString(dateTimeFormatter7);
        boolean boolean9 = monthDay2.isBefore((org.joda.time.ReadablePartial) monthDay6);
        try {
            org.joda.time.DateTimeField dateTimeField11 = monthDay2.getField(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����-W��-�" + "'", str8.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getName();
        int int5 = property3.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        boolean boolean3 = gJChronology0.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.MonthDay monthDay7 = monthDay4.withFieldAdded(durationFieldType5, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(monthDay4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra(0);
        int int8 = dateTime5.getYear();
        org.joda.time.DateTime dateTime10 = dateTime5.minusMinutes(100);
        int int11 = dateTime5.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfSecond();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = monthDay4.getFields();
        int[] intArray8 = new int[] { 100, (byte) 100 };
        try {
            iSOChronology0.validate((org.joda.time.ReadablePartial) monthDay4, intArray8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getName();
        int int5 = property3.get();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField7 = iSOChronology6.eras();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.clockhourOfDay();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) int5, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        java.io.Writer writer3 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.minuteOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.millisOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.dayOfWeek();
        org.joda.time.DateTime dateTime11 = dateTime7.withEarlierOffsetAtOverlap();
        try {
            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadableInstant) dateTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("12");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gJChronology0.seconds();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gJChronology0.add(readablePeriod3, 0L, 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        try {
            long long24 = dividedDateTimeField21.set(0L, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 197);
        try {
            org.joda.time.LocalDate localDate4 = dateTimeFormatter2.parseLocalDate("Jun");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Jun\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipDateTimeField6.getAsShortText((int) (short) 0, locale9);
        try {
            long long13 = skipDateTimeField6.set(10L, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfSecond();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusDays((int) (short) 1);
        java.util.GregorianCalendar gregorianCalendar10 = dateTime9.toGregorianCalendar();
        boolean boolean11 = iSOChronology0.equals((java.lang.Object) dateTime9);
        try {
            org.joda.time.DateTime dateTime16 = dateTime9.withTime(100, 360000000, 4, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withDefaultYear(100);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.LocalTime localTime9 = dateTime8.toLocalTime();
        org.joda.time.DateTime.Property property10 = dateTime8.era();
        int int11 = property10.get();
        org.joda.time.DurationField durationField12 = property10.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(durationField12);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) (short) 1);
        boolean boolean6 = dateTime5.isEqualNow();
        int int7 = dateTime5.getMillisOfSecond();
        java.util.GregorianCalendar gregorianCalendar8 = dateTime5.toGregorianCalendar();
        try {
            org.joda.time.DateTime dateTime10 = dateTime5.withMonthOfYear(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertNotNull(gregorianCalendar8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(0, 97, 0, 0, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) (byte) 10, 97);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology4.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipDateTimeField7.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType8);
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = null;
        org.joda.time.format.DateTimeParser dateTimeParser11 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.append(dateTimePrinter10, dateTimeParser11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int0 = org.joda.time.MonthDay.DAY_OF_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 'a', dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime16 = dateTime14.withCenturyOfEra(0);
        boolean boolean17 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime.Property property18 = dateTime8.era();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long5 = dateTimeZone1.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        int int8 = dateTimeZone6.getOffsetFromLocal(0L);
        try {
            org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-359999990L) + "'", long5 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 360000000 + "'", int8 == 360000000);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        long long9 = skipDateTimeField6.roundCeiling((long) (short) -1);
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipDateTimeField6.getAsShortText(207L, locale11);
        java.util.Locale locale15 = null;
        try {
            long long16 = skipDateTimeField6.set((long) (byte) 100, "(\"org.joda.time.JodaTimePermission\" \"hi!\")", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"(\"org.joda.time.JodaTimePermission\" \"hi!\")\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 950400000L + "'", long9 == 950400000L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra(0);
        int int8 = dateTime5.getYear();
        org.joda.time.DateTime.Property property9 = dateTime5.weekyear();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.millisOfSecond();
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = monthDay12.getFieldType((int) (byte) 0);
        org.joda.time.LocalDate localDate16 = monthDay12.toLocalDate((-1));
        try {
            int int17 = property9.compareTo((org.joda.time.ReadablePartial) monthDay12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(localDate16);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter1.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 'a', dateTimeZone5);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        java.lang.String str9 = dateTimeZone5.getName((-359999990L));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a', dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 'a', dateTimeZone16);
        org.joda.time.DateTime dateTime18 = dateTime13.withZoneRetainFields(dateTimeZone16);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime20 = dateTime13.minus(readableDuration19);
        org.joda.time.DateTime dateTime22 = dateTime20.minusMinutes((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long28 = dateTimeZone24.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
        org.joda.time.DateTime dateTime30 = dateTime22.toDateTime(dateTimeZone29);
        long long32 = dateTimeZone5.getMillisKeepLocal(dateTimeZone29, 0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter1.withZone(dateTimeZone5);
        try {
            org.joda.time.MonthDay monthDay34 = org.joda.time.MonthDay.parse("hi!", dateTimeFormatter33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+100:00" + "'", str9.equals("+100:00"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-359999990L) + "'", long28 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        java.util.Locale locale24 = null;
        try {
            long long25 = dividedDateTimeField21.set((long) 6, "", locale24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property3.getFieldType();
        int int5 = property3.getMaximumValue();
        int int6 = property3.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis(4, 4, (int) (short) 100, (int) ' ', 0, (int) (short) 0, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) (short) 1);
        org.joda.time.DateTime dateTime7 = dateTime3.withYearOfCentury(9);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.DateTime dateTime10 = dateTime7.withZone(dateTimeZone9);
        int int11 = dateTime10.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) (short) 1);
        org.joda.time.DateTime dateTime7 = dateTime3.withYearOfCentury(9);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.DateTime dateTime10 = dateTime7.withZone(dateTimeZone9);
        try {
            org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, 0L, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 'a', dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a', dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.withZoneRetainFields(dateTimeZone12);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        int int16 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 'a', dateTimeZone19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) dateTime5, dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 'a', dateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 'a', dateTimeZone28);
        org.joda.time.DateTime dateTime30 = dateTime25.withZoneRetainFields(dateTimeZone28);
        org.joda.time.LocalTime localTime31 = dateTime30.toLocalTime();
        org.joda.time.DateTime dateTime33 = dateTime30.plusSeconds(0);
        org.joda.time.DateTime.Property property34 = dateTime30.monthOfYear();
        int int35 = dateTime30.getYear();
        try {
            org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, (org.joda.time.ReadableInstant) dateTime30, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getName();
        boolean boolean6 = property3.equals((java.lang.Object) 360000000);
        org.joda.time.MonthDay monthDay8 = property3.addToCopy(8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(monthDay8);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfSecond();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now(chronology3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear(1970, false);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.millisOfSecond();
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.monthOfYear();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology15.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder19.appendMonthOfYear((int) (short) 100);
        boolean boolean25 = dateTimeFormatterBuilder24.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.millisOfSecond();
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.MonthDay.Property property29 = monthDay28.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder24.appendShortText(dateTimeFieldType30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField18, dateTimeFieldType30, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder8.appendFixedSignedDecimal(dateTimeFieldType30, (int) (byte) 1);
        try {
            org.joda.time.MonthDay monthDay37 = monthDay4.withField(dateTimeFieldType30, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMonthOfYear((int) (short) 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.millisOfSecond();
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = monthDay8.getFieldType((int) (byte) 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendDecimal(dateTimeFieldType10, (-292269056), 360000000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        try {
            long long6 = gJChronology0.getDateTimeMillis((int) 'a', (-1), 4, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        int int23 = skipDateTimeField6.getMinimumValue(207L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292269054) + "'", int23 == (-292269054));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant2 = instant0.minus((long) 83);
        org.junit.Assert.assertNotNull(instant2);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray4 = iSOChronology0.get(readablePeriod2, (-292269056L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra(0);
        int int8 = dateTime5.getYear();
        org.joda.time.DateTime.Property property9 = dateTime5.weekyear();
        int int10 = dateTime5.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 'a', dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a', dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.withZoneRetainFields(dateTimeZone12);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        int int16 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime14);
        try {
            org.joda.time.DateTime dateTime18 = dateTime14.withEra((int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipDateTimeField6.getAsShortText((int) (short) 0, locale9);
        java.lang.String str11 = skipDateTimeField6.getName();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.millisOfSecond();
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        java.lang.String str16 = property15.getAsText();
        org.joda.time.DateTimeField dateTimeField17 = property15.getField();
        org.joda.time.MonthDay monthDay19 = property15.addWrapFieldToCopy((int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField22 = iSOChronology21.eras();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 'a', dateTimeZone25);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 'a', dateTimeZone29);
        org.joda.time.DateTime dateTime31 = dateTime26.withZoneRetainFields(dateTimeZone29);
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.DateTime dateTime33 = dateTime26.minus(readableDuration32);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField36 = iSOChronology35.eras();
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology35.millisOfSecond();
        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology35);
        org.joda.time.DateTime dateTime39 = dateTime33.withFields((org.joda.time.ReadablePartial) monthDay38);
        int[] intArray41 = iSOChronology21.get((org.joda.time.ReadablePartial) monthDay38, (-62137152000001L));
        try {
            int[] intArray43 = skipDateTimeField6.set((org.joda.time.ReadablePartial) monthDay19, 15382789, intArray41, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 15382789");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "weekyear" + "'", str11.equals("weekyear"));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "December" + "'", str16.equals("December"));
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(intArray41);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        java.util.Locale locale13 = null;
        try {
            java.lang.String str14 = unsupportedDateTimeField11.getAsText((int) (byte) 10, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "December" + "'", str4.equals("December"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.Instant instant3 = instant1.minus((long) (byte) 0);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant6 = instant1.minus((long) (short) 1);
        org.joda.time.Instant instant8 = instant1.plus((long) 1);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField13 = iSOChronology12.eras();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.millisOfSecond();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime16 = dateTime10.withFields((org.joda.time.ReadablePartial) monthDay15);
        org.joda.time.DateTime dateTime18 = dateTime10.plusMillis((int) 'a');
        int int19 = dateTime18.getWeekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 'a', dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime23.plusDays((int) (short) 1);
        boolean boolean26 = dateTime25.isEqualNow();
        int int27 = dateTime25.getMillisOfSecond();
        org.joda.time.DateTime dateTime29 = dateTime25.withCenturyOfEra((int) (byte) 100);
        boolean boolean30 = dateTime18.isEqual((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime.Property property31 = dateTime25.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 97 + "'", int27 == 97);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(property31);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long5 = dateTimeZone1.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        int int8 = dateTimeZone6.getOffsetFromLocal(0L);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        try {
            long long17 = julianChronology9.getDateTimeMillis(83, (-292269056), 14400097, 1970, 0, 10, (-292269056));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-359999990L) + "'", long5 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 360000000 + "'", int8 == 360000000);
        org.junit.Assert.assertNotNull(julianChronology9);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) (short) 1);
        org.joda.time.DateTime dateTime7 = dateTime3.withYearOfCentury(9);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.DateTime dateTime10 = dateTime7.withZone(dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime10.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DurationField durationField7 = property3.getDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "December" + "'", str4.equals("December"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((-62137152000001L), (long) 360000000, (-292269056));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-105278997312000001L) + "'", long4 == (-105278997312000001L));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property3.getFieldType();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property3.getAsShortText(locale5);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Dec" + "'", str6.equals("Dec"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("AM", false, (int) (short) 10, (int) '4');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendFractionOfSecond(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
        org.joda.time.DateTime dateTime11 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (-1));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        long long10 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeField dateTimeField11 = property4.getField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) ' ');
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.millisOfSecond();
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField[] dateTimeFieldArray15 = monthDay14.getFields();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField18 = iSOChronology17.eras();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 'a', dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 'a', dateTimeZone25);
        org.joda.time.DateTime dateTime27 = dateTime22.withZoneRetainFields(dateTimeZone25);
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime29 = dateTime22.minus(readableDuration28);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField32 = iSOChronology31.eras();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.millisOfSecond();
        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTime dateTime35 = dateTime29.withFields((org.joda.time.ReadablePartial) monthDay34);
        int[] intArray37 = iSOChronology17.get((org.joda.time.ReadablePartial) monthDay34, (-62137152000001L));
        try {
            int[] intArray39 = unsupportedDateTimeField11.addWrapPartial((org.joda.time.ReadablePartial) monthDay14, (-292269054), intArray37, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "December" + "'", str4.equals("December"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldArray15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(intArray37);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gJChronology0.seconds();
        java.lang.String str3 = gJChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 'a', dateTimeZone10);
        org.joda.time.DateTime dateTime12 = dateTime7.withZoneRetainFields(dateTimeZone10);
        boolean boolean13 = dateTime7.isBeforeNow();
        boolean boolean14 = gJChronology0.equals((java.lang.Object) dateTime7);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[UTC]" + "'", str3.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneShortName();
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatterBuilder16.toParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder7.append(dateTimePrinter8, dateTimeParser17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 197);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        org.joda.time.Chronology chronology4 = dateTimeFormatter2.getChronolgy();
        java.io.Writer writer5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.millisOfSecond();
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.MonthDay.Property property9 = monthDay8.monthOfYear();
        java.lang.String str10 = property9.getAsText();
        org.joda.time.DateTimeField dateTimeField11 = property9.getField();
        org.joda.time.MonthDay monthDay13 = property9.addWrapFieldToCopy((int) (byte) 1);
        java.lang.String str14 = monthDay13.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.eras();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.millisOfSecond();
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.millisOfSecond();
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology20);
        org.joda.time.DateTimeField[] dateTimeFieldArray23 = monthDay22.getFields();
        boolean boolean24 = monthDay19.isBefore((org.joda.time.ReadablePartial) monthDay22);
        int int25 = monthDay13.compareTo((org.joda.time.ReadablePartial) monthDay19);
        try {
            dateTimeFormatter2.printTo(writer5, (org.joda.time.ReadablePartial) monthDay19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
        org.junit.Assert.assertNull(chronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "December" + "'", str10.equals("December"));
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "--01-31" + "'", str14.equals("--01-31"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeFieldArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("AM");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"AM/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 'a', dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime16 = dateTime14.withCenturyOfEra(0);
        boolean boolean17 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime19 = dateTime16.plusHours(1439);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        try {
            long long14 = unsupportedDateTimeField11.set((long) (byte) 100, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "December" + "'", str4.equals("December"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        java.lang.String str2 = dateTimeZone1.getID();
        java.lang.String str4 = dateTimeZone1.getShortName((long) (short) -1);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        try {
            org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) 14400097, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+100:00" + "'", str2.equals("+100:00"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+100:00" + "'", str4.equals("+100:00"));
        org.junit.Assert.assertNotNull(julianChronology5);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        java.lang.String str7 = property3.getAsShortText();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "December" + "'", str4.equals("December"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Dec" + "'", str7.equals("Dec"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 197);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        java.lang.Appendable appendable4 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 'a', dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone11);
        org.joda.time.LocalTime localTime14 = dateTime13.toLocalTime();
        org.joda.time.DateTime dateTime16 = dateTime13.plusSeconds(0);
        org.joda.time.DateTime.Property property17 = dateTime13.monthOfYear();
        try {
            dateTimeFormatter2.printTo(appendable4, (org.joda.time.ReadableInstant) dateTime13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        long long23 = dividedDateTimeField21.roundHalfEven((long) (byte) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int[] intArray26 = null;
        try {
            int[] intArray28 = dividedDateTimeField21.set(readablePartial24, 97, intArray26, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 190252800000L + "'", long23 == 190252800000L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.millisOfSecond();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType9, 1);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.millisOfSecond();
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.monthOfYear();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology15.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder19.appendMonthOfYear((int) (short) 100);
        boolean boolean25 = dateTimeFormatterBuilder24.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.millisOfSecond();
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.MonthDay.Property property29 = monthDay28.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder24.appendShortText(dateTimeFieldType30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField18, dateTimeFieldType30, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder11.appendFraction(dateTimeFieldType30, 8, 14400097);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFixedSignedDecimal(dateTimeFieldType37, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.millisOfSecond();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType9, 1);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.millisOfSecond();
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.monthOfYear();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology15.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder19.appendMonthOfYear((int) (short) 100);
        boolean boolean25 = dateTimeFormatterBuilder24.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.millisOfSecond();
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.MonthDay.Property property29 = monthDay28.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder24.appendShortText(dateTimeFieldType30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField18, dateTimeFieldType30, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder11.appendFraction(dateTimeFieldType30, 8, 14400097);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder11.appendPattern("1969");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property3.getFieldType();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra(0);
        org.joda.time.DateTime dateTime8 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        java.lang.String str11 = property9.getAsShortText();
        int int12 = property9.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1439 + "'", int12 == 1439);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekyear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendMonthOfYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendYearOfEra(12, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 'a', dateTimeZone16);
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.era();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser28 = dateTimeFormatterBuilder27.toParser();
        boolean boolean29 = buddhistChronology18.equals((java.lang.Object) dateTimeParser28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder3.appendOptional(dateTimeParser28);
        boolean boolean31 = julianChronology0.equals((java.lang.Object) dateTimeFormatterBuilder30);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap32 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder30.appendTimeZoneName(strMap32);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeParser28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfSecond();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.monthOfYear();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology7.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology4, dateTimeField9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = skipDateTimeField10.getType();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField13 = iSOChronology12.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField14 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField13);
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) unsupportedDateTimeField14);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField14);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology6.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (-292269056), false);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(100, (int) 'a', (int) (short) 10, (int) (byte) 100, (-292269056), (int) (byte) 0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-292269056L) + "'", long10 == (-292269056L));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 'a', dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime16 = dateTime14.withCenturyOfEra(0);
        boolean boolean17 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.LocalTime localTime9 = dateTime8.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds(0);
        org.joda.time.DateTime.Property property12 = dateTime8.monthOfYear();
        int int13 = dateTime8.getYear();
        try {
            org.joda.time.DateTime dateTime15 = dateTime8.withHourOfDay(1439);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1439 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32) + "'", int1 == (-32));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("monthOfYear");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: monthOfYear");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMonthOfYear((int) (short) 100);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendYearOfCentury((int) (byte) 100, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-1L), (long) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-100) + "'", int2 == (-100));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 'a', dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a', dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.withZoneRetainFields(dateTimeZone12);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        int int16 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.toDateTimeISO();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 'a', dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.minuteOfDay();
        org.joda.time.DateTime.Property property23 = dateTime21.millisOfDay();
        org.joda.time.DateTime.Property property24 = dateTime21.dayOfWeek();
        org.joda.time.DateTime dateTime25 = dateTime21.withEarlierOffsetAtOverlap();
        boolean boolean26 = dateTime14.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.Chronology chronology27 = dateTime14.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(chronology27);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        try {
            long long13 = unsupportedDateTimeField11.remainder((-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "December" + "'", str4.equals("December"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 15382789, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 'a', dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a', dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.withZoneRetainFields(dateTimeZone12);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        int int16 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.toDateTimeISO();
        org.joda.time.DateTime.Property property18 = dateTime17.minuteOfDay();
        org.joda.time.DateTime dateTime19 = property18.withMaximumValue();
        org.joda.time.DateTime.Property property20 = dateTime19.year();
        org.joda.time.DurationField durationField21 = property20.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNull(durationField21);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        java.util.Locale locale24 = null;
        long long25 = dividedDateTimeField21.set((long) 360000000, "1969", locale24);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1118843467200000L + "'", long25 == 1118843467200000L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipDateTimeField6.getAsShortText((int) (short) 0, locale9);
        java.lang.String str11 = skipDateTimeField6.getName();
        long long13 = skipDateTimeField6.roundHalfEven((long) (short) 10);
        boolean boolean14 = skipDateTimeField6.isLenient();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "weekyear" + "'", str11.equals("weekyear"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 950400000L + "'", long13 == 950400000L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField1 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField8 = iSOChronology7.eras();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.millisOfSecond();
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now(chronology10);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(0, (-292269054), (-10), 100, 9, (-1), 1439, chronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(monthDay11);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra(0);
        java.util.Date date8 = dateTime7.toDate();
        org.joda.time.Instant instant9 = dateTime7.toInstant();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) (short) -1);
        int int9 = property6.getMinimumValue();
        java.util.Locale locale11 = null;
        try {
            org.joda.time.DateTime dateTime12 = property6.setCopy("(\"org.joda.time.JodaTimePermission\" \"hi!\")", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"(\"org.joda.time.JodaTimePermission\" \"hi!\")\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra(0);
        java.util.Date date8 = dateTime7.toDate();
        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
        org.joda.time.Interval interval10 = property9.toInterval();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(interval10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        java.lang.String str2 = dateTimeZone1.getID();
        java.lang.String str4 = dateTimeZone1.getShortName((long) (short) -1);
        long long8 = dateTimeZone1.convertLocalToUTC((long) (short) 100, true, (-359999990L));
        long long11 = dateTimeZone1.adjustOffset((long) (-100), true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+100:00" + "'", str2.equals("+100:00"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+100:00" + "'", str4.equals("+100:00"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-359999900L) + "'", long8 == (-359999900L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-100L) + "'", long11 == (-100L));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.MonthDay monthDay7 = property3.addWrapFieldToCopy((int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.monthOfYear();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology8, dateTimeField13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField14.getType();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField17);
        try {
            int int19 = monthDay7.get(dateTimeFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "December" + "'", str4.equals("December"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        try {
            long long24 = dividedDateTimeField21.add((long) (-32), 1118843467200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 21258025876800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.era();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology4.halfdayOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        java.util.Locale locale9 = null;
        java.lang.String str10 = delegatedDateTimeField7.getAsShortText((long) (byte) 10, locale9);
        long long12 = delegatedDateTimeField7.roundFloor((-100L));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "AM" + "'", str10.equals("AM"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-14400000L) + "'", long12 == (-14400000L));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMinutes((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long18 = dateTimeZone14.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.joda.time.DateTime dateTime20 = dateTime12.toDateTime(dateTimeZone19);
        boolean boolean21 = dateTime12.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-359999990L) + "'", long18 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.LocalTime localTime9 = dateTime8.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds(0);
        int int12 = dateTime11.getWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime11.minusHours((int) '#');
        long long15 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.withSecondOfMinute(6);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-125999903L) + "'", long15 == (-125999903L));
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-359999903L));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        java.util.Locale locale13 = null;
        try {
            java.lang.String str14 = unsupportedDateTimeField11.getAsText(1970, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June" + "'", str4.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField9 = iSOChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField10 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField9);
        try {
            long long12 = unsupportedDateTimeField10.roundCeiling((long) 360000000);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField10);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "December");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMonthOfYear((int) (short) 100);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendMillisOfDay(4);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatterBuilder5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str8 = monthDay6.toString(dateTimeFormatter7);
        boolean boolean9 = monthDay2.isBefore((org.joda.time.ReadablePartial) monthDay6);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay11 = monthDay6.plus(readablePeriod10);
        java.util.Locale locale13 = null;
        try {
            java.lang.String str14 = monthDay11.toString("June", locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����-W��-�" + "'", str8.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(monthDay11);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str4 = monthDay2.toString(dateTimeFormatter3);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 'a', dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = monthDay2.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "����-W��-�" + "'", str4.equals("����-W��-�"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.Instant instant3 = instant1.minus((long) (byte) 0);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant6 = instant3.withDurationAdded(readableDuration4, (int) (byte) 1);
        org.joda.time.DateTime dateTime7 = instant6.toDateTime();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        boolean boolean9 = dateTime3.isBeforeNow();
        org.joda.time.DateTime dateTime11 = dateTime3.plusMillis(100);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Property[dayOfWeek]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Property[dayOfWeek]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("December", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"December/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology4.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipDateTimeField7.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType8);
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildParser();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(83, 197);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 197");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMonthOfYear((int) (short) 100);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.MonthDay.Property property10 = monthDay9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder5.appendMonthOfYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 59959141200097L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology4.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField6);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField6);
        long long10 = skipUndoDateTimeField8.roundHalfFloor((long) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfSecond();
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology11);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) ' ', locale15);
        long long19 = skipUndoDateTimeField8.set((long) (short) -1, 0);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.millisOfSecond();
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology20);
        org.joda.time.MonthDay.Property property23 = monthDay22.monthOfYear();
        java.lang.String str24 = property23.getName();
        int int25 = property23.get();
        org.joda.time.MonthDay monthDay27 = property23.setCopy("Jun");
        org.joda.time.MonthDay.Property property28 = monthDay27.dayOfMonth();
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.millisOfSecond();
        org.joda.time.DurationField durationField32 = iSOChronology30.halfdays();
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.millisOfSecond();
        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology33);
        org.joda.time.MonthDay.Property property36 = monthDay35.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology37.millisOfSecond();
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology37);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str41 = monthDay39.toString(dateTimeFormatter40);
        boolean boolean42 = monthDay35.isBefore((org.joda.time.ReadablePartial) monthDay39);
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.MonthDay monthDay44 = monthDay39.plus(readablePeriod43);
        int[] intArray46 = iSOChronology30.get((org.joda.time.ReadablePartial) monthDay39, 0L);
        try {
            int[] intArray48 = skipUndoDateTimeField8.add((org.joda.time.ReadablePartial) monthDay27, 2, intArray46, 197);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 950400000L + "'", long10 == 950400000L);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "32" + "'", str16.equals("32"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62137152000001L) + "'", long19 == (-62137152000001L));
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "monthOfYear" + "'", str24.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "����-W��-�" + "'", str41.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(intArray46);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMonthOfYear((int) (short) 100);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.MonthDay.Property property10 = monthDay9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        dateTimeFormatterBuilder5.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        java.lang.String str11 = dateTimeZone7.getName((-359999990L));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(83, (-32), 6, 97, 360000000, dateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+100:00" + "'", str11.equals("+100:00"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfSecond();
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = monthDay24.getFieldType((int) (byte) 0);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21, dateTimeFieldType26);
        long long29 = remainderDateTimeField27.roundHalfCeiling((long) 360000000);
        java.util.Locale locale31 = null;
        java.lang.String str32 = remainderDateTimeField27.getAsText((long) 8, locale31);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.eras();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.millisOfSecond();
        org.joda.time.MonthDay monthDay37 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology34);
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology38.millisOfSecond();
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology38);
        org.joda.time.DateTimeField[] dateTimeFieldArray41 = monthDay40.getFields();
        boolean boolean42 = monthDay37.isBefore((org.joda.time.ReadablePartial) monthDay40);
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.millisOfSecond();
        org.joda.time.DurationField durationField46 = iSOChronology44.halfdays();
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology47.millisOfSecond();
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology47);
        org.joda.time.MonthDay.Property property50 = monthDay49.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology51.millisOfSecond();
        org.joda.time.MonthDay monthDay53 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology51);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str55 = monthDay53.toString(dateTimeFormatter54);
        boolean boolean56 = monthDay49.isBefore((org.joda.time.ReadablePartial) monthDay53);
        org.joda.time.ReadablePeriod readablePeriod57 = null;
        org.joda.time.MonthDay monthDay58 = monthDay53.plus(readablePeriod57);
        int[] intArray60 = iSOChronology44.get((org.joda.time.ReadablePartial) monthDay53, 0L);
        try {
            int[] intArray62 = remainderDateTimeField27.add((org.joda.time.ReadablePartial) monthDay37, 2, intArray60, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 950400000L + "'", long29 == 950400000L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "12" + "'", str32.equals("12"));
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeFieldArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeFormatter54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "����-W��-�" + "'", str55.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(monthDay58);
        org.junit.Assert.assertNotNull(intArray60);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getName();
        int int5 = property3.get();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property3.getAsShortText(locale6);
        int int8 = property3.getMaximumValueOverall();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        boolean boolean10 = dateTimeFormatter9.isOffsetParsed();
        boolean boolean11 = property3.equals((java.lang.Object) boolean10);
        java.lang.String str12 = property3.getAsShortText();
        try {
            org.joda.time.MonthDay monthDay14 = property3.setCopy("hi!");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jun" + "'", str7.equals("Jun"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Jun" + "'", str12.equals("Jun"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        java.util.Locale locale22 = null;
        int int23 = dividedDateTimeField21.getMaximumTextLength(locale22);
        java.util.Locale locale24 = null;
        int int25 = dividedDateTimeField21.getMaximumTextLength(locale24);
        org.joda.time.DurationField durationField26 = dividedDateTimeField21.getDurationField();
        long long29 = dividedDateTimeField21.add((-292269056L), (int) (short) 10);
        long long31 = dividedDateTimeField21.roundHalfEven((long) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 8 + "'", int25 == 8);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 5995694930944L + "'", long29 == 5995694930944L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 190252800000L + "'", long31 == 190252800000L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField9 = iSOChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField10 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField9);
        try {
            int int12 = unsupportedDateTimeField10.getMaximumValue((long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField10);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType3, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField2 = julianChronology1.weekyears();
        org.joda.time.DurationField durationField3 = julianChronology1.weekyears();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField6 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField3, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long5 = dateTimeZone1.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        long long8 = dateTimeZone6.convertUTCToLocal((long) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-359999990L) + "'", long5 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 360000000L + "'", long8 == 360000000L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 'a', dateTimeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
        java.lang.String str8 = dateTimeZone4.getName((-359999990L));
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 'a', dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 'a', dateTimeZone15);
        org.joda.time.DateTime dateTime17 = dateTime12.withZoneRetainFields(dateTimeZone15);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime19 = dateTime12.minus(readableDuration18);
        org.joda.time.DateTime dateTime21 = dateTime19.minusMinutes((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long27 = dateTimeZone23.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.DateTime dateTime29 = dateTime21.toDateTime(dateTimeZone28);
        long long31 = dateTimeZone4.getMillisKeepLocal(dateTimeZone28, 0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter0.withZone(dateTimeZone4);
        java.io.Writer writer33 = null;
        try {
            dateTimeFormatter0.printTo(writer33, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+100:00" + "'", str8.equals("+100:00"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-359999990L) + "'", long27 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.LocalTime localTime9 = dateTime8.toLocalTime();
        org.joda.time.DateTime.Property property10 = dateTime8.era();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant12 = gJChronology11.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 'a', dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.minuteOfDay();
        org.joda.time.DateTime.Property property19 = dateTime17.millisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime17.dayOfWeek();
        org.joda.time.DateTime dateTime22 = property20.addToCopy((long) (short) -1);
        org.joda.time.MutableDateTime mutableDateTime23 = dateTime22.toMutableDateTimeISO();
        int int26 = dateTimeFormatter13.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime23, "����-W��-�", 0);
        java.lang.String str27 = instant12.toString(dateTimeFormatter13);
        org.joda.time.DateTime dateTime28 = instant12.toDateTime();
        try {
            int int29 = property10.getDifference((org.joda.time.ReadableInstant) instant12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1582W415T000000Z" + "'", str27.equals("1582W415T000000Z"));
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfSecond();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = monthDay4.getFieldType((int) (byte) 0);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType6, 15382789, 0, (-1));
        int int13 = offsetDateTimeField10.getDifference((long) (byte) 10, (-292269056L));
        int int14 = offsetDateTimeField10.getMaximumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        long long9 = skipDateTimeField6.roundHalfCeiling((long) 1439);
        int int11 = skipDateTimeField6.get(0L);
        long long13 = skipDateTimeField6.roundCeiling(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 950400000L + "'", long9 == 950400000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 950400000L + "'", long13 == 950400000L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) (short) -1);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property10 = dateTime8.weekyear();
        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
        int int12 = property10.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292275054) + "'", int12 == (-292275054));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 'a', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfSecond();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.monthOfYear();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology7.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology4, dateTimeField9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = skipDateTimeField10.getType();
        long long13 = skipDateTimeField10.roundHalfCeiling((long) 1439);
        int int15 = skipDateTimeField10.get(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) skipDateTimeField10);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.millisOfSecond();
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.MonthDay.Property property20 = monthDay19.monthOfYear();
        org.joda.time.MonthDay monthDay22 = property20.addToCopy(1970);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay22.minus(readablePeriod23);
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = julianChronology26.monthOfYear();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology26.weekyear();
        java.lang.String str29 = julianChronology26.toString();
        org.joda.time.DurationField durationField30 = julianChronology26.seconds();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) 'a', dateTimeZone33);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) 'a', dateTimeZone37);
        org.joda.time.DateTime dateTime39 = dateTime34.withZoneRetainFields(dateTimeZone37);
        org.joda.time.LocalTime localTime40 = dateTime39.toLocalTime();
        int[] intArray42 = julianChronology26.get((org.joda.time.ReadablePartial) localTime40, (long) 6);
        try {
            int[] intArray44 = skipDateTimeField10.addWrapPartial((org.joda.time.ReadablePartial) monthDay24, 0, intArray42, 14400097);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 14400096");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 950400000L + "'", long13 == 950400000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[UTC]" + "'", str29.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localTime40);
        org.junit.Assert.assertNotNull(intArray42);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 1969, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1967L + "'", long2 == 1967L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField9 = iSOChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField10 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField9);
        try {
            int int12 = unsupportedDateTimeField10.get((long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField10);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-15382582), (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMinuteOfDay((int) (short) 1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendFractionOfDay((-292269054), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology4.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField6);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField6);
        long long10 = skipUndoDateTimeField8.roundHalfFloor((long) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfSecond();
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology11);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) ' ', locale15);
        long long19 = skipUndoDateTimeField8.set((long) (short) -1, 0);
        long long21 = skipUndoDateTimeField8.roundHalfEven((long) (byte) 100);
        long long24 = skipUndoDateTimeField8.set((long) 'a', (int) 'a');
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipUndoDateTimeField8.getAsText((int) 'a', locale26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.millisOfSecond();
        org.joda.time.DurationField durationField30 = iSOChronology28.halfdays();
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.millisOfSecond();
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology31);
        org.joda.time.MonthDay.Property property34 = monthDay33.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.millisOfSecond();
        org.joda.time.MonthDay monthDay37 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology35);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str39 = monthDay37.toString(dateTimeFormatter38);
        boolean boolean40 = monthDay33.isBefore((org.joda.time.ReadablePartial) monthDay37);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.MonthDay monthDay42 = monthDay37.plus(readablePeriod41);
        int[] intArray44 = iSOChronology28.get((org.joda.time.ReadablePartial) monthDay37, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField47 = iSOChronology46.millisOfSecond();
        org.joda.time.DurationField durationField48 = iSOChronology46.halfdays();
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.millisOfSecond();
        org.joda.time.MonthDay monthDay51 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology49);
        org.joda.time.MonthDay.Property property52 = monthDay51.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology53.millisOfSecond();
        org.joda.time.MonthDay monthDay55 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology53);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str57 = monthDay55.toString(dateTimeFormatter56);
        boolean boolean58 = monthDay51.isBefore((org.joda.time.ReadablePartial) monthDay55);
        org.joda.time.ReadablePeriod readablePeriod59 = null;
        org.joda.time.MonthDay monthDay60 = monthDay55.plus(readablePeriod59);
        int[] intArray62 = iSOChronology46.get((org.joda.time.ReadablePartial) monthDay55, 0L);
        try {
            int[] intArray64 = skipUndoDateTimeField8.addWrapPartial((org.joda.time.ReadablePartial) monthDay37, (-15382582), intArray62, 197);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -15382582");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 950400000L + "'", long10 == 950400000L);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "32" + "'", str16.equals("32"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62137152000001L) + "'", long19 == (-62137152000001L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 950400000L + "'", long21 == 950400000L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-59075654399903L) + "'", long24 == (-59075654399903L));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "97" + "'", str27.equals("97"));
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "����-W��-�" + "'", str39.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "����-W��-�" + "'", str57.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(monthDay60);
        org.junit.Assert.assertNotNull(intArray62);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 59959141200097L, (java.lang.Number) (short) 0, (java.lang.Number) 360000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField9 = iSOChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField10 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfSecond();
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.MonthDay.Property property14 = monthDay13.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.millisOfSecond();
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str19 = monthDay17.toString(dateTimeFormatter18);
        boolean boolean20 = monthDay13.isBefore((org.joda.time.ReadablePartial) monthDay17);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfSecond();
        org.joda.time.DurationField durationField24 = iSOChronology22.halfdays();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.millisOfSecond();
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology25);
        org.joda.time.MonthDay.Property property28 = monthDay27.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.millisOfSecond();
        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str33 = monthDay31.toString(dateTimeFormatter32);
        boolean boolean34 = monthDay27.isBefore((org.joda.time.ReadablePartial) monthDay31);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.MonthDay monthDay36 = monthDay31.plus(readablePeriod35);
        int[] intArray38 = iSOChronology22.get((org.joda.time.ReadablePartial) monthDay31, 0L);
        try {
            int[] intArray40 = unsupportedDateTimeField10.addWrapField((org.joda.time.ReadablePartial) monthDay13, 100, intArray38, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "����-W��-�" + "'", str19.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "����-W��-�" + "'", str33.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(intArray38);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 'a', dateTimeZone13);
        boolean boolean15 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime14);
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = dateTime14.toString("", locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((-125999903L));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        int int14 = unsupportedDateTimeField11.getDifference(0L, (-359999903L));
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.eras();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 'a', dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 'a', dateTimeZone23);
        org.joda.time.DateTime dateTime25 = dateTime20.withZoneRetainFields(dateTimeZone23);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime27 = dateTime20.minus(readableDuration26);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField30 = iSOChronology29.eras();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology29.millisOfSecond();
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology29);
        org.joda.time.DateTime dateTime33 = dateTime27.withFields((org.joda.time.ReadablePartial) monthDay32);
        int[] intArray35 = iSOChronology15.get((org.joda.time.ReadablePartial) monthDay32, (-62137152000001L));
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.MonthDay monthDay37 = monthDay32.minus(readablePeriod36);
        try {
            int int38 = unsupportedDateTimeField11.getMaximumValue((org.joda.time.ReadablePartial) monthDay32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June" + "'", str4.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(monthDay37);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        long long9 = skipDateTimeField6.roundHalfCeiling((long) 1439);
        try {
            org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((java.lang.Object) 1439);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 950400000L + "'", long9 == 950400000L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        int int6 = dateTime3.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.weekyears();
        org.joda.time.DurationField durationField2 = julianChronology0.weekyears();
        try {
            long long10 = julianChronology0.getDateTimeMillis(6, 360000000, (int) (byte) 100, 197, (int) '#', 1970, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 197 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 83, (java.lang.Number) (-1), (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) (short) -1);
        int int9 = property6.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a', dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 'a', dateTimeZone16);
        org.joda.time.DateTime dateTime18 = dateTime13.withZoneRetainFields(dateTimeZone16);
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        org.joda.time.DateTime dateTime21 = dateTime18.plusSeconds(0);
        int int22 = dateTime21.getWeekyear();
        org.joda.time.DateTime dateTime24 = dateTime21.minusHours((int) '#');
        org.joda.time.DateTime dateTime26 = dateTime21.withEra(0);
        int int27 = property6.compareTo((org.joda.time.ReadableInstant) dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1970 + "'", int22 == 1970);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        java.lang.String str7 = dateTimeZone6.getID();
        java.lang.String str9 = dateTimeZone6.getShortName((long) (short) -1);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(dateTimeZone6);
        org.joda.time.Chronology chronology12 = buddhistChronology4.withZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+100:00" + "'", str7.equals("+100:00"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+100:00" + "'", str9.equals("+100:00"));
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("org.joda.time.IllegalFieldValueException: : Value \"hi!\" for hi! is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'org.joda.time.IllegalFieldValueException: : Value \"hi!\" for hi! is not supported' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DurationField durationField2 = iSOChronology0.halfdays();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.MonthDay.Property property6 = monthDay5.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str11 = monthDay9.toString(dateTimeFormatter10);
        boolean boolean12 = monthDay5.isBefore((org.joda.time.ReadablePartial) monthDay9);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay14 = monthDay9.plus(readablePeriod13);
        int[] intArray16 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        try {
            java.lang.String str18 = monthDay9.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-W��-�" + "'", str11.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekyear();
        org.joda.time.DurationField durationField3 = julianChronology0.weekyears();
        long long7 = julianChronology0.add(1967L, 0L, 12);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1967L + "'", long7 == 1967L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.monthOfYear();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology13, dateTimeField18);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology12, dateTimeField18);
        long long22 = skipUndoDateTimeField20.roundHalfFloor((long) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.millisOfSecond();
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology23);
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField20.getAsText((org.joda.time.ReadablePartial) monthDay25, (int) ' ', locale27);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.millisOfSecond();
        org.joda.time.DurationField durationField32 = iSOChronology30.halfdays();
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.millisOfSecond();
        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology33);
        org.joda.time.MonthDay.Property property36 = monthDay35.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology37.millisOfSecond();
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology37);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str41 = monthDay39.toString(dateTimeFormatter40);
        boolean boolean42 = monthDay35.isBefore((org.joda.time.ReadablePartial) monthDay39);
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.MonthDay monthDay44 = monthDay39.plus(readablePeriod43);
        int[] intArray46 = iSOChronology30.get((org.joda.time.ReadablePartial) monthDay39, 0L);
        try {
            int[] intArray48 = unsupportedDateTimeField11.addWrapField((org.joda.time.ReadablePartial) monthDay25, 15382789, intArray46, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June" + "'", str4.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 950400000L + "'", long22 == 950400000L);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "32" + "'", str28.equals("32"));
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "����-W��-�" + "'", str41.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(intArray46);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.millisOfSecond();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.monthOfYear();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology8, dateTimeField13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField14.getType();
        long long17 = skipDateTimeField14.roundHalfCeiling((long) 1439);
        int int19 = skipDateTimeField14.get(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, (org.joda.time.DateTimeField) skipDateTimeField14);
        org.joda.time.DateTime dateTime21 = instant1.toDateTime(chronology7);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 950400000L + "'", long17 == 950400000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(9, 8, 0, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfSecond();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = monthDay4.getFieldType((int) (byte) 0);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType6, 15382789, 0, (-1));
        int int13 = offsetDateTimeField10.getDifference((long) (byte) 10, (-292269056L));
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        java.lang.String str18 = property17.getName();
        int int19 = property17.get();
        java.util.Locale locale20 = null;
        java.lang.String str21 = property17.getAsShortText(locale20);
        int int22 = property17.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay24 = property17.setCopy(10);
        int int25 = offsetDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) monthDay24);
        try {
            long long28 = offsetDateTimeField10.add((long) (short) -1, (-15382582));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15382791 for monthOfYear must be in the range [15382790,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "monthOfYear" + "'", str18.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Jun" + "'", str21.equals("Jun"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15382790 + "'", int25 == 15382790);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getName();
        int int5 = property3.get();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property3.getAsShortText(locale6);
        int int8 = property3.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay10 = property3.setCopy(10);
        org.joda.time.MonthDay monthDay12 = property3.addWrapFieldToCopy((int) 'a');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jun" + "'", str7.equals("Jun"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField9 = iSOChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField10 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfSecond();
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.monthOfYear();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology14.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology11, dateTimeField16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        long long20 = skipDateTimeField17.roundCeiling((long) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField23 = iSOChronology22.eras();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.millisOfSecond();
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology22);
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) monthDay25, 100, locale27);
        org.joda.time.MonthDay.Property property29 = monthDay25.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = julianChronology31.monthOfYear();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology31.weekyear();
        java.lang.String str34 = julianChronology31.toString();
        org.joda.time.DurationField durationField35 = julianChronology31.seconds();
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 'a', dateTimeZone38);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) 'a', dateTimeZone42);
        org.joda.time.DateTime dateTime44 = dateTime39.withZoneRetainFields(dateTimeZone42);
        org.joda.time.LocalTime localTime45 = dateTime44.toLocalTime();
        int[] intArray47 = julianChronology31.get((org.joda.time.ReadablePartial) localTime45, (long) 6);
        try {
            int[] intArray49 = unsupportedDateTimeField10.set((org.joda.time.ReadablePartial) monthDay25, (int) (byte) 100, intArray47, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 950400000L + "'", long20 == 950400000L);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "100" + "'", str28.equals("100"));
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "JulianChronology[UTC]" + "'", str34.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(localTime45);
        org.junit.Assert.assertNotNull(intArray47);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfSecond();
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        int int14 = unsupportedDateTimeField11.getDifference(0L, (-359999903L));
        try {
            int int15 = unsupportedDateTimeField11.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June" + "'", str4.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.millisOfSecond();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType9, 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfHalfday(4);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendYearOfEra(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property12 = dateTime3.minuteOfHour();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumTextLength(locale13);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.era();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField7 = iSOChronology6.eras();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology4, dateTimeField8, 12);
        int int11 = skipUndoDateTimeField10.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 999 + "'", int11 == 999);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField13 = iSOChronology12.eras();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.millisOfSecond();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime16 = dateTime10.withFields((org.joda.time.ReadablePartial) monthDay15);
        org.joda.time.DateTime dateTime18 = dateTime10.plusMillis((int) 'a');
        org.joda.time.DateTime dateTime20 = dateTime18.plus(0L);
        org.joda.time.DateTime dateTime22 = dateTime18.withMinuteOfHour(6);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        long long10 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("32");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.millisOfSecond();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType9, 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder13.appendFractionOfMinute(100, (int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(4, (int) '#', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 5995694930944L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        int int14 = unsupportedDateTimeField11.getDifference(0L, (-359999903L));
        try {
            long long17 = unsupportedDateTimeField11.set((-105278997312000001L), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June" + "'", str4.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = skipDateTimeField9.getType();
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField9.getAsShortText((int) (short) 0, locale12);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) skipDateTimeField9);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.millisOfSecond();
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology15);
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipUndoDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) monthDay17, (int) 'a', locale19);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField23 = iSOChronology22.eras();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.millisOfSecond();
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology22);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.millisOfSecond();
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField[] dateTimeFieldArray29 = monthDay28.getFields();
        boolean boolean30 = monthDay25.isBefore((org.joda.time.ReadablePartial) monthDay28);
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipUndoDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) monthDay28, 197, locale32);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.millisOfSecond();
        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.MonthDay.Property property37 = monthDay36.monthOfYear();
        java.lang.String str38 = property37.getAsText();
        org.joda.time.DateTimeField dateTimeField39 = property37.getField();
        org.joda.time.MonthDay monthDay41 = property37.addWrapFieldToCopy((int) (byte) 1);
        java.util.Locale locale42 = null;
        try {
            java.lang.String str43 = skipUndoDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) monthDay41, locale42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "97" + "'", str20.equals("97"));
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeFieldArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "197" + "'", str33.equals("197"));
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(monthDay41);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.LocalTime localTime9 = dateTime8.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds(0);
        int int12 = dateTime11.getWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime11.minusHours((int) '#');
        org.joda.time.DateTime dateTime16 = dateTime14.withYearOfEra(12);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField13 = iSOChronology12.eras();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.millisOfSecond();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime16 = dateTime10.withFields((org.joda.time.ReadablePartial) monthDay15);
        org.joda.time.DateTime dateTime18 = dateTime10.plusMillis((int) 'a');
        int int19 = dateTime18.getWeekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 'a', dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime23.plusDays((int) (short) 1);
        boolean boolean26 = dateTime25.isEqualNow();
        int int27 = dateTime25.getMillisOfSecond();
        org.joda.time.DateTime dateTime29 = dateTime25.withCenturyOfEra((int) (byte) 100);
        boolean boolean30 = dateTime18.isEqual((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime.Property property31 = dateTime18.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 97 + "'", int27 == 97);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(property31);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology4.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField6);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField6);
        long long10 = skipUndoDateTimeField8.roundHalfFloor((long) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfSecond();
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology11);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) ' ', locale15);
        long long19 = skipUndoDateTimeField8.set((long) (short) -1, 0);
        long long21 = skipUndoDateTimeField8.roundHalfEven((long) (byte) 100);
        long long24 = skipUndoDateTimeField8.set((long) 'a', (int) 'a');
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipUndoDateTimeField8.getAsText((int) 'a', locale26);
        int int29 = skipUndoDateTimeField8.getMinimumValue((long) 19);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 950400000L + "'", long10 == 950400000L);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "32" + "'", str16.equals("32"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62137152000001L) + "'", long19 == (-62137152000001L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 950400000L + "'", long21 == 950400000L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-59075654399903L) + "'", long24 == (-59075654399903L));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "97" + "'", str27.equals("97"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292269054) + "'", int29 == (-292269054));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
        org.joda.time.DateTime.Property property11 = dateTime10.year();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 'a', dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 'a', dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 'a', dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime21.withZoneRetainFields(dateTimeZone24);
        org.joda.time.LocalTime localTime27 = dateTime26.toLocalTime();
        int int28 = dateTime17.compareTo((org.joda.time.ReadableInstant) dateTime26);
        int int29 = property11.compareTo((org.joda.time.ReadableInstant) dateTime26);
        long long30 = property11.remainder();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 360000097L + "'", long30 == 360000097L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField6 = iSOChronology5.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 'a', dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.minuteOfDay();
        org.joda.time.DateTime.Property property13 = dateTime11.millisOfDay();
        org.joda.time.DateTime.Property property14 = dateTime11.dayOfWeek();
        org.joda.time.DateTime dateTime15 = dateTime11.withEarlierOffsetAtOverlap();
        java.util.GregorianCalendar gregorianCalendar16 = dateTime15.toGregorianCalendar();
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar16);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.millisOfSecond();
        org.joda.time.DurationField durationField21 = iSOChronology19.halfdays();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfSecond();
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.MonthDay.Property property25 = monthDay24.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.millisOfSecond();
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str30 = monthDay28.toString(dateTimeFormatter29);
        boolean boolean31 = monthDay24.isBefore((org.joda.time.ReadablePartial) monthDay28);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.MonthDay monthDay33 = monthDay28.plus(readablePeriod32);
        int[] intArray35 = iSOChronology19.get((org.joda.time.ReadablePartial) monthDay28, 0L);
        try {
            int[] intArray37 = unsupportedDateTimeField7.add((org.joda.time.ReadablePartial) monthDay17, 0, intArray35, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gregorianCalendar16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "����-W��-�" + "'", str30.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(intArray35);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        java.util.Locale locale22 = null;
        int int23 = dividedDateTimeField21.getMaximumTextLength(locale22);
        java.util.Locale locale24 = null;
        int int25 = dividedDateTimeField21.getMaximumTextLength(locale24);
        org.joda.time.DurationField durationField26 = dividedDateTimeField21.getDurationField();
        long long29 = dividedDateTimeField21.add((-292269056L), (int) (short) 10);
        org.joda.time.DurationField durationField30 = dividedDateTimeField21.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 8 + "'", int25 == 8);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 5995694930944L + "'", long29 == 5995694930944L);
        org.junit.Assert.assertNull(durationField30);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.DurationField durationField4 = gJChronology2.seconds();
        try {
            org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(0, (int) '4', (org.joda.time.Chronology) gJChronology2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) (short) -1);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property10 = dateTime8.weekyear();
        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-86399903L) + "'", long11 == (-86399903L));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 'a', dateTimeZone3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone3);
        java.io.Writer writer6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.monthOfYear();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology10.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology7, dateTimeField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = skipDateTimeField13.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.millisOfSecond();
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.MonthDay.Property property19 = monthDay18.monthOfYear();
        org.joda.time.MonthDay monthDay21 = property19.addToCopy(1970);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.MonthDay monthDay23 = monthDay21.minus(readablePeriod22);
        org.joda.time.MonthDay monthDay25 = monthDay23.withMonthOfYear(4);
        org.joda.time.MonthDay.Property property26 = monthDay23.dayOfMonth();
        int int27 = delegatedDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) monthDay23);
        try {
            dateTimeFormatter5.printTo(writer6, (org.joda.time.ReadablePartial) monthDay23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 292272992 + "'", int27 == 292272992);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getName();
        int int5 = property3.get();
        org.joda.time.MonthDay monthDay7 = property3.setCopy("Jun");
        org.joda.time.MonthDay.Property property8 = monthDay7.dayOfMonth();
        try {
            org.joda.time.MonthDay monthDay10 = property8.setCopy("100");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.Instant instant3 = instant1.minus((long) (byte) 0);
        boolean boolean4 = instant1.isBeforeNow();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfSecond();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = monthDay4.getFieldType((int) (byte) 0);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType6, 15382789, 0, (-1));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumTextLength(locale11);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField6 = iSOChronology5.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.MonthDay.Property property11 = monthDay10.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.millisOfSecond();
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str16 = monthDay14.toString(dateTimeFormatter15);
        boolean boolean17 = monthDay10.isBefore((org.joda.time.ReadablePartial) monthDay14);
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = unsupportedDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) monthDay14, (-15382582), locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "����-W��-�" + "'", str16.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.weekyears();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 197);
        boolean boolean5 = julianChronology0.equals((java.lang.Object) dateTimeFormatter4);
        java.io.Writer writer6 = null;
        try {
            dateTimeFormatter4.printTo(writer6, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField13 = iSOChronology12.eras();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.millisOfSecond();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime16 = dateTime10.withFields((org.joda.time.ReadablePartial) monthDay15);
        org.joda.time.DateTime dateTime18 = dateTime10.plusMillis((int) 'a');
        org.joda.time.DateTime dateTime20 = dateTime10.minus((-1L));
        java.util.Locale locale21 = null;
        java.util.Calendar calendar22 = dateTime10.toCalendar(locale21);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(calendar22);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.junit.Assert.assertNotNull(monthDay0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        java.util.Locale locale12 = null;
        try {
            int int13 = unsupportedDateTimeField11.getMaximumTextLength(locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June" + "'", str4.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(1970, false);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.monthOfYear();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology10.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology7, dateTimeField12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder14.appendMonthOfYear((int) (short) 100);
        boolean boolean20 = dateTimeFormatterBuilder19.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.millisOfSecond();
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.MonthDay.Property property24 = monthDay23.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField13, dateTimeFieldType25, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder3.appendFixedSignedDecimal(dateTimeFieldType25, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder31.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder34.appendEraText();
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.millisOfSecond();
        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology36);
        org.joda.time.MonthDay.Property property39 = monthDay38.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder34.appendFixedDecimal(dateTimeFieldType40, 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendClockhourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder45.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder48.appendTwoDigitWeekyear(1970, false);
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology52.millisOfSecond();
        org.joda.time.MonthDay monthDay54 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology52);
        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = julianChronology55.monthOfYear();
        org.joda.time.DateTimeField dateTimeField57 = julianChronology55.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology52, dateTimeField57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder59.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder59.appendMonthOfYear((int) (short) 100);
        boolean boolean65 = dateTimeFormatterBuilder64.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField67 = iSOChronology66.millisOfSecond();
        org.joda.time.MonthDay monthDay68 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology66);
        org.joda.time.MonthDay.Property property69 = monthDay68.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = property69.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder64.appendShortText(dateTimeFieldType70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField73 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField58, dateTimeFieldType70, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder48.appendFixedSignedDecimal(dateTimeFieldType70, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder44.appendDecimal(dateTimeFieldType70, 83, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder30.appendShortText(dateTimeFieldType70);
        org.joda.time.format.DateTimePrinter dateTimePrinter80 = null;
        org.joda.time.DateTimeZone dateTimeZone83 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime84 = new org.joda.time.DateTime((long) 'a', dateTimeZone83);
        org.joda.time.chrono.BuddhistChronology buddhistChronology85 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone83);
        org.joda.time.DateTimeField dateTimeField86 = buddhistChronology85.era();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder87 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder90 = dateTimeFormatterBuilder87.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder93 = dateTimeFormatterBuilder90.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder94 = dateTimeFormatterBuilder93.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser95 = dateTimeFormatterBuilder94.toParser();
        boolean boolean96 = buddhistChronology85.equals((java.lang.Object) dateTimeParser95);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder97 = dateTimeFormatterBuilder79.append(dateTimePrinter80, dateTimeParser95);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(julianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(iSOChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
        org.junit.Assert.assertNotNull(dateTimeZone83);
        org.junit.Assert.assertNotNull(buddhistChronology85);
        org.junit.Assert.assertNotNull(dateTimeField86);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder90);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder93);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder94);
        org.junit.Assert.assertNotNull(dateTimeParser95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 'a', dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 'a', dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime5.withZoneRetainFields(dateTimeZone8);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime5.minus(readableDuration11);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField15 = iSOChronology14.eras();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime18 = dateTime12.withFields((org.joda.time.ReadablePartial) monthDay17);
        int[] intArray20 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay17, (-62137152000001L));
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 'a', dateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 'a', dateTimeZone27);
        org.joda.time.DateTime dateTime29 = dateTime24.withZoneRetainFields(dateTimeZone27);
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime31 = dateTime24.minus(readableDuration30);
        org.joda.time.DateTime dateTime33 = dateTime31.minusMinutes((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long39 = dateTimeZone35.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeUtils.getZone(dateTimeZone35);
        org.joda.time.DateTime dateTime41 = dateTime33.toDateTime(dateTimeZone40);
        org.joda.time.DateTime dateTime42 = monthDay17.toDateTime((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DurationFieldType durationFieldType43 = null;
        try {
            org.joda.time.MonthDay monthDay45 = monthDay17.withFieldAdded(durationFieldType43, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-359999990L) + "'", long39 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime42);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekyear();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology0);
        try {
            long long12 = julianChronology0.getDateTimeMillis((int) (byte) 1, 1439, 0, (int) ' ', (-100), 999, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        long long7 = dateTimeZone2.adjustOffset(1368000100L, true);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1368000100L + "'", long7 == 1368000100L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.monthOfYear();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology8, dateTimeField13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField14.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder7.appendFixedDecimal(dateTimeFieldType15, 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder17.appendTimeZoneOffset("1969", "-1", true, (-10), (-15382582));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfSecond();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.monthOfYear();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology7.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology4, dateTimeField9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = skipDateTimeField10.getType();
        long long13 = skipDateTimeField10.roundHalfCeiling((long) 1439);
        int int15 = skipDateTimeField10.get(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) skipDateTimeField10);
        int int18 = skipDateTimeField10.get(360000000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 950400000L + "'", long13 == 950400000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 0.0f, (java.lang.Number) (-292269056L), (java.lang.Number) 950400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField13 = iSOChronology12.eras();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 'a', dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 'a', dateTimeZone20);
        org.joda.time.DateTime dateTime22 = dateTime17.withZoneRetainFields(dateTimeZone20);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime24 = dateTime17.minus(readableDuration23);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.eras();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.millisOfSecond();
        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTime dateTime30 = dateTime24.withFields((org.joda.time.ReadablePartial) monthDay29);
        int[] intArray32 = iSOChronology12.get((org.joda.time.ReadablePartial) monthDay29, (-62137152000001L));
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.MonthDay monthDay34 = monthDay29.minus(readablePeriod33);
        try {
            int int35 = unsupportedDateTimeField11.getMaximumValue((org.joda.time.ReadablePartial) monthDay29);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June" + "'", str4.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(monthDay34);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        try {
            long long8 = iSOChronology0.getDateTimeMillis(12, 0, 10, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.hourOfDay();
        org.joda.time.Chronology chronology8 = dateTime6.getChronology();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 4);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 0L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfYear(100);
        int int5 = dateTime4.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) (short) -1);
        org.joda.time.DateTime dateTime9 = property6.withMinimumValue();
        try {
            org.joda.time.DateTime dateTime11 = dateTime9.withDayOfYear(15382789);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15382789 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getName();
        int int5 = property3.get();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property3.getAsText(locale6);
        org.joda.time.MonthDay monthDay9 = property3.addWrapFieldToCopy((-10));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June" + "'", str7.equals("June"));
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("15382789");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = julianChronology0.add(readablePeriod1, (-9223309961711998030L), 97);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-9223309961711998030L) + "'", long4 == (-9223309961711998030L));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        jodaTimePermission1.checkGuard((java.lang.Object) 1439);
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str7 = illegalFieldValueException6.getIllegalValueAsString();
        jodaTimePermission1.checkGuard((java.lang.Object) illegalFieldValueException6);
        java.lang.Object obj9 = null;
        jodaTimePermission1.checkGuard(obj9);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMonthOfYear((int) (short) 100);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.MonthDay.Property property10 = monthDay9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendTwoDigitYear(97);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
        org.joda.time.DateTime.Property property11 = dateTime10.year();
        java.lang.String str12 = dateTime10.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-05T04:00:00.097+100:00" + "'", str12.equals("1970-01-05T04:00:00.097+100:00"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.millisOfSecond();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType9, 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendHourOfDay((int) (short) 0);
        try {
            org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((java.lang.Object) dateTimeFormatterBuilder13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = skipDateTimeField9.getType();
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) dateTimeFieldType10);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 'a', dateTimeZone14);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
        java.lang.String str18 = dateTimeZone14.getName((-359999990L));
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.joda.time.Chronology chronology20 = gregorianChronology0.withZone(dateTimeZone19);
        long long23 = dateTimeZone19.adjustOffset((long) 197, false);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+100:00" + "'", str18.equals("+100:00"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 197L + "'", long23 == 197L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.Throwable throwable3 = null;
        try {
            illegalFieldValueException2.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        long long10 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime8);
        int int11 = property4.getMinimumValueOverall();
        org.joda.time.DateTimeField dateTimeField12 = property4.getField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 'a', dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a', dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.withZoneRetainFields(dateTimeZone12);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        int int16 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property17 = dateTime14.weekyear();
        org.joda.time.DateTime dateTime18 = property17.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeFormatter3.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        java.lang.String str11 = dateTimeZone7.getName((-359999990L));
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 'a', dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 'a', dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime15.minus(readableDuration21);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMinutes((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long30 = dateTimeZone26.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
        org.joda.time.DateTime dateTime32 = dateTime24.toDateTime(dateTimeZone31);
        long long34 = dateTimeZone7.getMillisKeepLocal(dateTimeZone31, 0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter3.withZone(dateTimeZone7);
        org.joda.time.Chronology chronology36 = copticChronology0.withZone(dateTimeZone7);
        try {
            long long41 = copticChronology0.getDateTimeMillis((int) (short) 0, (-10), 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+100:00" + "'", str11.equals("+100:00"));
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-359999990L) + "'", long30 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(chronology36);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        int int22 = dividedDateTimeField21.getMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.millisOfSecond();
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology23);
        org.joda.time.MonthDay.Property property26 = monthDay25.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.millisOfSecond();
        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str31 = monthDay29.toString(dateTimeFormatter30);
        boolean boolean32 = monthDay25.isBefore((org.joda.time.ReadablePartial) monthDay29);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.eras();
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 'a', dateTimeZone38);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) 'a', dateTimeZone42);
        org.joda.time.DateTime dateTime44 = dateTime39.withZoneRetainFields(dateTimeZone42);
        org.joda.time.ReadableDuration readableDuration45 = null;
        org.joda.time.DateTime dateTime46 = dateTime39.minus(readableDuration45);
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField49 = iSOChronology48.eras();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.millisOfSecond();
        org.joda.time.MonthDay monthDay51 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology48);
        org.joda.time.DateTime dateTime52 = dateTime46.withFields((org.joda.time.ReadablePartial) monthDay51);
        int[] intArray54 = iSOChronology34.get((org.joda.time.ReadablePartial) monthDay51, (-62137152000001L));
        try {
            int[] intArray56 = dividedDateTimeField21.set((org.joda.time.ReadablePartial) monthDay29, 8, intArray54, (-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for monthOfYear must be in the range [-15382582,15382789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15382789 + "'", int22 == 15382789);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "����-W��-�" + "'", str31.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(intArray54);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology4.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField6);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField6);
        long long10 = skipUndoDateTimeField8.roundHalfFloor((long) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfSecond();
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology11);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) ' ', locale15);
        long long19 = skipUndoDateTimeField8.set((long) (short) -1, 0);
        boolean boolean20 = skipUndoDateTimeField8.isSupported();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 950400000L + "'", long10 == 950400000L);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "32" + "'", str16.equals("32"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62137152000001L) + "'", long19 == (-62137152000001L));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        boolean boolean3 = gJChronology0.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.DurationField durationField4 = gJChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.MonthDay monthDay7 = property3.addWrapFieldToCopy((int) (byte) 1);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumTextLength(locale8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June" + "'", str4.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DurationField durationField2 = iSOChronology0.halfdays();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.millisOfSecond();
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.MonthDay.Property property6 = monthDay5.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str11 = monthDay9.toString(dateTimeFormatter10);
        boolean boolean12 = monthDay5.isBefore((org.joda.time.ReadablePartial) monthDay9);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay14 = monthDay9.plus(readablePeriod13);
        int[] intArray16 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-W��-�" + "'", str11.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMinutes((int) 'a');
        org.joda.time.DateTime dateTime14 = dateTime12.plusMinutes(15382789);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        java.lang.String str4 = dateTimeZone3.getID();
        java.lang.String str6 = dateTimeZone3.getShortName((long) (short) -1);
        org.joda.time.Chronology chronology7 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 'a', dateTimeZone10);
        boolean boolean13 = dateTime11.isAfter((-1L));
        org.joda.time.DateTime dateTime15 = dateTime11.minusMillis(0);
        int int16 = dateTime11.getMillisOfDay();
        int int17 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property18 = dateTime11.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 'a', dateTimeZone21);
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone21);
        java.lang.String str25 = dateTimeZone21.getName((-359999990L));
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 'a', dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 'a', dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime29.withZoneRetainFields(dateTimeZone32);
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime36 = dateTime29.minus(readableDuration35);
        org.joda.time.DateTime dateTime38 = dateTime36.minusMinutes((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long44 = dateTimeZone40.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
        org.joda.time.DateTime dateTime46 = dateTime38.toDateTime(dateTimeZone45);
        long long48 = dateTimeZone21.getMillisKeepLocal(dateTimeZone45, 0L);
        org.joda.time.DateTime dateTime49 = dateTime11.toDateTime(dateTimeZone45);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+100:00" + "'", str4.equals("+100:00"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+100:00" + "'", str6.equals("+100:00"));
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 14400097 + "'", int16 == 14400097);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 360000000 + "'", int17 == 360000000);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+100:00" + "'", str25.equals("+100:00"));
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-359999990L) + "'", long44 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTime49);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfSecond();
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = monthDay24.getFieldType((int) (byte) 0);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21, dateTimeFieldType26);
        long long29 = remainderDateTimeField27.roundHalfCeiling((long) 360000000);
        java.util.Locale locale31 = null;
        java.lang.String str32 = remainderDateTimeField27.getAsText((long) 8, locale31);
        try {
            long long35 = remainderDateTimeField27.set((long) (short) 100, 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [0,18]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 950400000L + "'", long29 == 950400000L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "12" + "'", str32.equals("12"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1L, 83);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 83L + "'", long2 == 83L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.weekOfWeekyear();
        java.lang.String str4 = copticChronology0.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField13 = iSOChronology12.eras();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.millisOfSecond();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime16 = dateTime10.withFields((org.joda.time.ReadablePartial) monthDay15);
        org.joda.time.DateTime dateTime18 = dateTime10.plusMillis((int) 'a');
        org.joda.time.DateTime dateTime20 = dateTime18.plus(0L);
        org.joda.time.DateTime dateTime22 = dateTime20.plusHours(83);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 10, 14400097);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 14400097");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.LocalTime localTime9 = dateTime8.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds(0);
        int int12 = dateTime11.getWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime11.minusHours((int) '#');
        org.joda.time.DateTime dateTime16 = dateTime11.plusSeconds(6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.lang.String str18 = dateTime16.toString(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "04" + "'", str18.equals("04"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((-1), 100, (int) (byte) 10, 15382789, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15382789 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        long long10 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime8);
        int int11 = property4.getMaximumValueOverall();
        org.joda.time.DateTime dateTime12 = property4.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime13 = property4.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime14 = property4.withMaximumValue();
        org.joda.time.DurationField durationField15 = property4.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1439 + "'", int11 == 1439);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dividedDateTimeField21.getAsShortText((-359999990L), locale23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.millisOfSecond();
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology25);
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = julianChronology28.monthOfYear();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology28.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology25, dateTimeField30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder32.appendMonthOfYear((int) (short) 100);
        boolean boolean38 = dateTimeFormatterBuilder37.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.millisOfSecond();
        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.MonthDay.Property property42 = monthDay41.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder37.appendShortText(dateTimeFieldType43);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField31, dateTimeFieldType43, 19);
        java.util.Locale locale47 = null;
        int int48 = dividedDateTimeField46.getMaximumTextLength(locale47);
        java.util.Locale locale49 = null;
        int int50 = dividedDateTimeField46.getMaximumTextLength(locale49);
        org.joda.time.DurationField durationField51 = dividedDateTimeField46.getDurationField();
        long long54 = dividedDateTimeField46.add((-292269056L), (int) (short) 10);
        long long57 = dividedDateTimeField46.add((-359999900L), (-100));
        org.joda.time.JodaTimePermission jodaTimePermission59 = new org.joda.time.JodaTimePermission("hi!");
        jodaTimePermission59.checkGuard((java.lang.Object) 1439);
        org.joda.time.chrono.JulianChronology julianChronology62 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = julianChronology62.hourOfDay();
        jodaTimePermission59.checkGuard((java.lang.Object) julianChronology62);
        org.joda.time.MonthDay monthDay65 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology62);
        org.joda.time.ReadablePeriod readablePeriod66 = null;
        org.joda.time.MonthDay monthDay67 = monthDay65.plus(readablePeriod66);
        java.util.Locale locale69 = null;
        java.lang.String str70 = dividedDateTimeField46.getAsShortText((org.joda.time.ReadablePartial) monthDay67, (-292275054), locale69);
        int int71 = dividedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) monthDay67);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "103" + "'", str24.equals("103"));
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 8 + "'", int48 == 8);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 8 + "'", int50 == 8);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 5995694930944L + "'", long54 == 5995694930944L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-59959627199900L) + "'", long57 == (-59959627199900L));
        org.junit.Assert.assertNotNull(julianChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(monthDay67);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "-292275054" + "'", str70.equals("-292275054"));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 15382789 + "'", int71 == 15382789);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        java.util.Locale locale9 = null;
        long long10 = skipDateTimeField6.set((long) 8, "32", locale9);
        int int12 = skipDateTimeField6.get(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61127135999992L) + "'", long10 == (-61127135999992L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(1970, false);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.monthOfYear();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology10.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology7, dateTimeField12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder14.appendMonthOfYear((int) (short) 100);
        boolean boolean20 = dateTimeFormatterBuilder19.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.millisOfSecond();
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.MonthDay.Property property24 = monthDay23.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField13, dateTimeFieldType25, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder3.appendFixedSignedDecimal(dateTimeFieldType25, (int) (byte) 1);
        org.joda.time.DurationField durationField31 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plus((long) (byte) -1);
        int int6 = dateTime3.getWeekyear();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField8 = iSOChronology7.eras();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.hourOfHalfday();
        int int10 = dateTime3.get(dateTimeField9);
        org.joda.time.DateTime dateTime12 = dateTime3.withWeekyear(8);
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.DateTime dateTime15 = dateTime12.withFieldAdded(durationFieldType13, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendMonthOfYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder8.appendYearOfEra(12, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 'a', dateTimeZone21);
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.era();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder28.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder31.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser33 = dateTimeFormatterBuilder32.toParser();
        boolean boolean34 = buddhistChronology23.equals((java.lang.Object) dateTimeParser33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder8.appendOptional(dateTimeParser33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder6.append(dateTimeParser33);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology37.millisOfSecond();
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology37);
        org.joda.time.MonthDay.Property property40 = monthDay39.monthOfYear();
        java.lang.String str41 = property40.getAsText();
        org.joda.time.DateTimeField dateTimeField42 = property40.getField();
        int int43 = property40.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property40.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology45.millisOfSecond();
        org.joda.time.DurationField durationField47 = iSOChronology45.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField48 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField47);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder36.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder49.appendHourOfDay(1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeParser33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "June" + "'", str41.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 12 + "'", int43 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) (short) -1);
        org.joda.time.Interval interval9 = property6.toInterval();
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval9);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipDateTimeField6.getAsShortText((int) (short) 0, locale9);
        org.joda.time.DurationField durationField11 = skipDateTimeField6.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 'a', dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 'a', dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
        java.util.Locale locale22 = null;
        try {
            java.lang.String str23 = skipDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localTime21, locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localTime21);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        java.util.Locale locale9 = null;
        java.util.Calendar calendar10 = dateTime3.toCalendar(locale9);
        org.joda.time.DateTime dateTime12 = dateTime3.withMinuteOfHour(0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(calendar10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipDateTimeField6.getAsShortText((int) (short) 0, locale9);
        java.lang.String str11 = skipDateTimeField6.getName();
        long long13 = skipDateTimeField6.roundHalfEven((long) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 'a', dateTimeZone16);
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.era();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology18.halfdayOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfSecond();
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology22);
        java.util.Locale locale26 = null;
        java.lang.String str27 = delegatedDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (-1), locale26);
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) monthDay24, 15382789, locale29);
        long long32 = skipDateTimeField6.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "weekyear" + "'", str11.equals("weekyear"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 950400000L + "'", long13 == 950400000L);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "15382789" + "'", str30.equals("15382789"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 950400000L + "'", long32 == 950400000L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.JodaTimePermission jodaTimePermission2 = new org.joda.time.JodaTimePermission("hi!");
        jodaTimePermission2.checkGuard((java.lang.Object) 1439);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.hourOfDay();
        jodaTimePermission2.checkGuard((java.lang.Object) julianChronology5);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology5);
        try {
            org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((java.lang.Object) (-292269054), (org.joda.time.Chronology) julianChronology5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        java.lang.StringBuffer stringBuffer2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (-359999990L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        org.joda.time.MonthDay monthDay5 = property3.addToCopy(1970);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay7 = monthDay5.minus(readablePeriod6);
        org.joda.time.MonthDay monthDay9 = monthDay7.withMonthOfYear(4);
        org.joda.time.MonthDay.Property property10 = monthDay7.dayOfMonth();
        try {
            org.joda.time.MonthDay monthDay12 = property10.setCopy(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gJChronology0.seconds();
        java.lang.String str3 = gJChronology0.toString();
        org.joda.time.DurationField durationField4 = gJChronology0.weekyears();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[UTC]" + "'", str3.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.Instant instant3 = instant1.minus((long) (byte) 0);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant6 = instant1.minus((long) (short) 1);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant8 = instant1.plus(readableDuration7);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        java.lang.String str2 = dateTimeZone1.getID();
        java.lang.String str4 = dateTimeZone1.getShortName((long) (short) -1);
        long long8 = dateTimeZone1.convertLocalToUTC((long) (short) 100, true, (-359999990L));
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+100:00" + "'", str2.equals("+100:00"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+100:00" + "'", str4.equals("+100:00"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-359999900L) + "'", long8 == (-359999900L));
        org.junit.Assert.assertNotNull(julianChronology9);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.Instant instant3 = instant1.minus((long) (byte) 0);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant6 = instant1.minus((long) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.Chronology chronology9 = gregorianChronology7.withZone(dateTimeZone8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.millisOfSecond();
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.monthOfYear();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology13.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology10, dateTimeField15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = skipDateTimeField16.getType();
        boolean boolean18 = gregorianChronology7.equals((java.lang.Object) dateTimeFieldType17);
        org.joda.time.DateTime dateTime19 = instant6.toDateTime((org.joda.time.Chronology) gregorianChronology7);
        java.util.Date date20 = instant6.toDate();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) (short) -1);
        org.joda.time.DurationField durationField9 = property6.getRangeDurationField();
        org.joda.time.DateTime dateTime11 = property6.addToCopy((long) (-292269056));
        org.joda.time.DateTimeField dateTimeField12 = property6.getField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (-61127135999992L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfSecond();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = monthDay4.getFieldType((int) (byte) 0);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType6, 15382789, 0, (-1));
        int int13 = offsetDateTimeField10.getDifference((long) (byte) 10, (-292269056L));
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        java.lang.String str18 = property17.getName();
        int int19 = property17.get();
        java.util.Locale locale20 = null;
        java.lang.String str21 = property17.getAsShortText(locale20);
        int int22 = property17.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay24 = property17.setCopy(10);
        int int25 = offsetDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) monthDay24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder26.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder29.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder32.appendTimeZoneName();
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.millisOfSecond();
        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.monthOfYear();
        org.joda.time.DateTimeField dateTimeField39 = julianChronology37.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology34, dateTimeField39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField40.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType41, 10);
        try {
            int int44 = monthDay24.get(dateTimeFieldType41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "monthOfYear" + "'", str18.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Jun" + "'", str21.equals("Jun"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15382790 + "'", int25 == 15382790);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getName();
        int int5 = property3.get();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property3.getAsShortText(locale6);
        int int8 = property3.getMaximumValueOverall();
        org.joda.time.DurationField durationField9 = property3.getDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jun" + "'", str7.equals("Jun"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        illegalFieldValueException2.prependMessage("");
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException2.getSuppressed();
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException2.getSuppressed();
        java.lang.String str8 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.millisOfSecond();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType9, 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendTwoDigitWeekyear(1970, false);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.millisOfSecond();
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = julianChronology24.monthOfYear();
        org.joda.time.DateTimeField dateTimeField26 = julianChronology24.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology21, dateTimeField26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder28.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder28.appendMonthOfYear((int) (short) 100);
        boolean boolean34 = dateTimeFormatterBuilder33.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.millisOfSecond();
        org.joda.time.MonthDay monthDay37 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology35);
        org.joda.time.MonthDay.Property property38 = monthDay37.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder33.appendShortText(dateTimeFieldType39);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField27, dateTimeFieldType39, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder17.appendFixedSignedDecimal(dateTimeFieldType39, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder13.appendDecimal(dateTimeFieldType39, 83, (int) (byte) 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter48 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder47.append(dateTimePrinter48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        java.lang.String str12 = unsupportedDateTimeField11.toString();
        try {
            long long14 = unsupportedDateTimeField11.roundCeiling(190252800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June" + "'", str4.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDateTimeField" + "'", str12.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        jodaTimePermission1.checkGuard((java.lang.Object) 1439);
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str7 = illegalFieldValueException6.getIllegalValueAsString();
        jodaTimePermission1.checkGuard((java.lang.Object) illegalFieldValueException6);
        jodaTimePermission1.checkGuard((java.lang.Object) 100);
        try {
            org.joda.time.Instant instant11 = new org.joda.time.Instant((java.lang.Object) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 'a', dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a', dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.withZoneRetainFields(dateTimeZone12);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        int int16 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property17 = dateTime14.weekyear();
        org.joda.time.DurationField durationField18 = property17.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNull(durationField18);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 'a', dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 'a', dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime5.withZoneRetainFields(dateTimeZone8);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime5.minus(readableDuration11);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField15 = iSOChronology14.eras();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime18 = dateTime12.withFields((org.joda.time.ReadablePartial) monthDay17);
        int[] intArray20 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay17, (-62137152000001L));
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.MonthDay monthDay23 = monthDay17.withPeriodAdded(readablePeriod21, (int) (short) 0);
        org.joda.time.Chronology chronology24 = monthDay23.getChronology();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 'a', dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime6.dayOfWeek();
        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (short) -1);
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime11.toMutableDateTimeISO();
        int int15 = dateTimeFormatter2.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime12, "����-W��-�", 0);
        java.lang.String str16 = instant1.toString(dateTimeFormatter2);
        org.joda.time.DateTime dateTime17 = instant1.toDateTime();
        org.joda.time.DateTime dateTime19 = dateTime17.plusMinutes(0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1582W415T000000Z" + "'", str16.equals("1582W415T000000Z"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMonthOfYear((int) (short) 100);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.MonthDay.Property property10 = monthDay9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendSecondOfMinute((-292269056));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((int) (short) 10, (-15382582));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -15382582 for dayOfMonth must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) (short) 1);
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        boolean boolean8 = property6.equals((java.lang.Object) (-1.0d));
        org.joda.time.DateTime dateTime9 = property6.roundCeilingCopy();
        org.joda.time.DateTime dateTime11 = property6.addToCopy(0L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.weekyears();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 197);
        boolean boolean5 = julianChronology0.equals((java.lang.Object) dateTimeFormatter4);
        int int6 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology0.year();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        try {
            long long10 = gJChronology0.getDateTimeMillis((int) (short) -1, 0, (-32), 1970, (int) ' ', (-15382582), (-32));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
//        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        java.lang.String str8 = monthDay6.toString(dateTimeFormatter7);
//        boolean boolean9 = monthDay2.isBefore((org.joda.time.ReadablePartial) monthDay6);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay6.plus(readablePeriod10);
//        int int12 = monthDay11.size();
//        java.lang.String str13 = monthDay11.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����-W��-�" + "'", str8.equals("����-W��-�"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "--06-15" + "'", str13.equals("--06-15"));
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.Instant instant3 = instant1.minus((long) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.monthOfYear();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology7.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology4, dateTimeField9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendMonthOfYear((int) (short) 100);
        boolean boolean17 = dateTimeFormatterBuilder16.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.millisOfSecond();
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology18);
        org.joda.time.MonthDay.Property property21 = monthDay20.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder16.appendShortText(dateTimeFieldType22);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType22, 19);
        int int26 = instant3.get((org.joda.time.DateTimeField) dividedDateTimeField25);
        org.joda.time.DurationField durationField27 = dividedDateTimeField25.getLeapDurationField();
        org.joda.time.DurationField durationField28 = dividedDateTimeField25.getDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.millisOfSecond();
        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology29);
        org.joda.time.MonthDay.Property property32 = monthDay31.monthOfYear();
        org.joda.time.MonthDay monthDay34 = property32.addToCopy(1970);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.millisOfSecond();
        org.joda.time.MonthDay monthDay37 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology35);
        org.joda.time.MonthDay.Property property38 = monthDay37.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.millisOfSecond();
        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str43 = monthDay41.toString(dateTimeFormatter42);
        boolean boolean44 = monthDay37.isBefore((org.joda.time.ReadablePartial) monthDay41);
        org.joda.time.Chronology chronology45 = monthDay37.getChronology();
        int int46 = property32.compareTo((org.joda.time.ReadablePartial) monthDay37);
        int int47 = dividedDateTimeField25.getMinimumValue((org.joda.time.ReadablePartial) monthDay37);
        int int49 = dividedDateTimeField25.getLeapAmount((long) 360000000);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 83 + "'", int26 == 83);
        org.junit.Assert.assertNull(durationField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "����-W��-�" + "'", str43.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-15382582) + "'", int47 == (-15382582));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology4.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipDateTimeField7.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType8);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType8, 1970, 0, (-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for weekyear must be in the range [0,-10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str8 = monthDay6.toString(dateTimeFormatter7);
        boolean boolean9 = monthDay2.isBefore((org.joda.time.ReadablePartial) monthDay6);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay11 = monthDay6.plus(readablePeriod10);
        org.joda.time.MonthDay.Property property12 = monthDay11.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����-W��-�" + "'", str8.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfSecond();
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = monthDay24.getFieldType((int) (byte) 0);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21, dateTimeFieldType26);
        long long29 = remainderDateTimeField27.roundHalfCeiling((long) 360000000);
        long long31 = remainderDateTimeField27.roundHalfEven(0L);
        try {
            long long34 = remainderDateTimeField27.set((-62167190822000L), 15382790);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15382790 for monthOfYear must be in the range [0,18]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 950400000L + "'", long29 == 950400000L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 950400000L + "'", long31 == 950400000L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter0.parseMutableDateTime("--01-31");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"--01-31\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (short) 10);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        long long10 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.Interval interval11 = property4.toInterval();
        org.joda.time.DateTimeField dateTimeField12 = property4.getField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(interval11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        java.lang.String str12 = unsupportedDateTimeField11.toString();
        try {
            long long14 = unsupportedDateTimeField11.roundCeiling((long) (-15382582));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June" + "'", str4.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDateTimeField" + "'", str12.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 'a', dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a', dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.withZoneRetainFields(dateTimeZone12);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        int int16 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.toDateTimeISO();
        org.joda.time.DateTime.Property property18 = dateTime17.minuteOfDay();
        org.joda.time.DateTime dateTime19 = property18.withMaximumValue();
        org.joda.time.DateTime.Property property20 = dateTime19.year();
        org.joda.time.DateTime.Property property21 = dateTime19.millisOfDay();
        org.joda.time.DateTime dateTime22 = property21.roundFloorCopy();
        java.lang.String str23 = property21.getAsString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "86340097" + "'", str23.equals("86340097"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.monthOfYear();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.weekyear();
        java.lang.String str8 = julianChronology5.toString();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology5);
        org.joda.time.Chronology chronology10 = julianChronology5.withUTC();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(15382789, 999, 19, (-32), 83, chronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "JulianChronology[UTC]" + "'", str8.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        org.joda.time.MonthDay monthDay5 = property3.addToCopy(1970);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay7 = monthDay5.minus(readablePeriod6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        java.lang.String str10 = dateTimeZone9.getID();
        java.lang.String str12 = dateTimeZone9.getShortName((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 'a', dateTimeZone15);
        boolean boolean18 = dateTime16.isAfter((-1L));
        org.joda.time.DateTime dateTime20 = dateTime16.minusMillis(0);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) dateTime16, 1);
        org.joda.time.DurationField durationField23 = gJChronology22.centuries();
        org.joda.time.MonthDay monthDay24 = monthDay5.withChronologyRetainFields((org.joda.time.Chronology) gJChronology22);
        int int25 = monthDay24.size();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+100:00" + "'", str10.equals("+100:00"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+100:00" + "'", str12.equals("+100:00"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMonthOfYear((int) (short) 100);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.MonthDay.Property property10 = monthDay9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder5.appendClockhourOfDay(83);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "-292275054");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.Instant instant3 = instant1.minus((long) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.monthOfYear();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology7.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology4, dateTimeField9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendMonthOfYear((int) (short) 100);
        boolean boolean17 = dateTimeFormatterBuilder16.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.millisOfSecond();
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology18);
        org.joda.time.MonthDay.Property property21 = monthDay20.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder16.appendShortText(dateTimeFieldType22);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType22, 19);
        int int26 = instant3.get((org.joda.time.DateTimeField) dividedDateTimeField25);
        org.joda.time.DurationField durationField27 = dividedDateTimeField25.getLeapDurationField();
        org.joda.time.DurationField durationField28 = dividedDateTimeField25.getDurationField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField25);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 83 + "'", int26 == 83);
        org.junit.Assert.assertNull(durationField27);
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime11 = dateTime9.withCenturyOfEra(0);
        org.joda.time.LocalDateTime localDateTime12 = dateTime9.toLocalDateTime();
        boolean boolean13 = dateTimeZone3.isLocalDateTimeGap(localDateTime12);
        org.joda.time.Chronology chronology14 = copticChronology0.withZone(dateTimeZone3);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology4.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField6);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField6);
        org.joda.time.DurationField durationField9 = skipUndoDateTimeField8.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter6.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimeParser7);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYearOfCentury((-100), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) (short) -1);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.DateTime dateTime11 = dateTime8.withFieldAdded(durationFieldType9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        java.lang.String str12 = unsupportedDateTimeField11.toString();
        try {
            long long15 = unsupportedDateTimeField11.add((-59959627199900L), 59957884800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 59957884800000 * 43200000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June" + "'", str4.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDateTimeField" + "'", str12.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (long) (byte) 100, 83);
        org.joda.time.DurationField durationField5 = gJChronology0.days();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', 0, 14400097, 4, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 'a', dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a', dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.withZoneRetainFields(dateTimeZone12);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        int int16 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime14);
        int int17 = dateTime14.getYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1970 + "'", int17 == 1970);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfSecond();
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = monthDay24.getFieldType((int) (byte) 0);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21, dateTimeFieldType26);
        long long29 = remainderDateTimeField27.roundHalfCeiling((long) 360000000);
        int int31 = remainderDateTimeField27.get((long) '4');
        long long33 = remainderDateTimeField27.roundHalfEven((long) 1439);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 950400000L + "'", long29 == 950400000L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 12 + "'", int31 == 12);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 950400000L + "'", long33 == 950400000L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gJChronology0.seconds();
        java.lang.String str3 = gJChronology0.toString();
        org.joda.time.Instant instant4 = gJChronology0.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[UTC]" + "'", str3.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField6 = iSOChronology5.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfSecond();
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.monthOfYear();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology14.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology11, dateTimeField16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipDateTimeField17.getType();
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField17.getAsShortText((int) (short) 0, locale20);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology8, (org.joda.time.DateTimeField) skipDateTimeField17);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.millisOfSecond();
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology23);
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) monthDay25, (int) 'a', locale27);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant31 = gJChronology30.getGregorianCutover();
        org.joda.time.Instant instant33 = instant31.minus((long) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.millisOfSecond();
        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.monthOfYear();
        org.joda.time.DateTimeField dateTimeField39 = julianChronology37.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology34, dateTimeField39);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder41.appendMonthOfYear((int) (short) 100);
        boolean boolean47 = dateTimeFormatterBuilder46.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.millisOfSecond();
        org.joda.time.MonthDay monthDay50 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology48);
        org.joda.time.MonthDay.Property property51 = monthDay50.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property51.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder46.appendShortText(dateTimeFieldType52);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField55 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField40, dateTimeFieldType52, 19);
        int int56 = instant33.get((org.joda.time.DateTimeField) dividedDateTimeField55);
        org.joda.time.DurationField durationField57 = dividedDateTimeField55.getLeapDurationField();
        org.joda.time.DurationField durationField58 = dividedDateTimeField55.getDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.millisOfSecond();
        org.joda.time.MonthDay monthDay61 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology59);
        org.joda.time.MonthDay.Property property62 = monthDay61.monthOfYear();
        org.joda.time.MonthDay monthDay64 = property62.addToCopy(1970);
        org.joda.time.chrono.ISOChronology iSOChronology65 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField66 = iSOChronology65.millisOfSecond();
        org.joda.time.MonthDay monthDay67 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology65);
        org.joda.time.MonthDay.Property property68 = monthDay67.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.millisOfSecond();
        org.joda.time.MonthDay monthDay71 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology69);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str73 = monthDay71.toString(dateTimeFormatter72);
        boolean boolean74 = monthDay67.isBefore((org.joda.time.ReadablePartial) monthDay71);
        org.joda.time.Chronology chronology75 = monthDay67.getChronology();
        int int76 = property62.compareTo((org.joda.time.ReadablePartial) monthDay67);
        int int77 = dividedDateTimeField55.getMinimumValue((org.joda.time.ReadablePartial) monthDay67);
        org.joda.time.ReadablePartial readablePartial78 = null;
        org.joda.time.chrono.ISOChronology iSOChronology79 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField80 = iSOChronology79.millisOfSecond();
        org.joda.time.DurationField durationField81 = iSOChronology79.halfdays();
        org.joda.time.chrono.ISOChronology iSOChronology82 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField83 = iSOChronology82.millisOfSecond();
        org.joda.time.MonthDay monthDay84 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology82);
        org.joda.time.MonthDay.Property property85 = monthDay84.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology86 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField87 = iSOChronology86.millisOfSecond();
        org.joda.time.MonthDay monthDay88 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology86);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter89 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str90 = monthDay88.toString(dateTimeFormatter89);
        boolean boolean91 = monthDay84.isBefore((org.joda.time.ReadablePartial) monthDay88);
        org.joda.time.ReadablePeriod readablePeriod92 = null;
        org.joda.time.MonthDay monthDay93 = monthDay88.plus(readablePeriod92);
        int[] intArray95 = iSOChronology79.get((org.joda.time.ReadablePartial) monthDay88, 0L);
        int int96 = dividedDateTimeField55.getMaximumValue(readablePartial78, intArray95);
        try {
            int[] intArray98 = unsupportedDateTimeField7.addWrapField((org.joda.time.ReadablePartial) monthDay25, 8, intArray95, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "97" + "'", str28.equals("97"));
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(instant31);
        org.junit.Assert.assertNotNull(instant33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 83 + "'", int56 == 83);
        org.junit.Assert.assertNull(durationField57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(monthDay64);
        org.junit.Assert.assertNotNull(iSOChronology65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(property68);
        org.junit.Assert.assertNotNull(iSOChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeFormatter72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "����-W��-�" + "'", str73.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(chronology75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-15382582) + "'", int77 == (-15382582));
        org.junit.Assert.assertNotNull(iSOChronology79);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertNotNull(durationField81);
        org.junit.Assert.assertNotNull(iSOChronology82);
        org.junit.Assert.assertNotNull(dateTimeField83);
        org.junit.Assert.assertNotNull(property85);
        org.junit.Assert.assertNotNull(iSOChronology86);
        org.junit.Assert.assertNotNull(dateTimeField87);
        org.junit.Assert.assertNotNull(dateTimeFormatter89);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "����-W��-�" + "'", str90.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(monthDay93);
        org.junit.Assert.assertNotNull(intArray95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 15382789 + "'", int96 == 15382789);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 19);
        java.lang.StringBuffer stringBuffer4 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.era();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology9.halfdayOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology13);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) monthDay15, (-1), locale17);
        try {
            dateTimeFormatter0.printTo(stringBuffer4, (org.joda.time.ReadablePartial) monthDay15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-1" + "'", str18.equals("-1"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.Instant instant3 = instant1.minus((long) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.monthOfYear();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology7.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology4, dateTimeField9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendMonthOfYear((int) (short) 100);
        boolean boolean17 = dateTimeFormatterBuilder16.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.millisOfSecond();
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology18);
        org.joda.time.MonthDay.Property property21 = monthDay20.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder16.appendShortText(dateTimeFieldType22);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType22, 19);
        int int26 = instant3.get((org.joda.time.DateTimeField) dividedDateTimeField25);
        org.joda.time.DurationField durationField27 = dividedDateTimeField25.getLeapDurationField();
        int int29 = dividedDateTimeField25.getMinimumValue((long) '#');
        java.util.Locale locale31 = null;
        java.lang.String str32 = dividedDateTimeField25.getAsShortText(97L, locale31);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 83 + "'", int26 == 83);
        org.junit.Assert.assertNull(durationField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-15382582) + "'", int29 == (-15382582));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "103" + "'", str32.equals("103"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getName();
        boolean boolean6 = property3.equals((java.lang.Object) 360000000);
        int int7 = property3.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "monthOfYear" + "'", str4.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfSecond();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.monthOfYear();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology7.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology4, dateTimeField9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = skipDateTimeField10.getType();
        long long13 = skipDateTimeField10.roundHalfCeiling((long) 1439);
        int int15 = skipDateTimeField10.get(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) skipDateTimeField10);
        int int18 = skipUndoDateTimeField16.getMaximumValue(1967L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 950400000L + "'", long13 == 950400000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292272992 + "'", int18 == 292272992);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 'a', dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra(0);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean10 = dateTimeZone0.isLocalDateTimeGap(localDateTime9);
        long long13 = dateTimeZone0.adjustOffset(97L, false);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 97L + "'", long13 == 97L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.weekOfWeekyear();
        int int4 = copticChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfSecond();
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = monthDay24.getFieldType((int) (byte) 0);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21, dateTimeFieldType26);
        long long29 = remainderDateTimeField27.roundHalfCeiling((-86399903L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 950400000L + "'", long29 == 950400000L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfSecond();
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = monthDay24.getFieldType((int) (byte) 0);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21, dateTimeFieldType26);
        long long30 = dividedDateTimeField21.getDifferenceAsLong((long) (short) 1, (long) (-10));
        java.util.Locale locale31 = null;
        int int32 = dividedDateTimeField21.getMaximumShortTextLength(locale31);
        try {
            long long35 = dividedDateTimeField21.add((long) 1969, 360000000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1749932623 for weekyear must be in the range [-292269054,292272992]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 8 + "'", int32 == 8);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        java.lang.String str12 = unsupportedDateTimeField11.toString();
        org.joda.time.DurationField durationField13 = unsupportedDateTimeField11.getDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        java.lang.String str18 = property17.getName();
        int int19 = property17.get();
        org.joda.time.MonthDay monthDay21 = property17.setCopy("Jun");
        java.util.Locale locale23 = null;
        try {
            java.lang.String str24 = unsupportedDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay21, (int) (short) 1, locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June" + "'", str4.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDateTimeField" + "'", str12.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "monthOfYear" + "'", str18.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(monthDay21);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        java.util.Locale locale22 = null;
        int int23 = dividedDateTimeField21.getMaximumTextLength(locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = dividedDateTimeField21.getType();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra(0);
        java.util.Date date8 = dateTime7.toDate();
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.DateTime dateTime12 = dateTime7.withFieldAdded(durationFieldType10, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 'a', dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime9 = dateTime7.withCenturyOfEra(0);
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        boolean boolean11 = dateTimeZone1.isLocalDateTimeGap(localDateTime10);
        long long13 = buddhistChronology0.set((org.joda.time.ReadablePartial) localDateTime10, 0L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-17134286821904L) + "'", long13 == (-17134286821904L));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        org.joda.time.MonthDay monthDay5 = property3.addToCopy(1970);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.millisOfSecond();
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.MonthDay.Property property9 = monthDay8.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.millisOfSecond();
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str14 = monthDay12.toString(dateTimeFormatter13);
        boolean boolean15 = monthDay8.isBefore((org.joda.time.ReadablePartial) monthDay12);
        org.joda.time.Chronology chronology16 = monthDay8.getChronology();
        int int17 = property3.compareTo((org.joda.time.ReadablePartial) monthDay8);
        org.joda.time.MonthDay monthDay18 = property3.getMonthDay();
        try {
            org.joda.time.MonthDay monthDay20 = property3.setCopy((-100));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "����-W��-�" + "'", str14.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(monthDay18);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(1970, false);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.monthOfYear();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology10.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology7, dateTimeField12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder14.appendMonthOfYear((int) (short) 100);
        boolean boolean20 = dateTimeFormatterBuilder19.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.millisOfSecond();
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.MonthDay.Property property24 = monthDay23.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField13, dateTimeFieldType25, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder3.appendFixedSignedDecimal(dateTimeFieldType25, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder31.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder34.appendEraText();
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.millisOfSecond();
        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology36);
        org.joda.time.MonthDay.Property property39 = monthDay38.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder34.appendFixedDecimal(dateTimeFieldType40, 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendClockhourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder45.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder48.appendTwoDigitWeekyear(1970, false);
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology52.millisOfSecond();
        org.joda.time.MonthDay monthDay54 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology52);
        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = julianChronology55.monthOfYear();
        org.joda.time.DateTimeField dateTimeField57 = julianChronology55.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology52, dateTimeField57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder59.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder59.appendMonthOfYear((int) (short) 100);
        boolean boolean65 = dateTimeFormatterBuilder64.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField67 = iSOChronology66.millisOfSecond();
        org.joda.time.MonthDay monthDay68 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology66);
        org.joda.time.MonthDay.Property property69 = monthDay68.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = property69.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder64.appendShortText(dateTimeFieldType70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField73 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField58, dateTimeFieldType70, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder48.appendFixedSignedDecimal(dateTimeFieldType70, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder44.appendDecimal(dateTimeFieldType70, 83, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder30.appendShortText(dateTimeFieldType70);
        org.joda.time.chrono.ISOChronology iSOChronology80 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField81 = iSOChronology80.millisOfSecond();
        org.joda.time.MonthDay monthDay82 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology80);
        org.joda.time.MonthDay.Property property83 = monthDay82.monthOfYear();
        java.lang.String str84 = property83.getAsText();
        org.joda.time.DateTimeField dateTimeField85 = property83.getField();
        int int86 = property83.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType87 = property83.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology88 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField89 = iSOChronology88.millisOfSecond();
        org.joda.time.DurationField durationField90 = iSOChronology88.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField91 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType87, durationField90);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder93 = dateTimeFormatterBuilder79.appendFixedSignedDecimal(dateTimeFieldType87, 97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder94 = dateTimeFormatterBuilder79.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(julianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(iSOChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
        org.junit.Assert.assertNotNull(iSOChronology80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertNotNull(property83);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "June" + "'", str84.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeField85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 12 + "'", int86 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType87);
        org.junit.Assert.assertNotNull(iSOChronology88);
        org.junit.Assert.assertNotNull(dateTimeField89);
        org.junit.Assert.assertNotNull(durationField90);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField91);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder93);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder94);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        boolean boolean3 = gJChronology0.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.DurationField durationField4 = gJChronology0.seconds();
        try {
            long long12 = gJChronology0.getDateTimeMillis(14400097, 14400097, (int) '4', 1969, 83, 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a', dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 'a', dateTimeZone16);
        org.joda.time.DateTime dateTime18 = dateTime13.withZoneRetainFields(dateTimeZone16);
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        int int20 = property9.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime22 = property9.setCopy(8);
        int int23 = dateTime22.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeFormatter3.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        java.lang.String str11 = dateTimeZone7.getName((-359999990L));
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 'a', dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 'a', dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime15.minus(readableDuration21);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMinutes((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long30 = dateTimeZone26.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
        org.joda.time.DateTime dateTime32 = dateTime24.toDateTime(dateTimeZone31);
        long long34 = dateTimeZone7.getMillisKeepLocal(dateTimeZone31, 0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter3.withZone(dateTimeZone7);
        org.joda.time.Chronology chronology36 = copticChronology0.withZone(dateTimeZone7);
        java.lang.String str37 = copticChronology0.toString();
        java.lang.String str38 = copticChronology0.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+100:00" + "'", str11.equals("+100:00"));
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-359999990L) + "'", long30 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "CopticChronology[UTC]" + "'", str37.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "CopticChronology[UTC]" + "'", str38.equals("CopticChronology[UTC]"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeFormatter3.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        java.lang.String str11 = dateTimeZone7.getName((-359999990L));
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 'a', dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 'a', dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime15.minus(readableDuration21);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMinutes((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long30 = dateTimeZone26.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
        org.joda.time.DateTime dateTime32 = dateTime24.toDateTime(dateTimeZone31);
        long long34 = dateTimeZone7.getMillisKeepLocal(dateTimeZone31, 0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter3.withZone(dateTimeZone7);
        org.joda.time.Chronology chronology36 = copticChronology0.withZone(dateTimeZone7);
        java.lang.String str37 = copticChronology0.toString();
        org.joda.time.DurationField durationField38 = copticChronology0.halfdays();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+100:00" + "'", str11.equals("+100:00"));
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-359999990L) + "'", long30 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "CopticChronology[UTC]" + "'", str37.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField38);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 360000000, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        int int7 = skipDateTimeField6.getMinimumValue();
        int int9 = skipDateTimeField6.get((-9223309961711998030L));
        long long12 = skipDateTimeField6.set((long) (byte) 100, (int) (byte) 100);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292269056) + "'", int7 == (-292269056));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-292267089) + "'", int9 == (-292267089));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-58981305599900L) + "'", long12 == (-58981305599900L));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        int int7 = skipDateTimeField6.getMinimumValue();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.monthOfYear();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology8, dateTimeField13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField14.getType();
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField14.getAsShortText((int) (short) 0, locale17);
        java.lang.String str19 = skipDateTimeField14.getName();
        long long21 = skipDateTimeField14.roundHalfEven((long) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 'a', dateTimeZone24);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology26.era();
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology26.halfdayOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.millisOfSecond();
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology30);
        java.util.Locale locale34 = null;
        java.lang.String str35 = delegatedDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) monthDay32, (-1), locale34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) monthDay32, 15382789, locale37);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.millisOfSecond();
        org.joda.time.DurationField durationField42 = iSOChronology40.halfdays();
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.millisOfSecond();
        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology43);
        org.joda.time.MonthDay.Property property46 = monthDay45.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology47.millisOfSecond();
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology47);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str51 = monthDay49.toString(dateTimeFormatter50);
        boolean boolean52 = monthDay45.isBefore((org.joda.time.ReadablePartial) monthDay49);
        org.joda.time.ReadablePeriod readablePeriod53 = null;
        org.joda.time.MonthDay monthDay54 = monthDay49.plus(readablePeriod53);
        int[] intArray56 = iSOChronology40.get((org.joda.time.ReadablePartial) monthDay49, 0L);
        java.util.Locale locale58 = null;
        try {
            int[] intArray59 = skipDateTimeField6.set((org.joda.time.ReadablePartial) monthDay32, 1969, intArray56, "", locale58);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292269056) + "'", int7 == (-292269056));
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "weekyear" + "'", str19.equals("weekyear"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 950400000L + "'", long21 == 950400000L);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "-1" + "'", str35.equals("-1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "15382789" + "'", str38.equals("15382789"));
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeFormatter50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "����-W��-�" + "'", str51.equals("����-W��-�"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(intArray56);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, (-32));
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) instant1);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        boolean boolean3 = gJChronology0.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
        org.joda.time.DateTime.Property property11 = dateTime10.year();
        org.joda.time.DateTime dateTime13 = dateTime10.minusYears(19);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfSecond();
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = monthDay24.getFieldType((int) (byte) 0);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21, dateTimeFieldType26);
        long long29 = remainderDateTimeField27.roundHalfCeiling((long) 360000000);
        int int31 = remainderDateTimeField27.get((long) (byte) 100);
        org.joda.time.DurationField durationField32 = remainderDateTimeField27.getRangeDurationField();
        int int34 = remainderDateTimeField27.get((long) 100);
        int int35 = remainderDateTimeField27.getDivisor();
        int int36 = remainderDateTimeField27.getDivisor();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 950400000L + "'", long29 == 950400000L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 12 + "'", int31 == 12);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 12 + "'", int34 == 12);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 19 + "'", int35 == 19);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 19 + "'", int36 == 19);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) (short) -1);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime8.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField13 = iSOChronology12.eras();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.millisOfSecond();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime16 = dateTime10.withFields((org.joda.time.ReadablePartial) monthDay15);
        org.joda.time.DateTime dateTime18 = dateTime16.plusWeeks(0);
        org.joda.time.DateTime.Property property19 = dateTime16.dayOfYear();
        try {
            org.joda.time.DateTime dateTime21 = dateTime16.withMinuteOfHour(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        java.lang.String str3 = gJChronology0.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[UTC]" + "'", str3.equals("GJChronology[UTC]"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("--01-31", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: --01-31");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        long long9 = skipDateTimeField6.roundCeiling((long) (short) -1);
        long long11 = skipDateTimeField6.roundHalfCeiling(1118843467200000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 950400000L + "'", long9 == 950400000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1118844057600000L + "'", long11 == 1118844057600000L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter2.printTo(writer3, (-359999990L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeFormatter3.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        java.lang.String str11 = dateTimeZone7.getName((-359999990L));
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 'a', dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 'a', dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime15.minus(readableDuration21);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMinutes((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long30 = dateTimeZone26.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
        org.joda.time.DateTime dateTime32 = dateTime24.toDateTime(dateTimeZone31);
        long long34 = dateTimeZone7.getMillisKeepLocal(dateTimeZone31, 0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter3.withZone(dateTimeZone7);
        org.joda.time.Chronology chronology36 = copticChronology0.withZone(dateTimeZone7);
        java.lang.String str37 = copticChronology0.toString();
        org.joda.time.Chronology chronology38 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+100:00" + "'", str11.equals("+100:00"));
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-359999990L) + "'", long30 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "CopticChronology[UTC]" + "'", str37.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology38);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfSecond();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = monthDay4.getFieldType((int) (byte) 0);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType6, 15382789, 0, (-1));
        long long12 = offsetDateTimeField10.remainder((-59959627199900L));
        long long14 = offsetDateTimeField10.remainder(83L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1368000100L + "'", long12 == 1368000100L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1555200083L + "'", long14 == 1555200083L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        java.util.Locale locale22 = null;
        int int23 = dividedDateTimeField21.getMaximumTextLength(locale22);
        long long26 = dividedDateTimeField21.add((-125999903L), 100L);
        boolean boolean28 = dividedDateTimeField21.isLeap((long) 1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 59959141200097L + "'", long26 == 59959141200097L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendSecondOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 'a', dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a', dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.withZoneRetainFields(dateTimeZone12);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        int int16 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.toDateTimeISO();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 'a', dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.minuteOfDay();
        org.joda.time.DateTime.Property property23 = dateTime21.millisOfDay();
        org.joda.time.DateTime.Property property24 = dateTime21.dayOfWeek();
        org.joda.time.DateTime dateTime25 = dateTime21.withEarlierOffsetAtOverlap();
        boolean boolean26 = dateTime14.isAfter((org.joda.time.ReadableInstant) dateTime21);
        try {
            org.joda.time.DateTime dateTime30 = dateTime14.withDate(4, 1969, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        java.util.TimeZone timeZone4 = dateTimeZone2.toTimeZone();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.monthOfYear();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology10.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology7, dateTimeField12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder14.appendMonthOfYear((int) (short) 100);
        boolean boolean20 = dateTimeFormatterBuilder19.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.millisOfSecond();
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.MonthDay.Property property24 = monthDay23.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField13, dateTimeFieldType25, 19);
        java.util.Locale locale29 = null;
        int int30 = dividedDateTimeField28.getMaximumTextLength(locale29);
        java.util.Locale locale31 = null;
        int int32 = dividedDateTimeField28.getMaximumTextLength(locale31);
        org.joda.time.DurationField durationField33 = dividedDateTimeField28.getDurationField();
        int int34 = dateTime3.get((org.joda.time.DateTimeField) dividedDateTimeField28);
        org.joda.time.DateTime dateTime36 = dateTime3.plusWeeks((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 8 + "'", int32 == 8);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 103 + "'", int34 == 103);
        org.junit.Assert.assertNotNull(dateTime36);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        long long9 = skipDateTimeField6.roundHalfCeiling((long) 1439);
        int int11 = skipDateTimeField6.get(0L);
        long long13 = skipDateTimeField6.roundHalfCeiling((-292269056L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 950400000L + "'", long9 == 950400000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 950400000L + "'", long13 == 950400000L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("AM", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"AM/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        java.lang.String str12 = unsupportedDateTimeField11.toString();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.MonthDay.Property property16 = monthDay15.monthOfYear();
        org.joda.time.MonthDay monthDay18 = property16.addToCopy(1970);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay20 = monthDay18.minus(readablePeriod19);
        org.joda.time.MonthDay monthDay22 = monthDay20.withMonthOfYear(4);
        try {
            int int23 = unsupportedDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) monthDay22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June" + "'", str4.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDateTimeField" + "'", str12.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.LocalTime localTime9 = dateTime8.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds(0);
        int int12 = dateTime11.getWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime11.minusHours((int) '#');
        org.joda.time.DateTime dateTime16 = dateTime11.plusDays((int) 'a');
        int int17 = dateTime16.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.weekyears();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 197);
        boolean boolean5 = julianChronology0.equals((java.lang.Object) dateTimeFormatter4);
        int int6 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        try {
            int[] intArray11 = julianChronology0.get(readablePeriod8, 0L, (long) 1009);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.String str2 = dateTimeFormatter0.print((long) 100);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.monthOfYear();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology7.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology4, dateTimeField9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = skipDateTimeField10.getType();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((int) (short) 0, locale13);
        java.lang.String str15 = skipDateTimeField10.getName();
        long long17 = skipDateTimeField10.roundHalfEven((long) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 'a', dateTimeZone20);
        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology22.era();
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology22.halfdayOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.millisOfSecond();
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology26);
        java.util.Locale locale30 = null;
        java.lang.String str31 = delegatedDateTimeField25.getAsShortText((org.joda.time.ReadablePartial) monthDay28, (-1), locale30);
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) monthDay28, 15382789, locale33);
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadablePartial) monthDay28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970W013" + "'", str2.equals("1970W013"));
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "weekyear" + "'", str15.equals("weekyear"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 950400000L + "'", long17 == 950400000L);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(buddhistChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "-1" + "'", str31.equals("-1"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "15382789" + "'", str34.equals("15382789"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        int int14 = unsupportedDateTimeField11.getDifference(0L, (-359999903L));
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField11.getRangeDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.eras();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 'a', dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 'a', dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime21.withZoneRetainFields(dateTimeZone24);
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.DateTime dateTime28 = dateTime21.minus(readableDuration27);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField31 = iSOChronology30.eras();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.millisOfSecond();
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology30);
        org.joda.time.DateTime dateTime34 = dateTime28.withFields((org.joda.time.ReadablePartial) monthDay33);
        int[] intArray36 = iSOChronology16.get((org.joda.time.ReadablePartial) monthDay33, (-62137152000001L));
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.MonthDay monthDay38 = monthDay33.minus(readablePeriod37);
        int[] intArray39 = null;
        try {
            int int40 = unsupportedDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) monthDay38, intArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June" + "'", str4.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(monthDay38);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(1368000100L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("--06-15");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"--06-15\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        java.util.Locale locale9 = null;
        long long10 = skipDateTimeField6.set((long) 8, "32", locale9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfSecond();
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.monthOfYear();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology17.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology14, dateTimeField19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField20.getType();
        java.util.Locale locale23 = null;
        java.lang.String str24 = skipDateTimeField20.getAsShortText((int) (short) 0, locale23);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology11, (org.joda.time.DateTimeField) skipDateTimeField20);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.millisOfSecond();
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology26);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipUndoDateTimeField25.getAsShortText((org.joda.time.ReadablePartial) monthDay28, (int) 'a', locale30);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField34 = iSOChronology33.eras();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.millisOfSecond();
        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology37.millisOfSecond();
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology37);
        org.joda.time.DateTimeField[] dateTimeFieldArray40 = monthDay39.getFields();
        boolean boolean41 = monthDay36.isBefore((org.joda.time.ReadablePartial) monthDay39);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipUndoDateTimeField25.getAsShortText((org.joda.time.ReadablePartial) monthDay39, 197, locale43);
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipDateTimeField6.getAsText((org.joda.time.ReadablePartial) monthDay39, 15382790, locale46);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61127135999992L) + "'", long10 == (-61127135999992L));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0" + "'", str24.equals("0"));
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "97" + "'", str31.equals("97"));
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeFieldArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "197" + "'", str44.equals("197"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "15382790" + "'", str47.equals("15382790"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfSecond();
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = monthDay24.getFieldType((int) (byte) 0);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21, dateTimeFieldType26);
        long long29 = remainderDateTimeField27.roundHalfCeiling((long) 360000000);
        java.util.Locale locale31 = null;
        java.lang.String str32 = remainderDateTimeField27.getAsText((long) 8, locale31);
        boolean boolean33 = remainderDateTimeField27.isSupported();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 950400000L + "'", long29 == 950400000L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "12" + "'", str32.equals("12"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        int int14 = unsupportedDateTimeField11.getDifference(0L, (-359999903L));
        try {
            int int16 = unsupportedDateTimeField11.getLeapAmount((long) (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January" + "'", str4.equals("January"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        java.lang.String str2 = dateTimeZone1.getID();
        java.lang.String str4 = dateTimeZone1.getShortName((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        boolean boolean10 = dateTime8.isAfter((-1L));
        org.joda.time.DateTime dateTime12 = dateTime8.minusMillis(0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime8, 1);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.millisOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+100:00" + "'", str2.equals("+100:00"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+100:00" + "'", str4.equals("+100:00"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        jodaTimePermission1.checkGuard((java.lang.Object) 1439);
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str7 = illegalFieldValueException6.getIllegalValueAsString();
        jodaTimePermission1.checkGuard((java.lang.Object) illegalFieldValueException6);
        jodaTimePermission1.checkGuard((java.lang.Object) 100);
        org.joda.time.JodaTimePermission jodaTimePermission12 = new org.joda.time.JodaTimePermission("hi!");
        jodaTimePermission12.checkGuard((java.lang.Object) 1439);
        org.joda.time.JodaTimePermission jodaTimePermission16 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str17 = jodaTimePermission16.getActions();
        boolean boolean18 = jodaTimePermission12.implies((java.security.Permission) jodaTimePermission16);
        boolean boolean19 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission12);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.millisOfSecond();
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.String str16 = monthDay14.toString(dateTimeFormatter15);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.monthOfYear();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology17.weekyear();
        java.lang.String str20 = julianChronology17.toString();
        org.joda.time.DurationField durationField21 = julianChronology17.seconds();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 'a', dateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 'a', dateTimeZone28);
        org.joda.time.DateTime dateTime30 = dateTime25.withZoneRetainFields(dateTimeZone28);
        org.joda.time.LocalTime localTime31 = dateTime30.toLocalTime();
        int[] intArray33 = julianChronology17.get((org.joda.time.ReadablePartial) localTime31, (long) 6);
        try {
            int int34 = unsupportedDateTimeField11.getMaximumValue((org.joda.time.ReadablePartial) monthDay14, intArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January" + "'", str4.equals("January"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "����-W��-�" + "'", str16.equals("����-W��-�"));
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "JulianChronology[UTC]" + "'", str20.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localTime31);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 'a', dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 'a', dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime5.withZoneRetainFields(dateTimeZone8);
        org.joda.time.LocalTime localTime11 = dateTime10.toLocalTime();
        org.joda.time.DateTime dateTime13 = dateTime10.plusSeconds(0);
        int int14 = dateTime10.getCenturyOfEra();
        org.joda.time.DateTime.Property property15 = dateTime10.yearOfEra();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfSecond();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = monthDay4.getFieldType((int) (byte) 0);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType6, 15382789, 0, (-1));
        int int13 = offsetDateTimeField10.getDifference((long) (byte) 10, (-292269056L));
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        java.lang.String str18 = property17.getName();
        int int19 = property17.get();
        java.util.Locale locale20 = null;
        java.lang.String str21 = property17.getAsShortText(locale20);
        int int22 = property17.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay24 = property17.setCopy(10);
        int int25 = offsetDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) monthDay24);
        int int26 = offsetDateTimeField10.getMinimumValue();
        int int27 = offsetDateTimeField10.getOffset();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "monthOfYear" + "'", str18.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Jan" + "'", str21.equals("Jan"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15382790 + "'", int25 == 15382790);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15382790 + "'", int26 == 15382790);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15382789 + "'", int27 == 15382789);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        int int6 = property3.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DurationField durationField10 = iSOChronology8.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField10);
        java.lang.String str12 = unsupportedDateTimeField11.toString();
        org.joda.time.DurationField durationField13 = unsupportedDateTimeField11.getDurationField();
        java.util.Locale locale15 = null;
        try {
            java.lang.String str16 = unsupportedDateTimeField11.getAsText((-125999903L), locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January" + "'", str4.equals("January"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDateTimeField" + "'", str12.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime3.minus(readableDuration9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMinutes((int) 'a');
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, (-1));
        int int16 = dateTime15.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long5 = dateTimeZone1.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        int int8 = dateTimeZone6.getOffsetFromLocal(0L);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        long long12 = dateTimeZone6.convertLocalToUTC((-100L), true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-359999990L) + "'", long5 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 360000000 + "'", int8 == 360000000);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-360000100L) + "'", long12 == (-360000100L));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField6.getType();
        long long9 = skipDateTimeField6.roundHalfCeiling((long) 1439);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.millisOfSecond();
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.MonthDay.Property property13 = monthDay12.monthOfYear();
        java.lang.String str14 = property13.getName();
        int int15 = property13.get();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property13.getAsShortText(locale16);
        int int18 = property13.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay20 = property13.setCopy(10);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipDateTimeField6.getAsText((org.joda.time.ReadablePartial) monthDay20, (int) (byte) 1, locale22);
        int int25 = skipDateTimeField6.getMinimumValue((-292269056L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 950400000L + "'", long9 == 950400000L);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "monthOfYear" + "'", str14.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Jan" + "'", str17.equals("Jan"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1" + "'", str23.equals("1"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292269054) + "'", int25 == (-292269054));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str5 = jodaTimePermission4.getActions();
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.millisOfSecond();
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.monthOfYear();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology13.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology10, dateTimeField15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = skipDateTimeField16.getType();
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField16.getAsShortText((int) (short) 0, locale19);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeField) skipDateTimeField16);
        boolean boolean22 = jodaTimePermission4.equals((java.lang.Object) iSOChronology7);
        org.joda.time.DurationField durationField23 = iSOChronology7.centuries();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology4.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField6);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField6);
        java.lang.String str10 = skipUndoDateTimeField8.getAsShortText((-105278997312000001L));
        java.lang.String str11 = skipUndoDateTimeField8.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-3334121" + "'", str10.equals("-3334121"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DateTimeField[weekyear]" + "'", str11.equals("DateTimeField[weekyear]"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        jodaTimePermission1.checkGuard((java.lang.Object) 1439);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.hourOfDay();
        jodaTimePermission1.checkGuard((java.lang.Object) julianChronology4);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology4);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 'a', dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 'a', dateTimeZone14);
        org.joda.time.DateTime dateTime16 = dateTime11.withZoneRetainFields(dateTimeZone14);
        boolean boolean17 = dateTime11.isBeforeNow();
        org.joda.time.DateTime dateTime18 = monthDay7.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        int int19 = dateTime18.getDayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 'a', dateTimeZone22);
        org.joda.time.DateTime.Property property24 = dateTime23.minuteOfDay();
        org.joda.time.DateTime.Property property25 = dateTime23.millisOfDay();
        org.joda.time.DateTime.Property property26 = dateTime23.dayOfWeek();
        org.joda.time.DateTime dateTime27 = dateTime23.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime29 = dateTime23.withCenturyOfEra(100);
        org.joda.time.DateTime dateTime31 = dateTime29.plusSeconds(197);
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime18, (org.joda.time.ReadableInstant) dateTime31);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(chronology32);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        java.lang.String str7 = property6.getAsString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.Instant instant3 = instant1.minus((long) (byte) 0);
        org.joda.time.Instant instant5 = instant1.minus((-62167190822000L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.LocalTime localTime9 = dateTime8.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds(0);
        int int12 = dateTime11.getWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime11.minusHours((int) '#');
        long long15 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime14);
        int int16 = dateTime14.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-125999903L) + "'", long15 == (-125999903L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        java.util.Locale locale22 = null;
        int int23 = dividedDateTimeField21.getMaximumTextLength(locale22);
        java.util.Locale locale24 = null;
        int int25 = dividedDateTimeField21.getMaximumTextLength(locale24);
        int int26 = dividedDateTimeField21.getDivisor();
        long long29 = dividedDateTimeField21.add((-14400000L), 0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 8 + "'", int25 == 8);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-14400000L) + "'", long29 == (-14400000L));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(1970, false);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.monthOfYear();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology10.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology7, dateTimeField12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder14.appendMonthOfYear((int) (short) 100);
        boolean boolean20 = dateTimeFormatterBuilder19.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.millisOfSecond();
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.MonthDay.Property property24 = monthDay23.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField13, dateTimeFieldType25, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder3.appendFixedSignedDecimal(dateTimeFieldType25, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder30.appendTimeZoneOffset("CopticChronology[UTC]", true, 9, 999);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 'a', dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime5.minuteOfDay();
        org.joda.time.DateTime.Property property7 = dateTime5.millisOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.dayOfWeek();
        org.joda.time.DateTime dateTime10 = property8.addToCopy((long) (short) -1);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTimeISO();
        int int14 = dateTimeFormatter1.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime11, "����-W��-�", 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter1.withDefaultYear((int) (short) 0);
        try {
            org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.parse("+100:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+100:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "103");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra(0);
        org.joda.time.DateTime dateTime8 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        java.lang.String str11 = property9.getAsShortText();
        org.joda.time.DateTime dateTime13 = property9.addToCopy(14400097);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendSecondOfMinute((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 'a', dateTimeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
        java.lang.String str8 = dateTimeZone4.getName((-359999990L));
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 'a', dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 'a', dateTimeZone15);
        org.joda.time.DateTime dateTime17 = dateTime12.withZoneRetainFields(dateTimeZone15);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime19 = dateTime12.minus(readableDuration18);
        org.joda.time.DateTime dateTime21 = dateTime19.minusMinutes((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long27 = dateTimeZone23.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.DateTime dateTime29 = dateTime21.toDateTime(dateTimeZone28);
        long long31 = dateTimeZone4.getMillisKeepLocal(dateTimeZone28, 0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now(dateTimeZone4);
        long long37 = dateTimeZone4.convertLocalToUTC(10L, false, (long) ' ');
        java.lang.String str38 = dateTimeZone4.getID();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+100:00" + "'", str8.equals("+100:00"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-359999990L) + "'", long27 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-359999990L) + "'", long37 == (-359999990L));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "+100:00" + "'", str38.equals("+100:00"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        long long4 = dateTimeZone1.convertLocalToUTC((long) 2, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-8L) + "'", long4 == (-8L));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        int int24 = dividedDateTimeField21.getDifference((long) 19, (long) (-10));
        org.joda.time.DurationField durationField25 = dividedDateTimeField21.getDurationField();
        boolean boolean26 = dividedDateTimeField21.isLenient();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.millisOfSecond();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType9, 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendTimeZoneName();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = monthDay15.getFieldType((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType17);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.millisOfSecond();
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology19);
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = julianChronology22.monthOfYear();
        org.joda.time.DateTimeField dateTimeField24 = julianChronology22.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology19, dateTimeField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipDateTimeField25.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder11.appendDecimal(dateTimeFieldType26, 100, (-292269054));
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendMonthOfYear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendYearOfCentury(0, (-292267089));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology4.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField6);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField6);
        java.lang.String str10 = skipUndoDateTimeField8.getAsShortText((-105278997312000001L));
        int int12 = skipUndoDateTimeField8.getMinimumValue((long) (byte) -1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-3334121" + "'", str10.equals("-3334121"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292269054) + "'", int12 == (-292269054));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long5 = dateTimeZone1.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        int int8 = dateTimeZone6.getOffsetFromLocal(0L);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        try {
            int[] intArray13 = julianChronology9.get(readablePeriod10, (-105278997312000001L), 59959141200097L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-359999990L) + "'", long5 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 360000000 + "'", int8 == 360000000);
        org.junit.Assert.assertNotNull(julianChronology9);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.LocalTime localTime9 = dateTime8.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds(0);
        int int12 = dateTime8.getCenturyOfEra();
        boolean boolean14 = dateTime8.isBefore((long) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.weekOfWeekyear();
        org.joda.time.Chronology chronology4 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.era();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology4.halfdayOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        int int9 = delegatedDateTimeField7.getMaximumValue((-1L));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "(\"org.joda.time.JodaTimePermission\" \"hi!\")");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("103", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"103\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 'a', dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 'a', dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 'a', dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 'a', dateTimeZone16);
        org.joda.time.DateTime dateTime18 = dateTime13.withZoneRetainFields(dateTimeZone16);
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        int int20 = property9.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.LocalTime localTime21 = dateTime18.toLocalTime();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(localTime21);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property3.getFieldType();
        int int5 = property3.getMaximumValue();
        org.joda.time.DateTimeField dateTimeField6 = property3.getField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekyear();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.DurationField durationField4 = julianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 'a', dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 'a', dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone11);
        org.joda.time.LocalTime localTime14 = dateTime13.toLocalTime();
        int[] intArray16 = julianChronology0.get((org.joda.time.ReadablePartial) localTime14, (long) 6);
        org.joda.time.DurationField durationField17 = julianChronology0.millis();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localTime14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology4.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField6);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField6);
        long long10 = skipUndoDateTimeField8.roundHalfFloor((long) (short) 0);
        long long13 = skipUndoDateTimeField8.add((long) 1970, (long) (-292269056));
        int int15 = skipUndoDateTimeField8.get((-105278997312000001L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 950400000L + "'", long10 == 950400000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-9223309961711998030L) + "'", long13 == (-9223309961711998030L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-3334121) + "'", int15 == (-3334121));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.millisOfSecond();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType9, 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder13.appendTimeZoneOffset("", false, 4, (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(1970, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18, 19);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfSecond();
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = monthDay24.getFieldType((int) (byte) 0);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21, dateTimeFieldType26);
        long long30 = remainderDateTimeField27.getDifferenceAsLong((long) ' ', (long) (-15382582));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 'a', dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 'a', dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime5.withZoneRetainFields(dateTimeZone8);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime5.minus(readableDuration11);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField15 = iSOChronology14.eras();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.millisOfSecond();
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(207L, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime18 = dateTime12.withFields((org.joda.time.ReadablePartial) monthDay17);
        int[] intArray20 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay17, (-62137152000001L));
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 'a', dateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 'a', dateTimeZone27);
        org.joda.time.DateTime dateTime29 = dateTime24.withZoneRetainFields(dateTimeZone27);
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime31 = dateTime24.minus(readableDuration30);
        org.joda.time.DateTime dateTime33 = dateTime31.minusMinutes((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        long long39 = dateTimeZone35.convertLocalToUTC((long) 10, false, (long) (-1));
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeUtils.getZone(dateTimeZone35);
        org.joda.time.DateTime dateTime41 = dateTime33.toDateTime(dateTimeZone40);
        org.joda.time.DateTime dateTime42 = monthDay17.toDateTime((org.joda.time.ReadableInstant) dateTime41);
        int int43 = dateTime42.getSecondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-359999990L) + "'", long39 == (-359999990L));
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }
}

