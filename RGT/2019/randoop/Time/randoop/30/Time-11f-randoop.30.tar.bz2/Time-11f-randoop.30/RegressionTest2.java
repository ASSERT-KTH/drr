import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = org.joda.time.Period.minutes((int) (byte) 1);
        int int4 = period3.getMillis();
        org.joda.time.Period period6 = period3.plusSeconds((int) (byte) 100);
        int[] intArray8 = iSOChronology1.get((org.joda.time.ReadablePeriod) period3, 100L);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.months();
        boolean boolean12 = periodType10.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType13 = periodType10.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 100, periodType13, (org.joda.time.Chronology) iSOChronology14);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) iSOChronology14);
        org.joda.time.DurationField durationField17 = iSOChronology14.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology14.dayOfWeek();
        org.joda.time.Period period19 = new org.joda.time.Period((long) 52, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DurationField durationField20 = iSOChronology14.hours();
        long long24 = iSOChronology14.add(4147200000000000L, (long) 11, 52);
        org.joda.time.chrono.LenientChronology lenientChronology25 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology14);
        java.lang.String str26 = lenientChronology25.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 4147200000000572L + "'", long24 == 4147200000000572L);
        org.junit.Assert.assertNotNull(lenientChronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str26.equals("LenientChronology[ISOChronology[UTC]]"));
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.months();
        boolean boolean5 = periodType3.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType6 = periodType3.withMillisRemoved();
        org.joda.time.Period period7 = new org.joda.time.Period(10L, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withMinutesRemoved();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) -1, (java.lang.Number) 1L, (java.lang.Number) (short) 100);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        illegalFieldValueException4.prependMessage("org.joda.time.IllegalInstantException: (\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value -1 for  must be in the range [1,100]\")");
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertNull(dateTimeFieldType6);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.era();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.centuryOfEra();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 32, 115196400000L, periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology3.dayOfMonth();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.joda.time.Period period2 = new org.joda.time.Period((long) '#', (long) (short) 1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationFrom(readableInstant3);
        long long5 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration4, readableInstant6);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-34L) + "'", long5 == (-34L));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        boolean boolean32 = scaledDurationField31.isSupported();
        long long35 = scaledDurationField31.add(2440588L, (int) (byte) 0);
        long long38 = scaledDurationField31.getDifferenceAsLong((-1152000000L), 100L);
        long long41 = scaledDurationField31.getValueAsLong((long) ' ', (long) (short) 100);
        long long44 = scaledDurationField31.getValueAsLong(0L, 2440581L);
        long long45 = scaledDurationField31.getUnitMillis();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2440588L + "'", long35 == 2440588L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-1L) + "'", long38 == (-1L));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1152000000L + "'", long45 == 1152000000L);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfYear();
        java.lang.Object obj4 = null;
        boolean boolean5 = iSOChronology2.equals(obj4);
        org.joda.time.DurationField durationField6 = iSOChronology2.eras();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-1));
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField10.getAsText((long) (short) 0, locale12);
        long long15 = offsetDateTimeField10.roundCeiling((long) (byte) 10);
        java.lang.String str16 = offsetDateTimeField10.getName();
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField10.getMaximumTextLength(locale17);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfYear();
        java.lang.Object obj21 = null;
        boolean boolean22 = iSOChronology19.equals(obj21);
        org.joda.time.DurationField durationField23 = iSOChronology19.eras();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology19.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology19.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (-1));
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField27.getAsText((long) (short) 0, locale29);
        int int32 = offsetDateTimeField27.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField27.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10, dateTimeFieldType33);
        long long36 = zeroIsMaxDateTimeField34.remainder((-1104566400001L));
        boolean boolean38 = zeroIsMaxDateTimeField34.isLeap((long) 32);
        org.joda.time.ReadablePartial readablePartial39 = null;
        int int40 = zeroIsMaxDateTimeField34.getMaximumValue(readablePartial39);
        long long42 = zeroIsMaxDateTimeField34.roundHalfEven(2440587L);
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.dayOfYear();
        java.lang.Object obj45 = null;
        boolean boolean46 = iSOChronology43.equals(obj45);
        org.joda.time.DurationField durationField47 = iSOChronology43.eras();
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology43.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology43.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, (-1));
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField51.getAsText((long) (short) 0, locale53);
        long long57 = offsetDateTimeField51.add((-1104537600001L), (int) (byte) 1);
        int int59 = offsetDateTimeField51.getLeapAmount(60001L);
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = offsetDateTimeField51.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType60, "-1");
        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType60, "PeriodType[YearDayTime]");
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType60, (int) 'a', 52, (int) (byte) 100);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField34, dateTimeFieldType60, 64);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField72 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType60, 125999965);
        int int73 = remainderDateTimeField72.getMinimumValue();
        int int74 = remainderDateTimeField72.getMaximumValue();
        long long76 = remainderDateTimeField72.roundHalfCeiling((long) 320);
        long long79 = remainderDateTimeField72.add(3600970L, 55);
        int int81 = remainderDateTimeField72.get(1561780800000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "11" + "'", str13.equals("11"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3600000L + "'", long15 == 3600000L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "clockhourOfHalfday" + "'", str16.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "11" + "'", str30.equals("11"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 11 + "'", int32 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 3599999L + "'", long36 == 3599999L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 12 + "'", int40 == 12);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 3600000L + "'", long42 == 3600000L);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "11" + "'", str54.equals("11"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-1104534000001L) + "'", long57 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 125999964 + "'", int74 == 125999964);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 0L + "'", long76 == 0L);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 201600970L + "'", long79 == 201600970L);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 4 + "'", int81 == 4);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 1191168000000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long14 = offsetDateTimeField8.add((-1104537600001L), (int) (byte) 1);
        int int16 = offsetDateTimeField8.getLeapAmount(60001L);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int int18 = offsetDateTimeField8.getMinimumValue(readablePartial17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField8.getType();
        long long21 = offsetDateTimeField8.roundHalfFloor(10L);
        java.lang.String str23 = offsetDateTimeField8.getAsText(73727967681L);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField8.getMinimumValue(readablePartial24);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1104534000001L) + "'", long14 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "6" + "'", str23.equals("6"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        long long34 = scaledDurationField31.getDifferenceAsLong((long) 52, (long) 11);
        long long36 = scaledDurationField31.getMillis(0L);
        long long38 = scaledDurationField31.getValueAsLong((-3599999L));
        java.lang.String str39 = scaledDurationField31.toString();
        int int42 = scaledDurationField31.getDifference((-184357857600000L), 1560630012727L);
        java.lang.String str43 = scaledDurationField31.toString();
        long long46 = scaledDurationField31.getDifferenceAsLong(126000002L, 11L);
        org.joda.time.DurationFieldType durationFieldType47 = scaledDurationField31.getType();
        long long49 = scaledDurationField31.getMillis(45);
        long long51 = scaledDurationField31.getValueAsLong(100257048000000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DurationField[years]" + "'", str39.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-161387) + "'", int42 == (-161387));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DurationField[years]" + "'", str43.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 51840000000L + "'", long49 == 51840000000L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 87028L + "'", long51 == 87028L);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText((long) (short) 1, locale15);
        long long18 = offsetDateTimeField8.roundFloor((-1L));
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfYear();
        java.lang.Object obj21 = null;
        boolean boolean22 = iSOChronology19.equals(obj21);
        org.joda.time.DurationField durationField23 = iSOChronology19.eras();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology19.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology19.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (-1));
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField27.getAsText((long) (short) 0, locale29);
        long long33 = offsetDateTimeField27.add((-1104537600001L), (int) (byte) 1);
        int int35 = offsetDateTimeField27.getLeapAmount(60001L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField27.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField27.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType38);
        long long41 = zeroIsMaxDateTimeField39.roundHalfCeiling((long) (short) 1);
        org.joda.time.ReadablePartial readablePartial42 = null;
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.dayOfYear();
        java.lang.Object obj45 = null;
        boolean boolean46 = iSOChronology43.equals(obj45);
        org.joda.time.DurationField durationField47 = iSOChronology43.eras();
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology43.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology43.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, (-1));
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField51.getAsText((long) (short) 0, locale53);
        long long56 = offsetDateTimeField51.roundCeiling((long) (byte) 10);
        java.lang.String str57 = offsetDateTimeField51.getName();
        java.util.Locale locale58 = null;
        int int59 = offsetDateTimeField51.getMaximumTextLength(locale58);
        org.joda.time.chrono.ISOChronology iSOChronology60 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology60.dayOfYear();
        java.lang.Object obj62 = null;
        boolean boolean63 = iSOChronology60.equals(obj62);
        org.joda.time.DurationField durationField64 = iSOChronology60.eras();
        org.joda.time.DateTimeField dateTimeField65 = iSOChronology60.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField66 = iSOChronology60.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, (-1));
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField68.getAsText((long) (short) 0, locale70);
        int int73 = offsetDateTimeField68.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType74 = offsetDateTimeField68.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField75 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField51, dateTimeFieldType74);
        long long77 = zeroIsMaxDateTimeField75.remainder((-1104566400001L));
        boolean boolean79 = zeroIsMaxDateTimeField75.isLeap((long) 32);
        org.joda.time.ReadablePartial readablePartial80 = null;
        org.joda.time.chrono.ISOChronology iSOChronology81 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period83 = org.joda.time.Period.minutes((int) (byte) 1);
        int int84 = period83.getMillis();
        org.joda.time.Period period86 = period83.plusSeconds((int) (byte) 100);
        int[] intArray88 = iSOChronology81.get((org.joda.time.ReadablePeriod) period83, 100L);
        int int89 = zeroIsMaxDateTimeField75.getMinimumValue(readablePartial80, intArray88);
        int int90 = zeroIsMaxDateTimeField39.getMaximumValue(readablePartial42, intArray88);
        org.joda.time.ReadablePartial readablePartial91 = null;
        int int92 = zeroIsMaxDateTimeField39.getMinimumValue(readablePartial91);
        int int94 = zeroIsMaxDateTimeField39.getMaximumValue(2440587L);
        int int96 = zeroIsMaxDateTimeField39.get((long) 125999964);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3600000L) + "'", long18 == (-3600000L));
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "11" + "'", str30.equals("11"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1104534000001L) + "'", long33 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "11" + "'", str54.equals("11"));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 3600000L + "'", long56 == 3600000L);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "clockhourOfHalfday" + "'", str57.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
        org.junit.Assert.assertNotNull(iSOChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(durationField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "11" + "'", str71.equals("11"));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 11 + "'", int73 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType74);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 3599999L + "'", long77 == 3599999L);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(iSOChronology81);
        org.junit.Assert.assertNotNull(period83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(period86);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 12 + "'", int90 == 12);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 12 + "'", int94 == 12);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 9 + "'", int96 == 9);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.weeks();
        java.lang.String str5 = iSOChronology0.toString();
        org.joda.time.Period period7 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period9 = period7.withMonths((int) (short) 10);
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period7, (long) 4);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.dayOfMonth();
        org.joda.time.Chronology chronology13 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType1 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withDaysRemoved();
        org.joda.time.PeriodType periodType4 = periodType1.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("0", "P10MT1M", 64, (int) ' ');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        int int9 = period8.getMillis();
        org.joda.time.Period period11 = period8.plusSeconds((int) (byte) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePeriod) period8, 100L);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.months();
        boolean boolean17 = periodType15.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType18 = periodType15.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, periodType18, (org.joda.time.Chronology) iSOChronology19);
        boolean boolean21 = iSOChronology6.equals((java.lang.Object) iSOChronology19);
        org.joda.time.DurationField durationField22 = iSOChronology6.hours();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology6.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology6.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology6.dayOfWeek();
        boolean boolean26 = cachedDateTimeZone5.equals((java.lang.Object) iSOChronology6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfYear();
        java.lang.Object obj4 = null;
        boolean boolean5 = iSOChronology2.equals(obj4);
        org.joda.time.DurationField durationField6 = iSOChronology2.eras();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (-1));
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField10.getAsText((long) (short) 0, locale12);
        long long15 = offsetDateTimeField10.roundCeiling((long) (byte) 10);
        java.lang.String str16 = offsetDateTimeField10.getName();
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField10.getMaximumTextLength(locale17);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfYear();
        java.lang.Object obj21 = null;
        boolean boolean22 = iSOChronology19.equals(obj21);
        org.joda.time.DurationField durationField23 = iSOChronology19.eras();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology19.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology19.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (-1));
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField27.getAsText((long) (short) 0, locale29);
        int int32 = offsetDateTimeField27.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField27.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10, dateTimeFieldType33);
        long long36 = zeroIsMaxDateTimeField34.remainder((-1104566400001L));
        boolean boolean38 = zeroIsMaxDateTimeField34.isLeap((long) 32);
        org.joda.time.ReadablePartial readablePartial39 = null;
        int int40 = zeroIsMaxDateTimeField34.getMaximumValue(readablePartial39);
        long long42 = zeroIsMaxDateTimeField34.roundHalfEven(2440587L);
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.dayOfYear();
        java.lang.Object obj45 = null;
        boolean boolean46 = iSOChronology43.equals(obj45);
        org.joda.time.DurationField durationField47 = iSOChronology43.eras();
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology43.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology43.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, (-1));
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField51.getAsText((long) (short) 0, locale53);
        long long57 = offsetDateTimeField51.add((-1104537600001L), (int) (byte) 1);
        int int59 = offsetDateTimeField51.getLeapAmount(60001L);
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = offsetDateTimeField51.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType60, "-1");
        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType60, "PeriodType[YearDayTime]");
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType60, (int) 'a', 52, (int) (byte) 100);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField34, dateTimeFieldType60, 64);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField72 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType60, 125999965);
        int int73 = remainderDateTimeField72.getMinimumValue();
        int int74 = remainderDateTimeField72.getMaximumValue();
        long long76 = remainderDateTimeField72.roundHalfCeiling((long) 320);
        long long79 = remainderDateTimeField72.addWrapField((-210858120000000L), (-1));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "11" + "'", str13.equals("11"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3600000L + "'", long15 == 3600000L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "clockhourOfHalfday" + "'", str16.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "11" + "'", str30.equals("11"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 11 + "'", int32 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 3599999L + "'", long36 == 3599999L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 12 + "'", int40 == 12);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 3600000L + "'", long42 == 3600000L);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "11" + "'", str54.equals("11"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-1104534000001L) + "'", long57 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 125999964 + "'", int74 == 125999964);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 0L + "'", long76 == 0L);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + (-210858123600000L) + "'", long79 == (-210858123600000L));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.minutes((int) (byte) 1);
        int int3 = period2.getMillis();
        org.joda.time.Period period5 = period2.plusSeconds((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period5.toDurationFrom(readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant8);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.months();
        boolean boolean13 = periodType11.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType14 = periodType11.withMillisRemoved();
        org.joda.time.Period period15 = new org.joda.time.Period(10L, periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7, periodType16);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
    }
}

